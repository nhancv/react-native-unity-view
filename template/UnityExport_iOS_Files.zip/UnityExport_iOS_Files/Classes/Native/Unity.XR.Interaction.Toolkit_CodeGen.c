﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Boolean InputHelpers::IsPressed(UnityEngine.XR.InputDevice,InputHelpers_Button,System.Boolean&,System.Single)
extern void InputHelpers_IsPressed_m69EE95AAE336BC130A2C550B5B7B9D5A9EB1AF8D ();
// 0x00000002 System.Void InputHelpers::.cctor()
extern void InputHelpers__cctor_mC787541B02D9D72463B96880C6BC36EF3D89ED58 ();
// 0x00000003 UnityEngine.XR.Interaction.Toolkit.XRController_UpdateType UnityEngine.XR.Interaction.Toolkit.XRController::get_updateTrackingType()
extern void XRController_get_updateTrackingType_m442E096CE62E4C2C6669EF3B9E6FC7D1E0239B7F ();
// 0x00000004 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_updateTrackingType(UnityEngine.XR.Interaction.Toolkit.XRController_UpdateType)
extern void XRController_set_updateTrackingType_m609B44DEE474E9C1110F20D8069683C733CFEB14 ();
// 0x00000005 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::get_enableInputTracking()
extern void XRController_get_enableInputTracking_m330812B762F1E9220728C29CB40F75F6D3227622 ();
// 0x00000006 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_enableInputTracking(System.Boolean)
extern void XRController_set_enableInputTracking_mA16289953E4AC9FF8D2EE1301C0D6F00A22F57F7 ();
// 0x00000007 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::get_enableInputActions()
extern void XRController_get_enableInputActions_m3514156F2D487C463A4D93C7356CC1E7997EA62D ();
// 0x00000008 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_enableInputActions(System.Boolean)
extern void XRController_set_enableInputActions_m96F49261E38D16C758F245AF671349A1131B82BD ();
// 0x00000009 UnityEngine.Experimental.XR.Interaction.BasePoseProvider UnityEngine.XR.Interaction.Toolkit.XRController::get_poseProvider()
extern void XRController_get_poseProvider_m71A04819C3B3E7C4C2E35DCC33329127B8A8E442 ();
// 0x0000000A System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_poseProvider(UnityEngine.Experimental.XR.Interaction.BasePoseProvider)
extern void XRController_set_poseProvider_m432B63A237FA388CE402493CB563B9812FF2C9E9 ();
// 0x0000000B UnityEngine.XR.XRNode UnityEngine.XR.Interaction.Toolkit.XRController::get_controllerNode()
extern void XRController_get_controllerNode_mFA1CF53ED1088BB6617B832D687A76C4E3C20922 ();
// 0x0000000C System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_controllerNode(UnityEngine.XR.XRNode)
extern void XRController_set_controllerNode_m669AC504D2FF1217B9EC5782636FDB09C0D59746 ();
// 0x0000000D InputHelpers_Button UnityEngine.XR.Interaction.Toolkit.XRController::get_selectUsage()
extern void XRController_get_selectUsage_m73183495F3D06EE88BFF5AF1A571A8ABD2C41440 ();
// 0x0000000E System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_selectUsage(InputHelpers_Button)
extern void XRController_set_selectUsage_mF007FBB8D54077062459F3B5D41D44D3992F926D ();
// 0x0000000F InputHelpers_Button UnityEngine.XR.Interaction.Toolkit.XRController::get_activateUsage()
extern void XRController_get_activateUsage_mA728B9B5780E0D746D38A059CF3AEEF26509CA2E ();
// 0x00000010 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_activateUsage(InputHelpers_Button)
extern void XRController_set_activateUsage_m3E918B789B5EA5D6D3B35B5F4ECDE39F8C1EFB2F ();
// 0x00000011 InputHelpers_Button UnityEngine.XR.Interaction.Toolkit.XRController::get_uiPressUsage()
extern void XRController_get_uiPressUsage_mB8FB066CCD005CA0D49E4254FD227CAF97BD6305 ();
// 0x00000012 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_uiPressUsage(InputHelpers_Button)
extern void XRController_set_uiPressUsage_m4435516F65BAEE14881598FC0D34FCDBE1732584 ();
// 0x00000013 System.Single UnityEngine.XR.Interaction.Toolkit.XRController::get_axisToPressThreshold()
extern void XRController_get_axisToPressThreshold_m3993724C4E6510069774510216F80E5589FB7914 ();
// 0x00000014 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_axisToPressThreshold(System.Single)
extern void XRController_set_axisToPressThreshold_m3E61DDBCE3E5EDAEF2728AAB35D24EA1832BD98E ();
// 0x00000015 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRController::get_modelPrefab()
extern void XRController_get_modelPrefab_m247FD5CCA6889E19CCD91C8CB5C13F4C3CE0A886 ();
// 0x00000016 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_modelPrefab(UnityEngine.Transform)
extern void XRController_set_modelPrefab_mE2F07C11A925C71D263E5F3B64899DE38796ED93 ();
// 0x00000017 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRController::get_modelTransform()
extern void XRController_get_modelTransform_m5B62BA0EE14300B942DC5377B47359745F83ED2B ();
// 0x00000018 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::get_animateModel()
extern void XRController_get_animateModel_m5AD6379D693C3C081B0D2956695A11A44E742928 ();
// 0x00000019 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_animateModel(System.Boolean)
extern void XRController_set_animateModel_m06645851679B5D9F4A0FDBEE19F816BB5E74C30B ();
// 0x0000001A System.String UnityEngine.XR.Interaction.Toolkit.XRController::get_modelSelectTransition()
extern void XRController_get_modelSelectTransition_m81D9684D650DCAF6C9C734B0AB677CD0D9BAA083 ();
// 0x0000001B System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_modelSelectTransition(System.String)
extern void XRController_set_modelSelectTransition_m84AA85CB2265B1C4181550432B434CED45C2BD8F ();
// 0x0000001C System.String UnityEngine.XR.Interaction.Toolkit.XRController::get_modelDeSelectTransition()
extern void XRController_get_modelDeSelectTransition_m4806C0A164F719C78E4F9F6840F687C715D48EEA ();
// 0x0000001D System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_modelDeSelectTransition(System.String)
extern void XRController_set_modelDeSelectTransition_m88ED24A6DF5943D06100B5E442E7B9F7D91526E1 ();
// 0x0000001E UnityEngine.XR.Interaction.Toolkit.XRController_InteractionState UnityEngine.XR.Interaction.Toolkit.XRController::get_selectInteractionState()
extern void XRController_get_selectInteractionState_mD51654A7954C12AA378E601C91369509B2B26E1E ();
// 0x0000001F UnityEngine.XR.Interaction.Toolkit.XRController_InteractionState UnityEngine.XR.Interaction.Toolkit.XRController::get_activateInteractionState()
extern void XRController_get_activateInteractionState_m421DA30802B2A0ED137566F07721A7E25FB428B4 ();
// 0x00000020 UnityEngine.XR.Interaction.Toolkit.XRController_InteractionState UnityEngine.XR.Interaction.Toolkit.XRController::get_uiPressInteractionState()
extern void XRController_get_uiPressInteractionState_mBD1EDC35546DC172DAA78F6CB101169EBA419B25 ();
// 0x00000021 UnityEngine.XR.InputDevice UnityEngine.XR.Interaction.Toolkit.XRController::get_inputDevice()
extern void XRController_get_inputDevice_m66B22CF304CFD4037009EB61FE0849D4AD6ED69C ();
// 0x00000022 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::get_hideControllerModel()
extern void XRController_get_hideControllerModel_mE6888E31696D1C2453AA723188A6B8AECE87AA5C ();
// 0x00000023 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_hideControllerModel(System.Boolean)
extern void XRController_set_hideControllerModel_mD439ED7C05834E39269825F118377A4DD69DD26F ();
// 0x00000024 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::OnEnable()
extern void XRController_OnEnable_m0AD8DBBB84784F361EF4094C3B79521C1BF8F166 ();
// 0x00000025 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::OnDisable()
extern void XRController_OnDisable_m405F16579533C22BC0BFCFCA1CF43842B03ED778 ();
// 0x00000026 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::OnBeforeRender()
extern void XRController_OnBeforeRender_m9A65952FF6022ADF81123A79CA6C24CE859FE79F ();
// 0x00000027 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::Awake()
extern void XRController_Awake_m0D2826EB0DD0262D3635DD51D70746CF56D924C0 ();
// 0x00000028 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::PerformSetup()
extern void XRController_PerformSetup_m0B91907F0A055B92379F5FF59EC0ADCCFDE19C47 ();
// 0x00000029 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::SetupModel()
extern void XRController_SetupModel_mD2D93AF3C3A2548C9342F0DA22613495CD8F7A08 ();
// 0x0000002A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::ShouldUpdateTrackingInput()
extern void XRController_ShouldUpdateTrackingInput_m5F50FFD3CF7EBC94A514777DF019E2509E661B32 ();
// 0x0000002B System.Void UnityEngine.XR.Interaction.Toolkit.XRController::Update()
extern void XRController_Update_mE16453032E348DAE294B617FBF70119F5DD97197 ();
// 0x0000002C System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateTrackingInput()
extern void XRController_UpdateTrackingInput_m5FF4C725C1BF5AF3A3E8C5174E5BFB3B2CBD13E1 ();
// 0x0000002D System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateInput()
extern void XRController_UpdateInput_mAEF54953F0C9A8F54C5DC56DCFEEAAFC08F15253 ();
// 0x0000002E System.Void UnityEngine.XR.Interaction.Toolkit.XRController::HandleInteractionAction(UnityEngine.XR.XRNode,InputHelpers_Button,UnityEngine.XR.Interaction.Toolkit.XRController_InteractionState&)
extern void XRController_HandleInteractionAction_m79A71A9C049DA8636D033E66BB996FB34716147E ();
// 0x0000002F System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateInteractionType(UnityEngine.XR.Interaction.Toolkit.XRController_InteractionTypes,System.Boolean)
extern void XRController_UpdateInteractionType_m2F7231F15A0DBAD883C85D6AEC6CED2AB1CD6F5C ();
// 0x00000030 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateInteractionState(UnityEngine.XR.Interaction.Toolkit.XRController_InteractionState&,System.Boolean)
extern void XRController_UpdateInteractionState_m92CEBDDD52209E797A4F9F552D99C5F2FA9D3D6C ();
// 0x00000031 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateControllerModelAnimation()
extern void XRController_UpdateControllerModelAnimation_mAB98F962C03DBD48AD042EBDF57E2E5E97B9332D ();
// 0x00000032 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateControllerPose(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void XRController_UpdateControllerPose_mF7CE607B7A9B56D2A29CBD5149F6511E4D2973B8 ();
// 0x00000033 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::SendHapticImpulse(System.Single,System.Single)
extern void XRController_SendHapticImpulse_mECB44F3F591E286A081213E31BC629AD280308CD ();
// 0x00000034 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::.ctor()
extern void XRController__ctor_m3B5DEAA872ED466E60332B5EADEABE0953C6325A ();
// 0x00000035 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_playOnStart()
extern void XRControllerRecorder_get_playOnStart_mF5EFC34E267D5A49C15BC5DD8FE771DC7382776F ();
// 0x00000036 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_playOnStart(System.Boolean)
extern void XRControllerRecorder_set_playOnStart_mA8CC67EF7E221F668F6999564754D0D00C1628F7 ();
// 0x00000037 UnityEngine.XR.Interaction.Toolkit.XRController UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_controller()
extern void XRControllerRecorder_get_controller_mE948C4BE70FA612D38F916195F9BCFF0EF0A4FC6 ();
// 0x00000038 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_controller(UnityEngine.XR.Interaction.Toolkit.XRController)
extern void XRControllerRecorder_set_controller_m344AD05C8C9ABC3324759BBB0C3E1F9FDF93C161 ();
// 0x00000039 UnityEngine.XR.Interaction.Toolkit.XRControllerRecording UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_recording()
extern void XRControllerRecorder_get_recording_m6ACF024C7E288D961C45A5109B2A51560D0EA9E7 ();
// 0x0000003A System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_recording(UnityEngine.XR.Interaction.Toolkit.XRControllerRecording)
extern void XRControllerRecorder_set_recording_m9D7BD8B40B5BDC1D1E6DCE798D66E5E3896F670F ();
// 0x0000003B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isRecording()
extern void XRControllerRecorder_get_isRecording_mFBD5038ECBDF7554515C8FE4046917BBED44E467 ();
// 0x0000003C System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isRecording(System.Boolean)
extern void XRControllerRecorder_set_isRecording_m839FA72BF3E69563CFAAEA0F0A4735AFF768D4D4 ();
// 0x0000003D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isPlaying()
extern void XRControllerRecorder_get_isPlaying_m4542516EC8095C07B151D6F5B7714FB4D7A27CF1 ();
// 0x0000003E System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isPlaying(System.Boolean)
extern void XRControllerRecorder_set_isPlaying_mA78593981FBE07E51FA0D0E6D1F5C39B3644B8A9 ();
// 0x0000003F System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_currentTime()
extern void XRControllerRecorder_get_currentTime_m83F8AC04E9E88B71E25C2F01685E764DF126D5E3 ();
// 0x00000040 System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_duration()
extern void XRControllerRecorder_get_duration_m5D2F3FA990302D4C6C4F70A5B5FDE776891CD57B ();
// 0x00000041 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Awake()
extern void XRControllerRecorder_Awake_m243108156B345C57339191B79C0559AB7593206A ();
// 0x00000042 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::OnDestroy()
extern void XRControllerRecorder_OnDestroy_m035AFC916AE475C38D8F7CDAF6309D0165503F2C ();
// 0x00000043 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::ToggleRecording()
extern void XRControllerRecorder_ToggleRecording_m59A1510C093335941BEE64F31CCB1896B1B6A9FC ();
// 0x00000044 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Update()
extern void XRControllerRecorder_Update_mAF08E0E8EAE7BD6923174938BE054E8499C233A1 ();
// 0x00000045 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::UpdateControllerRecordingUpdate(UnityEngine.XR.Interaction.Toolkit.XRControllerRecording_Frame)
extern void XRControllerRecorder_UpdateControllerRecordingUpdate_mC284EDAFE5C076BBBD22B136038C4426E3CF5C0D ();
// 0x00000046 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::ResetPlayback()
extern void XRControllerRecorder_ResetPlayback_m7213FB313D6DE393B87607A5838E4F7B3DD68FD1 ();
// 0x00000047 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::UpdatePlaybackTime(System.Double)
extern void XRControllerRecorder_UpdatePlaybackTime_m96E97297B5CDFA6EC9AC0F818DB8BB90867E4DFE ();
// 0x00000048 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::.ctor()
extern void XRControllerRecorder__ctor_m3BF2E212949FC9CD43084C7A7EC9F4A3DE496C51 ();
// 0x00000049 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRControllerRecording_Frame> UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_frames()
extern void XRControllerRecording_get_frames_m950FBCFB1539E7DE6B155322D2276636128333DE ();
// 0x0000004A System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_duration()
extern void XRControllerRecording_get_duration_m84F2430B786F72D94DF4436A5D8EFBBBEAC5B160 ();
// 0x0000004B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrame(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerRecording_AddRecordingFrame_m127E863CCE19A2CB7C164A4F017F4C4488ECC075 ();
// 0x0000004C System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::InitRecording()
extern void XRControllerRecording_InitRecording_m144776A7148E99A6ED5D17C7E3FDD508540D4D8A ();
// 0x0000004D System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::SaveRecording()
extern void XRControllerRecording_SaveRecording_mDBD76AC756E3D46EA7C4A54BC0A95A7CC7CDF995 ();
// 0x0000004E System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::.ctor()
extern void XRControllerRecording__ctor_m93CCC4D71B4E40311F3023145DD746081A6A1A72 ();
// 0x0000004F UnityEngine.Color UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintColor()
extern void XRTintInteractableVisual_get_tintColor_m7D9FC962082181C96935364BFCD7B63A083DC982 ();
// 0x00000050 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintColor(UnityEngine.Color)
extern void XRTintInteractableVisual_set_tintColor_m2E0E2F8DD957E66D32699BB6F4BFF841C8F5BD5E ();
// 0x00000051 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnHover()
extern void XRTintInteractableVisual_get_tintOnHover_m9781D8692AB8169AC19CADF5E5BA459F72AB00BD ();
// 0x00000052 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnHover(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnHover_m55D29E6A60526DFE0BFA9653A5951950251A7840 ();
// 0x00000053 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnSelection()
extern void XRTintInteractableVisual_get_tintOnSelection_m2485C76707E1045AE1EF7558040DEDE94CE39898 ();
// 0x00000054 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnSelection(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnSelection_m5393E066862A72CD40A73EF687A6E183B6283F9F ();
// 0x00000055 System.Collections.Generic.List`1<UnityEngine.Renderer> UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintRenderers()
extern void XRTintInteractableVisual_get_tintRenderers_mD511E551675190580AA6592AF4E2FFF79D64BAB3 ();
// 0x00000056 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintRenderers(System.Collections.Generic.List`1<UnityEngine.Renderer>)
extern void XRTintInteractableVisual_set_tintRenderers_mFC301F1D953AB7453F12A67567F82E3D22544629 ();
// 0x00000057 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::Awake()
extern void XRTintInteractableVisual_Awake_mC67A774BB957814AA4C17ACA57761ADF475FA4A7 ();
// 0x00000058 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::Destroy()
extern void XRTintInteractableVisual_Destroy_mBEA1FB017557AFF434015D0B7C54E163E485453B ();
// 0x00000059 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::SetTint(System.Boolean)
extern void XRTintInteractableVisual_SetTint_m882035C34C671A8CD425DD338EA3E0E6D872F180 ();
// 0x0000005A System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnFirstHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRTintInteractableVisual_OnFirstHoverEnter_m3F99D685DC4889001B513B5FB08444E906EDFF98 ();
// 0x0000005B System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnLastHoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRTintInteractableVisual_OnLastHoverExit_mC379BED007BBF9FF8C7A4E13EE363C4E857FCB90 ();
// 0x0000005C System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRTintInteractableVisual_OnSelectEnter_m21A77FF718AEA39BC96A6DA6C0CD14038D483D99 ();
// 0x0000005D System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRTintInteractableVisual_OnSelectExit_mC2AF19A078C1965A2698190BDE39872237A1334A ();
// 0x0000005E System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::.ctor()
extern void XRTintInteractableVisual__ctor_m67DBBA2274AE180AD46CF4A88B56ECFEED1A3AE3 ();
// 0x0000005F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent::.ctor()
extern void XRInteractableEvent__ctor_mFD4073963C2A8B758C0F04C35C18F13ABBBD308F ();
// 0x00000060 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionManager()
extern void XRBaseInteractable_get_interactionManager_m462CC45EE97EDAE438C9D59C1FB870BD7A7839BB ();
// 0x00000061 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractable_set_interactionManager_m92EE6DDC848D87136A5FD8A6A06A4080D5D99014 ();
// 0x00000062 System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_colliders()
extern void XRBaseInteractable_get_colliders_m7AD14886623F98D5FA7B69E3CE670F9310B28816 ();
// 0x00000063 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionLayerMask()
extern void XRBaseInteractable_get_interactionLayerMask_mC9E32D0C76B718A2E140E8F1AFE87C42CBC9B492 ();
// 0x00000064 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractable_set_interactionLayerMask_m3EEEE1793EAC79485DC2155AF41F0FF78F29C1C5 ();
// 0x00000065 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoveringInteractors()
extern void XRBaseInteractable_get_hoveringInteractors_m903A4AB07A74447D0CEA3E427D769AEBBE42B31B ();
// 0x00000066 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isHovered()
extern void XRBaseInteractable_get_isHovered_m25C78D1C8D25C65FC5B6370CE707C8C92DFF45EE ();
// 0x00000067 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_isHovered(System.Boolean)
extern void XRBaseInteractable_set_isHovered_mA867523E3C5660465277837F950EE95DEFF3315A ();
// 0x00000068 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isSelected()
extern void XRBaseInteractable_get_isSelected_m8FA8E86FC49FC636909AEE2461F170DD994A5D1A ();
// 0x00000069 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_isSelected(System.Boolean)
extern void XRBaseInteractable_set_isSelected_m8DEC7CF523CA6A6E9BDF34A2488B1734563FD5F2 ();
// 0x0000006A UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onFirstHoverEnter()
extern void XRBaseInteractable_get_onFirstHoverEnter_m29024B487C2CF7FFB483C23F13EA574631E5D664 ();
// 0x0000006B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onFirstHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onFirstHoverEnter_m51A49CF3B71F9D44F8E3338294D85A68BCD27797 ();
// 0x0000006C UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverEnter()
extern void XRBaseInteractable_get_onHoverEnter_mA75BDB23C2109233FA33C84958C384C63A38439E ();
// 0x0000006D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverEnter_m1288D80BDC3D6FB756E4BC5CBB3FA9A99AE2ABBB ();
// 0x0000006E UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverExit()
extern void XRBaseInteractable_get_onHoverExit_mA3B560C4BE57EBF902829108DFDB6C05379B2C5C ();
// 0x0000006F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverExit(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverExit_mB9633C1BD6E2F19395F7A862AFCC98AFCC921915 ();
// 0x00000070 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onLastHoverExit()
extern void XRBaseInteractable_get_onLastHoverExit_m0D4C817249076E77C85F319AB9A38EB9A956032A ();
// 0x00000071 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onLastHoverExit(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onLastHoverExit_mFBC67D28EA4183A7EE9E15E0009CE83E5938FF3E ();
// 0x00000072 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectEnter()
extern void XRBaseInteractable_get_onSelectEnter_m7C06801085DC6791EDCC69F4485922945867B358 ();
// 0x00000073 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectEnter_m832750946C516B48292DD25F7BB161074BBF3F53 ();
// 0x00000074 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectExit()
extern void XRBaseInteractable_get_onSelectExit_m9ACDC6F112B9313C850FB952D976662A108D52CF ();
// 0x00000075 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectExit(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectExit_m5C9739A44D9DA0C0DB4DF472BE0717028D63637E ();
// 0x00000076 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onActivate()
extern void XRBaseInteractable_get_onActivate_mC20E07057B8748CAF89CB8A6D3A369E079C2B6E0 ();
// 0x00000077 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onActivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onActivate_mD158ED280BB7B1F2E015CC5CFC99B4BCA22B5ED8 ();
// 0x00000078 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onDeactivate()
extern void XRBaseInteractable_get_onDeactivate_mC0F19CF6211D9E729A10B09B6DB4079F76D6EA18 ();
// 0x00000079 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onDeactivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onDeactivate_m88773396256EB3541C11C8484B5718C4B981B0C0 ();
// 0x0000007A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Reset()
extern void XRBaseInteractable_Reset_m220E20015F1BE4972A549B081EAAA3C233D1D7E7 ();
// 0x0000007B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Awake()
extern void XRBaseInteractable_Awake_m79DDD24D35EF96A8A8A596F67AEACAE055B0F559 ();
// 0x0000007C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::FindCreateInteractionManager()
extern void XRBaseInteractable_FindCreateInteractionManager_mCADB9DEB1058D03AFA62F6650846A91CA1028D2B ();
// 0x0000007D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RegisterWithInteractionMananger()
extern void XRBaseInteractable_RegisterWithInteractionMananger_m1BE91EC4AE39F44CAFAAB38B839D7D7D92CFEFA1 ();
// 0x0000007E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDestroy()
extern void XRBaseInteractable_OnDestroy_mC92AFCFE4ACEF2A18C9284B3DCE33B90FE1197FA ();
// 0x0000007F System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetDistanceSqrToInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_GetDistanceSqrToInteractor_m18E50C4D249F594F5200B8434F9824CE318CB724 ();
// 0x00000080 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsOnValidLayerMask(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsOnValidLayerMask_m6731F4E3BAF20A2F7D6B3A8C80EA7F1ACF106E1B ();
// 0x00000081 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsHoverableBy_m918E1EB1F5ECFC4B0F9A5DD481E30CC8DF701587 ();
// 0x00000082 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsSelectableBy_m37E04117555CC595B49CAF2FB87632F903A8B580 ();
// 0x00000083 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverEnter_m455EB6549212781FD8C150FE13E0A80E55CC1DAD ();
// 0x00000084 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverExit_m2A77B4701C52F27D0F1CD82467484C82B868641A ();
// 0x00000085 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectEnter_mF11D017950D0020B2CC1D9A1D477C5A80BD43A16 ();
// 0x00000086 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectExit_mE56AD354EF9EF821013ABCF83230CFD0275E315D ();
// 0x00000087 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnActivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnActivate_m449A16C713009626E0E7152A0256D6CA6CB54805 ();
// 0x00000088 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_customReticle()
extern void XRBaseInteractable_get_customReticle_mD362ACAA7427380008B92254D5D54E6CCBFB96BD ();
// 0x00000089 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_customReticle(UnityEngine.GameObject)
extern void XRBaseInteractable_set_customReticle_mCC32EA8360ADE05FAF57FD2DF26F213AB7A06305 ();
// 0x0000008A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::AttachCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_AttachCustomReticle_mBBBA8E52B6C2924BE391D085D2EE28341D4EC33D ();
// 0x0000008B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RemoveCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_RemoveCustomReticle_m4A43D9872E9B339890A4E33AFCF0495B7E3B5C61 ();
// 0x0000008C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDeactivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnDeactivate_mB03318B9315788B9F0A1CBA753533F49DC469A28 ();
// 0x0000008D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRBaseInteractable_ProcessInteractable_m2178A2D08A3714E3E34B3747DB204CFFC514B7D8 ();
// 0x0000008E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::.ctor()
extern void XRBaseInteractable__ctor_m8C7F386C4768CAFA731C55B9BD73656FF790F257 ();
// 0x0000008F UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachTransform()
extern void XRGrabInteractable_get_attachTransform_m862693B3A4363C54ECE7D58892CCA365C3EAD564 ();
// 0x00000090 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachTransform(UnityEngine.Transform)
extern void XRGrabInteractable_set_attachTransform_m1A515A4DEFF4BB5D6F3AF18EB586DDCB399E8DB9 ();
// 0x00000091 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachEaseInTime()
extern void XRGrabInteractable_get_attachEaseInTime_mF03620A5B99DDEE3F4018A60974FA60D5F9699AD ();
// 0x00000092 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachEaseInTime(System.Single)
extern void XRGrabInteractable_set_attachEaseInTime_m3F9539667CB670CC7D02A0277EEF600731F0018B ();
// 0x00000093 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable_MovementType UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_movementType()
extern void XRGrabInteractable_get_movementType_m80CC6F327C05751202C0E14AD3D5D653D8849EF7 ();
// 0x00000094 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_movementType(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable_MovementType)
extern void XRGrabInteractable_set_movementType_m59D86D860B23167D42166C62E29C3F88B43194E3 ();
// 0x00000095 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackPosition()
extern void XRGrabInteractable_get_trackPosition_m157384DF8DCED4430149D13B20DF5A7090039BA8 ();
// 0x00000096 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackPosition(System.Boolean)
extern void XRGrabInteractable_set_trackPosition_mE201DBD3856714BBB8B06C7A32FEB05D3BEF5B5C ();
// 0x00000097 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPosition()
extern void XRGrabInteractable_get_smoothPosition_mBC5A08AC5DB148F540082712FBA3786DD9D0B3DB ();
// 0x00000098 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPosition(System.Boolean)
extern void XRGrabInteractable_set_smoothPosition_mCCA9EDE743FCD50825B3DD42A02A291BF948C4BB ();
// 0x00000099 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPositionAmount()
extern void XRGrabInteractable_get_smoothPositionAmount_mA471FDA39E5E3E4B53A3EAA02B686C5E6C9D9E22 ();
// 0x0000009A System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPositionAmount(System.Single)
extern void XRGrabInteractable_set_smoothPositionAmount_m71C1BDECF12079DFA438F0421F16078239F5C361 ();
// 0x0000009B System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenPosition()
extern void XRGrabInteractable_get_tightenPosition_m2CFB0F65F5AD25CF1450039F7F916A8F45086F30 ();
// 0x0000009C System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenPosition(System.Single)
extern void XRGrabInteractable_set_tightenPosition_m6ACB5F1DCE808EACB4DD3E8D55E81F7AF30D6568 ();
// 0x0000009D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackRotation()
extern void XRGrabInteractable_get_trackRotation_mC03716ADC86ED7A9F2AE86FFF4F6BD01CB2C2795 ();
// 0x0000009E System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackRotation(System.Boolean)
extern void XRGrabInteractable_set_trackRotation_m1CF36DFEAF88077CCD72F7156DDDCAFB70FC5B5B ();
// 0x0000009F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotation()
extern void XRGrabInteractable_get_smoothRotation_m65355D11CE9839373923EB9467310EFFADBB74F1 ();
// 0x000000A0 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotation(System.Boolean)
extern void XRGrabInteractable_set_smoothRotation_mFE4126DC8FEB5BF96526D439F32ED250D7396635 ();
// 0x000000A1 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotationAmount()
extern void XRGrabInteractable_get_smoothRotationAmount_m552CD592CB56817C8C6FE707F67356081560A12D ();
// 0x000000A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotationAmount(System.Single)
extern void XRGrabInteractable_set_smoothRotationAmount_m8AC286E5C4392A7E58DD40B6944B1F47F83FFBE8 ();
// 0x000000A3 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenRotation()
extern void XRGrabInteractable_get_tightenRotation_m6585CAC0635CCB8A437601E0AAA8E6B9B7ACF01B ();
// 0x000000A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenRotation(System.Single)
extern void XRGrabInteractable_set_tightenRotation_m996BF739AC92BE581876179CCAF1428C5E7D7F55 ();
// 0x000000A5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwOnDetach()
extern void XRGrabInteractable_get_throwOnDetach_m29763F3151096255FD2E33C74131582740A9F648 ();
// 0x000000A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwOnDetach(System.Boolean)
extern void XRGrabInteractable_set_throwOnDetach_mEE1025D07D8957A312FAFC5FD1B0D3C48EA9D235 ();
// 0x000000A7 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwSmoothingDuration()
extern void XRGrabInteractable_get_throwSmoothingDuration_m2CC87335A9470ACB90337AE57F871C0908A2D9F7 ();
// 0x000000A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwSmoothingDuration(System.Single)
extern void XRGrabInteractable_set_throwSmoothingDuration_m9C5C524411B33469E54B742F534B141974491C53 ();
// 0x000000A9 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwVelocityScale()
extern void XRGrabInteractable_get_throwVelocityScale_m9899BF6EB4F1D7A0AA1075F651A6C27D48DF7DD2 ();
// 0x000000AA System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwVelocityScale_m40C7F957366FB967F58A577294BB6DFC1D33EAE9 ();
// 0x000000AB System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwAngularVelocityScale()
extern void XRGrabInteractable_get_throwAngularVelocityScale_m7464F02849EEB3B8D9A9C10C40945C018E04CFBE ();
// 0x000000AC System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwAngularVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwAngularVelocityScale_mE2349E400B925E9B240186D0A134F838A16FB65B ();
// 0x000000AD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_gravityOnDetach()
extern void XRGrabInteractable_get_gravityOnDetach_m9F46816E5BF80657BDB6C78DC06C70845077C2B4 ();
// 0x000000AE System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_gravityOnDetach(System.Boolean)
extern void XRGrabInteractable_set_gravityOnDetach_mEE5F50DD837EE54667C57782A75B23F1BFFFCD0C ();
// 0x000000AF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_retainTransformParent()
extern void XRGrabInteractable_get_retainTransformParent_m3BBC6F2A1B488C2359D0786801FDD8B2D456B119 ();
// 0x000000B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_retainTransformParent(System.Boolean)
extern void XRGrabInteractable_set_retainTransformParent_m34708BF8C2A6893C903107A1016D70DCDE2EC517 ();
// 0x000000B1 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_selectingInteractor()
extern void XRGrabInteractable_get_selectingInteractor_m69CAFC4677B95560A13EF44442B6997433464E37 ();
// 0x000000B2 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Awake()
extern void XRGrabInteractable_Awake_m1BF1F714B162AA0534AD5374EBF8A1473E12C151 ();
// 0x000000B3 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRGrabInteractable_ProcessInteractable_m2137F159D30520448DC9D16E2416622266215317 ();
// 0x000000B4 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachPosition(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_GetWorldAttachPosition_m2F4A65271C9044F80934FF2AE53E287251C3C13E ();
// 0x000000B5 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachRotation(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_GetWorldAttachRotation_m41E15EE8EA3D77A6E0B8A71FCF33D9B4F99A4F8C ();
// 0x000000B6 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateTarget(System.Single)
extern void XRGrabInteractable_UpdateTarget_m305427E797921DC28F17601C032225B3CF7ACA2D ();
// 0x000000B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformInstantaneousUpdate(System.Single,UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRGrabInteractable_PerformInstantaneousUpdate_mF11C16E54E3794378ACCBDC7D5A7C373B9074D3B ();
// 0x000000B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformKinematicUpdate(System.Single,UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRGrabInteractable_PerformKinematicUpdate_m7FD846A18AFF18D01FFE6534C4608E37EA0E64DA ();
// 0x000000B9 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformVelocityTrackingUpdate(System.Single,UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRGrabInteractable_PerformVelocityTrackingUpdate_m84739063D192F1F4B9CB98C4C8729FB2BE809B45 ();
// 0x000000BA System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Teleport(UnityEngine.Transform)
extern void XRGrabInteractable_Teleport_m6C564F277BD72C9AD458746E714F3FD74B2340C1 ();
// 0x000000BB System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Detach()
extern void XRGrabInteractable_Detach_m218F564849DC940DC9F5D99DE36B4F7E9EFA0C30 ();
// 0x000000BC System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateInteractorLocalPose(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_UpdateInteractorLocalPose_m559E77C3864E825945398CA07E4361051BE09AE6 ();
// 0x000000BD System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_OnSelectEnter_m12F361A216C9CE799645C5BC678BF42EF0D90861 ();
// 0x000000BE System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_OnSelectExit_m3B8CE08F1FCBFEA219AEC620EF03215EE0A3BECC ();
// 0x000000BF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRGrabInteractable_IsHoverableBy_m71C308782F1159E004079260774829E6C0FF73AA ();
// 0x000000C0 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityStart()
extern void XRGrabInteractable_SmoothVelocityStart_m0E0DB96FDFEADD0C42728BE89A8D75E010218D76 ();
// 0x000000C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityEnd()
extern void XRGrabInteractable_SmoothVelocityEnd_m556FA381B4AE2A51012D05CB62446EDAE79FC3E8 ();
// 0x000000C2 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityUpdate()
extern void XRGrabInteractable_SmoothVelocityUpdate_mB062D40EE08DA2D20D411F1D531F7A4114154BB3 ();
// 0x000000C3 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::getSmoothedVelocityValue(UnityEngine.Vector3[])
extern void XRGrabInteractable_getSmoothedVelocityValue_m633346177413351F8DC72FF2B39F329C00A65468 ();
// 0x000000C4 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::.ctor()
extern void XRGrabInteractable__ctor_m37710191367C3F56074C135870E35E0918E758B4 ();
// 0x000000C5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSimpleInteractable::.ctor()
extern void XRSimpleInteractable__ctor_m3F955EA3DE342BCC5CE0562B5CB7C3644A9E9EE5 ();
// 0x000000C6 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::AttachCustomReticle(UnityEngine.GameObject)
// 0x000000C7 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::RemoveCustomReticle()
// 0x000000C8 System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
// 0x000000C9 System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
// 0x000000CA System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineWidth()
extern void XRInteractorLineVisual_get_lineWidth_m18710176FC537DEB413370C7C0E7A521339E2B2F ();
// 0x000000CB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineWidth(System.Single)
extern void XRInteractorLineVisual_set_lineWidth_m8934617A2CE9568373A6D7C88578F75D56DFA1A9 ();
// 0x000000CC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_overrideInteractorLineLength()
extern void XRInteractorLineVisual_get_overrideInteractorLineLength_mEE23EE3B15284131BB7019386E88B76C95C4978A ();
// 0x000000CD System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_overrideInteractorLineLength(System.Boolean)
extern void XRInteractorLineVisual_set_overrideInteractorLineLength_m556194DE02DA3EEC3146F51B75DF0C5D349E7125 ();
// 0x000000CE System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineLength()
extern void XRInteractorLineVisual_get_lineLength_m85CFC2FEBB7416938EB2B93CC3F7586F79E32D84 ();
// 0x000000CF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineLength(System.Single)
extern void XRInteractorLineVisual_set_lineLength_m5B84CD185E41B83DB5FCF7CAD35A25A49966BB21 ();
// 0x000000D0 UnityEngine.AnimationCurve UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_widthCurve()
extern void XRInteractorLineVisual_get_widthCurve_m72A134DE24BE4A0DB179848D442BFBFF8C7844ED ();
// 0x000000D1 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_widthCurve(UnityEngine.AnimationCurve)
extern void XRInteractorLineVisual_set_widthCurve_m6D02C08E49DFA525E8BD382A82D5C5F7C11E8D38 ();
// 0x000000D2 UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_validColorGradient()
extern void XRInteractorLineVisual_get_validColorGradient_m484CCC79897732334CE93E09EA154C66A2C03AB4 ();
// 0x000000D3 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_validColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_validColorGradient_m4978178317009699ECD79B197B283D2422C09E39 ();
// 0x000000D4 UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_invalidColorGradient()
extern void XRInteractorLineVisual_get_invalidColorGradient_m4BEC57B84C9FA4285A4DA4D3890581D676E90ACC ();
// 0x000000D5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_invalidColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_invalidColorGradient_m61D828EB2FE273ABCFEC466B7CCDBF1A6C1D9A96 ();
// 0x000000D6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_smoothMovement()
extern void XRInteractorLineVisual_get_smoothMovement_mF098F50939981B6F2F3AC33C99C63BAA6316D885 ();
// 0x000000D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_smoothMovement(System.Boolean)
extern void XRInteractorLineVisual_set_smoothMovement_m7D9DE827719C72A20BD451869E197122B1B95657 ();
// 0x000000D8 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_followTightness()
extern void XRInteractorLineVisual_get_followTightness_mC326C0EACEF14A43EF60C191F886CA7B3A9595D0 ();
// 0x000000D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_followTightness(System.Single)
extern void XRInteractorLineVisual_set_followTightness_m28109F87EF28852475B98B742154C99E79BDB58E ();
// 0x000000DA System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_snapThresholdDistance()
extern void XRInteractorLineVisual_get_snapThresholdDistance_mACD2188A8F09E1C19CE25084879707DC20F85F74 ();
// 0x000000DB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_snapThresholdDistance(System.Single)
extern void XRInteractorLineVisual_set_snapThresholdDistance_m8E7E1B5481767B423FFDE7E7A7757651F27499BC ();
// 0x000000DC UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_reticle()
extern void XRInteractorLineVisual_get_reticle_m4E95EADACF9AA81026ABEB84D328B4DEFF96B46F ();
// 0x000000DD System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_reticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_set_reticle_m8FE9D8281C147F664F1273BE8D261C57E66BD3D2 ();
// 0x000000DE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_stopLineAtFirstRaycastHit()
extern void XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m8F4A5C4E96E7BB8B48339C0DD5E23C3FE2A7BE71 ();
// 0x000000DF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_stopLineAtFirstRaycastHit(System.Boolean)
extern void XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m392A6AC6ABDBF1D9435A435636FFEB861543A75E ();
// 0x000000E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Awake()
extern void XRInteractorLineVisual_Awake_m4580BBC2B8AF004C07265B71FADC38FC7F36A652 ();
// 0x000000E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnEnable()
extern void XRInteractorLineVisual_OnEnable_mBEAC76E68500B6521AD4168612FED8EE146096ED ();
// 0x000000E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnDisable()
extern void XRInteractorLineVisual_OnDisable_m037FF8397E777F7BEC730461CCFE8C1F3B0B7A25 ();
// 0x000000E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Reset()
extern void XRInteractorLineVisual_Reset_m26A6A421208893DD1F25B9C28858D0A61B23F8CD ();
// 0x000000E4 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::ClearLineRenderer()
extern void XRInteractorLineVisual_ClearLineRenderer_m12A591D0DBB12EF33E207EA5749EADF9845CD230 ();
// 0x000000E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Update()
extern void XRInteractorLineVisual_Update_m048B642FE6224023DBB1DCBF8BF46FC17E2AC60C ();
// 0x000000E6 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateLineVisual()
extern void XRInteractorLineVisual_UpdateLineVisual_mBAF4BBE6B0F660432C883423069FF3AB6BB1DF01 ();
// 0x000000E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnValidate()
extern void XRInteractorLineVisual_OnValidate_m3D84AEA7FB9CAAB2847417877CBAF0EC76DBCC69 ();
// 0x000000E8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateSettings()
extern void XRInteractorLineVisual_UpdateSettings_mEA4683CD450DB3ED40D06350F7E613133EFAE244 ();
// 0x000000E9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::TryFindLineRenderer()
extern void XRInteractorLineVisual_TryFindLineRenderer_mB6F10478B91887C8D2DCED78F77275C0319B177D ();
// 0x000000EA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::AttachCustomReticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_AttachCustomReticle_m42ACD0E1E6DE1026B6BE5FD7C570A5A58C94F884 ();
// 0x000000EB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::RemoveCustomReticle()
extern void XRInteractorLineVisual_RemoveCustomReticle_mAE43F45A0C9FB66175301759FFBF64B7C9BA794E ();
// 0x000000EC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::.ctor()
extern void XRInteractorLineVisual__ctor_m05F4354C0719D69C9F6D5B5063F15B746644EC2F ();
// 0x000000ED System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_maxRaycastDistance()
extern void XRInteractorReticleVisual_get_maxRaycastDistance_m7555EA620186425507CD52A06F97CCA12328B980 ();
// 0x000000EE System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_maxRaycastDistance(System.Single)
extern void XRInteractorReticleVisual_set_maxRaycastDistance_m9232388A53EF4030D1605B557F3E7BA798FBDF24 ();
// 0x000000EF UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticlePrefab()
extern void XRInteractorReticleVisual_get_reticlePrefab_m61B43EBE87C0D23AD34AD5D773FAC803B88E20CE ();
// 0x000000F0 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticlePrefab(UnityEngine.GameObject)
extern void XRInteractorReticleVisual_set_reticlePrefab_m733CF9717249A36878A31F74400EF6EB802B91C1 ();
// 0x000000F1 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_prefabScalingFactor()
extern void XRInteractorReticleVisual_get_prefabScalingFactor_m9EC1B0B6D20FB321C250565DC7B8BE58624AEEA8 ();
// 0x000000F2 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_prefabScalingFactor(System.Single)
extern void XRInteractorReticleVisual_set_prefabScalingFactor_m6703A3D1E869669427A7A4BE42A6C5974DDC85EE ();
// 0x000000F3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_undoDistanceScaling()
extern void XRInteractorReticleVisual_get_undoDistanceScaling_mCACE32DE9893831E40AFAB56B4DE021E2A3DE840 ();
// 0x000000F4 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_undoDistanceScaling(System.Boolean)
extern void XRInteractorReticleVisual_set_undoDistanceScaling_mC7F27BBDFC3DDA211BCA7123B3EDF825202DD4A8 ();
// 0x000000F5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_alignPrefabWithSurfaceNormal()
extern void XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_m953D2A15011C4DEF67FEB66085D675924693E4AD ();
// 0x000000F6 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_alignPrefabWithSurfaceNormal(System.Boolean)
extern void XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_m29C28F760103B1D995643897EA92019393C83A67 ();
// 0x000000F7 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_endpointSmoothingTime()
extern void XRInteractorReticleVisual_get_endpointSmoothingTime_mDBF630C71C458E0765678C47425A3847CFA93E9B ();
// 0x000000F8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_endpointSmoothingTime(System.Single)
extern void XRInteractorReticleVisual_set_endpointSmoothingTime_m440B93645801A20B13D180C6C29E4A03A98D4697 ();
// 0x000000F9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_drawWhileSelecting()
extern void XRInteractorReticleVisual_get_drawWhileSelecting_mB2EB291C7EBBBAF05643AA2A38FE1281199804DB ();
// 0x000000FA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_drawWhileSelecting(System.Boolean)
extern void XRInteractorReticleVisual_set_drawWhileSelecting_m5673968C0646C399E1F8ED140DA4279E79C747FB ();
// 0x000000FB UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_raycastMask()
extern void XRInteractorReticleVisual_get_raycastMask_m431BD493C44623976B255255460A0EE75DCA6EF0 ();
// 0x000000FC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_raycastMask(UnityEngine.LayerMask)
extern void XRInteractorReticleVisual_set_raycastMask_m446330A898844EB5DBA19D7B4266EE3F5BE78E81 ();
// 0x000000FD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticleActive()
extern void XRInteractorReticleVisual_get_reticleActive_mE2643807B536606417F695BABE8F50C73DCC1027 ();
// 0x000000FE System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticleActive(System.Boolean)
extern void XRInteractorReticleVisual_set_reticleActive_mAEC43ACA76193F43153068CA28532A4EEC23A928 ();
// 0x000000FF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Awake()
extern void XRInteractorReticleVisual_Awake_mC02C31987911CD4D9AC9EC9947410BF03EDA37E3 ();
// 0x00000100 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnDestroy()
extern void XRInteractorReticleVisual_OnDestroy_m954C8BB59F1EB3439D9B2034531E40BF698D5833 ();
// 0x00000101 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::SetupReticlePrefab()
extern void XRInteractorReticleVisual_SetupReticlePrefab_mB29AADD1CC049ECAA97305793F489D434AD42D78 ();
// 0x00000102 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Update()
extern void XRInteractorReticleVisual_Update_mCF460E61ED5AC801423686DEC78F0E4A4101DA06 ();
// 0x00000103 UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void XRInteractorReticleVisual_FindClosestHit_m79F1C604AE2AA3812ACC5F5CA94AF5F1CAFF45DD ();
// 0x00000104 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::TryGetRaycastPoint(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRInteractorReticleVisual_TryGetRaycastPoint_mA9ACF3867020A25BF53EBC10735839B8ACB0C306 ();
// 0x00000105 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::UpdateReticleTarget()
extern void XRInteractorReticleVisual_UpdateReticleTarget_m9A04A1D4AF7D9FD6462B57249E943116741CF23B ();
// 0x00000106 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::ActivateReticleAtTarget()
extern void XRInteractorReticleVisual_ActivateReticleAtTarget_mBBBD28FF44A71B06170A0D17EC0E9D1DD6D43732 ();
// 0x00000107 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractorReticleVisual_OnSelectEnter_m459E88D8800615976E30F7A45E6EFE114C7E144C ();
// 0x00000108 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractorReticleVisual_OnSelectExit_m2928EC14A70AB21F2F879564E5CE45D0138C9C68 ();
// 0x00000109 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::.ctor()
extern void XRInteractorReticleVisual__ctor_m8BC2776AC52BE756B46856BB6675CD70A79339D3 ();
// 0x0000010A UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor_SelectActionTriggerType UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_selectActionTrigger()
extern void XRBaseControllerInteractor_get_selectActionTrigger_mC3B03B7F4D0B7C07101479A46FA3938D13E0F093 ();
// 0x0000010B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_selectActionTrigger(UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor_SelectActionTriggerType)
extern void XRBaseControllerInteractor_set_selectActionTrigger_m0FF90268EA196B74850CCC2D6B45A1B246212CF6 ();
// 0x0000010C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hideControllerOnSelect()
extern void XRBaseControllerInteractor_get_hideControllerOnSelect_m384BF23FA3D844C3F0C1B3F814874E10AE704A3E ();
// 0x0000010D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hideControllerOnSelect(System.Boolean)
extern void XRBaseControllerInteractor_set_hideControllerOnSelect_m026D33DD0E557ED84082A9B28FC96CA8EDB2ED4D ();
// 0x0000010E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_m3B21A22995BFAB6E9410D7AAE857C1193F74464C ();
// 0x0000010F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectEnter(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectEnter_m6D2C28C6BBC61B9730916282C7E687ADB1001DCC ();
// 0x00000110 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m6B9CC9B63717238BC23594E62C220E6CA14CC5C1 ();
// 0x00000111 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m8C10AD90604CBD5558C1B19C0117AABE9C280BFF ();
// 0x00000112 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m3A9625B60C92E44718D17C13222EA70C62C35BE4 ();
// 0x00000113 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectExit(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectExit_m1FECF9F38D22706C376977516490C46E90286B37 ();
// 0x00000114 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectExit_mA282326331E7D806EE650BB7FE6BD2118A496EB6 ();
// 0x00000115 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mFDA64A5104EAE4D8813F442DB211F5EBFF642136 ();
// 0x00000116 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_m462E980B038E7038F6C9F1E0306597A268C87282 ();
// 0x00000117 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverEnter(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverEnter_m1DDD6D2849068CB2489498FF693D410FEDB203F8 ();
// 0x00000118 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_mD643290F06D3F20269B864FA07D879DC67A733FF ();
// 0x00000119 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_m3DD5F5DB46040AE83B15F4C3303DA7869E1967EC ();
// 0x0000011A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverExit_mC9ED611D2009E3A8BB51B577F33656A515E5C05C ();
// 0x0000011B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverExit(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverExit_m624F1FDADC63C6370603B80B7E27F51D4E8E2D11 ();
// 0x0000011C UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverExit_m853A5476006B197CB4F64911CE31BE0CF1E3769D ();
// 0x0000011D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverExit_m8BF214EB7B7129F6379D8AC131CE4ED5B42BACD7 ();
// 0x0000011E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectEnter_m5E2745052FAABED5C78396E8DF8532707B3E523B ();
// 0x0000011F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectEnter(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectEnter_m9DA39064D0EAFBBA82C25AE2F13F8DC50559D7B9 ();
// 0x00000120 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectEnterIntensity_mC1DAA8BF8E4DDF8DA3F1AE792247CFB09F4B1495 ();
// 0x00000121 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterIntensity_m30D050BCD0A6A2A2DA9D647960F549D007D02998 ();
// 0x00000122 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterDuration()
extern void XRBaseControllerInteractor_get_hapticSelectEnterDuration_m410A4C712D66432061FE6F0B756E1C747D61017C ();
// 0x00000123 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterDuration_m6B577454DCD8CB6D8C7DFEB7B496147A8C5E3664 ();
// 0x00000124 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectExit()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectExit_m051A9C73AD41A2D0FF5B0852D2E4FDCB4E46E905 ();
// 0x00000125 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectExit(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectExit_mEA5C73828E600CFC6D41CFD91EC397870FFD52D7 ();
// 0x00000126 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectExitIntensity_mF7C29A0AC8F5C9AB298873ECA9802531EC9F0BB2 ();
// 0x00000127 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitIntensity_mE507564E2B51D80DC6778F8E59D242EBC1DDDDDE ();
// 0x00000128 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitDuration()
extern void XRBaseControllerInteractor_get_hapticSelectExitDuration_m5638563859F2032C6354C7F99B96D2554C5A7AA7 ();
// 0x00000129 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitDuration_mE04EBD54B9F88154BE1A60A5963D77E02E9F44DC ();
// 0x0000012A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverEnter_m914A8B3E32341D4A19E623A582204B20B88BB562 ();
// 0x0000012B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverEnter(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverEnter_mCE2B913BD7F2C53D38698FFA9C2E3E4575858D9A ();
// 0x0000012C System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverEnterIntensity_mD1339CCDEF6D42D4A593170240832FCC4A283D60 ();
// 0x0000012D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterIntensity_mFF33CDFFE7229B242F7A39DC48D0B89AE74048F2 ();
// 0x0000012E System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterDuration()
extern void XRBaseControllerInteractor_get_hapticHoverEnterDuration_mE1565B80CA4A08E87C04A384DE3064B63F161C2B ();
// 0x0000012F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterDuration_mE338B38F8DD2858D81DF9AC7DAA5CD1DD37F7E58 ();
// 0x00000130 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverExit()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverExit_m9D5734C0432E49B32B3FA6742C56AB2E0E5170CB ();
// 0x00000131 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverExit(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverExit_mD1EF36344E53A4C662AD1DEE23EC1AC0F7C0157B ();
// 0x00000132 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverExitIntensity_m3B124C5FCAD1E41AB72884F19CA366291A984B5C ();
// 0x00000133 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitIntensity_m08F03E1F9C154F01B34C5EBBEA69F886BEF771E3 ();
// 0x00000134 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitDuration()
extern void XRBaseControllerInteractor_get_hapticHoverExitDuration_m431B10F8CA2E3D105473CFD04FB120FA07CD5741 ();
// 0x00000135 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitDuration_m6D7282F2ADBA2AEEA339878F3AD96A6B19BA32E0 ();
// 0x00000136 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_ValidTargets()
// 0x00000137 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::Awake()
extern void XRBaseControllerInteractor_Awake_m963160FC66B34AC5FE699F6C8BEED5EBE3577F46 ();
// 0x00000138 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::CreateEffectsAudioSource()
extern void XRBaseControllerInteractor_CreateEffectsAudioSource_m443EDB75B9E7137484A01731E9BDED7D3C8F236A ();
// 0x00000139 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRBaseControllerInteractor_ProcessInteractor_m89A38BCCDDE2DD50F5F85B17431A98D796356830 ();
// 0x0000013A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isSelectActive()
extern void XRBaseControllerInteractor_get_isSelectActive_mE2C1787101FED3096FFB25F3D6FF1A944B938264 ();
// 0x0000013B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isUISelectActive()
extern void XRBaseControllerInteractor_get_isUISelectActive_m72E4C5335BDAD2E04144F0EAE0A8328BC3DA8CBB ();
// 0x0000013C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseControllerInteractor_OnSelectEnter_m2DBA143CCD7C25937592DEA5E19BFB2CD4540E56 ();
// 0x0000013D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseControllerInteractor_OnSelectExit_m3D78EEC75D9220330CC4C281712FA230CBAD8BB0 ();
// 0x0000013E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseControllerInteractor_OnHoverEnter_mC348C0B782B8779F9D0B50D60BFB41999AD91068 ();
// 0x0000013F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseControllerInteractor_OnHoverExit_m7732DD7E34BF1CAC3865D488C11DFCEADB392F1C ();
// 0x00000140 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::SendHapticImpulse(System.Single,System.Single)
extern void XRBaseControllerInteractor_SendHapticImpulse_mEF524BFEBFE3752E7D8EF06435B6DA8BFC5FD249 ();
// 0x00000141 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::.ctor()
extern void XRBaseControllerInteractor__ctor_mCC35C801B5B8C9C8DF13B021BA9AD45542041DF6 ();
// 0x00000142 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent::.ctor()
extern void XRInteractorEvent__ctor_m0D00AE053208EC0079CBD0B502D11E13674A96AF ();
// 0x00000143 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionManager()
extern void XRBaseInteractor_get_interactionManager_m0524A500D7EA779A49816C2CDDAFE5E174C7279F ();
// 0x00000144 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractor_set_interactionManager_mC61758909438262074C5FCBC6D41333CF02DF247 ();
// 0x00000145 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_InteractionLayerMask()
extern void XRBaseInteractor_get_InteractionLayerMask_m706D28405BA5E3926FD9EEC0D1955159098CF855 ();
// 0x00000146 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_InteractionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractor_set_InteractionLayerMask_m895761A0E88A12DCFE2E1BA2B89208526C3ED5CA ();
// 0x00000147 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_attachTransform()
extern void XRBaseInteractor_get_attachTransform_mC35D8EB5DD5D4E0FA29C67EE5B5534995B0A9E73 ();
// 0x00000148 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectTarget()
extern void XRBaseInteractor_get_selectTarget_m2AB72491DDCE9259810C59A21853D8941334D947 ();
// 0x00000149 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_startingSelectedInteractable()
extern void XRBaseInteractor_get_startingSelectedInteractable_m92FAD461D1C898A985B2B6ACE4C0407B96A7D21E ();
// 0x0000014A UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionLayerMask()
extern void XRBaseInteractor_get_interactionLayerMask_m8AA1D83AE9A13C8A65DAA2C1B6D83A8A0EDC81D4 ();
// 0x0000014B UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverEnter()
extern void XRBaseInteractor_get_onHoverEnter_mCE374B1E484877EC9E9786BF3E01DE7CA0F3DF55 ();
// 0x0000014C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverEnter_m0C246A4A48EEABD5DAB8ACF865E7C720C8F21B57 ();
// 0x0000014D UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverExit()
extern void XRBaseInteractor_get_onHoverExit_mBC1973EFA0BF917797A79D0274D25323F50A828B ();
// 0x0000014E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverExit(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverExit_mBF8132C6656FF8AD2384E9A14B281321E69EF7A0 ();
// 0x0000014F UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectEnter()
extern void XRBaseInteractor_get_onSelectEnter_mDBD18EEE886633441903483496C6C80895F9C543 ();
// 0x00000150 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectEnter_mFF9830688F6C828F93DE8B1E15F194EA43EE1691 ();
// 0x00000151 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectExit()
extern void XRBaseInteractor_get_onSelectExit_m8F35FFD148A7F8EE1BB7DB0CD4496009CF3C5892 ();
// 0x00000152 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectExit(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectExit_m4D6B0862496ACDE1A2DB8113D621829A8CFD0F66 ();
// 0x00000153 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowHover()
extern void XRBaseInteractor_get_allowHover_m8AA16C59F27DED5103CE26E7E75F62B827C77416 ();
// 0x00000154 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowHover(System.Boolean)
extern void XRBaseInteractor_set_allowHover_mE51E161598CADF8153BDD8E8C3006EC0844EEA15 ();
// 0x00000155 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowSelect()
extern void XRBaseInteractor_get_allowSelect_mD09EC3B11EC2DC2AD3C51FCA6563AF1EF6ADFA93 ();
// 0x00000156 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowSelect(System.Boolean)
extern void XRBaseInteractor_set_allowSelect_mFCB46F3E88D5946D281636B0946301F9F0B5EF0A ();
// 0x00000157 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_enableInteractions()
extern void XRBaseInteractor_get_enableInteractions_m776A77C7988AE704740403905F2AA51F74455E60 ();
// 0x00000158 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_enableInteractions(System.Boolean)
extern void XRBaseInteractor_set_enableInteractions_mF287B3135C4937C6948A6FA83B74AE3FC9A21EE8 ();
// 0x00000159 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::EnableInteractions(System.Boolean)
extern void XRBaseInteractor_EnableInteractions_mD04E011645BF0FA9B6246960B96A5DB38C28836E ();
// 0x0000015A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Reset()
extern void XRBaseInteractor_Reset_mF3F64F45D5816C4B745EAD7B6556DCAA505FC47E ();
// 0x0000015B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Awake()
extern void XRBaseInteractor_Awake_mFEBB5E0BCF5C205688878D65F544F9067D4607E2 ();
// 0x0000015C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Start()
extern void XRBaseInteractor_Start_m50BFCF76917FF7F510DC405A6619CEDB8237AA4E ();
// 0x0000015D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnEnable()
extern void XRBaseInteractor_OnEnable_mA582A33C1F4FF98B6F0E3FBAEF6EB21CC67961A3 ();
// 0x0000015E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDisable()
extern void XRBaseInteractor_OnDisable_m40F9838CF4DA18DC0B6B281992B786C01CC86D74 ();
// 0x0000015F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDestroy()
extern void XRBaseInteractor_OnDestroy_mDDE22CB5CEEB46ADD31480DC8453FA27067F04CC ();
// 0x00000160 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetHoverTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRBaseInteractor_GetHoverTargets_m612455C80FB845FF428EA6D1115CB2C763561228 ();
// 0x00000161 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::FindCreateInteractionManager()
extern void XRBaseInteractor_FindCreateInteractionManager_m3ABCD9402CE04F96ED936CF07A2A3CAFA412A6A7 ();
// 0x00000162 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::RegisterWithInteractionMananger()
extern void XRBaseInteractor_RegisterWithInteractionMananger_m4E8BFE70DA26D202A996E71AE09E572465C8943F ();
// 0x00000163 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::ClearHoverTargets()
extern void XRBaseInteractor_ClearHoverTargets_m5856C4D188A8987520836A5BE7BA65D51FFB191D ();
// 0x00000164 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsOnValidLayerMask(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_IsOnValidLayerMask_mBC7EE661321AC935E5C5106F17E98DAB76455C97 ();
// 0x00000165 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
// 0x00000166 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isHoverActive()
extern void XRBaseInteractor_get_isHoverActive_m28BCFFB444E8C487037906AFC0D71127797CA770 ();
// 0x00000167 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isSelectActive()
extern void XRBaseInteractor_get_isSelectActive_m655312055615991189BB2A15D7A746714B3C46F3 ();
// 0x00000168 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanHover_m4DA82A0B43D307B7006264EFD743B8FB28BE0B31 ();
// 0x00000169 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanSelect_m42F071A99050193C815C9D5854AF68301A860A19 ();
// 0x0000016A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_requireSelectExclusive()
extern void XRBaseInteractor_get_requireSelectExclusive_m41D4E9822B1EF75314F1CFE282700BE4A0FCF0FB ();
// 0x0000016B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_overrideSelectedInteractableMovement()
extern void XRBaseInteractor_get_overrideSelectedInteractableMovement_mDEE58B2DC9D4C94E096EC6024EC2F2BA7F356030 ();
// 0x0000016C System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable_MovementType> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m45FAB49EDD0097503EBC794E38E632877F690BEF ();
// 0x0000016D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverEnter_m0A9ADC65D4F36325FD280B77AC59282D582F9B07 ();
// 0x0000016E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverExit_m624670639393438D40D857526878EFD960EF9912 ();
// 0x0000016F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectEnter_mFD7BD282D4C4C6A3FE16045E4F2B1103F78314C6 ();
// 0x00000170 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectExit_m6A8A50C5A1BEDC620DCFC372EBDE43D4AA404736 ();
// 0x00000171 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRBaseInteractor_ProcessInteractor_mAEC1BF7AF8B8424D750EFB8004F6F43852A5CCB7 ();
// 0x00000172 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::.ctor()
extern void XRBaseInteractor__ctor_m2389520C1806CA9AE2B59EA66A72D8B357E8057D ();
// 0x00000173 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::get_ValidTargets()
extern void XRDirectInteractor_get_ValidTargets_m2A04723801E832149C52DC797E900A2A0F3A8D0E ();
// 0x00000174 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::InteractableSortComparison(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_InteractableSortComparison_mD65EF60508DE426F7AB037E2B03BE6C6AB430AFA ();
// 0x00000175 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::Awake()
extern void XRDirectInteractor_Awake_m1A178FC5E2A37D208969526C33DD018AF0FC59A0 ();
// 0x00000176 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerEnter_m32B796D1DDDD5D572F2F2CC56A16C34908DFD95B ();
// 0x00000177 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerExit_m9E45A7BEEF6FBD8C79AA309FB038F3B158B4E135 ();
// 0x00000178 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRDirectInteractor_GetValidTargets_m49E510BBD1ADF990443A7A5AAD29CA320252525C ();
// 0x00000179 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanHover_m8DABE4AE2E19DF7B60B2287543E4E28543B2350C ();
// 0x0000017A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanSelect_mD7D6F6D4B56BB13FDCA82F37C9AF5D4DD37425A5 ();
// 0x0000017B System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::.ctor()
extern void XRDirectInteractor__ctor_m9BCE389FD9FC10B07E2B4F97A26DCE4C3FF01737 ();
// 0x0000017C UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_LineType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_lineType()
extern void XRRayInteractor_get_lineType_m69D9614AC1F531C7D40AF5A827CAFF2D63F98E17 ();
// 0x0000017D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_lineType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_LineType)
extern void XRRayInteractor_set_lineType_m107B49B31C80C515ACA7C77A1140E5D35FAEA50A ();
// 0x0000017E System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_maxRaycastDistance()
extern void XRRayInteractor_get_maxRaycastDistance_m7165049251A0C57C3C9240BA6E8F9E20D9E1923E ();
// 0x0000017F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_maxRaycastDistance(System.Single)
extern void XRRayInteractor_set_maxRaycastDistance_m22AFACEFD15318EB24834EA7898E4E35F665060C ();
// 0x00000180 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_referenceFrame()
extern void XRRayInteractor_get_referenceFrame_m8B9F83975D5762DFAA3983425FD5D6731290BE2E ();
// 0x00000181 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_referenceFrame(UnityEngine.Transform)
extern void XRRayInteractor_set_referenceFrame_m69CC444B6BAE2EE4CCB0C9E8AD1B4F19A47AECE4 ();
// 0x00000182 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Velocity()
extern void XRRayInteractor_get_Velocity_m59ECD975823AF90697A3E71A16F14D990E500797 ();
// 0x00000183 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Velocity(System.Single)
extern void XRRayInteractor_set_Velocity_mF05C39A7188423E183F8C64832A952D4150A76ED ();
// 0x00000184 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Acceleration()
extern void XRRayInteractor_get_Acceleration_m768D0ED7794ADBC971D7A6E76F86E9AB497EC8D8 ();
// 0x00000185 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Acceleration(System.Single)
extern void XRRayInteractor_set_Acceleration_m92307B1A32F342DAD6E7F318916353FE2D31725E ();
// 0x00000186 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_AdditionalFlightTime()
extern void XRRayInteractor_get_AdditionalFlightTime_mA715F770E9A797BA0C2A207A0AF0B2BCE93B3D50 ();
// 0x00000187 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_AdditionalFlightTime(System.Single)
extern void XRRayInteractor_set_AdditionalFlightTime_m4D1DCDB85AD63CE285EAD19B7E2968CE2AF5B80F ();
// 0x00000188 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointDistance()
extern void XRRayInteractor_get_endPointDistance_m8D00D888DA5216ECE3862CCCC801CEB0961BB595 ();
// 0x00000189 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointDistance(System.Single)
extern void XRRayInteractor_set_endPointDistance_m49597E7B05E17046E2BE70837F82A69260C3E0CA ();
// 0x0000018A System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointHeight()
extern void XRRayInteractor_get_endPointHeight_m5F66EB6E8F296621A7EA67C8FE94B3C37A6D8F59 ();
// 0x0000018B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointHeight(System.Single)
extern void XRRayInteractor_set_endPointHeight_mBB80755F27FB6563572B7F4280FE1AE1721E7DD0 ();
// 0x0000018C System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointDistance()
extern void XRRayInteractor_get_controlPointDistance_mB9F75D57BD6587B028CE38D47E1F481E5447A495 ();
// 0x0000018D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointDistance(System.Single)
extern void XRRayInteractor_set_controlPointDistance_m1521446ABFF71F2EF33D5F418885F0E2D2E5A64B ();
// 0x0000018E System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointHeight()
extern void XRRayInteractor_get_controlPointHeight_m1AAD564F85FD2F6365CFAEE675A34E94C6D9D48C ();
// 0x0000018F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointHeight(System.Single)
extern void XRRayInteractor_set_controlPointHeight_m7761B4DB37DE91D0C54E15F20F97B1613487449C ();
// 0x00000190 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sampleFrequency()
extern void XRRayInteractor_get_sampleFrequency_m993DA9CED98253A41EC19516A1DFD9C92BAFB27D ();
// 0x00000191 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sampleFrequency(System.Int32)
extern void XRRayInteractor_set_sampleFrequency_m0B07A62D1C556DF31298DF6E04EAE2A769CAAAD1 ();
// 0x00000192 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_HitDetectionType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hitDetectionType()
extern void XRRayInteractor_get_hitDetectionType_m30BCCEB490FD32892428BBBC1C1EC56416328310 ();
// 0x00000193 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hitDetectionType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_HitDetectionType)
extern void XRRayInteractor_set_hitDetectionType_mA5AF55C15AC9302F4F9087100871185EE0BF6B1E ();
// 0x00000194 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sphereCastRadius()
extern void XRRayInteractor_get_sphereCastRadius_mED19AD64F61D5413B5BFEA77E9E3F50AB7FEDB79 ();
// 0x00000195 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sphereCastRadius(System.Single)
extern void XRRayInteractor_set_sphereCastRadius_m2B9599081095234B9E066A2D656D6B644D6CFC20 ();
// 0x00000196 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastMask()
extern void XRRayInteractor_get_raycastMask_m285AC79024FF906CC7FA9C69F7F25CAB6A684BBE ();
// 0x00000197 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastMask(UnityEngine.LayerMask)
extern void XRRayInteractor_set_raycastMask_mD417643CD49C5D1CB73F40F00D107B9ACF6DB7E5 ();
// 0x00000198 UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastTriggerInteraction()
extern void XRRayInteractor_get_raycastTriggerInteraction_m3D21554D90B3D75F3B67CAB459432B19AD415A03 ();
// 0x00000199 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void XRRayInteractor_set_raycastTriggerInteraction_mCBB1567CB7CC52711B85A47DD6D3B2F2108F23E5 ();
// 0x0000019A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverToSelect()
extern void XRRayInteractor_get_hoverToSelect_m9B985C38B0C7905CEAB8752E690F76B2F21A88EE ();
// 0x0000019B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverToSelect(System.Boolean)
extern void XRRayInteractor_set_hoverToSelect_m4F985CDB474B582030AA85B93F76BDF00815CCC8 ();
// 0x0000019C System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverTimeToSelect()
extern void XRRayInteractor_get_hoverTimeToSelect_m90834E31EB97172737F150609F7413C0B9482C1A ();
// 0x0000019D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverTimeToSelect(System.Single)
extern void XRRayInteractor_set_hoverTimeToSelect_mDE2CA372995D5A0AC79A39BF62711581A7B06690 ();
// 0x0000019E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_enableUIInteraction()
extern void XRRayInteractor_get_enableUIInteraction_m821A148D23F18A1782765EBBCBD0BB2E7C790CC1 ();
// 0x0000019F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_enableUIInteraction(System.Boolean)
extern void XRRayInteractor_set_enableUIInteraction_m6C0841923B80991EE009F1699D02610B211CBA15 ();
// 0x000001A0 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Angle()
extern void XRRayInteractor_get_Angle_mB52BA01355416A79BB43795B6FBEDCB98040C0BB ();
// 0x000001A1 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_ValidTargets()
extern void XRRayInteractor_get_ValidTargets_m0A4F2287A0ED9829D930C91568EAB060AE8AD7E5 ();
// 0x000001A2 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_m_StartTransform()
extern void XRRayInteractor_get_m_StartTransform_mF3FF8BE0CF9B8A70A7DB3B6DEE49C862C249EB7E ();
// 0x000001A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RebuildSamplePoints()
extern void XRRayInteractor_RebuildSamplePoints_mA12051974A132F73638084F5DA9444DA59962B76 ();
// 0x000001A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindOrCreateXRUIInputModule()
extern void XRRayInteractor_FindOrCreateXRUIInputModule_m6C7E97B899EBBB52BE0D57C2694FF0FEBA10D266 ();
// 0x000001A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnEnable()
extern void XRRayInteractor_OnEnable_mBA6F5370C4AFE61B54E80FF3C0ECCAC324EE3159 ();
// 0x000001A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnDisable()
extern void XRRayInteractor_OnDisable_mE4732DE5B5EE56A6C47BA563AD0CF58BF1E70F6B ();
// 0x000001A7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
extern void XRRayInteractor_GetLinePoints_m9735576EA4917C96A841A642608B86DF2915EE7B ();
// 0x000001A8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
extern void XRRayInteractor_TryGetHitInfo_m3DFF9A5E6E6032A189181AA6FD391B105933AAE9 ();
// 0x000001A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_UpdateUIModel_m5AC12E1086A92D5DC240F4707616F3D03A797968 ();
// 0x000001AA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_TryGetUIModel_m2C1C217D1BDBBEFDA32D23473A3E641466CE0EF3 ();
// 0x000001AB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetCurrentRaycastHit(UnityEngine.RaycastHit&)
extern void XRRayInteractor_GetCurrentRaycastHit_m1629DCCB648079BBFE80C45317AA7B750751605B ();
// 0x000001AC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetCurrentUIRaycastResult(UnityEngine.EventSystems.RaycastResult&,System.Int32&)
extern void XRRayInteractor_GetCurrentUIRaycastResult_m99F49842196B1AF29127F16EDA58932A76382E21 ();
// 0x000001AD System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateControlPoints()
extern void XRRayInteractor_UpdateControlPoints_m067571721401422ECAF256F4432A3136A3D9E1AA ();
// 0x000001AE UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CalculateBezierPoint(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_CalculateBezierPoint_m3163B78D83E67565E8EBF0F852015D6981C3E954 ();
// 0x000001AF UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CalculateProjectilePoint(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_CalculateProjectilePoint_m10200BF900130144930C8580E7F47DE2FF9ED608 ();
// 0x000001B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindReferenceFrame()
extern void XRRayInteractor_FindReferenceFrame_mF3227A07A39CAB1B462421953E1D8E111A6B91A7 ();
// 0x000001B1 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRRayInteractor_ProcessInteractor_m304BBCD520BED85920893C7A3537DA0599FFDAA2 ();
// 0x000001B2 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CheckCollidersBetweenPoints(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_CheckCollidersBetweenPoints_m73B5EC8B3BD6E3D0D6D90C9E57AFDDEE8F98D653 ();
// 0x000001B3 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRRayInteractor_GetValidTargets_mD2C50F88BA3F905357C5D70072C800CAF9ACB2D2 ();
// 0x000001B4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanHover_mC4EB027D09FF38A796E8C3A00FBB74B31FB6B462 ();
// 0x000001B5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanSelect_m6089433C736EF15DAD54CD02BAD1ACB8E6107003 ();
// 0x000001B6 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::.ctor()
extern void XRRayInteractor__ctor_m433214E833E8EC0D7CA6D47354F435AC87D2703C ();
// 0x000001B7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_showInteractableHoverMeshes()
extern void XRSocketInteractor_get_showInteractableHoverMeshes_mEB1DF83F62CCE06D1CF062FD112F5255B9E109A9 ();
// 0x000001B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_showInteractableHoverMeshes(System.Boolean)
extern void XRSocketInteractor_set_showInteractableHoverMeshes_mC61590004B3774828104B4F1CDB23F458D2673A9 ();
// 0x000001B9 UnityEngine.Material UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverMeshMaterial()
extern void XRSocketInteractor_get_interactableHoverMeshMaterial_mEDA7A7C7743746CB9219018FAE3E8FDE87864D47 ();
// 0x000001BA System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverMeshMaterial(UnityEngine.Material)
extern void XRSocketInteractor_set_interactableHoverMeshMaterial_m46A16B36DF990A4B31B625C671DEEE2F1339766B ();
// 0x000001BB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_socketActive()
extern void XRSocketInteractor_get_socketActive_m8629C92707FCD8DED816AE64EF929E07EBEAB399 ();
// 0x000001BC System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_socketActive(System.Boolean)
extern void XRSocketInteractor_set_socketActive_mF223A5ACD38EDE357BED6CB77E9AE1FDD40FE371 ();
// 0x000001BD System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverScale()
extern void XRSocketInteractor_get_interactableHoverScale_mBE4CA2E7BC9470068C4D9B1DE679E18240A50D6E ();
// 0x000001BE System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverScale(System.Single)
extern void XRSocketInteractor_set_interactableHoverScale_m7A3E7229DE0881A7BE788BEF57F49714E5489130 ();
// 0x000001BF System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_recycleDelayTime()
extern void XRSocketInteractor_get_recycleDelayTime_mA779E8DCCA14636DFD812DCE7A52DD1D792D7F48 ();
// 0x000001C0 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_recycleDelayTime(System.Single)
extern void XRSocketInteractor_set_recycleDelayTime_mA76B7D29AE438D4554A405D0AB843592B8547252 ();
// 0x000001C1 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::InteractableSortComparison(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_InteractableSortComparison_mE1085975C84578503975834D933053CDC608D610 ();
// 0x000001C2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::Awake()
extern void XRSocketInteractor_Awake_m3249DE7BA9575FE08C854F8C34820266CC50FDB2 ();
// 0x000001C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_OnHoverEnter_m3B4A036366DC7D742EA67E04464145DDA8FDD9B7 ();
// 0x000001C4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_OnHoverExit_m2B0F734395998BD1224FB038AC6BBB7DF94B5A81 ();
// 0x000001C5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_OnSelectExit_m6C23A0B6A2A23965D0D2B3837F9504D98FFC2D83 ();
// 0x000001C6 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRSocketInteractor_ProcessInteractor_m913CC4783E116E7919A13BF6607F839B6A3D5231 ();
// 0x000001C7 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerEnter_m312DD6E7D953F60A281C365CC133B23D8222A1CC ();
// 0x000001C8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerExit_m9BC079A9A7FC389D5AFAEF6402CCAA01A7CAE6CD ();
// 0x000001C9 UnityEngine.Matrix4x4 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetInteractableAttachMatrix(UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable,UnityEngine.Vector3)
extern void XRSocketInteractor_GetInteractableAttachMatrix_mF9A504406BC409C69D89A5EBE442C1E5EC7E34E0 ();
// 0x000001CA System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::DrawHoveredInteractables()
extern void XRSocketInteractor_DrawHoveredInteractables_m0AC6B350CB492FBB75DE5FBCFA5FD9DB67FBFFF2 ();
// 0x000001CB System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRSocketInteractor_GetValidTargets_m9C01C78D9AC32A77F26D06D09C2BD1D2B795D02F ();
// 0x000001CC System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isHoverActive()
extern void XRSocketInteractor_get_isHoverActive_m6421AC6A23A3F5EF467222E35C62A08013188D5C ();
// 0x000001CD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isSelectActive()
extern void XRSocketInteractor_get_isSelectActive_m4F3AE351A49F23F85B31840FA7C2E33321498F13 ();
// 0x000001CE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_requireSelectExclusive()
extern void XRSocketInteractor_get_requireSelectExclusive_m8DC1D4332B735BF16EC6A31A0798CE192BAEAEA3 ();
// 0x000001CF System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable_MovementType> UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRSocketInteractor_get_selectedInteractableMovementTypeOverride_m0618F1F3E7145F23FA3ADEAE1D012A2622226F76 ();
// 0x000001D0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanSelect_mFB810DEAA003C5253211A45476DA644C0B0BF99B ();
// 0x000001D1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanHover_m5719EF6ADCF67346B0473E90A1B37C98221C2970 ();
// 0x000001D2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::.ctor()
extern void XRSocketInteractor__ctor_mB0085D92313C64FE397CA8C8C1384F6F62977CAB ();
// 0x000001D3 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::get_interactors()
extern void XRInteractionManager_get_interactors_m75F118A92316AFA60642DD5DF0DC0FDA310E12DA ();
// 0x000001D4 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::get_interactables()
extern void XRInteractionManager_get_interactables_m46ED191A4D547C7384FCB9F3FC992C213E30F5D5 ();
// 0x000001D5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnEnable()
extern void XRInteractionManager_OnEnable_m405111A8E472033A1F24E66FB5705D38E559BF88 ();
// 0x000001D6 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnDisable()
extern void XRInteractionManager_OnDisable_m9B22A64A3F161F1B805B72ED8384A886820F99AE ();
// 0x000001D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnBeforeRender()
extern void XRInteractionManager_OnBeforeRender_m4BB1422C4AAFCFFFD54C4AD32F3C1BB47A28C525 ();
// 0x000001D8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractors(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRInteractionManager_ProcessInteractors_mBD9C5510D94031B548509CC2865E0EC7BC94C30A ();
// 0x000001D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractables(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder_UpdatePhase)
extern void XRInteractionManager_ProcessInteractables_m9D527F569EA357546BAC71A0592684F251291FC0 ();
// 0x000001DA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::LateUpdate()
extern void XRInteractionManager_LateUpdate_m5E3864D93DD0E4E2572C37AABD798D70494B6306 ();
// 0x000001DB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::FixedUpdate()
extern void XRInteractionManager_FixedUpdate_m71F4117FCA47B4FA1AADAD795E15940479D512F7 ();
// 0x000001DC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::Update()
extern void XRInteractionManager_Update_m1741D3A77E5129A979C62D95C63C9BBDA73FCD8F ();
// 0x000001DD System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_RegisterInteractor_m44ADA7384A1E08BF7ABFD1615CED287034068205 ();
// 0x000001DE System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_UnregisterInteractor_mEF83EB5FFB8B3FEB0E317A7B37AD9202C35A85CF ();
// 0x000001DF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_RegisterInteractable_m81AF897E7E94C539A9A6A2BDDB0AF57F671584BE ();
// 0x000001E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_UnregisterInteractable_mEC5E5DA8AF2FF275C2942AC77A460997669E1A8F ();
// 0x000001E1 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::TryGetInteractableForCollider(UnityEngine.Collider)
extern void XRInteractionManager_TryGetInteractableForCollider_mB8869F30597BE71571F7540DF4E946F4127CC05B ();
// 0x000001E2 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_GetValidTargets_mE6B61F09D67079A619256E89104E7B264B7F5755 ();
// 0x000001E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ForceSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_ForceSelect_m444C94DFCC4D8CB9D95A7DBB240C854EA23C427D ();
// 0x000001E4 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_ClearInteractorSelection_m3B3884EBC998389C72456AEBC5CEFF04FE741C84 ();
// 0x000001E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_ClearInteractorHover_mC90678CA15B445FFE8BA3026BC9FB208DCD0B520 ();
// 0x000001E6 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectEnter_mB91BCE65D82FC7589053F69B27084A1F8C5FAC15 ();
// 0x000001E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectExit_m4266F182D5396FAD3409ECE4C8D7DE61BB867078 ();
// 0x000001E8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverEnter_mC051716D4C05FF94A1410DBB5E9AE59CDDC71C1C ();
// 0x000001E9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverExit_m74A5704B91D15BA067E4FF2537337DD62F270073 ();
// 0x000001EA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorSelectValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorSelectValidTargets_mAF3592E3D5F8CF6BA2CB0A7F3443CA6740A32D46 ();
// 0x000001EB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorHoverValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorHoverValidTargets_mB562C96BC84F091D3E4022D6D973A302F95E9962 ();
// 0x000001EC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::.ctor()
extern void XRInteractionManager__ctor_m30F956C2FF9995AA89F349C10A6FF2A2050BFDAA ();
// 0x000001ED UnityEngine.XR.Interaction.Toolkit.LocomotionSystem UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::get_system()
extern void LocomotionProvider_get_system_m90AC7397FFA3D20AF8997986D070C25157E12202 ();
// 0x000001EE System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::set_system(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void LocomotionProvider_set_system_mD14CD68037C09DF8034D4A49F3C2F057437D448C ();
// 0x000001EF System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::Awake()
extern void LocomotionProvider_Awake_m319D924047BCDAF59A49FDE34D6A2484EBDC721E ();
// 0x000001F0 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::CanBeginLocomotion()
extern void LocomotionProvider_CanBeginLocomotion_m7474CB758B89D29EF1AA97790BEAFBC78C4A8689 ();
// 0x000001F1 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::BeginLocomotion()
extern void LocomotionProvider_BeginLocomotion_m89820B0677BC57D861FC5F83296EE379E9C278B4 ();
// 0x000001F2 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::EndLocomotion()
extern void LocomotionProvider_EndLocomotion_m04D2B0759DBE4B478C97A8FC2B913E534B169F89 ();
// 0x000001F3 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_startLocomotion_mCFF63EAFC37996ABF906AE4F8BEB1DF7B009BA64 ();
// 0x000001F4 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_startLocomotion_mE5C113C124FB0792043E7E009A1A36870B12192E ();
// 0x000001F5 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_endLocomotion_m71E025814D3F746CB15A187CD26604939335C6C7 ();
// 0x000001F6 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_endLocomotion_m6F24729D33471877E901B54EE0E3C016F3D79B40 ();
// 0x000001F7 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::.ctor()
extern void LocomotionProvider__ctor_mA9AB6ECD039DBD874A605B02A6BA4B4A5095F2BD ();
// 0x000001F8 System.Single UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_timeout()
extern void LocomotionSystem_get_timeout_m4295FF47DC39F04627416F8B8F668E97B835F56E ();
// 0x000001F9 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_timeout(System.Single)
extern void LocomotionSystem_set_timeout_mED341E185C0E190974D7D662E7C0ECECB01654F3 ();
// 0x000001FA UnityEngine.XR.Interaction.Toolkit.XRRig UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_xrRig()
extern void LocomotionSystem_get_xrRig_m1B83D3792E057D7FECD7F6860FD402A11EA7C670 ();
// 0x000001FB System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_xrRig(UnityEngine.XR.Interaction.Toolkit.XRRig)
extern void LocomotionSystem_set_xrRig_m2466A078FF131165F9D2F21D15D001279CDF2F6B ();
// 0x000001FC System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_Busy()
extern void LocomotionSystem_get_Busy_mE14AC351FCB03E9D7BA392B59EA22846C6BB657A ();
// 0x000001FD UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::RequestExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_RequestExclusiveOperation_mE63F786E28C3D73F03F561E7E7A8677E1FEF7D9A ();
// 0x000001FE System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::ResetExclusivity()
extern void LocomotionSystem_ResetExclusivity_m02A942B4641B4C4870AD4A67CB49F2F28E8C7614 ();
// 0x000001FF UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::FinishExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_FinishExclusiveOperation_m0823B3BE4524830F038C39C761C2BC95847CF731 ();
// 0x00000200 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Update()
extern void LocomotionSystem_Update_m716EC5E445CBF55CFA1DB65D369022A0DB0FE2F2 ();
// 0x00000201 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Awake()
extern void LocomotionSystem_Awake_m3C61E3D8AA130EE36CC34D63E3270E9C40C4B2EA ();
// 0x00000202 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::.ctor()
extern void LocomotionSystem__ctor_m69F7336A303E0D6B3CC183D02DD6057CC1B7318A ();
// 0x00000203 UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider_InputAxes UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::get_turnUsage()
extern void SnapTurnProvider_get_turnUsage_m9A7456252FE66E68C5D633F928631DB11C07CE36 ();
// 0x00000204 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::set_turnUsage(UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider_InputAxes)
extern void SnapTurnProvider_set_turnUsage_m7EC96F46E738AC17B95F1EC8E6BC1C31DF674C2A ();
// 0x00000205 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRController> UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::get_controllers()
extern void SnapTurnProvider_get_controllers_mFC1625466FD1E13DE9089FC4786CB68DF19C58B6 ();
// 0x00000206 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRController>)
extern void SnapTurnProvider_set_controllers_m7D43866D48660809BC1D6497A467A6935E12421D ();
// 0x00000207 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::get_turnAmount()
extern void SnapTurnProvider_get_turnAmount_mDA81670D5FFEAEE73131B53C871F3357A3BB7625 ();
// 0x00000208 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::set_turnAmount(System.Single)
extern void SnapTurnProvider_set_turnAmount_m779DD8B8F95DF60E7B8E7056FBDD5D33FC3C44B0 ();
// 0x00000209 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::get_debounceTime()
extern void SnapTurnProvider_get_debounceTime_mD099EFC88D0543E3E49E8D0E54E5DFB3F5F65E48 ();
// 0x0000020A System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::set_debounceTime(System.Single)
extern void SnapTurnProvider_set_debounceTime_m9E634BB99F4193DDC417F911ED000E25B77744B7 ();
// 0x0000020B System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::get_deadZone()
extern void SnapTurnProvider_get_deadZone_m1FD6F324B136B3AB40B6B63AFEBCE10751BFBF21 ();
// 0x0000020C System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::set_deadZone(System.Single)
extern void SnapTurnProvider_set_deadZone_mA5102E3A68E6C0FB97680AF1272B6F6BF4840D8A ();
// 0x0000020D System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::Update()
extern void SnapTurnProvider_Update_mAA48D563873E5DAA50472CA9F33886FAC7E5A945 ();
// 0x0000020E System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::EnsureControllerDataListSize()
extern void SnapTurnProvider_EnsureControllerDataListSize_mCC2C823B78A132510AC4B82B62E8B45060C0FD2B ();
// 0x0000020F System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::FakeStartTurn(System.Boolean)
extern void SnapTurnProvider_FakeStartTurn_mB7B5E4483B2A369DFC73EEB5535553D474BCF7A4 ();
// 0x00000210 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::StartTurn(System.Single)
extern void SnapTurnProvider_StartTurn_mD5E37AB69B4C9A39B9EE51801E060750AD23CD63 ();
// 0x00000211 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::.ctor()
extern void SnapTurnProvider__ctor_m4023B7462EA0BED60E21C2F854382788D17663C1 ();
// 0x00000212 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProvider::.cctor()
extern void SnapTurnProvider__cctor_m7183A1445A27BFABFFEE79E366521B4CA3902806 ();
// 0x00000213 UnityEngine.XR.Interaction.Toolkit.TeleportationProvider UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportationProvider()
extern void BaseTeleportationInteractable_get_teleportationProvider_mEB5F711AEA32E94584895626496838A398EAA8CD ();
// 0x00000214 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportationProvider(UnityEngine.XR.Interaction.Toolkit.TeleportationProvider)
extern void BaseTeleportationInteractable_set_teleportationProvider_m6569BF87EF7DD8D99FFA2A3F038E8D460BA74D26 ();
// 0x00000215 UnityEngine.XR.Interaction.Toolkit.MatchOrientation UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_matchOrientation()
extern void BaseTeleportationInteractable_get_matchOrientation_m225912F45B1FEF3A1B72E1A97E3A2FB74C09C0C2 ();
// 0x00000216 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_matchOrientation(UnityEngine.XR.Interaction.Toolkit.MatchOrientation)
extern void BaseTeleportationInteractable_set_matchOrientation_m190F2D4F391326F04F7147DD402478CF242B0E03 ();
// 0x00000217 UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable_TeleportTrigger UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportTrigger()
extern void BaseTeleportationInteractable_get_teleportTrigger_mE6F011E002849389B186C18E26AC6B1C5D8003FE ();
// 0x00000218 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportTrigger(UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable_TeleportTrigger)
extern void BaseTeleportationInteractable_set_teleportTrigger_m5DEA8F17C83662D2FAF502F6BF2C521E9325E388 ();
// 0x00000219 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::Awake()
extern void BaseTeleportationInteractable_Awake_m134F34477CD14CD67A0797B26D4F74AA849D7A5B ();
// 0x0000021A System.Boolean UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void BaseTeleportationInteractable_GenerateTeleportRequest_mDC785801939118EC5360284EF76CD34CF9741CAA ();
// 0x0000021B System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::SendTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_SendTeleportRequest_m098E54A8C71EFA83CB91A531177EE1064440A4D6 ();
// 0x0000021C System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_OnSelectEnter_m26607CCBC4B600DFBCD2D537D55A8CAB2939545C ();
// 0x0000021D System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_OnSelectExit_mF3942411DE00BA86260134262B5FA775C9809CAF ();
// 0x0000021E System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnActivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_OnActivate_m1E35E2D40EFAEB185BC6AEC65796B97F84D86360 ();
// 0x0000021F System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnDeactivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseTeleportationInteractable_OnDeactivate_m099EE523E74506D53A31224E62A7E371D2177F67 ();
// 0x00000220 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::.ctor()
extern void BaseTeleportationInteractable__ctor_m4F0BBD2EBF8F6A0DEAE96763AE817A1F3055E404 ();
// 0x00000221 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::get_teleportAnchorTransform()
extern void TeleportationAnchor_get_teleportAnchorTransform_m6B549D02B8F75DFEBBEBE5E62CE5DC3AA3129ABB ();
// 0x00000222 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::set_teleportAnchorTransform(UnityEngine.Transform)
extern void TeleportationAnchor_set_teleportAnchorTransform_mCA4A86C9278E39B14A055532294FD6256A2927B9 ();
// 0x00000223 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnValidate()
extern void TeleportationAnchor_OnValidate_m9F822017731812291A11EA3302F9F33A4FAA092D ();
// 0x00000224 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationAnchor_GenerateTeleportRequest_m4F2DABFE22673CB2FD1662AF3DCBC0FA4A8E977C ();
// 0x00000225 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnDrawGizmos()
extern void TeleportationAnchor_OnDrawGizmos_mB7657FFFEFD993F91EA0339A982E2D61A12F5DFA ();
// 0x00000226 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::.ctor()
extern void TeleportationAnchor__ctor_m2EF32665CB4536C9BCB3D919496F37AAC9609861 ();
// 0x00000227 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationArea::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationArea_GenerateTeleportRequest_mF92C0C18328D0C5AD6E88EBA19F7E9DA7D9CB748 ();
// 0x00000228 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationArea::.ctor()
extern void TeleportationArea__ctor_m5D357C613A823E2C47B7382BB36E9BFC9834D9C0 ();
// 0x00000229 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::QueueTeleportRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportationProvider_QueueTeleportRequest_mDAAC9DEEA62DF4317F333093C36B0D31D57FD349 ();
// 0x0000022A System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::Update()
extern void TeleportationProvider_Update_m217AE96751464DF400B89AADDB8FFACB8005A73C ();
// 0x0000022B System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::.ctor()
extern void TeleportationProvider__ctor_m759A4088CA464F0681131E18F6A80139BEC6ECBA ();
// 0x0000022C System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWirePlaneOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWirePlaneOriented_m6EECE8744365F829183E391CBC7B33A46105E38E ();
// 0x0000022D System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWireCubeOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWireCubeOriented_m3E9BD666956DD13D3D98F4510C6A26269B83AAD4 ();
// 0x0000022E System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawAxisArrows(UnityEngine.Transform,System.Single)
extern void GizmoHelpers_DrawAxisArrows_m1CC0C0842A992FE53EE3C08D99FAE169A8A52B6F ();
// 0x0000022F System.Void UnityEngine.XR.Interaction.Toolkit.SortingHelpers::Sort(System.Collections.Generic.IList`1<T>,System.Collections.Generic.IComparer`1<T>)
// 0x00000230 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_rig()
extern void XRRig_get_rig_m16325CCB21390B2F05097C4C6F65F490A1460AC1 ();
// 0x00000231 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_rig(UnityEngine.GameObject)
extern void XRRig_set_rig_m721C4F2D42B03FE1DC3BEC3D82C4BE885C68572A ();
// 0x00000232 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraFloorOffsetObject()
extern void XRRig_get_cameraFloorOffsetObject_mF76C3E61CD4F1CB19BAF6D5FE2F948B3A264138E ();
// 0x00000233 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraFloorOffsetObject(UnityEngine.GameObject)
extern void XRRig_set_cameraFloorOffsetObject_m4A379E04866CCBADA19BEEE0BBC523E65AEAF6CC ();
// 0x00000234 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraGameObject()
extern void XRRig_get_cameraGameObject_m58F01423014802922928F6165F62B8A163EBFDD9 ();
// 0x00000235 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraGameObject(UnityEngine.GameObject)
extern void XRRig_set_cameraGameObject_m1C2E7F341DADC16F70FE753174646410E51159DF ();
// 0x00000236 UnityEngine.XR.TrackingOriginModeFlags UnityEngine.XR.Interaction.Toolkit.XRRig::get_TrackingOriginMode()
extern void XRRig_get_TrackingOriginMode_m54511194C3D4C5BE8340A4E065A5EA15A377504A ();
// 0x00000237 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_TrackingOriginMode(UnityEngine.XR.TrackingOriginModeFlags)
extern void XRRig_set_TrackingOriginMode_mACA37604EBF27AA71AB6376616DC1DEEE0A69B7E ();
// 0x00000238 UnityEngine.XR.TrackingSpaceType UnityEngine.XR.Interaction.Toolkit.XRRig::get_trackingSpace()
extern void XRRig_get_trackingSpace_m345A00507105ED4565806FB1F97D57EBC83B4E44 ();
// 0x00000239 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_trackingSpace(UnityEngine.XR.TrackingSpaceType)
extern void XRRig_set_trackingSpace_m8441778B808263BB0D5ABD718F8E99BE8471F7BF ();
// 0x0000023A System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraYOffset()
extern void XRRig_get_cameraYOffset_m72B07E4CD490EC94A1644DBFF5D0AEA4AA3625B5 ();
// 0x0000023B System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraYOffset(System.Single)
extern void XRRig_set_cameraYOffset_mE6842FFAAEC9ACA0F2030FC81BA16DE77375FC2E ();
// 0x0000023C UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_rigInCameraSpacePos()
extern void XRRig_get_rigInCameraSpacePos_m766D7B43281AE0F1A68CCDAE970FBF9EE4A15158 ();
// 0x0000023D UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpacePos()
extern void XRRig_get_cameraInRigSpacePos_m828B57CD2B58880E88C035D391D2FA6A1136EE2C ();
// 0x0000023E System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpaceHeight()
extern void XRRig_get_cameraInRigSpaceHeight_m63D3D88E75333D88893ABDA7165B4A07AF04A425 ();
// 0x0000023F System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::UpgradeTrackingSpaceToTrackingOriginMode()
extern void XRRig_UpgradeTrackingSpaceToTrackingOriginMode_m53C631EF6951E0BD2EE03735488804E122B121E6 ();
// 0x00000240 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::Awake()
extern void XRRig_Awake_m176BFD1464875C44DE4AB16AD32ECAA0000F2E23 ();
// 0x00000241 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::Start()
extern void XRRig_Start_m6E291BE00FD73FFA55DE55997E1BCF297FF361B6 ();
// 0x00000242 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnValidate()
extern void XRRig_OnValidate_m51A585563F541461E88A97C0FAF4695CFFEFA0D8 ();
// 0x00000243 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::TryInitializeCamera()
extern void XRRig_TryInitializeCamera_m759EAF84AE8A2E0FADB1DE2E675E27F872897081 ();
// 0x00000244 System.Collections.IEnumerator UnityEngine.XR.Interaction.Toolkit.XRRig::RepeatInitializeCamera()
extern void XRRig_RepeatInitializeCamera_m3BB00D7AC6298C3BFD17D0B463E8A505ACC3CC99 ();
// 0x00000245 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCamera()
extern void XRRig_SetupCamera_m5BDFED6B914201E66B56CBE08D1129E59942D77D ();
// 0x00000246 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCamera(UnityEngine.XR.XRInputSubsystem)
extern void XRRig_SetupCamera_m73A1C1692C1A9A3F09F6ECD04BBC84BF775BDE68 ();
// 0x00000247 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::SetupCameraLegacy(UnityEngine.XR.TrackingSpaceType)
extern void XRRig_SetupCameraLegacy_mB8A78374B8B9F7AF022D457672B6EE548B910512 ();
// 0x00000248 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::RotateAroundCameraUsingRigUp(System.Single)
extern void XRRig_RotateAroundCameraUsingRigUp_m31B8B16233AB236895D6AEC1B4AE71AE967824C8 ();
// 0x00000249 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::RotateAroundCameraPosition(UnityEngine.Vector3,System.Single)
extern void XRRig_RotateAroundCameraPosition_m6E18880AC86ABDB423C768D32C292527E2F13998 ();
// 0x0000024A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUp(UnityEngine.Vector3)
extern void XRRig_MatchRigUp_mAE3E4F54FF27D95814987AE6929FB469C2286781 ();
// 0x0000024B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpCameraForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpCameraForward_mA3785D2FE29B8EEDCD3ED57F5B47B648011C976E ();
// 0x0000024C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpRigForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpRigForward_m3C619295B2360F70D6650D8C3CB7422C7DE5DC81 ();
// 0x0000024D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MoveCameraToWorldLocation(UnityEngine.Vector3)
extern void XRRig_MoveCameraToWorldLocation_m3CA8830E78C9E1629AE6063D33A13B9B78F7A321 ();
// 0x0000024E System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::OnDrawGizmos()
extern void XRRig_OnDrawGizmos_m196320CF05C3CC7FB53FA86E42E93516FB1EA276 ();
// 0x0000024F System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::.ctor()
extern void XRRig__ctor_m28B554D72F651B49BA9CFE7AB824ED49EB68289F ();
// 0x00000250 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::.cctor()
extern void XRRig__cctor_mB25B8E2255EE3AD909FD5EBF84C63689924D43BD ();
// 0x00000251 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_move()
extern void JoystickModel_get_move_m83D23C958A1CA351FDA91DDC1BCE94D92B13C4B2_AdjustorThunk ();
// 0x00000252 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_move(UnityEngine.Vector2)
extern void JoystickModel_set_move_m67CCF9D2682BA0A7C7933535927214D515BD553E_AdjustorThunk ();
// 0x00000253 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDown()
extern void JoystickModel_get_submitButtonDown_mF8E0291A4C9B76E7248FAF34A77985A728D015D8_AdjustorThunk ();
// 0x00000254 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDown(System.Boolean)
extern void JoystickModel_set_submitButtonDown_m82D5339F5F822B2362D5298B39D009AE3D25855B_AdjustorThunk ();
// 0x00000255 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDelta()
extern void JoystickModel_get_submitButtonDelta_m54A995391CF613E8E6E598A20E6AA2C344F6240A_AdjustorThunk ();
// 0x00000256 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_submitButtonDelta_m5A50252E0DE0EFC991983AEDB4772A37F01D0D1B_AdjustorThunk ();
// 0x00000257 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDown()
extern void JoystickModel_get_cancelButtonDown_m68DB46ED9CAB5AF12DB9371E5E97C752B0E9EC75_AdjustorThunk ();
// 0x00000258 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDown(System.Boolean)
extern void JoystickModel_set_cancelButtonDown_m242CF5590457AC603A56F77D1626C0A1552E1BBB_AdjustorThunk ();
// 0x00000259 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDelta()
extern void JoystickModel_get_cancelButtonDelta_mDABC96B31605F56420E31478974E4EF16EA1C789_AdjustorThunk ();
// 0x0000025A System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_cancelButtonDelta_mCF2503FB0CDE8CB46E11C5087739BAFA24443B0F_AdjustorThunk ();
// 0x0000025B UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_implementationData()
extern void JoystickModel_get_implementationData_mB685AA91E6CB3036F206E465C5B93489620DF56A_AdjustorThunk ();
// 0x0000025C System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_implementationData(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData)
extern void JoystickModel_set_implementationData_mA4E28DB4A98DEF4889934E02DB94E2F6C389ED6C_AdjustorThunk ();
// 0x0000025D System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::Reset()
extern void JoystickModel_Reset_mFCD687DCA07667BE4FF1FFF30E80F50FC71E6124_AdjustorThunk ();
// 0x0000025E System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::OnFrameFinished()
extern void JoystickModel_OnFrameFinished_m8D2B8F1FA6A00BF63B7AC1B272AC2FB110E05549_AdjustorThunk ();
// 0x0000025F System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_isDown()
extern void MouseButtonModel_get_isDown_m27AEA5948516023FD5BC83C295C5F8CE5DDE7253_AdjustorThunk ();
// 0x00000260 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_isDown(System.Boolean)
extern void MouseButtonModel_set_isDown_m053FFB273E8260E67C3135F8AC2E4816299A2906_AdjustorThunk ();
// 0x00000261 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_lastFrameDelta()
extern void MouseButtonModel_get_lastFrameDelta_mD2C353F9AFCFBFA9DA8EA887D0873E2AAB69276C_AdjustorThunk ();
// 0x00000262 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_lastFrameDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void MouseButtonModel_set_lastFrameDelta_mBA68F356F664D2271EB72FFB6B549854C7A18B05_AdjustorThunk ();
// 0x00000263 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::Reset()
extern void MouseButtonModel_Reset_mDF3588426BD02B4C3FBABE9C87DF64CECC6D96B8_AdjustorThunk ();
// 0x00000264 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::OnFrameFinished()
extern void MouseButtonModel_OnFrameFinished_m66902D752AF7E920EA1480BCA81E82120134E800_AdjustorThunk ();
// 0x00000265 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyTo_m448E4998CE711E120CF69D14E944702EC047EAC2_AdjustorThunk ();
// 0x00000266 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyFrom_m513879AD7C7FBC253EE932BE1DDF29AD9F8C4847_AdjustorThunk ();
// 0x00000267 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_pointerId()
extern void MouseModel_get_pointerId_mD24BC7D61DB8530DF7E7866EEB238E30EA8DB3A3_AdjustorThunk ();
// 0x00000268 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_pointerId(System.Int32)
extern void MouseModel_set_pointerId_m827301A0CFAF0D73BB6BFDE3AFC1872586BA65C4_AdjustorThunk ();
// 0x00000269 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_changedThisFrame()
extern void MouseModel_get_changedThisFrame_m83E45A1F90A7672359F6BCA794B03FD5DEDF6AF8_AdjustorThunk ();
// 0x0000026A System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_changedThisFrame(System.Boolean)
extern void MouseModel_set_changedThisFrame_m833F02659D05EE961CB3D89C9B045C9BD6659381_AdjustorThunk ();
// 0x0000026B UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_position()
extern void MouseModel_get_position_m275B4E5FF92FF4B7DD3A24BEDDA0AD070C86A233_AdjustorThunk ();
// 0x0000026C System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_position(UnityEngine.Vector2)
extern void MouseModel_set_position_mC9F5908867CCEB392DE438B763D36E2590D66AD7_AdjustorThunk ();
// 0x0000026D UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_deltaPosition()
extern void MouseModel_get_deltaPosition_m0252301FD99EAFF1E6A3F889CE6B87D6069613A9_AdjustorThunk ();
// 0x0000026E System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_deltaPosition(UnityEngine.Vector2)
extern void MouseModel_set_deltaPosition_m5F9E7D8DF5D830349667379EFB2EFF953E4201C1_AdjustorThunk ();
// 0x0000026F UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_scrollPosition()
extern void MouseModel_get_scrollPosition_mD7296784A7A3B958AD04D2AC5E86207D71F86DC1_AdjustorThunk ();
// 0x00000270 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_scrollPosition(UnityEngine.Vector2)
extern void MouseModel_set_scrollPosition_mF26341BC9EB8E33AE297B1FFD22148192054B8E6_AdjustorThunk ();
// 0x00000271 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_scrollDelta()
extern void MouseModel_get_scrollDelta_m2E0953E7F952AA3E3ADFE2B0F9E4C6ABBC9F42F6_AdjustorThunk ();
// 0x00000272 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_scrollDelta(UnityEngine.Vector2)
extern void MouseModel_set_scrollDelta_m739DF6E3D48621581393AF9531384BFBAC890C48_AdjustorThunk ();
// 0x00000273 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_leftButton()
extern void MouseModel_get_leftButton_m358F56DE6EB3FC9BAE269CD9E60B8195F0F36763_AdjustorThunk ();
// 0x00000274 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_leftButton_mF39BE4069B31752F6097A443A18C24DC0809982D_AdjustorThunk ();
// 0x00000275 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButtonPressed(System.Boolean)
extern void MouseModel_set_leftButtonPressed_mB8C678C6B8945D252ACB4892D6E7C8EFCD78D442_AdjustorThunk ();
// 0x00000276 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_rightButton()
extern void MouseModel_get_rightButton_m88CDF6C0A0322794B3DDD9BCE2ABC5DEA1575C97_AdjustorThunk ();
// 0x00000277 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_rightButton_mA13E326ABF6838D1D0E3895EF20AAF55C3228CD0_AdjustorThunk ();
// 0x00000278 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButtonPressed(System.Boolean)
extern void MouseModel_set_rightButtonPressed_mCA7F1C430EC0DA33A70E692B164845E30CF89827_AdjustorThunk ();
// 0x00000279 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_middleButton()
extern void MouseModel_get_middleButton_m2B2657CCE63992FFEF84EB1E25FAD18DDA386832_AdjustorThunk ();
// 0x0000027A System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_middleButton_m4F8FB3C4D182877503A61E76E18A9BFF1513DD78_AdjustorThunk ();
// 0x0000027B System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButtonPressed(System.Boolean)
extern void MouseModel_set_middleButtonPressed_m92B40CEA75E9D1EBF5A1AF0EBA3D5EF317861D75_AdjustorThunk ();
// 0x0000027C System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::.ctor(System.Int32)
extern void MouseModel__ctor_m865EDFE56B252E91E12529D55DF75ABEC411E5EF_AdjustorThunk ();
// 0x0000027D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::OnFrameFinished()
extern void MouseModel_OnFrameFinished_m05C103853D5805A20C62F1951FEB605BE6158CF6_AdjustorThunk ();
// 0x0000027E System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyTo_m4E8A9A1FEE6306BD321301FD6E1ABBA09AE0B720_AdjustorThunk ();
// 0x0000027F System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyFrom_m6DBF2507A6D626F18D40EC92E329FDA0105C4179_AdjustorThunk ();
// 0x00000280 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_pointerId()
extern void TouchModel_get_pointerId_mA6FC68848A544FC0AE876902332DB9EE4CEE1CF3_AdjustorThunk ();
// 0x00000281 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_pointerId(System.Int32)
extern void TouchModel_set_pointerId_m2F9D6B74C9BA216895BD6FAB0A0E6C61D72CC230_AdjustorThunk ();
// 0x00000282 UnityEngine.TouchPhase UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectPhase()
extern void TouchModel_get_selectPhase_mD255DA107D39D9CE074A0A29CC90358589C79CB4_AdjustorThunk ();
// 0x00000283 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectPhase(UnityEngine.TouchPhase)
extern void TouchModel_set_selectPhase_mD3B758D0FC5A18DC4420A4F90C45608FB684481C_AdjustorThunk ();
// 0x00000284 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectDelta()
extern void TouchModel_get_selectDelta_m10BC9FDD36A6871BCE00CDD3131F10948D7304C0_AdjustorThunk ();
// 0x00000285 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TouchModel_set_selectDelta_m6F0595ABF1D4234F8BA8001FFF8635A6C2DBBB61_AdjustorThunk ();
// 0x00000286 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_changedThisFrame()
extern void TouchModel_get_changedThisFrame_mAA9FB3230C6F98A025578DD35672E8DB8E2A7F1D_AdjustorThunk ();
// 0x00000287 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_changedThisFrame(System.Boolean)
extern void TouchModel_set_changedThisFrame_mEF07D000500150A199867A20E829FAE9FEB65112_AdjustorThunk ();
// 0x00000288 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_position()
extern void TouchModel_get_position_m7E5ED3942111B4161343CC9ECF76F03472049815_AdjustorThunk ();
// 0x00000289 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_position(UnityEngine.Vector2)
extern void TouchModel_set_position_mA4A6610E16A8E6F81E4971B3C28821865D7F22F6_AdjustorThunk ();
// 0x0000028A UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_deltaPosition()
extern void TouchModel_get_deltaPosition_m253E563DE92BFFB8E545D95A18310D6F7D6493C1_AdjustorThunk ();
// 0x0000028B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_deltaPosition(UnityEngine.Vector2)
extern void TouchModel_set_deltaPosition_m8070333DAA1A905BF67329235CDE3B10332D56E9_AdjustorThunk ();
// 0x0000028C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::.ctor(System.Int32)
extern void TouchModel__ctor_m1918A09071F3AC531A0FD6F02DD0FD6F2E6F1BA5_AdjustorThunk ();
// 0x0000028D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::Reset()
extern void TouchModel_Reset_m66906BC296B4CD66A60AD3A577BE06AF2C94C788_AdjustorThunk ();
// 0x0000028E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::OnFrameFinished()
extern void TouchModel_OnFrameFinished_m78332BE60BA57585C80D830807B0FFD4C5EA60C8_AdjustorThunk ();
// 0x0000028F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyTo_m28A30540806415BDE23C7088EB9AB3CA5D82C668_AdjustorThunk ();
// 0x00000290 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyFrom_mABB6092E8267FB9AB96C9A6EB970F75BB7A7BA82_AdjustorThunk ();
// 0x00000291 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void TrackedDeviceEventData__ctor_m9D000221F4423B7645CAD6ADD0212B6923F094D6 ();
// 0x00000292 System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayPoints()
extern void TrackedDeviceEventData_get_rayPoints_m28D88FDB7E2767AE2768FE4ACEF1139753ADE921 ();
// 0x00000293 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceEventData_set_rayPoints_m9BA0E4D6E45A82995B607F11DA9E04516F090EE1 ();
// 0x00000294 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayHitIndex()
extern void TrackedDeviceEventData_get_rayHitIndex_mCDCCF20598326112CF9841701BC65A9870E59C2F ();
// 0x00000295 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayHitIndex(System.Int32)
extern void TrackedDeviceEventData_set_rayHitIndex_m1F6A977D2497B6A01679F46F152A5A0BD3E09FBB ();
// 0x00000296 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_layerMask()
extern void TrackedDeviceEventData_get_layerMask_mCC4E3FC3DBE17154C10DB69C6437A12C79130D08 ();
// 0x00000297 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_layerMask(UnityEngine.LayerMask)
extern void TrackedDeviceEventData_set_layerMask_m17E07F257B71DBE1D8444C397003FA64ED29F8C7 ();
// 0x00000298 UnityEngine.Canvas UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_canvas()
extern void TrackedDeviceGraphicRaycaster_get_canvas_m988AEC308E1E13FC4B75AF431BC0AC287423EBB9 ();
// 0x00000299 UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_eventCamera()
extern void TrackedDeviceGraphicRaycaster_get_eventCamera_m93B770F01BEB0D3C7914862E2B9B82EE643A2103 ();
// 0x0000029A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_Raycast_m8E9CC4101D5754C65196C4647E7A1A84AC1ECDEF ();
// 0x0000029B UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_m72BC91072FE659E18CE38523F541129868ED7FFB ();
// 0x0000029C UnityEngine.RaycastHit2D UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit2D[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_mF3E5A9A50D1F59852BA7CFCAFAC8696B6975179E ();
// 0x0000029D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycasts(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycasts_m7551E270EBD9058BCE3BEB66A28CC834B2019BBA ();
// 0x0000029E System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycast(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.LayerMask,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycast_m2BAD3F066AB8B59B606C286B87E21715BD3CB6B7 ();
// 0x0000029F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::SortedRaycastGraphics(UnityEngine.Canvas,UnityEngine.Ray,System.Single,UnityEngine.LayerMask,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData>)
extern void TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_mCAF366E95C766F53176D8FAF34BE7E457773E276 ();
// 0x000002A0 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::RayIntersectsRectTransform(UnityEngine.RectTransform,UnityEngine.Ray,UnityEngine.Vector3&,System.Single&)
extern void TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_m61477CEB7C4295F8A9CCF4A16A6C4007B70A4F83 ();
// 0x000002A1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.ctor()
extern void TrackedDeviceGraphicRaycaster__ctor_mDE43A2C0552A6267D8E1DA4A0C6D877306DAC8BC ();
// 0x000002A2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.cctor()
extern void TrackedDeviceGraphicRaycaster__cctor_mA7232584E0E3D76AF8E68032671B6BB4A18715EF ();
// 0x000002A3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_implementationData()
extern void TrackedDeviceModel_get_implementationData_mCAB49C3357937CA8CB9C044D45FABA747DC55F05_AdjustorThunk ();
// 0x000002A4 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_pointerId()
extern void TrackedDeviceModel_get_pointerId_mD0FF45520BF345CE8B873E15D1BE2B729C2D27D5_AdjustorThunk ();
// 0x000002A5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_pointerId(System.Int32)
extern void TrackedDeviceModel_set_pointerId_mFF7C1856BCD90F3D2708668DA4FCE5F7A8270A78_AdjustorThunk ();
// 0x000002A6 System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_maxRaycastDistance()
extern void TrackedDeviceModel_get_maxRaycastDistance_mE355509CDE42A30DD6A1ED2B8CEFBCBE1CFB1A32_AdjustorThunk ();
// 0x000002A7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_maxRaycastDistance(System.Single)
extern void TrackedDeviceModel_set_maxRaycastDistance_mC26E5F4A629D0008850F717BD3260C47CD12EBF8_AdjustorThunk ();
// 0x000002A8 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_select()
extern void TrackedDeviceModel_get_select_m38251660639F72711104D52D1D7962FC1D67F19A_AdjustorThunk ();
// 0x000002A9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_select(System.Boolean)
extern void TrackedDeviceModel_set_select_mACE130EDDD77426A1772469F3F009E417160317D_AdjustorThunk ();
// 0x000002AA UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_selectDelta()
extern void TrackedDeviceModel_get_selectDelta_m47B098C8C85A0EE93A83211020AB00D604EF82BF_AdjustorThunk ();
// 0x000002AB System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TrackedDeviceModel_set_selectDelta_m7174A0051C403A2F86E380267AFEBEAC182FF045_AdjustorThunk ();
// 0x000002AC System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_changedThisFrame()
extern void TrackedDeviceModel_get_changedThisFrame_m99132AF4690ED098D103CF6C1AE64F9D46C1B7F2_AdjustorThunk ();
// 0x000002AD System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_changedThisFrame(System.Boolean)
extern void TrackedDeviceModel_set_changedThisFrame_mFA3101878F06AC8B28A21C6DF1D9DDAA0B8F8F6D_AdjustorThunk ();
// 0x000002AE UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_position()
extern void TrackedDeviceModel_get_position_mA69AA65D186A58F348657F5CDFCD8F16B8087595_AdjustorThunk ();
// 0x000002AF System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_position(UnityEngine.Vector3)
extern void TrackedDeviceModel_set_position_mBDA113E82AF63A4729F0C2C0175E57AD8D6FF1D2_AdjustorThunk ();
// 0x000002B0 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_orientation()
extern void TrackedDeviceModel_get_orientation_mC6A350F145613009CFA86DEE12E4834C59AC368D_AdjustorThunk ();
// 0x000002B1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_orientation(UnityEngine.Quaternion)
extern void TrackedDeviceModel_set_orientation_m5C163A42198861DCED561E56C2D17F694E17DD1C_AdjustorThunk ();
// 0x000002B2 System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastPoints()
extern void TrackedDeviceModel_get_raycastPoints_m92794D4EA0B62F138C8A7CC11B0B1FFD4DFC7FA2_AdjustorThunk ();
// 0x000002B3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceModel_set_raycastPoints_m99F499AFEB3CA821D7932944D27A34D1E3C5EFF3_AdjustorThunk ();
// 0x000002B4 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastLayerMask()
extern void TrackedDeviceModel_get_raycastLayerMask_m363F7363B9FB674FBBAC5FCAE2734EFADAC379E8_AdjustorThunk ();
// 0x000002B5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastLayerMask(UnityEngine.LayerMask)
extern void TrackedDeviceModel_set_raycastLayerMask_mE371B8BE9649D9C41C9B9D7B74457FC17E3DE518_AdjustorThunk ();
// 0x000002B6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::.ctor(System.Int32)
extern void TrackedDeviceModel__ctor_m75625276E990C86ECFE91F0C1E6A7DAAB940E2D0_AdjustorThunk ();
// 0x000002B7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::Reset(System.Boolean)
extern void TrackedDeviceModel_Reset_m9BB80854893C64A471FC3FEC3C3526254DA0D1D1_AdjustorThunk ();
// 0x000002B8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::OnFrameFinished()
extern void TrackedDeviceModel_OnFrameFinished_mC34ECFF1DF5B4E242E1143200BBB15DF0748237A_AdjustorThunk ();
// 0x000002B9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyTo(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyTo_m8EFB5D3DB5E119714FE1FEFE9C5D19F2AA90575A_AdjustorThunk ();
// 0x000002BA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyFrom(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyFrom_mAC39132B9E0B49594697B4460F0AFB5E856AF202_AdjustorThunk ();
// 0x000002BB UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_uiCamera()
extern void UIInputModule_get_uiCamera_mC981BBAEDDA8D755484CA8A19E692A3DF064BBE7 ();
// 0x000002BC System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_uiCamera(UnityEngine.Camera)
extern void UIInputModule_set_uiCamera_m9E05BADD870B0F7FF5486D12250C84D9610DF235 ();
// 0x000002BD System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::DoProcess()
// 0x000002BE System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::Process()
extern void UIInputModule_Process_m05F16F652C1C055981845374C43A8A97CF231DFE ();
// 0x000002BF UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::PerformRaycast(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_PerformRaycast_m0AFE5A63E32939970FB27513BF9076ED065FBCDC ();
// 0x000002C0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouse(UnityEngine.XR.Interaction.Toolkit.UI.MouseModel&)
extern void UIInputModule_ProcessMouse_m5C697B37044AAEF1E1CF6EC986891B4B2922D476 ();
// 0x000002C1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseMovement(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseMovement_m4B516FB2B757B72D821BA2CCCFAC4952A5533419 ();
// 0x000002C2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButton(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState,UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseButton_mF9A5E3EC43D7C70EF2C2D00886D904393D4B4443 ();
// 0x000002C3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButtonDrag(UnityEngine.EventSystems.PointerEventData,System.Single)
extern void UIInputModule_ProcessMouseButtonDrag_mDEF2966C52098087125CCBA60714A650F9C66648 ();
// 0x000002C4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseScroll(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseScroll_mEFF04D34B4B034CC19047988BB2385DC8A800E05 ();
// 0x000002C5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTouch(UnityEngine.XR.Interaction.Toolkit.UI.TouchModel&)
extern void UIInputModule_ProcessTouch_mF07C36AC9F10E9E9B7F19E3154B999765A55D222 ();
// 0x000002C6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTrackedDevice(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&,System.Boolean)
extern void UIInputModule_ProcessTrackedDevice_mB1DF1AF69E272CE328403893FB33605DB28582CC ();
// 0x000002C7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessJoystick(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel&)
extern void UIInputModule_ProcessJoystick_m4FFE76F82B96ED6046CD49118FE01D414B4E8765 ();
// 0x000002C8 UnityEngine.EventSystems.PointerEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedPointerEvent()
extern void UIInputModule_GetOrCreateCachedPointerEvent_mFA7338E0D407658F0D89F2848E79DE3EE10DFA1C ();
// 0x000002C9 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedTrackedDeviceEvent()
extern void UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m7339648E449584A86DDBD8801DB8EA79FA40D541 ();
// 0x000002CA UnityEngine.EventSystems.AxisEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedAxisEvent()
extern void UIInputModule_GetOrCreateCachedAxisEvent_m58B3D1B7D59DB97969E7AFFC502A716398D62762 ();
// 0x000002CB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::.ctor()
extern void UIInputModule__ctor_m8EFCE975AA4801178D24158911CB0DD010C62518 ();
// 0x000002CC System.Void UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x000002CD System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x000002CE System.Single UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_maxRaycastDistance()
extern void XRUIInputModule_get_maxRaycastDistance_mCF1E624E5D27B03A440E42A288AC557C9EFC0AD5 ();
// 0x000002CF System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_maxRaycastDistance(System.Single)
extern void XRUIInputModule_set_maxRaycastDistance_mDB06E959A3379F8376FF9EA3EE27DFE6D8812264 ();
// 0x000002D0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::EnsureInitialized()
extern void XRUIInputModule_EnsureInitialized_m04973CB7103DB1C0A8989739E75D5BAA5FEAC7D4 ();
// 0x000002D1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::Awake()
extern void XRUIInputModule_Awake_m9B96994F1E07E5003F4B1C75FF71B1D077F1AC69 ();
// 0x000002D2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::OnEnable()
extern void XRUIInputModule_OnEnable_m4FC1BBC0400102BAFE6C8C8AF7362DAEFE5444AE ();
// 0x000002D3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::RegisterInteractable(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable)
extern void XRUIInputModule_RegisterInteractable_m2480E98E7331EAF0753189065B2ADC4FC796CB10 ();
// 0x000002D4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::UnregisterInteractable(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable)
extern void XRUIInputModule_UnregisterInteractable_mC8799EDF5274A739FEB4AE5E6522F232BFAFA3EF ();
// 0x000002D5 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::GetTrackedDeviceModel(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRUIInputModule_GetTrackedDeviceModel_m80B1A753B03C000F932945359C28973C121D8B30 ();
// 0x000002D6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::DoProcess()
extern void XRUIInputModule_DoProcess_mB8CDECC0BC332E569F03FDF7B7BE368ECA3F2570 ();
// 0x000002D7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessMouse()
extern void XRUIInputModule_ProcessMouse_m51FE2E0ADBC87D6161D0C453F218B09DF85ED491 ();
// 0x000002D8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessTouches()
extern void XRUIInputModule_ProcessTouches_m344B5D739A6557FB87202F13509D027E57CC4337 ();
// 0x000002D9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::.ctor()
extern void XRUIInputModule__ctor_mE3AAC3931AF2D05519294D9B438FA0121D319A43 ();
// 0x000002DA System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer,UnityEngine.Touch)
extern void DragGesture__ctor_mEE1B2B87B41055C50570AB8EEF5BB21135C7C7E0 ();
// 0x000002DB System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::get_FingerId()
extern void DragGesture_get_FingerId_m3F0E9155632370351892A98E1D09B20A91D85108 ();
// 0x000002DC System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::set_FingerId(System.Int32)
extern void DragGesture_set_FingerId_mE785F447B5410F96D0A8BCA5E2585BE66E245C99 ();
// 0x000002DD UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::get_StartPosition()
extern void DragGesture_get_StartPosition_mAD54D2A1F886B8DE673B8071999783D24625D2DD ();
// 0x000002DE System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::set_StartPosition(UnityEngine.Vector2)
extern void DragGesture_set_StartPosition_m926FB8E9858EE6D24ACABF2E994CD3C14831D005 ();
// 0x000002DF UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::get_Position()
extern void DragGesture_get_Position_m06F85393A385574F5F2D61A6AFA8AEA883362E55 ();
// 0x000002E0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::set_Position(UnityEngine.Vector2)
extern void DragGesture_set_Position_mCCDCCFF6270046499C2592A74FD71FC01DE0BFB3 ();
// 0x000002E1 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::get_Delta()
extern void DragGesture_get_Delta_m2C35653E38F6349D2B78DF799D9C721DE13CCF59 ();
// 0x000002E2 System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::set_Delta(UnityEngine.Vector2)
extern void DragGesture_set_Delta_mDBC232719AA8D6C790FC1D1C6E1DB004BF5D3405 ();
// 0x000002E3 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::CanStart()
extern void DragGesture_CanStart_m4F7FDEDC8D4B562E62B73CBCA0E6CFB1B3E92F60 ();
// 0x000002E4 System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::OnStart()
extern void DragGesture_OnStart_mF5584B8CEFACDB7D21FC25E74601D36C3F947B31 ();
// 0x000002E5 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::UpdateGesture()
extern void DragGesture_UpdateGesture_m3400B517C83FF6D144D510681ECB8D965D585968 ();
// 0x000002E6 System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::OnCancel()
extern void DragGesture_OnCancel_m0428DCC0DEA28601921CA228EE0F3B7B6C368A3A ();
// 0x000002E7 System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGesture::OnFinish()
extern void DragGesture_OnFinish_mFC9D15337DB361C202D507B3C40DAC9655E35EEB ();
// 0x000002E8 System.Single UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer::get_m_SlopInches()
extern void DragGestureRecognizer_get_m_SlopInches_mF32609E171451759E39C8CE9DB266F0DEE9795CB ();
// 0x000002E9 UnityEngine.XR.Interaction.Toolkit.AR.DragGesture UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer::CreateGesture(UnityEngine.Touch)
extern void DragGestureRecognizer_CreateGesture_mD841A9FFA7B4BF13828BA048D942B6EB85DB97B7 ();
// 0x000002EA System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer::TryCreateGestures()
extern void DragGestureRecognizer_TryCreateGestures_m694AFADB96876AF896557C459A4B440EB5DCD7BE ();
// 0x000002EB System.Void UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer::.ctor()
extern void DragGestureRecognizer__ctor_m3CA89FE4900C7FE9B75991BE5F4DF855E78AEF86 ();
// 0x000002EC System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1<T>)
// 0x000002ED System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::add_onStart(System.Action`1<T>)
// 0x000002EE System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::remove_onStart(System.Action`1<T>)
// 0x000002EF System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::add_onUpdated(System.Action`1<T>)
// 0x000002F0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::remove_onUpdated(System.Action`1<T>)
// 0x000002F1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::add_onFinished(System.Action`1<T>)
// 0x000002F2 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::remove_onFinished(System.Action`1<T>)
// 0x000002F3 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::get_WasCancelled()
// 0x000002F4 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::set_WasCancelled(System.Boolean)
// 0x000002F5 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::get_TargetObject()
// 0x000002F6 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::set_TargetObject(UnityEngine.GameObject)
// 0x000002F7 UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1<T> UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::get_m_Recognizer()
// 0x000002F8 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::set_m_Recognizer(UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1<T>)
// 0x000002F9 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::get_m_HasStarted()
// 0x000002FA System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::set_m_HasStarted(System.Boolean)
// 0x000002FB System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::Update()
// 0x000002FC System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::Cancel()
// 0x000002FD System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::CanStart()
// 0x000002FE System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::OnStart()
// 0x000002FF System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::UpdateGesture()
// 0x00000300 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::OnCancel()
// 0x00000301 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::OnFinish()
// 0x00000302 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::Complete()
// 0x00000303 System.Void UnityEngine.XR.Interaction.Toolkit.AR.Gesture`1::Start()
// 0x00000304 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::add_onGestureStarted(System.Action`1<T>)
// 0x00000305 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::remove_onGestureStarted(System.Action`1<T>)
// 0x00000306 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::Update()
// 0x00000307 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::TryCreateGestures()
// 0x00000308 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::TryCreateOneFingerGestureOnTouchBegan(System.Func`2<UnityEngine.Touch,T>)
// 0x00000309 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::TryCreateTwoFingerGestureOnTouchBegan(System.Func`3<UnityEngine.Touch,UnityEngine.Touch,T>)
// 0x0000030A System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::TryCreateGestureTwoFingerGestureOnTouchBeganForTouchIndex(System.Int32,System.Func`3<UnityEngine.Touch,UnityEngine.Touch,T>)
// 0x0000030B System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::OnStart(T)
// 0x0000030C System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::OnFinished(T)
// 0x0000030D System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureRecognizer`1::.ctor()
// 0x0000030E System.Single UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_deltaTime()
extern void MockTouch_get_deltaTime_m886BD356BE84D66355562B34F9E6858249FE08B5 ();
// 0x0000030F System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_deltaTime(System.Single)
extern void MockTouch_set_deltaTime_m40C82B1D6158979D0B77CA51F21A4231637A7BF6 ();
// 0x00000310 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_tapCount()
extern void MockTouch_get_tapCount_mEA1DF0773E789CC4F3636D969EA763CDBF2FF007 ();
// 0x00000311 System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_tapCount(System.Int32)
extern void MockTouch_set_tapCount_m439F8138BA96EB06EFDA4538CC756212655D38CA ();
// 0x00000312 UnityEngine.TouchPhase UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_phase()
extern void MockTouch_get_phase_mDD5A621D4100B85CED4BBA70877AC123F5AC039C ();
// 0x00000313 System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_phase(UnityEngine.TouchPhase)
extern void MockTouch_set_phase_m7208044D032C87397FA43BB744912625A6FFBF4A ();
// 0x00000314 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_deltaPosition()
extern void MockTouch_get_deltaPosition_m738917AC4EFF04FF60F0689E83EF9C6522EC9AF1 ();
// 0x00000315 System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_deltaPosition(UnityEngine.Vector2)
extern void MockTouch_set_deltaPosition_m4634D79381D9F6385F3EB9DA9BBB9DE040C4B549 ();
// 0x00000316 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_fingerId()
extern void MockTouch_get_fingerId_mE321C4D0B91BAE2EBEEE08B866161B8FBF7BB874 ();
// 0x00000317 System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_fingerId(System.Int32)
extern void MockTouch_set_fingerId_m539D5015BB2417C1D4ACF57C1BCD544E7DD560A3 ();
// 0x00000318 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_position()
extern void MockTouch_get_position_m88C8BA71D7E58F0B57214479A0556732003F78ED ();
// 0x00000319 System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_position(UnityEngine.Vector2)
extern void MockTouch_set_position_mB001DA566D0250D8CF915681D44548045CA0A9DA ();
// 0x0000031A UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_rawPosition()
extern void MockTouch_get_rawPosition_mD3244C058A946CD980AD4931DA71ED5AA134582D ();
// 0x0000031B System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::set_rawPosition(UnityEngine.Vector2)
extern void MockTouch_set_rawPosition_m7CD233B279D29AA4E0270D0FD4143000B2847336 ();
// 0x0000031C UnityEngine.Touch UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::get_Touch()
extern void MockTouch_get_Touch_m886DD369688CFC9073BD57948E674327AAA982C3 ();
// 0x0000031D System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::.ctor()
extern void MockTouch__ctor_m86C6649D8B83521B881C31266E4EE843A5EC6915 ();
// 0x0000031E System.Void UnityEngine.XR.Interaction.Toolkit.AR.MockTouch::.cctor()
extern void MockTouch__cctor_m75B3A7CC1C87D10CECB879EB8A31BEC85E149E39 ();
// 0x0000031F System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::TryFindTouch(System.Int32,UnityEngine.Touch&)
extern void GestureTouchesUtility_TryFindTouch_mB9DB73CC42445E6CCDE1FCAA7036A4EF1F30CFDB ();
// 0x00000320 System.Single UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::PixelsToInches(System.Single)
extern void GestureTouchesUtility_PixelsToInches_m9EE885556C2C3FFA95D4523F9652D2F66DED24AF ();
// 0x00000321 System.Single UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::InchesToPixels(System.Single)
extern void GestureTouchesUtility_InchesToPixels_m34694AFCE76D34C55EAD38F5D6C47DA3F6F2F843 ();
// 0x00000322 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::IsTouchOffScreenEdge(UnityEngine.Touch)
extern void GestureTouchesUtility_IsTouchOffScreenEdge_mE4255F6AE7B9C2006CCD54F85084BE669DB845D8 ();
// 0x00000323 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::RaycastFromCamera(UnityEngine.Vector2,UnityEngine.RaycastHit&)
extern void GestureTouchesUtility_RaycastFromCamera_mC099E8AD3DE908B762A3B5EB51FBCE955B701EA4 ();
// 0x00000324 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::LockFingerId(System.Int32)
extern void GestureTouchesUtility_LockFingerId_mAF14357CC5AA3F2487D4FF999314FAC67E858E2B ();
// 0x00000325 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::ReleaseFingerId(System.Int32)
extern void GestureTouchesUtility_ReleaseFingerId_mB76CF5A6BEFE386B9189B03C7299BAF79AC933AF ();
// 0x00000326 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::IsFingerIdRetained(System.Int32)
extern void GestureTouchesUtility_IsFingerIdRetained_m5F2316F7619F10959429FA5623A11BA344861328 ();
// 0x00000327 UnityEngine.Touch[] UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::get_Touches()
extern void GestureTouchesUtility_get_Touches_m516613155123117730281CCA07FDE526133A017E ();
// 0x00000328 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureTouchesUtility::.cctor()
extern void GestureTouchesUtility__cctor_m85EF69EBF494F474D263BFD0C8C048BA50B11861 ();
// 0x00000329 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer,UnityEngine.Touch,UnityEngine.Touch)
extern void PinchGesture__ctor_m822E5323D5EE3C25D80C6121D0BACCAC063D1649 ();
// 0x0000032A System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_FingerId1()
extern void PinchGesture_get_FingerId1_mB463C8F4FABB44F07FB88AB6FA917E43EA0CCB61 ();
// 0x0000032B System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_FingerId1(System.Int32)
extern void PinchGesture_set_FingerId1_mF0D2DCC3FA5E43CDCB5D30E8F71B49C5647CDF45 ();
// 0x0000032C System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_FingerId2()
extern void PinchGesture_get_FingerId2_mBDEDC3FBE5200EF29DCE314A83090013637C6C4D ();
// 0x0000032D System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_FingerId2(System.Int32)
extern void PinchGesture_set_FingerId2_m17F62DE31E9F6854A479D40B5136D382B8B6ACF8 ();
// 0x0000032E UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_StartPosition1()
extern void PinchGesture_get_StartPosition1_m81C3F71E37D92282B7CF7B6691FBD450FF1E9B9B ();
// 0x0000032F System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_StartPosition1(UnityEngine.Vector2)
extern void PinchGesture_set_StartPosition1_m45041BF1E73C5775B1D95B2896300A99345B235D ();
// 0x00000330 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_StartPosition2()
extern void PinchGesture_get_StartPosition2_m8DE6277EF43243A67CEEDA403F616A525C2BA128 ();
// 0x00000331 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_StartPosition2(UnityEngine.Vector2)
extern void PinchGesture_set_StartPosition2_mE0AE69D9E9BD762646F934545B3332A8A0422D3B ();
// 0x00000332 System.Single UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_Gap()
extern void PinchGesture_get_Gap_mDD4307D029D9B28A44F0D615CA113FB5E32D59B7 ();
// 0x00000333 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_Gap(System.Single)
extern void PinchGesture_set_Gap_m7B3AD44B738C7B5173986BC6B5DE8DC9FC1366C4 ();
// 0x00000334 System.Single UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::get_GapDelta()
extern void PinchGesture_get_GapDelta_m821292C4E8B5B35DE9585A6A7BB2FCDA8F2DEE58 ();
// 0x00000335 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::set_GapDelta(System.Single)
extern void PinchGesture_set_GapDelta_m5167A50D76702DA5163A8208C4F08FA2AC6A947D ();
// 0x00000336 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::CanStart()
extern void PinchGesture_CanStart_m67ABDFB5511C82CC9F55B13E2E7A5B02DC73F42A ();
// 0x00000337 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::OnStart()
extern void PinchGesture_OnStart_mBD07EA1F4E644D0AF8D9CF9C75E88D2B02355B1D ();
// 0x00000338 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::UpdateGesture()
extern void PinchGesture_UpdateGesture_m01E0BE18E23B47253F1603E5643F901BF26EDBAD ();
// 0x00000339 System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::OnCancel()
extern void PinchGesture_OnCancel_mF885A0A19727D854DBC688C22D1D4E461066B54D ();
// 0x0000033A System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture::OnFinish()
extern void PinchGesture_OnFinish_m564464E9A0522FEBD48AFB01B7D36B06C05510B8 ();
// 0x0000033B System.Single UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer::get_m_SlopInches()
extern void PinchGestureRecognizer_get_m_SlopInches_mD8EB44E2BCCED64E7EC339145F646B385820A3DF ();
// 0x0000033C System.Single UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer::get_m_SlopMotionDirectionDegrees()
extern void PinchGestureRecognizer_get_m_SlopMotionDirectionDegrees_mA52E8E172B0BF7FEF8ADAAD9FD0139A1BA51C1AD ();
// 0x0000033D UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer::CreateGesture(UnityEngine.Touch,UnityEngine.Touch)
extern void PinchGestureRecognizer_CreateGesture_m395FCC58C9FAF25EFA0237814461C2297FE9419F ();
// 0x0000033E System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer::TryCreateGestures()
extern void PinchGestureRecognizer_TryCreateGestures_mE2608279FB11818E631353C7C6028D211FD4B6D4 ();
// 0x0000033F System.Void UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer::.ctor()
extern void PinchGestureRecognizer__ctor_mE432A7DF75369A2CCDECF1EC6A7F38F764B43110 ();
// 0x00000340 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer,UnityEngine.Touch)
extern void TapGesture__ctor_m83F24A5C80F6405C2E1D2A3A1B7F9D8C0C3F3225 ();
// 0x00000341 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::get_FingerId()
extern void TapGesture_get_FingerId_mD83DE164580182342062AF51CFCA547F2F0CCE37 ();
// 0x00000342 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::set_FingerId(System.Int32)
extern void TapGesture_set_FingerId_m5D91D9AA60CE130B00511467FD8B3878B156C649 ();
// 0x00000343 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::get_StartPosition()
extern void TapGesture_get_StartPosition_m5B5096E8E9E079FB4D6D592F12CB3F92B67ED548 ();
// 0x00000344 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::set_StartPosition(UnityEngine.Vector2)
extern void TapGesture_set_StartPosition_mB918274919CEF6E49490576AD7B8BCAF5374F545 ();
// 0x00000345 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::CanStart()
extern void TapGesture_CanStart_mAEAD687A484F2DA467503F60A9FBD3E984451B80 ();
// 0x00000346 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::OnStart()
extern void TapGesture_OnStart_mEB43CBAFA7B1025B2F0AC4BC794721941DF93FF6 ();
// 0x00000347 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::UpdateGesture()
extern void TapGesture_UpdateGesture_m31E3D344E09ECB7897C348AA2C57E2CC6C6C3631 ();
// 0x00000348 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::OnCancel()
extern void TapGesture_OnCancel_m21F54DD075EC3A6C880CFBE850606FCC10553000 ();
// 0x00000349 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGesture::OnFinish()
extern void TapGesture_OnFinish_m155510AFA434FF4F3AEEB243F2F44E22FC56429D ();
// 0x0000034A System.Single UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer::get_m_SlopInches()
extern void TapGestureRecognizer_get_m_SlopInches_m87F15934037BE24E498D4ECF2F77637C99485489 ();
// 0x0000034B System.Single UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer::get_m_TimeSeconds()
extern void TapGestureRecognizer_get_m_TimeSeconds_mFC69E6FBFECB4002174B5D78423874C90922CDF9 ();
// 0x0000034C UnityEngine.XR.Interaction.Toolkit.AR.TapGesture UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer::CreateGesture(UnityEngine.Touch)
extern void TapGestureRecognizer_CreateGesture_mB7D66B93A217C245799E006163BC4454F92A569E ();
// 0x0000034D System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer::TryCreateGestures()
extern void TapGestureRecognizer_TryCreateGestures_mB23EC9D36727B026B450FB6AE9C104DEACCD9B8C ();
// 0x0000034E System.Void UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer::.ctor()
extern void TapGestureRecognizer__ctor_m9B12C5E9E214FD4EFBC7370D51C5F6E879DFE055 ();
// 0x0000034F System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer,UnityEngine.Touch,UnityEngine.Touch)
extern void TwistGesture__ctor_m4A947D2C5ABAD0FDEABE10D93406C488B27C40D1 ();
// 0x00000350 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::get_FingerId1()
extern void TwistGesture_get_FingerId1_m680DCA9648FA68B7FFDE005E6D1B1E46039E3101 ();
// 0x00000351 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::set_FingerId1(System.Int32)
extern void TwistGesture_set_FingerId1_mC8859D6D363872F7D4E40451CBA5C628D08E26C1 ();
// 0x00000352 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::get_FingerId2()
extern void TwistGesture_get_FingerId2_mDE3C5D6676F74CBC94CAD5AC42BC33378319F734 ();
// 0x00000353 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::set_FingerId2(System.Int32)
extern void TwistGesture_set_FingerId2_mE295378609385DEE20032F4A784068D9A2252D02 ();
// 0x00000354 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::get_StartPosition1()
extern void TwistGesture_get_StartPosition1_m4400A61E18A6A0D1D3784A70E999264A5D9D1CA2 ();
// 0x00000355 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::set_StartPosition1(UnityEngine.Vector2)
extern void TwistGesture_set_StartPosition1_m70111D46F83DB80DEA635B54CBD53E196383C86D ();
// 0x00000356 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::get_StartPosition2()
extern void TwistGesture_get_StartPosition2_m2ACCFA161BCD2A22128591DAE89BFCF8FBD86FD6 ();
// 0x00000357 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::set_StartPosition2(UnityEngine.Vector2)
extern void TwistGesture_set_StartPosition2_mC4A764E1B22A60E705E3758310DFAB823819F5BE ();
// 0x00000358 System.Single UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::get_DeltaRotation()
extern void TwistGesture_get_DeltaRotation_mC219DF2A09390CA7E7DF81CBD4E6C695603A8200 ();
// 0x00000359 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::set_DeltaRotation(System.Single)
extern void TwistGesture_set_DeltaRotation_mD3F7DC06480A7D59DC2759AF34F2F66BA17A45FA ();
// 0x0000035A System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::CanStart()
extern void TwistGesture_CanStart_m37FDB18F0546B744F37E30F608D69BF3822B77DE ();
// 0x0000035B System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::OnStart()
extern void TwistGesture_OnStart_m0425559871726F0014F222B0DDA87ED9F3C04D3C ();
// 0x0000035C System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::UpdateGesture()
extern void TwistGesture_UpdateGesture_m54A67B1B6CDE26F0A8852C62EA2AB05C490C6CB8 ();
// 0x0000035D System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::OnCancel()
extern void TwistGesture_OnCancel_m2D8693186729995F4649A4028C0235CC46E6F9BB ();
// 0x0000035E System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::OnFinish()
extern void TwistGesture_OnFinish_m1665857275E3CB3A0ADE45D3E8A4538481112AF3 ();
// 0x0000035F System.Single UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture::CalculateDeltaRotation(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2)
extern void TwistGesture_CalculateDeltaRotation_mE8A51C99D9033C4CF180F7B272C458CC71BFD88A ();
// 0x00000360 System.Single UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer::get_m_SlopRotation()
extern void TwistGestureRecognizer_get_m_SlopRotation_m00CE1CB708A67BA649CB4ADD8947E413F774E233 ();
// 0x00000361 UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer::CreateGesture(UnityEngine.Touch,UnityEngine.Touch)
extern void TwistGestureRecognizer_CreateGesture_mF1694E380A7017A82E02B9F00A42E7E759D92BCE ();
// 0x00000362 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer::TryCreateGestures()
extern void TwistGestureRecognizer_TryCreateGestures_m800512EDB1BC6BFAFADA843B3D5430B472B342D4 ();
// 0x00000363 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer::.ctor()
extern void TwistGestureRecognizer__ctor_m1B1E54D4D5F59EF6BB6BC3B6E19758CC0EBE0D65 ();
// 0x00000364 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::.ctor(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer,UnityEngine.Touch,UnityEngine.Touch)
extern void TwoFingerDragGesture__ctor_m8A1C85FF898CCCC8A5C2D2A9F91B0BEEA6231D52 ();
// 0x00000365 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_FingerId1()
extern void TwoFingerDragGesture_get_FingerId1_mECF5DE6DED6018FCF3BE581512C1549DE7ECA00D ();
// 0x00000366 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_FingerId1(System.Int32)
extern void TwoFingerDragGesture_set_FingerId1_mA870294382A8DA3D0B5CF927E1F3D22EF8A5EDD5 ();
// 0x00000367 System.Int32 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_FingerId2()
extern void TwoFingerDragGesture_get_FingerId2_m975E38EF68D4AF60189128712F522248F34DA6CF ();
// 0x00000368 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_FingerId2(System.Int32)
extern void TwoFingerDragGesture_set_FingerId2_m3D676BB86C60643A7FC20B9C8B4DC7131C40B68F ();
// 0x00000369 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_StartPosition1()
extern void TwoFingerDragGesture_get_StartPosition1_m144511C299A814976B1E546B2CC951169DFE4FE5 ();
// 0x0000036A System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_StartPosition1(UnityEngine.Vector2)
extern void TwoFingerDragGesture_set_StartPosition1_mF8D038F29F50A7029B981D002C2691638C91A892 ();
// 0x0000036B UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_StartPosition2()
extern void TwoFingerDragGesture_get_StartPosition2_mF46CE8F86C2F216168B87F4E5AC4D8F2932482A1 ();
// 0x0000036C System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_StartPosition2(UnityEngine.Vector2)
extern void TwoFingerDragGesture_set_StartPosition2_m42E560807EBA8B8ACBDCC65934BD1CF477FBF7EE ();
// 0x0000036D UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_Position()
extern void TwoFingerDragGesture_get_Position_m08ACDBAB1C97088B563EB03BA69A5DEAB4679212 ();
// 0x0000036E System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_Position(UnityEngine.Vector2)
extern void TwoFingerDragGesture_set_Position_m327AE3A557F27B37CE486041373DBB9F44BFE03A ();
// 0x0000036F UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::get_Delta()
extern void TwoFingerDragGesture_get_Delta_m428DEF67AD53C1BC0F5208DA667CA0F9698F8C61 ();
// 0x00000370 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::set_Delta(UnityEngine.Vector2)
extern void TwoFingerDragGesture_set_Delta_m24D32C583BBBD8BE058373B4E344FF96DE2DD499 ();
// 0x00000371 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::CanStart()
extern void TwoFingerDragGesture_CanStart_m9AEF884788BED94D4334E26A7258C65359453E6A ();
// 0x00000372 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::OnStart()
extern void TwoFingerDragGesture_OnStart_mD5F012B62A7F67C6924478BDF25BE83F8FF5249D ();
// 0x00000373 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::UpdateGesture()
extern void TwoFingerDragGesture_UpdateGesture_mDE6410F1D956B3BBC1EA7A0F0688EC4822A4F996 ();
// 0x00000374 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::OnCancel()
extern void TwoFingerDragGesture_OnCancel_m0AD7342C08D7D870096C1CD6C7D11947130AAF65 ();
// 0x00000375 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture::OnFinish()
extern void TwoFingerDragGesture_OnFinish_m37DB88313548889BC4E06B6C062BBCCA3279E84A ();
// 0x00000376 System.Single UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer::get_m_SlopInches()
extern void TwoFingerDragGestureRecognizer_get_m_SlopInches_m4674ABDBDC74A69AF636B910298A31ABC6CB674B ();
// 0x00000377 System.Single UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer::get_m_AngleThresholdRadians()
extern void TwoFingerDragGestureRecognizer_get_m_AngleThresholdRadians_m4243B0C772CD15E985E3E36894F74EC80F7AA724 ();
// 0x00000378 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer::CreateGesture(UnityEngine.Touch,UnityEngine.Touch)
extern void TwoFingerDragGestureRecognizer_CreateGesture_m1008C6F1BF54B8E4C24D88E2F002D2EB4817F6BF ();
// 0x00000379 System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer::TryCreateGestures()
extern void TwoFingerDragGestureRecognizer_TryCreateGestures_m70819A20B70EBDA179AD52CF74849DDF493FC52C ();
// 0x0000037A System.Void UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer::.ctor()
extern void TwoFingerDragGestureRecognizer__ctor_mDF64A446841840E772649B68DA129D7BC03E5D20 ();
// 0x0000037B UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::get_annotationVisualization()
extern void ARAnnotation_get_annotationVisualization_m41C9ECC2D731E190CB04C6B0A523DD2940A49C99 ();
// 0x0000037C System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::set_annotationVisualization(UnityEngine.GameObject)
extern void ARAnnotation_set_annotationVisualization_m26F475923E2D62E50BD8230A521F7174BD4BA77F ();
// 0x0000037D System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::get_maxFOVCenterOffsetAngle()
extern void ARAnnotation_get_maxFOVCenterOffsetAngle_m139A9E1D99A16B45A8A4848E4373BDF77333CC0A ();
// 0x0000037E System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::set_maxFOVCenterOffsetAngle(System.Single)
extern void ARAnnotation_set_maxFOVCenterOffsetAngle_mFACB1C98A823477B1466CC9F73EE707B8A056BD3 ();
// 0x0000037F System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::get_minAnnotationRange()
extern void ARAnnotation_get_minAnnotationRange_m24F600F5B1B45341A5B83B7DE9DB7A351FAE1A61 ();
// 0x00000380 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::set_minAnnotationRange(System.Single)
extern void ARAnnotation_set_minAnnotationRange_m7946408031CDBDA183E51019E8E15DF0321C17CD ();
// 0x00000381 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::get_maxAnnotationRange()
extern void ARAnnotation_get_maxAnnotationRange_m6CAAA4E03511ABE5002839D582F36FBB522B5863 ();
// 0x00000382 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::set_maxAnnotationRange(System.Single)
extern void ARAnnotation_set_maxAnnotationRange_m54EDB11A64ADDCAD93B3C8DB478B265BAF988B0C ();
// 0x00000383 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotation::.ctor()
extern void ARAnnotation__ctor_m31A8E4C80F013DB2B85FFBD6726D51351F85E17F ();
// 0x00000384 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotationInteractable::Update()
extern void ARAnnotationInteractable_Update_mFB8D1D314DFA8CF5467DBE038F991420659BEE77 ();
// 0x00000385 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotationInteractable::.ctor()
extern void ARAnnotationInteractable__ctor_m08A4A361FF38F1704CAC2088DD9A1404C62C760C ();
// 0x00000386 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void ARBaseGestureInteractable_IsSelectableBy_m6D197C69121E3BFC564037E9153EB9210CCBB6B1 ();
// 0x00000387 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_CanStartManipulationForGesture_m70CFFE88CAD2003D500C395207807ABA3DF499D2 ();
// 0x00000388 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_CanStartManipulationForGesture_mB398623C2A990707EBB798B277AD112F11EC96D8 ();
// 0x00000389 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_CanStartManipulationForGesture_m2A57FB4CB9280CA524E58531B70BC62F949243B8 ();
// 0x0000038A System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_CanStartManipulationForGesture_m96B9D4A87DEF737691189E5E8B77FAAFECC408BC ();
// 0x0000038B System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_CanStartManipulationForGesture_m7CA014101945BEA060BEE9B00E33AC4067CDF33F ();
// 0x0000038C System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnStartManipulation_m06E2A4D38687CF231A294AB2D616EF797CAFBD3F ();
// 0x0000038D System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnStartManipulation_mD9A79394A6DA2FB531D93F3D0788AB3FACF837D6 ();
// 0x0000038E System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnStartManipulation_m6CA6274AA91BDE9B405C6E6AE94B83E4A943EEEB ();
// 0x0000038F System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnStartManipulation_mB3DFF4600C1039071799B7D295EF922E988E4B8D ();
// 0x00000390 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnStartManipulation_m123836AC04FAA905A7304A484B5AEECB4CE50126 ();
// 0x00000391 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnContinueManipulation_m911E66BD38DC6C5399EA5D9198EC02F9E784E29D ();
// 0x00000392 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnContinueManipulation_mD7E744245054AA79B3978D2469E6CA54F368073B ();
// 0x00000393 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnContinueManipulation_m680B506E96C79D983C7749A92B8B0C640F0DDE3B ();
// 0x00000394 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnContinueManipulation_mE01BB2C91BFA53B46C8D97FEB36B74FA67B48E1B ();
// 0x00000395 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnContinueManipulation_m38914BFE7ABAD077C33FDDDFA9A6762AB3760044 ();
// 0x00000396 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnEndManipulation_m588ACA7838F3C2BDF6F7A7CCD141CD07D5C60D98 ();
// 0x00000397 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnEndManipulation_mF619C26A28371A7F204DE49E31ACB40A662BCFC2 ();
// 0x00000398 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnEndManipulation_m8BF2B80B9B1B44B7B1DB626A212DC006A4D8DD39 ();
// 0x00000399 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnEndManipulation_m43B1E695AA6214D5B1882211A9035936030153D0 ();
// 0x0000039A System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnEndManipulation_mFC2C064F9E6602298350F0E861F7AF3C425A784A ();
// 0x0000039B UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::get_gestureInteractor()
extern void ARBaseGestureInteractable_get_gestureInteractor_m0CC7D85390F605D2F4C8C9EBEF42C384CC06A3C4 ();
// 0x0000039C System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::UpdateGestureInteractor()
extern void ARBaseGestureInteractable_UpdateGestureInteractor_mA4ED0A38842D5E10D6C07FC4B8A8A16964A1B692 ();
// 0x0000039D System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::IsGameObjectSelected()
extern void ARBaseGestureInteractable_IsGameObjectSelected_mB9CD2337B48927B683EBE54E1AEBB379F09859DF ();
// 0x0000039E System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void ARBaseGestureInteractable_IsHoverableBy_mB7B68749ECD2388DEF5F6C5CF75A982EF932B1E2 ();
// 0x0000039F System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::ConnectGestureInteractor()
extern void ARBaseGestureInteractable_ConnectGestureInteractor_m686456BAAF4FABD52FCD9AC28F8ABCF28C4D4A60 ();
// 0x000003A0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::DisconnectGestureInteractor()
extern void ARBaseGestureInteractable_DisconnectGestureInteractor_m7C9589ADCAB351BA4923D3B02251711690BB8311 ();
// 0x000003A1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnGestureStarted(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnGestureStarted_mECABEB89704DF06B212FE49CFC481FCA14183877 ();
// 0x000003A2 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnGestureStarted(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnGestureStarted_mF1909BE94DDAD6B90E198AF5571C935DE7E77C52 ();
// 0x000003A3 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnGestureStarted(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnGestureStarted_m3B1F405EF6AEDBDF2AA965BFC69DC205731153B5 ();
// 0x000003A4 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnGestureStarted(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnGestureStarted_m7D7C805403FE30F4FA250B1AE5DFAAD2E01B9E78 ();
// 0x000003A5 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnGestureStarted(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnGestureStarted_m10819C110A105139DBCB8A214D5DAD1AD87A8543 ();
// 0x000003A6 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnUpdated(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnUpdated_mCAB9EB3DD26E4B1A539112CF3DA571BD2BB9E3A2 ();
// 0x000003A7 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnUpdated(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnUpdated_m00292EDB76C4AE705FA1568FA847998554FDB09D ();
// 0x000003A8 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnUpdated(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnUpdated_mF365667F724FC961CE35B0923FE06ABCDE306295 ();
// 0x000003A9 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnUpdated(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnUpdated_m783A569AE049787F98FDFDED69C605BA42D53095 ();
// 0x000003AA System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnUpdated(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnUpdated_m873FA4681EB4C54CCD362AEA6CAEA891C8914463 ();
// 0x000003AB System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnFinished(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARBaseGestureInteractable_OnFinished_mB1400D07FB14D00BA251F3A2DCF8C365B16A2EB6 ();
// 0x000003AC System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnFinished(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARBaseGestureInteractable_OnFinished_m37035E7E0897B1106A6BF6DFCEB2DE5D1A9D817D ();
// 0x000003AD System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnFinished(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARBaseGestureInteractable_OnFinished_mDC874B472781178E57A76A0FE71D2932B5ED890A ();
// 0x000003AE System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnFinished(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARBaseGestureInteractable_OnFinished_mEC3FE50348B1BA5F30C665C8D75017C185D6DF7F ();
// 0x000003AF System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::OnFinished(UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGesture)
extern void ARBaseGestureInteractable_OnFinished_mBB2773A74E2A5C3D18F82237BFD2FAC117465EFC ();
// 0x000003B0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::.ctor()
extern void ARBaseGestureInteractable__ctor_m9D6047BF7D98531682190AC5512ADBEAE39AB1BA ();
// 0x000003B1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARObjectPlacedEvent::.ctor()
extern void ARObjectPlacedEvent__ctor_mBC222061A0E28B7F7FD307C996754EEDE5BFE416 ();
// 0x000003B2 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::get_placementPrefab()
extern void ARPlacementInteractable_get_placementPrefab_m1CE36711A723F3EEEF67AFE504B2DF01877012C1 ();
// 0x000003B3 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::set_placementPrefab(UnityEngine.GameObject)
extern void ARPlacementInteractable_set_placementPrefab_m6D6C95A2EDE51845AC4D00B83141055AB6FB1A00 ();
// 0x000003B4 UnityEngine.XR.Interaction.Toolkit.AR.ARObjectPlacedEvent UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::get_onObjectPlaced()
extern void ARPlacementInteractable_get_onObjectPlaced_m361652546FE762CFD03B055373F7F5DD6BB76C9C ();
// 0x000003B5 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::set_onObjectPlaced(UnityEngine.XR.Interaction.Toolkit.AR.ARObjectPlacedEvent)
extern void ARPlacementInteractable_set_onObjectPlaced_m14C6EE4786BB64473EC87A35C596AACF6F58D2E1 ();
// 0x000003B6 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARPlacementInteractable_CanStartManipulationForGesture_m9EB9718DA2388A7ABABF8084AE59CF416BF81989 ();
// 0x000003B7 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARPlacementInteractable_OnEndManipulation_m7836E8DE2212BC7FBA9E62DD8C8A8192C2ADE29C ();
// 0x000003B8 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::.ctor()
extern void ARPlacementInteractable__ctor_m22CD62F8F54931146C5DDD7CA5EDA948CB06F14A ();
// 0x000003B9 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::.cctor()
extern void ARPlacementInteractable__cctor_m7B3EAD306C33ADDD024EF5FEB2DE557723F882E9 ();
// 0x000003BA System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::get_rotationRateDegreesDrag()
extern void ARRotationInteractable_get_rotationRateDegreesDrag_m3555F8EF4D83A78D16FEB056DA6576014488B514 ();
// 0x000003BB System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::set_rotationRateDegreesDrag(System.Single)
extern void ARRotationInteractable_set_rotationRateDegreesDrag_mA0CC7E590989DBFF4B95C88888C19EAE15444977 ();
// 0x000003BC System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::get_rotationRateDegreesTwist()
extern void ARRotationInteractable_get_rotationRateDegreesTwist_mB342E58234A4AF1549FC6437E64A15052EB57539 ();
// 0x000003BD System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::set_rotationRateDegreesTwist(System.Single)
extern void ARRotationInteractable_set_rotationRateDegreesTwist_m4E0A7512E205CB4B0D8D089AC1696BAFB7457695 ();
// 0x000003BE System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARRotationInteractable_CanStartManipulationForGesture_m620A44E1F2A3CB08190E9D08D4A0BB812F79EDB9 ();
// 0x000003BF System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARRotationInteractable_CanStartManipulationForGesture_m8366AF1F32BD4B71C6FE04807EBDF814FC0CC403 ();
// 0x000003C0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARRotationInteractable_OnContinueManipulation_m4EB544ADDEBE659A1B466CE2E6D84A2AA33DB96F ();
// 0x000003C1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TwistGesture)
extern void ARRotationInteractable_OnContinueManipulation_m7CE229E1EC70427372CF28C515C143CABAA3D707 ();
// 0x000003C2 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::.ctor()
extern void ARRotationInteractable__ctor_mE280554A465D09BCD229A191E717369BC15B4F1A ();
// 0x000003C3 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_minScale()
extern void ARScaleInteractable_get_minScale_mD71A5EECE529E3D56BCACEB5C850F4DAC8903C2F ();
// 0x000003C4 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::set_minScale(System.Single)
extern void ARScaleInteractable_set_minScale_m429E4725D4969EC3F0F164C5984914C46D12D2ED ();
// 0x000003C5 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_maxScale()
extern void ARScaleInteractable_get_maxScale_m14ADD3C752F96E18C5E4DCB64B8F7D9662DFF9EF ();
// 0x000003C6 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::set_maxScale(System.Single)
extern void ARScaleInteractable_set_maxScale_m9CE7E1F7EF147E4F07FC605E37C1F3D521017877 ();
// 0x000003C7 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_elasticRatioLimit()
extern void ARScaleInteractable_get_elasticRatioLimit_m4F102E42E15F2F39A79065750DDC81300AB6FCA8 ();
// 0x000003C8 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::set_elasticRatioLimit(System.Single)
extern void ARScaleInteractable_set_elasticRatioLimit_m5F6FBD0E99B3462084407F91F78B51A6BF1B8F44 ();
// 0x000003C9 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_sensitivity()
extern void ARScaleInteractable_get_sensitivity_mEEB2CB09EA58A62CD54817E93568BADD2E313306 ();
// 0x000003CA System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::set_sensitivity(System.Single)
extern void ARScaleInteractable_set_sensitivity_m4FB744FF08E817B52EC4765AAE73414194AC15A1 ();
// 0x000003CB System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_elasticity()
extern void ARScaleInteractable_get_elasticity_mE9E5CCD6C48A052790633CE475943B6878D9762B ();
// 0x000003CC System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::set_elasticity(System.Single)
extern void ARScaleInteractable_set_elasticity_mEFBBCF0D97EBE12B82AF639838367BB54E9479A5 ();
// 0x000003CD System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_m_ScaleDelta()
extern void ARScaleInteractable_get_m_ScaleDelta_m2338DF233E9FF63E34D6078D662D3DFA777E6607 ();
// 0x000003CE System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_m_ClampedScaleRatio()
extern void ARScaleInteractable_get_m_ClampedScaleRatio_mFE9CFA94E0D09EDAF99DD9068C4C32E30E76DD85 ();
// 0x000003CF System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::get_m_CurrentScale()
extern void ARScaleInteractable_get_m_CurrentScale_m7731EDD90A94B4FB8E2D8C922584C7511E90AA76 ();
// 0x000003D0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::OnEnable()
extern void ARScaleInteractable_OnEnable_mA15F95E3500AD17F4F37B47ABF9C65F614B33F60 ();
// 0x000003D1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::OnValidate()
extern void ARScaleInteractable_OnValidate_mB7DD33B8580419B0B7254E0D737358E8C6E57C84 ();
// 0x000003D2 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARScaleInteractable_CanStartManipulationForGesture_m2915B226DE05663FBC244FB6E7B7406F2166CF39 ();
// 0x000003D3 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARScaleInteractable_OnStartManipulation_mA6C1742BFCEE29CE3A7DD9470A916B85830C09C7 ();
// 0x000003D4 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARScaleInteractable_OnContinueManipulation_m5534877B9596696784B6CBE38F95EDF63A0F0F11 ();
// 0x000003D5 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.PinchGesture)
extern void ARScaleInteractable_OnEndManipulation_mB1EE3F09DBBD31A337DBBAA5F0D1B67FF5BF2736 ();
// 0x000003D6 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::ElasticDelta()
extern void ARScaleInteractable_ElasticDelta_m5FE1BCBDF4A9F945F294F85BDE9CD4BF0197F9A3 ();
// 0x000003D7 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::LateUpdate()
extern void ARScaleInteractable_LateUpdate_m387100E69671B90EFBE6B85EF81F1268B1EBB68C ();
// 0x000003D8 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::.ctor()
extern void ARScaleInteractable__ctor_m5C97522F8385540CEDE9FDBC25674B9158E70E67 ();
// 0x000003D9 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::get_selectionVisualization()
extern void ARSelectionInteractable_get_selectionVisualization_mA26426CB0C27349F35158C9B2A169A55C97397D0 ();
// 0x000003DA System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::set_selectionVisualization(UnityEngine.GameObject)
extern void ARSelectionInteractable_set_selectionVisualization_m8793958C9E31723EAEFEA53B5EF4ED5220CAAB60 ();
// 0x000003DB System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::Update()
extern void ARSelectionInteractable_Update_mA24F79A213FB7C257AFB1CF859B0E4C3E615AB84 ();
// 0x000003DC System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void ARSelectionInteractable_IsSelectableBy_m0EB98CE791E1C30D5025F07B85FEDDAF95FFE6E4 ();
// 0x000003DD System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARSelectionInteractable_CanStartManipulationForGesture_m73AD1BE853E6E7E2B8297164F956C5A4278D6815 ();
// 0x000003DE System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARSelectionInteractable_OnEndManipulation_m5F1FF971B75C1D87146CA98298A63AA53DE96A37 ();
// 0x000003DF System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::OnSelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void ARSelectionInteractable_OnSelectEnter_mA605248EB2C4A998137533D67FCB074EC59B554C ();
// 0x000003E0 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::OnSelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void ARSelectionInteractable_OnSelectExit_m826A1C34D4633FA415294E623A3B577023FD8039 ();
// 0x000003E1 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::.ctor()
extern void ARSelectionInteractable__ctor_mABB62A057D18673050B30677B23CA5105CCC819F ();
// 0x000003E2 UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility_GestureTranslationMode UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::get_objectGestureTranslationMode()
extern void ARTranslationInteractable_get_objectGestureTranslationMode_mF10CA3F5FBD2B4A353D46E21A2088A5B4C3B298F ();
// 0x000003E3 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::set_objectGestureTranslationMode(UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility_GestureTranslationMode)
extern void ARTranslationInteractable_set_objectGestureTranslationMode_m12FC78A83FC498490DA77D8B05231D04CD7BB3B6 ();
// 0x000003E4 System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::get_maxTranslationDistance()
extern void ARTranslationInteractable_get_maxTranslationDistance_mF256545FBB867F9C4F00F8BB0E491F25962CD0FE ();
// 0x000003E5 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::set_maxTranslationDistance(System.Single)
extern void ARTranslationInteractable_set_maxTranslationDistance_mA6FAEE6F7D7AC084EAEF9F6D0851D8879A77BCBE ();
// 0x000003E6 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::Start()
extern void ARTranslationInteractable_Start_mB97CF2745A7DA6B81A0AD3EBA1B7F2BFD7360E5C ();
// 0x000003E7 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::Update()
extern void ARTranslationInteractable_Update_mA5512613C59ECB1AD8063003B4A3C7FEB2508BDB ();
// 0x000003E8 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARTranslationInteractable_CanStartManipulationForGesture_m3AA6312CA0D35311A8D5853149990741DBD19CAC ();
// 0x000003E9 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::OnStartManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARTranslationInteractable_OnStartManipulation_m47EBB72B4F7585880A2DAB79FEBFF677936836A7 ();
// 0x000003EA System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::OnContinueManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARTranslationInteractable_OnContinueManipulation_m6690C473E4BFDD46AB1A74183833B79322EFB8BC ();
// 0x000003EB System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.DragGesture)
extern void ARTranslationInteractable_OnEndManipulation_m89D0E3B6304E1C99858ACC03305DA14B3E38D639 ();
// 0x000003EC System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::UpdatePosition()
extern void ARTranslationInteractable_UpdatePosition_m4615A639C83B46925F85376337A22E23BD9CEE7D ();
// 0x000003ED System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::.ctor()
extern void ARTranslationInteractable__ctor_m271529AC4D6F2DE46A203936D444E22B57090A4E ();
// 0x000003EE System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::CheckDependentManagers()
extern void GestureTransformationUtility_CheckDependentManagers_mD1F6A5EF863A6904FD1977B30ED68666E2CED2A8 ();
// 0x000003EF System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::Raycast(UnityEngine.Vector2,System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARRaycastHit>,UnityEngine.XR.ARSubsystems.TrackableType)
extern void GestureTransformationUtility_Raycast_m313F9945BF2931B9D7F0BF93C3861BBD0155BB85 ();
// 0x000003F0 UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility_Placement UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::GetBestPlacementPosition(UnityEngine.Vector3,UnityEngine.Vector2,System.Single,System.Single,System.Single,UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility_GestureTranslationMode)
extern void GestureTransformationUtility_GetBestPlacementPosition_mA9A996D81C1EF46D745A230D4DAAADEB0277162D ();
// 0x000003F1 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::LimitTranslation(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void GestureTransformationUtility_LimitTranslation_mFC66ED17E4745CEE9386555B3BDAE92111FD5597 ();
// 0x000003F2 System.Boolean UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::IsPlaneTypeAllowed(UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility_GestureTranslationMode,UnityEngine.XR.ARSubsystems.PlaneAlignment)
extern void GestureTransformationUtility_IsPlaneTypeAllowed_m2498FF2C6C875D29F6F680130057927A95FB74E0 ();
// 0x000003F3 System.Void UnityEngine.XR.Interaction.Toolkit.AR.GestureTransformationUtility::.cctor()
extern void GestureTransformationUtility__cctor_m5C0519A08212761182F5491F78D852B252F4B017 ();
// 0x000003F4 UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_Instance()
extern void ARGestureInteractor_get_Instance_mAB024E13349B591DE7D9762C83707A26B17CACCC ();
// 0x000003F5 UnityEngine.XR.Interaction.Toolkit.AR.DragGestureRecognizer UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_DragGestureRecognizer()
extern void ARGestureInteractor_get_DragGestureRecognizer_mD4096A81607DF42C6C59816147C2EFD9DFED770E ();
// 0x000003F6 UnityEngine.XR.Interaction.Toolkit.AR.PinchGestureRecognizer UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_PinchGestureRecognizer()
extern void ARGestureInteractor_get_PinchGestureRecognizer_mA727BAEAE83922C6D601B7DAF1E1DDF61E43E9F4 ();
// 0x000003F7 UnityEngine.XR.Interaction.Toolkit.AR.TwoFingerDragGestureRecognizer UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_TwoFingerDragGestureRecognizer()
extern void ARGestureInteractor_get_TwoFingerDragGestureRecognizer_m66E0B7D97AD3F8D8677D0C7E037CF00EDFC1C48A ();
// 0x000003F8 UnityEngine.XR.Interaction.Toolkit.AR.TapGestureRecognizer UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_TapGestureRecognizer()
extern void ARGestureInteractor_get_TapGestureRecognizer_mDC0D122D93582D0D3498B7D5A05051286CE85181 ();
// 0x000003F9 UnityEngine.XR.Interaction.Toolkit.AR.TwistGestureRecognizer UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::get_TwistGestureRecognizer()
extern void ARGestureInteractor_get_TwistGestureRecognizer_mFE75BE4726DEF9C28C9B5244E53DB424AFE70476 ();
// 0x000003FA System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::Awake()
extern void ARGestureInteractor_Awake_m4F936F978E4754329D231EA497905559F6603F16 ();
// 0x000003FB System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::Update()
extern void ARGestureInteractor_Update_m4FB0A53CE844767936F0119BC5376B5FD664F8E5 ();
// 0x000003FC System.Single UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::GetHorizontalFOV(UnityEngine.Camera)
extern void ARGestureInteractor_GetHorizontalFOV_mE2C25D7D81897A1EFB2555CFE599B99ADEEA02EF ();
// 0x000003FD System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void ARGestureInteractor_GetValidTargets_m4671EF0EB23139F16214B120AF4C6D34802ECA18 ();
// 0x000003FE System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::.ctor()
extern void ARGestureInteractor__ctor_mA6C679E95419FD7A3153DD42E501990B92C49AD0 ();
// 0x000003FF System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::.cctor()
extern void ARGestureInteractor__cctor_m82E2925F6EA05A8608659A26FB0C363A1E5122FC ();
// 0x00000400 System.Void InputHelpers_ButtonInfo::.ctor(System.String,InputHelpers_ButtonReadType)
extern void ButtonInfo__ctor_m318F4A1EB41E8B54177D20087620435E9AD74064_AdjustorThunk ();
// 0x00000401 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording_Frame::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void Frame__ctor_mCE2D471941F76FB7ABB0383A9F3BD49DE8FFB5FA_AdjustorThunk ();
// 0x00000402 System.String UnityEngine.XR.Interaction.Toolkit.XRControllerRecording_Frame::ToString()
extern void Frame_ToString_m18C27CDB47B560185DC5AC5BF22750AB7E3149BC_AdjustorThunk ();
// 0x00000403 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor_<>c::.cctor()
extern void U3CU3Ec__cctor_m9DDCBC4B16515D19A5B587C04548009A1D33D826 ();
// 0x00000404 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor_<>c::.ctor()
extern void U3CU3Ec__ctor_m061372CF9BEEC0B7A5526DE824428B4CA21E65C9 ();
// 0x00000405 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor_<>c::<Awake>b__6_0(UnityEngine.Collider)
extern void U3CU3Ec_U3CAwakeU3Eb__6_0_m64A8ADCD9A21B4617ED5944E1153CE7265CCE39D ();
// 0x00000406 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_m37FAF6292792208CFEDCEBE2D5C24B6E194C3286 ();
// 0x00000407 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor_RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_m751C364F35A51E01FBDDCA8C7E7F2A42822A3148 ();
// 0x00000408 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::.ctor(System.Int32)
extern void U3CRepeatInitializeCameraU3Ed__39__ctor_m39CBC9239D0E11C4271A7D6D2376D7414C99AC4B ();
// 0x00000409 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::System.IDisposable.Dispose()
extern void U3CRepeatInitializeCameraU3Ed__39_System_IDisposable_Dispose_mB4A19C1B67D5ABEBF5A878685EC83A0644CDB2CF ();
// 0x0000040A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::MoveNext()
extern void U3CRepeatInitializeCameraU3Ed__39_MoveNext_mF1AA8466CACF33234171F542520DBF9F8005026D ();
// 0x0000040B System.Object UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__39_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB23F2A611687EA649571E6606533B555A55A656D ();
// 0x0000040C System.Void UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::System.Collections.IEnumerator.Reset()
extern void U3CRepeatInitializeCameraU3Ed__39_System_Collections_IEnumerator_Reset_m3D35140D4378BC4397665BF814C2F41DCE1472B7 ();
// 0x0000040D System.Object UnityEngine.XR.Interaction.Toolkit.XRRig_<RepeatInitializeCamera>d__39::System.Collections.IEnumerator.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__39_System_Collections_IEnumerator_get_Current_m45039C6182C0B4914EB0CD87E775871FB58A030E ();
// 0x0000040E System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::get_consecutiveMoveCount()
extern void ImplementationData_get_consecutiveMoveCount_mF904135BD9EFA05B2D8E85D9065FA9A4C2839E12_AdjustorThunk ();
// 0x0000040F System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::set_consecutiveMoveCount(System.Int32)
extern void ImplementationData_set_consecutiveMoveCount_m6A8BE14485B92674DA53FA3219C6A6FD30838C2C_AdjustorThunk ();
// 0x00000410 UnityEngine.EventSystems.MoveDirection UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::get_lastMoveDirection()
extern void ImplementationData_get_lastMoveDirection_m437248CB1547D4FE2C1484F1E962C69B656FDD6E_AdjustorThunk ();
// 0x00000411 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::set_lastMoveDirection(UnityEngine.EventSystems.MoveDirection)
extern void ImplementationData_set_lastMoveDirection_m4D47C1BE229675F91B6F86178A95B6148A72BCF1_AdjustorThunk ();
// 0x00000412 System.Single UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::get_lastMoveTime()
extern void ImplementationData_get_lastMoveTime_m5A4AF5393938C80E48F8301F215F9B02868CF27B_AdjustorThunk ();
// 0x00000413 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::set_lastMoveTime(System.Single)
extern void ImplementationData_set_lastMoveTime_mB6283DED2E1645956730D3F3B855B0E8C9CFD5E8_AdjustorThunk ();
// 0x00000414 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel_ImplementationData::Reset()
extern void ImplementationData_Reset_mB79C2144A388A4260C2CB3CAB7C5E1C8E1E82672_AdjustorThunk ();
// 0x00000415 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m4D5F5F35960E6CAAEC9E07985BF4BB4BA8599E3B_AdjustorThunk ();
// 0x00000416 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m2121DA62AD191D8E2FA5851706D2D4FFBF85AE5F_AdjustorThunk ();
// 0x00000417 System.Single UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m34C48FB6C70DA8380FA7F613BA7D7260A51E0350_AdjustorThunk ();
// 0x00000418 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m25BBECEF789D7E5EF9D67BE9A5C3673F1AD04DF3_AdjustorThunk ();
// 0x00000419 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_mA0F3487E8E853FCD250DFAA49557CD32F2C33F43_AdjustorThunk ();
// 0x0000041A System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m833A5CB97001F3A6D587F8078DE7F456D29E6364_AdjustorThunk ();
// 0x0000041B UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_m79211F0341164D86D235FDEB292D41E7836A8649_AdjustorThunk ();
// 0x0000041C System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_m6F7AF5D5701F8DC7BAC8F1E9D62C885F5ADDA0ED_AdjustorThunk ();
// 0x0000041D UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m233C98D32B321AD0880F483CA59C29D7D6500A5B_AdjustorThunk ();
// 0x0000041E System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_mF2EAAFB3AC371FC3E2EACC7CFAC1CC138508490A_AdjustorThunk ();
// 0x0000041F UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_mA82B1E3F48D678133216E397B9EE3A99F72B8147_AdjustorThunk ();
// 0x00000420 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m635640DC36995E7A611BAF83ED52192784224599_AdjustorThunk ();
// 0x00000421 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_m140D50C1CD83D8025F5DACF504A631DD3F41FD8F_AdjustorThunk ();
// 0x00000422 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_mF06237076674CA342D2DAB9ABBDD735DAB8C4C2E_AdjustorThunk ();
// 0x00000423 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel_ImplementationData::Reset()
extern void ImplementationData_Reset_m44E028E047A062B2543EEF8DEC57466C3389E969_AdjustorThunk ();
// 0x00000424 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.MouseModel_InternalData::get_hoverTargets()
extern void InternalData_get_hoverTargets_mB6858B6E2DAD03788EEE42AC5ABE5E59174FF8B4_AdjustorThunk ();
// 0x00000425 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel_InternalData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void InternalData_set_hoverTargets_m263E54223464B7C1A2B4578B2532EA919D1DBC61_AdjustorThunk ();
// 0x00000426 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseModel_InternalData::get_pointerTarget()
extern void InternalData_get_pointerTarget_m35808B9C8C4AA1F95F9C6D5E92BD9D94D471C402_AdjustorThunk ();
// 0x00000427 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel_InternalData::set_pointerTarget(UnityEngine.GameObject)
extern void InternalData_set_pointerTarget_mBD6E5AA1B756B6C3256C3A7F824BCFD93326177F_AdjustorThunk ();
// 0x00000428 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel_InternalData::Reset()
extern void InternalData_Reset_m06FD7ADA3314F09B1639CF9F20685E84B2F062D6_AdjustorThunk ();
// 0x00000429 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_m8C68BFCBE662D18B3DE9264FD8DD0017A9582FB2_AdjustorThunk ();
// 0x0000042A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_m6DA0498FACE3573F7FF98F220D46CE3368D665FC_AdjustorThunk ();
// 0x0000042B UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_m15578FC54C5230C16ECE5EC1780A92C8E9BE4CC6_AdjustorThunk ();
// 0x0000042C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_m6798588B6085B4A88CC88590AEFED7EF4CA836CB_AdjustorThunk ();
// 0x0000042D System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m1386408077E680FE36572276C42BF8B53D2EE3F8_AdjustorThunk ();
// 0x0000042E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m37471A055706D58BE430DFA30E04761A98D8D7DC_AdjustorThunk ();
// 0x0000042F System.Single UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m6DD9BA132280689CE5ECB37B363D958B0152D044_AdjustorThunk ();
// 0x00000430 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m9CAD3C7B7BA96B30FD59B3B990E333B6FB1C9EC4_AdjustorThunk ();
// 0x00000431 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_m777080B865313932CC703D795A83C96E0BE41DC4_AdjustorThunk ();
// 0x00000432 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_mC61452C2EC804C94209A690E37D6C2799E7C7A9C_AdjustorThunk ();
// 0x00000433 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_m6AA140DEC4DC36B1501EE75BFFA087AAC3B167EC_AdjustorThunk ();
// 0x00000434 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_mBAB2EA7D44FAF48797F293D69219370C1482CFAC_AdjustorThunk ();
// 0x00000435 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m6740A5E50B5943F04B831B4FE5B227609A0DA24E_AdjustorThunk ();
// 0x00000436 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_mE64200883289E42E745EDCCCE906762AB564D79A_AdjustorThunk ();
// 0x00000437 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_m71A3C7E03C1A18CDD6CED39F6848C5F2C66B4169_AdjustorThunk ();
// 0x00000438 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m6880EF51A8A81E2ACC929FB2E7D3ED38ED552D23_AdjustorThunk ();
// 0x00000439 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mB89A3426D35F7C0C4046BAA60754CFCD28339D5E_AdjustorThunk ();
// 0x0000043A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_mDE467651B72DB5FDBBA8763D5E77C4CB54D58993_AdjustorThunk ();
// 0x0000043B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel_ImplementationData::Reset()
extern void ImplementationData_Reset_m87518738139AD004CF2973B09E5CDC10422B7A95_AdjustorThunk ();
// 0x0000043C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::.ctor(UnityEngine.UI.Graphic,UnityEngine.Vector3,UnityEngine.Vector2,System.Single)
extern void RaycastHitData__ctor_mA1D633A7E340AEB0F3759A9B105E91E4335CBEA0_AdjustorThunk ();
// 0x0000043D UnityEngine.UI.Graphic UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::get_graphic()
extern void RaycastHitData_get_graphic_m02D753644C4209BE852CF58D5C05E8B12ED3BB53_AdjustorThunk ();
// 0x0000043E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::set_graphic(UnityEngine.UI.Graphic)
extern void RaycastHitData_set_graphic_m20B98A559C0ABC27F0A4E4FEBEA5EF0BED75A29A_AdjustorThunk ();
// 0x0000043F UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::get_worldHitPosition()
extern void RaycastHitData_get_worldHitPosition_m287486D2AD9C2A3CEABD43522FCF4A214E6461F1_AdjustorThunk ();
// 0x00000440 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::set_worldHitPosition(UnityEngine.Vector3)
extern void RaycastHitData_set_worldHitPosition_mD07C999C6DED87A024C4C08BC024B7C80DC2D896_AdjustorThunk ();
// 0x00000441 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::get_screenPosition()
extern void RaycastHitData_get_screenPosition_m801EED488C4B748D97EFADC04DE58AB7D3BDD3EA_AdjustorThunk ();
// 0x00000442 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::set_screenPosition(UnityEngine.Vector2)
extern void RaycastHitData_set_screenPosition_mD7200EE2F7CAF57BEE53553F5255BC584CB2F4F4_AdjustorThunk ();
// 0x00000443 System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::get_distance()
extern void RaycastHitData_get_distance_m7C78E670D250A1E97DEA800DC76E50C9222140BD_AdjustorThunk ();
// 0x00000444 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData::set_distance(System.Single)
extern void RaycastHitData_set_distance_m5A3557D88FB3F597F6B7B028837707AE2022EB77_AdjustorThunk ();
// 0x00000445 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitComparer::Compare(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitData)
extern void RaycastHitComparer_Compare_m8C82B6BCABDB214A38B3CFF3FBCE2C71604445CC ();
// 0x00000446 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster_RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_mDB8188CFC41A7F5597F5EA937D0E07F86CAC5849 ();
// 0x00000447 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_mBBFE6CEF8CEA13D0D1014AE391A0B79D5DE336E4_AdjustorThunk ();
// 0x00000448 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_m9BB0D124829D89D7A55FBD4E1093FF9412339393_AdjustorThunk ();
// 0x00000449 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_m2FBB82C4207E95A8E32607A921845B77C55D73A5_AdjustorThunk ();
// 0x0000044A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_m5CB23ED3A7AFA95F297836ABC2BF3F92AB9B463E_AdjustorThunk ();
// 0x0000044B System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_mEAD1B7E29E488989B846BF21770C1908173BB46C_AdjustorThunk ();
// 0x0000044C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m4AD1D6DC7AB414D521AC82576F2DC3E5D6F5C0FF_AdjustorThunk ();
// 0x0000044D System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_mF5E2F4964CF0EDB11549D601911C786729B65A01_AdjustorThunk ();
// 0x0000044E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m55B204D98739CB7F1A6009E5218B3CB03A4506A8_AdjustorThunk ();
// 0x0000044F UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_m7F65A43AC6B2278EEB19013F76E2DB34D96058FA_AdjustorThunk ();
// 0x00000450 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m7F670B7C4EF2A61E87487D890469AB18C5361DCC_AdjustorThunk ();
// 0x00000451 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_mC2E0007565F77E61EB53258EA94166C41B8FB767_AdjustorThunk ();
// 0x00000452 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_mEB7F9A7CA494DF249D361866F0149287A3E32421_AdjustorThunk ();
// 0x00000453 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_lastFrameRaycast()
extern void ImplementationData_get_lastFrameRaycast_mDED8918A4858DEFF035D9F8F7C327312D524004E_AdjustorThunk ();
// 0x00000454 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_lastFrameRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_lastFrameRaycast_m61FEC0C088F11550783614BBE08382B79B0DC1C3_AdjustorThunk ();
// 0x00000455 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_lastFrameRaycastResultPositionInLine()
extern void ImplementationData_get_lastFrameRaycastResultPositionInLine_mD65E900115A3B64CC51048EAB89B30CC94D6D79F_AdjustorThunk ();
// 0x00000456 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_lastFrameRaycastResultPositionInLine(System.Int32)
extern void ImplementationData_set_lastFrameRaycastResultPositionInLine_m26D3562D1DAC83E1AC05031FF357AE474C3BA14A_AdjustorThunk ();
// 0x00000457 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m033F4F1733D1AA2EC7E3C9CB1955F4FAEA358BE4_AdjustorThunk ();
// 0x00000458 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m0165FDFFAF3E8EC7CE24FF171C6D0367C2FBA747_AdjustorThunk ();
// 0x00000459 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_mE828869D7B93632E47A967253DBC1D6153E0F192_AdjustorThunk ();
// 0x0000045A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m8EA5959ED8D09766FE22CC9E6581F9B75E4E9E50_AdjustorThunk ();
// 0x0000045B UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_m9A5A09599A59211A8D59E561537241B9F8364AA7_AdjustorThunk ();
// 0x0000045C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_mA0382FCD9AD185977C37E21161F8361A10774453_AdjustorThunk ();
// 0x0000045D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel_ImplementationData::Reset()
extern void ImplementationData_Reset_m4310073E858CFF95C8433CAF719F763A51711C39_AdjustorThunk ();
// 0x0000045E System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule_RegisteredInteractable::.ctor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractable,System.Int32)
extern void RegisteredInteractable__ctor_mA01A1DF22ED5A191D6398755DA30BB47E268B9E1_AdjustorThunk ();
// 0x0000045F System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule_RegisteredTouch::.ctor(UnityEngine.Touch,System.Int32)
extern void RegisteredTouch__ctor_m87F932AEA7B1C4846CE455D57466FC7B956576AA_AdjustorThunk ();
static Il2CppMethodPointer s_methodPointers[1119] = 
{
	InputHelpers_IsPressed_m69EE95AAE336BC130A2C550B5B7B9D5A9EB1AF8D,
	InputHelpers__cctor_mC787541B02D9D72463B96880C6BC36EF3D89ED58,
	XRController_get_updateTrackingType_m442E096CE62E4C2C6669EF3B9E6FC7D1E0239B7F,
	XRController_set_updateTrackingType_m609B44DEE474E9C1110F20D8069683C733CFEB14,
	XRController_get_enableInputTracking_m330812B762F1E9220728C29CB40F75F6D3227622,
	XRController_set_enableInputTracking_mA16289953E4AC9FF8D2EE1301C0D6F00A22F57F7,
	XRController_get_enableInputActions_m3514156F2D487C463A4D93C7356CC1E7997EA62D,
	XRController_set_enableInputActions_m96F49261E38D16C758F245AF671349A1131B82BD,
	XRController_get_poseProvider_m71A04819C3B3E7C4C2E35DCC33329127B8A8E442,
	XRController_set_poseProvider_m432B63A237FA388CE402493CB563B9812FF2C9E9,
	XRController_get_controllerNode_mFA1CF53ED1088BB6617B832D687A76C4E3C20922,
	XRController_set_controllerNode_m669AC504D2FF1217B9EC5782636FDB09C0D59746,
	XRController_get_selectUsage_m73183495F3D06EE88BFF5AF1A571A8ABD2C41440,
	XRController_set_selectUsage_mF007FBB8D54077062459F3B5D41D44D3992F926D,
	XRController_get_activateUsage_mA728B9B5780E0D746D38A059CF3AEEF26509CA2E,
	XRController_set_activateUsage_m3E918B789B5EA5D6D3B35B5F4ECDE39F8C1EFB2F,
	XRController_get_uiPressUsage_mB8FB066CCD005CA0D49E4254FD227CAF97BD6305,
	XRController_set_uiPressUsage_m4435516F65BAEE14881598FC0D34FCDBE1732584,
	XRController_get_axisToPressThreshold_m3993724C4E6510069774510216F80E5589FB7914,
	XRController_set_axisToPressThreshold_m3E61DDBCE3E5EDAEF2728AAB35D24EA1832BD98E,
	XRController_get_modelPrefab_m247FD5CCA6889E19CCD91C8CB5C13F4C3CE0A886,
	XRController_set_modelPrefab_mE2F07C11A925C71D263E5F3B64899DE38796ED93,
	XRController_get_modelTransform_m5B62BA0EE14300B942DC5377B47359745F83ED2B,
	XRController_get_animateModel_m5AD6379D693C3C081B0D2956695A11A44E742928,
	XRController_set_animateModel_m06645851679B5D9F4A0FDBEE19F816BB5E74C30B,
	XRController_get_modelSelectTransition_m81D9684D650DCAF6C9C734B0AB677CD0D9BAA083,
	XRController_set_modelSelectTransition_m84AA85CB2265B1C4181550432B434CED45C2BD8F,
	XRController_get_modelDeSelectTransition_m4806C0A164F719C78E4F9F6840F687C715D48EEA,
	XRController_set_modelDeSelectTransition_m88ED24A6DF5943D06100B5E442E7B9F7D91526E1,
	XRController_get_selectInteractionState_mD51654A7954C12AA378E601C91369509B2B26E1E,
	XRController_get_activateInteractionState_m421DA30802B2A0ED137566F07721A7E25FB428B4,
	XRController_get_uiPressInteractionState_mBD1EDC35546DC172DAA78F6CB101169EBA419B25,
	XRController_get_inputDevice_m66B22CF304CFD4037009EB61FE0849D4AD6ED69C,
	XRController_get_hideControllerModel_mE6888E31696D1C2453AA723188A6B8AECE87AA5C,
	XRController_set_hideControllerModel_mD439ED7C05834E39269825F118377A4DD69DD26F,
	XRController_OnEnable_m0AD8DBBB84784F361EF4094C3B79521C1BF8F166,
	XRController_OnDisable_m405F16579533C22BC0BFCFCA1CF43842B03ED778,
	XRController_OnBeforeRender_m9A65952FF6022ADF81123A79CA6C24CE859FE79F,
	XRController_Awake_m0D2826EB0DD0262D3635DD51D70746CF56D924C0,
	XRController_PerformSetup_m0B91907F0A055B92379F5FF59EC0ADCCFDE19C47,
	XRController_SetupModel_mD2D93AF3C3A2548C9342F0DA22613495CD8F7A08,
	XRController_ShouldUpdateTrackingInput_m5F50FFD3CF7EBC94A514777DF019E2509E661B32,
	XRController_Update_mE16453032E348DAE294B617FBF70119F5DD97197,
	XRController_UpdateTrackingInput_m5FF4C725C1BF5AF3A3E8C5174E5BFB3B2CBD13E1,
	XRController_UpdateInput_mAEF54953F0C9A8F54C5DC56DCFEEAAFC08F15253,
	XRController_HandleInteractionAction_m79A71A9C049DA8636D033E66BB996FB34716147E,
	XRController_UpdateInteractionType_m2F7231F15A0DBAD883C85D6AEC6CED2AB1CD6F5C,
	XRController_UpdateInteractionState_m92CEBDDD52209E797A4F9F552D99C5F2FA9D3D6C,
	XRController_UpdateControllerModelAnimation_mAB98F962C03DBD48AD042EBDF57E2E5E97B9332D,
	XRController_UpdateControllerPose_mF7CE607B7A9B56D2A29CBD5149F6511E4D2973B8,
	XRController_SendHapticImpulse_mECB44F3F591E286A081213E31BC629AD280308CD,
	XRController__ctor_m3B5DEAA872ED466E60332B5EADEABE0953C6325A,
	XRControllerRecorder_get_playOnStart_mF5EFC34E267D5A49C15BC5DD8FE771DC7382776F,
	XRControllerRecorder_set_playOnStart_mA8CC67EF7E221F668F6999564754D0D00C1628F7,
	XRControllerRecorder_get_controller_mE948C4BE70FA612D38F916195F9BCFF0EF0A4FC6,
	XRControllerRecorder_set_controller_m344AD05C8C9ABC3324759BBB0C3E1F9FDF93C161,
	XRControllerRecorder_get_recording_m6ACF024C7E288D961C45A5109B2A51560D0EA9E7,
	XRControllerRecorder_set_recording_m9D7BD8B40B5BDC1D1E6DCE798D66E5E3896F670F,
	XRControllerRecorder_get_isRecording_mFBD5038ECBDF7554515C8FE4046917BBED44E467,
	XRControllerRecorder_set_isRecording_m839FA72BF3E69563CFAAEA0F0A4735AFF768D4D4,
	XRControllerRecorder_get_isPlaying_m4542516EC8095C07B151D6F5B7714FB4D7A27CF1,
	XRControllerRecorder_set_isPlaying_mA78593981FBE07E51FA0D0E6D1F5C39B3644B8A9,
	XRControllerRecorder_get_currentTime_m83F8AC04E9E88B71E25C2F01685E764DF126D5E3,
	XRControllerRecorder_get_duration_m5D2F3FA990302D4C6C4F70A5B5FDE776891CD57B,
	XRControllerRecorder_Awake_m243108156B345C57339191B79C0559AB7593206A,
	XRControllerRecorder_OnDestroy_m035AFC916AE475C38D8F7CDAF6309D0165503F2C,
	XRControllerRecorder_ToggleRecording_m59A1510C093335941BEE64F31CCB1896B1B6A9FC,
	XRControllerRecorder_Update_mAF08E0E8EAE7BD6923174938BE054E8499C233A1,
	XRControllerRecorder_UpdateControllerRecordingUpdate_mC284EDAFE5C076BBBD22B136038C4426E3CF5C0D,
	XRControllerRecorder_ResetPlayback_m7213FB313D6DE393B87607A5838E4F7B3DD68FD1,
	XRControllerRecorder_UpdatePlaybackTime_m96E97297B5CDFA6EC9AC0F818DB8BB90867E4DFE,
	XRControllerRecorder__ctor_m3BF2E212949FC9CD43084C7A7EC9F4A3DE496C51,
	XRControllerRecording_get_frames_m950FBCFB1539E7DE6B155322D2276636128333DE,
	XRControllerRecording_get_duration_m84F2430B786F72D94DF4436A5D8EFBBBEAC5B160,
	XRControllerRecording_AddRecordingFrame_m127E863CCE19A2CB7C164A4F017F4C4488ECC075,
	XRControllerRecording_InitRecording_m144776A7148E99A6ED5D17C7E3FDD508540D4D8A,
	XRControllerRecording_SaveRecording_mDBD76AC756E3D46EA7C4A54BC0A95A7CC7CDF995,
	XRControllerRecording__ctor_m93CCC4D71B4E40311F3023145DD746081A6A1A72,
	XRTintInteractableVisual_get_tintColor_m7D9FC962082181C96935364BFCD7B63A083DC982,
	XRTintInteractableVisual_set_tintColor_m2E0E2F8DD957E66D32699BB6F4BFF841C8F5BD5E,
	XRTintInteractableVisual_get_tintOnHover_m9781D8692AB8169AC19CADF5E5BA459F72AB00BD,
	XRTintInteractableVisual_set_tintOnHover_m55D29E6A60526DFE0BFA9653A5951950251A7840,
	XRTintInteractableVisual_get_tintOnSelection_m2485C76707E1045AE1EF7558040DEDE94CE39898,
	XRTintInteractableVisual_set_tintOnSelection_m5393E066862A72CD40A73EF687A6E183B6283F9F,
	XRTintInteractableVisual_get_tintRenderers_mD511E551675190580AA6592AF4E2FFF79D64BAB3,
	XRTintInteractableVisual_set_tintRenderers_mFC301F1D953AB7453F12A67567F82E3D22544629,
	XRTintInteractableVisual_Awake_mC67A774BB957814AA4C17ACA57761ADF475FA4A7,
	XRTintInteractableVisual_Destroy_mBEA1FB017557AFF434015D0B7C54E163E485453B,
	XRTintInteractableVisual_SetTint_m882035C34C671A8CD425DD338EA3E0E6D872F180,
	XRTintInteractableVisual_OnFirstHoverEnter_m3F99D685DC4889001B513B5FB08444E906EDFF98,
	XRTintInteractableVisual_OnLastHoverExit_mC379BED007BBF9FF8C7A4E13EE363C4E857FCB90,
	XRTintInteractableVisual_OnSelectEnter_m21A77FF718AEA39BC96A6DA6C0CD14038D483D99,
	XRTintInteractableVisual_OnSelectExit_mC2AF19A078C1965A2698190BDE39872237A1334A,
	XRTintInteractableVisual__ctor_m67DBBA2274AE180AD46CF4A88B56ECFEED1A3AE3,
	XRInteractableEvent__ctor_mFD4073963C2A8B758C0F04C35C18F13ABBBD308F,
	XRBaseInteractable_get_interactionManager_m462CC45EE97EDAE438C9D59C1FB870BD7A7839BB,
	XRBaseInteractable_set_interactionManager_m92EE6DDC848D87136A5FD8A6A06A4080D5D99014,
	XRBaseInteractable_get_colliders_m7AD14886623F98D5FA7B69E3CE670F9310B28816,
	XRBaseInteractable_get_interactionLayerMask_mC9E32D0C76B718A2E140E8F1AFE87C42CBC9B492,
	XRBaseInteractable_set_interactionLayerMask_m3EEEE1793EAC79485DC2155AF41F0FF78F29C1C5,
	XRBaseInteractable_get_hoveringInteractors_m903A4AB07A74447D0CEA3E427D769AEBBE42B31B,
	XRBaseInteractable_get_isHovered_m25C78D1C8D25C65FC5B6370CE707C8C92DFF45EE,
	XRBaseInteractable_set_isHovered_mA867523E3C5660465277837F950EE95DEFF3315A,
	XRBaseInteractable_get_isSelected_m8FA8E86FC49FC636909AEE2461F170DD994A5D1A,
	XRBaseInteractable_set_isSelected_m8DEC7CF523CA6A6E9BDF34A2488B1734563FD5F2,
	XRBaseInteractable_get_onFirstHoverEnter_m29024B487C2CF7FFB483C23F13EA574631E5D664,
	XRBaseInteractable_set_onFirstHoverEnter_m51A49CF3B71F9D44F8E3338294D85A68BCD27797,
	XRBaseInteractable_get_onHoverEnter_mA75BDB23C2109233FA33C84958C384C63A38439E,
	XRBaseInteractable_set_onHoverEnter_m1288D80BDC3D6FB756E4BC5CBB3FA9A99AE2ABBB,
	XRBaseInteractable_get_onHoverExit_mA3B560C4BE57EBF902829108DFDB6C05379B2C5C,
	XRBaseInteractable_set_onHoverExit_mB9633C1BD6E2F19395F7A862AFCC98AFCC921915,
	XRBaseInteractable_get_onLastHoverExit_m0D4C817249076E77C85F319AB9A38EB9A956032A,
	XRBaseInteractable_set_onLastHoverExit_mFBC67D28EA4183A7EE9E15E0009CE83E5938FF3E,
	XRBaseInteractable_get_onSelectEnter_m7C06801085DC6791EDCC69F4485922945867B358,
	XRBaseInteractable_set_onSelectEnter_m832750946C516B48292DD25F7BB161074BBF3F53,
	XRBaseInteractable_get_onSelectExit_m9ACDC6F112B9313C850FB952D976662A108D52CF,
	XRBaseInteractable_set_onSelectExit_m5C9739A44D9DA0C0DB4DF472BE0717028D63637E,
	XRBaseInteractable_get_onActivate_mC20E07057B8748CAF89CB8A6D3A369E079C2B6E0,
	XRBaseInteractable_set_onActivate_mD158ED280BB7B1F2E015CC5CFC99B4BCA22B5ED8,
	XRBaseInteractable_get_onDeactivate_mC0F19CF6211D9E729A10B09B6DB4079F76D6EA18,
	XRBaseInteractable_set_onDeactivate_m88773396256EB3541C11C8484B5718C4B981B0C0,
	XRBaseInteractable_Reset_m220E20015F1BE4972A549B081EAAA3C233D1D7E7,
	XRBaseInteractable_Awake_m79DDD24D35EF96A8A8A596F67AEACAE055B0F559,
	XRBaseInteractable_FindCreateInteractionManager_mCADB9DEB1058D03AFA62F6650846A91CA1028D2B,
	XRBaseInteractable_RegisterWithInteractionMananger_m1BE91EC4AE39F44CAFAAB38B839D7D7D92CFEFA1,
	XRBaseInteractable_OnDestroy_mC92AFCFE4ACEF2A18C9284B3DCE33B90FE1197FA,
	XRBaseInteractable_GetDistanceSqrToInteractor_m18E50C4D249F594F5200B8434F9824CE318CB724,
	XRBaseInteractable_IsOnValidLayerMask_m6731F4E3BAF20A2F7D6B3A8C80EA7F1ACF106E1B,
	XRBaseInteractable_IsHoverableBy_m918E1EB1F5ECFC4B0F9A5DD481E30CC8DF701587,
	XRBaseInteractable_IsSelectableBy_m37E04117555CC595B49CAF2FB87632F903A8B580,
	XRBaseInteractable_OnHoverEnter_m455EB6549212781FD8C150FE13E0A80E55CC1DAD,
	XRBaseInteractable_OnHoverExit_m2A77B4701C52F27D0F1CD82467484C82B868641A,
	XRBaseInteractable_OnSelectEnter_mF11D017950D0020B2CC1D9A1D477C5A80BD43A16,
	XRBaseInteractable_OnSelectExit_mE56AD354EF9EF821013ABCF83230CFD0275E315D,
	XRBaseInteractable_OnActivate_m449A16C713009626E0E7152A0256D6CA6CB54805,
	XRBaseInteractable_get_customReticle_mD362ACAA7427380008B92254D5D54E6CCBFB96BD,
	XRBaseInteractable_set_customReticle_mCC32EA8360ADE05FAF57FD2DF26F213AB7A06305,
	XRBaseInteractable_AttachCustomReticle_mBBBA8E52B6C2924BE391D085D2EE28341D4EC33D,
	XRBaseInteractable_RemoveCustomReticle_m4A43D9872E9B339890A4E33AFCF0495B7E3B5C61,
	XRBaseInteractable_OnDeactivate_mB03318B9315788B9F0A1CBA753533F49DC469A28,
	XRBaseInteractable_ProcessInteractable_m2178A2D08A3714E3E34B3747DB204CFFC514B7D8,
	XRBaseInteractable__ctor_m8C7F386C4768CAFA731C55B9BD73656FF790F257,
	XRGrabInteractable_get_attachTransform_m862693B3A4363C54ECE7D58892CCA365C3EAD564,
	XRGrabInteractable_set_attachTransform_m1A515A4DEFF4BB5D6F3AF18EB586DDCB399E8DB9,
	XRGrabInteractable_get_attachEaseInTime_mF03620A5B99DDEE3F4018A60974FA60D5F9699AD,
	XRGrabInteractable_set_attachEaseInTime_m3F9539667CB670CC7D02A0277EEF600731F0018B,
	XRGrabInteractable_get_movementType_m80CC6F327C05751202C0E14AD3D5D653D8849EF7,
	XRGrabInteractable_set_movementType_m59D86D860B23167D42166C62E29C3F88B43194E3,
	XRGrabInteractable_get_trackPosition_m157384DF8DCED4430149D13B20DF5A7090039BA8,
	XRGrabInteractable_set_trackPosition_mE201DBD3856714BBB8B06C7A32FEB05D3BEF5B5C,
	XRGrabInteractable_get_smoothPosition_mBC5A08AC5DB148F540082712FBA3786DD9D0B3DB,
	XRGrabInteractable_set_smoothPosition_mCCA9EDE743FCD50825B3DD42A02A291BF948C4BB,
	XRGrabInteractable_get_smoothPositionAmount_mA471FDA39E5E3E4B53A3EAA02B686C5E6C9D9E22,
	XRGrabInteractable_set_smoothPositionAmount_m71C1BDECF12079DFA438F0421F16078239F5C361,
	XRGrabInteractable_get_tightenPosition_m2CFB0F65F5AD25CF1450039F7F916A8F45086F30,
	XRGrabInteractable_set_tightenPosition_m6ACB5F1DCE808EACB4DD3E8D55E81F7AF30D6568,
	XRGrabInteractable_get_trackRotation_mC03716ADC86ED7A9F2AE86FFF4F6BD01CB2C2795,
	XRGrabInteractable_set_trackRotation_m1CF36DFEAF88077CCD72F7156DDDCAFB70FC5B5B,
	XRGrabInteractable_get_smoothRotation_m65355D11CE9839373923EB9467310EFFADBB74F1,
	XRGrabInteractable_set_smoothRotation_mFE4126DC8FEB5BF96526D439F32ED250D7396635,
	XRGrabInteractable_get_smoothRotationAmount_m552CD592CB56817C8C6FE707F67356081560A12D,
	XRGrabInteractable_set_smoothRotationAmount_m8AC286E5C4392A7E58DD40B6944B1F47F83FFBE8,
	XRGrabInteractable_get_tightenRotation_m6585CAC0635CCB8A437601E0AAA8E6B9B7ACF01B,
	XRGrabInteractable_set_tightenRotation_m996BF739AC92BE581876179CCAF1428C5E7D7F55,
	XRGrabInteractable_get_throwOnDetach_m29763F3151096255FD2E33C74131582740A9F648,
	XRGrabInteractable_set_throwOnDetach_mEE1025D07D8957A312FAFC5FD1B0D3C48EA9D235,
	XRGrabInteractable_get_throwSmoothingDuration_m2CC87335A9470ACB90337AE57F871C0908A2D9F7,
	XRGrabInteractable_set_throwSmoothingDuration_m9C5C524411B33469E54B742F534B141974491C53,
	XRGrabInteractable_get_throwVelocityScale_m9899BF6EB4F1D7A0AA1075F651A6C27D48DF7DD2,
	XRGrabInteractable_set_throwVelocityScale_m40C7F957366FB967F58A577294BB6DFC1D33EAE9,
	XRGrabInteractable_get_throwAngularVelocityScale_m7464F02849EEB3B8D9A9C10C40945C018E04CFBE,
	XRGrabInteractable_set_throwAngularVelocityScale_mE2349E400B925E9B240186D0A134F838A16FB65B,
	XRGrabInteractable_get_gravityOnDetach_m9F46816E5BF80657BDB6C78DC06C70845077C2B4,
	XRGrabInteractable_set_gravityOnDetach_mEE5F50DD837EE54667C57782A75B23F1BFFFCD0C,
	XRGrabInteractable_get_retainTransformParent_m3BBC6F2A1B488C2359D0786801FDD8B2D456B119,
	XRGrabInteractable_set_retainTransformParent_m34708BF8C2A6893C903107A1016D70DCDE2EC517,
	XRGrabInteractable_get_selectingInteractor_m69CAFC4677B95560A13EF44442B6997433464E37,
	XRGrabInteractable_Awake_m1BF1F714B162AA0534AD5374EBF8A1473E12C151,
	XRGrabInteractable_ProcessInteractable_m2137F159D30520448DC9D16E2416622266215317,
	XRGrabInteractable_GetWorldAttachPosition_m2F4A65271C9044F80934FF2AE53E287251C3C13E,
	XRGrabInteractable_GetWorldAttachRotation_m41E15EE8EA3D77A6E0B8A71FCF33D9B4F99A4F8C,
	XRGrabInteractable_UpdateTarget_m305427E797921DC28F17601C032225B3CF7ACA2D,
	XRGrabInteractable_PerformInstantaneousUpdate_mF11C16E54E3794378ACCBDC7D5A7C373B9074D3B,
	XRGrabInteractable_PerformKinematicUpdate_m7FD846A18AFF18D01FFE6534C4608E37EA0E64DA,
	XRGrabInteractable_PerformVelocityTrackingUpdate_m84739063D192F1F4B9CB98C4C8729FB2BE809B45,
	XRGrabInteractable_Teleport_m6C564F277BD72C9AD458746E714F3FD74B2340C1,
	XRGrabInteractable_Detach_m218F564849DC940DC9F5D99DE36B4F7E9EFA0C30,
	XRGrabInteractable_UpdateInteractorLocalPose_m559E77C3864E825945398CA07E4361051BE09AE6,
	XRGrabInteractable_OnSelectEnter_m12F361A216C9CE799645C5BC678BF42EF0D90861,
	XRGrabInteractable_OnSelectExit_m3B8CE08F1FCBFEA219AEC620EF03215EE0A3BECC,
	XRGrabInteractable_IsHoverableBy_m71C308782F1159E004079260774829E6C0FF73AA,
	XRGrabInteractable_SmoothVelocityStart_m0E0DB96FDFEADD0C42728BE89A8D75E010218D76,
	XRGrabInteractable_SmoothVelocityEnd_m556FA381B4AE2A51012D05CB62446EDAE79FC3E8,
	XRGrabInteractable_SmoothVelocityUpdate_mB062D40EE08DA2D20D411F1D531F7A4114154BB3,
	XRGrabInteractable_getSmoothedVelocityValue_m633346177413351F8DC72FF2B39F329C00A65468,
	XRGrabInteractable__ctor_m37710191367C3F56074C135870E35E0918E758B4,
	XRSimpleInteractable__ctor_m3F955EA3DE342BCC5CE0562B5CB7C3644A9E9EE5,
	NULL,
	NULL,
	NULL,
	NULL,
	XRInteractorLineVisual_get_lineWidth_m18710176FC537DEB413370C7C0E7A521339E2B2F,
	XRInteractorLineVisual_set_lineWidth_m8934617A2CE9568373A6D7C88578F75D56DFA1A9,
	XRInteractorLineVisual_get_overrideInteractorLineLength_mEE23EE3B15284131BB7019386E88B76C95C4978A,
	XRInteractorLineVisual_set_overrideInteractorLineLength_m556194DE02DA3EEC3146F51B75DF0C5D349E7125,
	XRInteractorLineVisual_get_lineLength_m85CFC2FEBB7416938EB2B93CC3F7586F79E32D84,
	XRInteractorLineVisual_set_lineLength_m5B84CD185E41B83DB5FCF7CAD35A25A49966BB21,
	XRInteractorLineVisual_get_widthCurve_m72A134DE24BE4A0DB179848D442BFBFF8C7844ED,
	XRInteractorLineVisual_set_widthCurve_m6D02C08E49DFA525E8BD382A82D5C5F7C11E8D38,
	XRInteractorLineVisual_get_validColorGradient_m484CCC79897732334CE93E09EA154C66A2C03AB4,
	XRInteractorLineVisual_set_validColorGradient_m4978178317009699ECD79B197B283D2422C09E39,
	XRInteractorLineVisual_get_invalidColorGradient_m4BEC57B84C9FA4285A4DA4D3890581D676E90ACC,
	XRInteractorLineVisual_set_invalidColorGradient_m61D828EB2FE273ABCFEC466B7CCDBF1A6C1D9A96,
	XRInteractorLineVisual_get_smoothMovement_mF098F50939981B6F2F3AC33C99C63BAA6316D885,
	XRInteractorLineVisual_set_smoothMovement_m7D9DE827719C72A20BD451869E197122B1B95657,
	XRInteractorLineVisual_get_followTightness_mC326C0EACEF14A43EF60C191F886CA7B3A9595D0,
	XRInteractorLineVisual_set_followTightness_m28109F87EF28852475B98B742154C99E79BDB58E,
	XRInteractorLineVisual_get_snapThresholdDistance_mACD2188A8F09E1C19CE25084879707DC20F85F74,
	XRInteractorLineVisual_set_snapThresholdDistance_m8E7E1B5481767B423FFDE7E7A7757651F27499BC,
	XRInteractorLineVisual_get_reticle_m4E95EADACF9AA81026ABEB84D328B4DEFF96B46F,
	XRInteractorLineVisual_set_reticle_m8FE9D8281C147F664F1273BE8D261C57E66BD3D2,
	XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m8F4A5C4E96E7BB8B48339C0DD5E23C3FE2A7BE71,
	XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m392A6AC6ABDBF1D9435A435636FFEB861543A75E,
	XRInteractorLineVisual_Awake_m4580BBC2B8AF004C07265B71FADC38FC7F36A652,
	XRInteractorLineVisual_OnEnable_mBEAC76E68500B6521AD4168612FED8EE146096ED,
	XRInteractorLineVisual_OnDisable_m037FF8397E777F7BEC730461CCFE8C1F3B0B7A25,
	XRInteractorLineVisual_Reset_m26A6A421208893DD1F25B9C28858D0A61B23F8CD,
	XRInteractorLineVisual_ClearLineRenderer_m12A591D0DBB12EF33E207EA5749EADF9845CD230,
	XRInteractorLineVisual_Update_m048B642FE6224023DBB1DCBF8BF46FC17E2AC60C,
	XRInteractorLineVisual_UpdateLineVisual_mBAF4BBE6B0F660432C883423069FF3AB6BB1DF01,
	XRInteractorLineVisual_OnValidate_m3D84AEA7FB9CAAB2847417877CBAF0EC76DBCC69,
	XRInteractorLineVisual_UpdateSettings_mEA4683CD450DB3ED40D06350F7E613133EFAE244,
	XRInteractorLineVisual_TryFindLineRenderer_mB6F10478B91887C8D2DCED78F77275C0319B177D,
	XRInteractorLineVisual_AttachCustomReticle_m42ACD0E1E6DE1026B6BE5FD7C570A5A58C94F884,
	XRInteractorLineVisual_RemoveCustomReticle_mAE43F45A0C9FB66175301759FFBF64B7C9BA794E,
	XRInteractorLineVisual__ctor_m05F4354C0719D69C9F6D5B5063F15B746644EC2F,
	XRInteractorReticleVisual_get_maxRaycastDistance_m7555EA620186425507CD52A06F97CCA12328B980,
	XRInteractorReticleVisual_set_maxRaycastDistance_m9232388A53EF4030D1605B557F3E7BA798FBDF24,
	XRInteractorReticleVisual_get_reticlePrefab_m61B43EBE87C0D23AD34AD5D773FAC803B88E20CE,
	XRInteractorReticleVisual_set_reticlePrefab_m733CF9717249A36878A31F74400EF6EB802B91C1,
	XRInteractorReticleVisual_get_prefabScalingFactor_m9EC1B0B6D20FB321C250565DC7B8BE58624AEEA8,
	XRInteractorReticleVisual_set_prefabScalingFactor_m6703A3D1E869669427A7A4BE42A6C5974DDC85EE,
	XRInteractorReticleVisual_get_undoDistanceScaling_mCACE32DE9893831E40AFAB56B4DE021E2A3DE840,
	XRInteractorReticleVisual_set_undoDistanceScaling_mC7F27BBDFC3DDA211BCA7123B3EDF825202DD4A8,
	XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_m953D2A15011C4DEF67FEB66085D675924693E4AD,
	XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_m29C28F760103B1D995643897EA92019393C83A67,
	XRInteractorReticleVisual_get_endpointSmoothingTime_mDBF630C71C458E0765678C47425A3847CFA93E9B,
	XRInteractorReticleVisual_set_endpointSmoothingTime_m440B93645801A20B13D180C6C29E4A03A98D4697,
	XRInteractorReticleVisual_get_drawWhileSelecting_mB2EB291C7EBBBAF05643AA2A38FE1281199804DB,
	XRInteractorReticleVisual_set_drawWhileSelecting_m5673968C0646C399E1F8ED140DA4279E79C747FB,
	XRInteractorReticleVisual_get_raycastMask_m431BD493C44623976B255255460A0EE75DCA6EF0,
	XRInteractorReticleVisual_set_raycastMask_m446330A898844EB5DBA19D7B4266EE3F5BE78E81,
	XRInteractorReticleVisual_get_reticleActive_mE2643807B536606417F695BABE8F50C73DCC1027,
	XRInteractorReticleVisual_set_reticleActive_mAEC43ACA76193F43153068CA28532A4EEC23A928,
	XRInteractorReticleVisual_Awake_mC02C31987911CD4D9AC9EC9947410BF03EDA37E3,
	XRInteractorReticleVisual_OnDestroy_m954C8BB59F1EB3439D9B2034531E40BF698D5833,
	XRInteractorReticleVisual_SetupReticlePrefab_mB29AADD1CC049ECAA97305793F489D434AD42D78,
	XRInteractorReticleVisual_Update_mCF460E61ED5AC801423686DEC78F0E4A4101DA06,
	XRInteractorReticleVisual_FindClosestHit_m79F1C604AE2AA3812ACC5F5CA94AF5F1CAFF45DD,
	XRInteractorReticleVisual_TryGetRaycastPoint_mA9ACF3867020A25BF53EBC10735839B8ACB0C306,
	XRInteractorReticleVisual_UpdateReticleTarget_m9A04A1D4AF7D9FD6462B57249E943116741CF23B,
	XRInteractorReticleVisual_ActivateReticleAtTarget_mBBBD28FF44A71B06170A0D17EC0E9D1DD6D43732,
	XRInteractorReticleVisual_OnSelectEnter_m459E88D8800615976E30F7A45E6EFE114C7E144C,
	XRInteractorReticleVisual_OnSelectExit_m2928EC14A70AB21F2F879564E5CE45D0138C9C68,
	XRInteractorReticleVisual__ctor_m8BC2776AC52BE756B46856BB6675CD70A79339D3,
	XRBaseControllerInteractor_get_selectActionTrigger_mC3B03B7F4D0B7C07101479A46FA3938D13E0F093,
	XRBaseControllerInteractor_set_selectActionTrigger_m0FF90268EA196B74850CCC2D6B45A1B246212CF6,
	XRBaseControllerInteractor_get_hideControllerOnSelect_m384BF23FA3D844C3F0C1B3F814874E10AE704A3E,
	XRBaseControllerInteractor_set_hideControllerOnSelect_m026D33DD0E557ED84082A9B28FC96CA8EDB2ED4D,
	XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_m3B21A22995BFAB6E9410D7AAE857C1193F74464C,
	XRBaseControllerInteractor_set_playAudioClipOnSelectEnter_m6D2C28C6BBC61B9730916282C7E687ADB1001DCC,
	XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m6B9CC9B63717238BC23594E62C220E6CA14CC5C1,
	XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m8C10AD90604CBD5558C1B19C0117AABE9C280BFF,
	XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m3A9625B60C92E44718D17C13222EA70C62C35BE4,
	XRBaseControllerInteractor_set_playAudioClipOnSelectExit_m1FECF9F38D22706C376977516490C46E90286B37,
	XRBaseControllerInteractor_get_AudioClipForOnSelectExit_mA282326331E7D806EE650BB7FE6BD2118A496EB6,
	XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mFDA64A5104EAE4D8813F442DB211F5EBFF642136,
	XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_m462E980B038E7038F6C9F1E0306597A268C87282,
	XRBaseControllerInteractor_set_playAudioClipOnHoverEnter_m1DDD6D2849068CB2489498FF693D410FEDB203F8,
	XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_mD643290F06D3F20269B864FA07D879DC67A733FF,
	XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_m3DD5F5DB46040AE83B15F4C3303DA7869E1967EC,
	XRBaseControllerInteractor_get_playAudioClipOnHoverExit_mC9ED611D2009E3A8BB51B577F33656A515E5C05C,
	XRBaseControllerInteractor_set_playAudioClipOnHoverExit_m624F1FDADC63C6370603B80B7E27F51D4E8E2D11,
	XRBaseControllerInteractor_get_AudioClipForOnHoverExit_m853A5476006B197CB4F64911CE31BE0CF1E3769D,
	XRBaseControllerInteractor_set_AudioClipForOnHoverExit_m8BF214EB7B7129F6379D8AC131CE4ED5B42BACD7,
	XRBaseControllerInteractor_get_playHapticsOnSelectEnter_m5E2745052FAABED5C78396E8DF8532707B3E523B,
	XRBaseControllerInteractor_set_playHapticsOnSelectEnter_m9DA39064D0EAFBBA82C25AE2F13F8DC50559D7B9,
	XRBaseControllerInteractor_get_hapticSelectEnterIntensity_mC1DAA8BF8E4DDF8DA3F1AE792247CFB09F4B1495,
	XRBaseControllerInteractor_set_hapticSelectEnterIntensity_m30D050BCD0A6A2A2DA9D647960F549D007D02998,
	XRBaseControllerInteractor_get_hapticSelectEnterDuration_m410A4C712D66432061FE6F0B756E1C747D61017C,
	XRBaseControllerInteractor_set_hapticSelectEnterDuration_m6B577454DCD8CB6D8C7DFEB7B496147A8C5E3664,
	XRBaseControllerInteractor_get_playHapticsOnSelectExit_m051A9C73AD41A2D0FF5B0852D2E4FDCB4E46E905,
	XRBaseControllerInteractor_set_playHapticsOnSelectExit_mEA5C73828E600CFC6D41CFD91EC397870FFD52D7,
	XRBaseControllerInteractor_get_hapticSelectExitIntensity_mF7C29A0AC8F5C9AB298873ECA9802531EC9F0BB2,
	XRBaseControllerInteractor_set_hapticSelectExitIntensity_mE507564E2B51D80DC6778F8E59D242EBC1DDDDDE,
	XRBaseControllerInteractor_get_hapticSelectExitDuration_m5638563859F2032C6354C7F99B96D2554C5A7AA7,
	XRBaseControllerInteractor_set_hapticSelectExitDuration_mE04EBD54B9F88154BE1A60A5963D77E02E9F44DC,
	XRBaseControllerInteractor_get_playHapticsOnHoverEnter_m914A8B3E32341D4A19E623A582204B20B88BB562,
	XRBaseControllerInteractor_set_playHapticsOnHoverEnter_mCE2B913BD7F2C53D38698FFA9C2E3E4575858D9A,
	XRBaseControllerInteractor_get_hapticHoverEnterIntensity_mD1339CCDEF6D42D4A593170240832FCC4A283D60,
	XRBaseControllerInteractor_set_hapticHoverEnterIntensity_mFF33CDFFE7229B242F7A39DC48D0B89AE74048F2,
	XRBaseControllerInteractor_get_hapticHoverEnterDuration_mE1565B80CA4A08E87C04A384DE3064B63F161C2B,
	XRBaseControllerInteractor_set_hapticHoverEnterDuration_mE338B38F8DD2858D81DF9AC7DAA5CD1DD37F7E58,
	XRBaseControllerInteractor_get_playHapticsOnHoverExit_m9D5734C0432E49B32B3FA6742C56AB2E0E5170CB,
	XRBaseControllerInteractor_set_playHapticsOnHoverExit_mD1EF36344E53A4C662AD1DEE23EC1AC0F7C0157B,
	XRBaseControllerInteractor_get_hapticHoverExitIntensity_m3B124C5FCAD1E41AB72884F19CA366291A984B5C,
	XRBaseControllerInteractor_set_hapticHoverExitIntensity_m08F03E1F9C154F01B34C5EBBEA69F886BEF771E3,
	XRBaseControllerInteractor_get_hapticHoverExitDuration_m431B10F8CA2E3D105473CFD04FB120FA07CD5741,
	XRBaseControllerInteractor_set_hapticHoverExitDuration_m6D7282F2ADBA2AEEA339878F3AD96A6B19BA32E0,
	NULL,
	XRBaseControllerInteractor_Awake_m963160FC66B34AC5FE699F6C8BEED5EBE3577F46,
	XRBaseControllerInteractor_CreateEffectsAudioSource_m443EDB75B9E7137484A01731E9BDED7D3C8F236A,
	XRBaseControllerInteractor_ProcessInteractor_m89A38BCCDDE2DD50F5F85B17431A98D796356830,
	XRBaseControllerInteractor_get_isSelectActive_mE2C1787101FED3096FFB25F3D6FF1A944B938264,
	XRBaseControllerInteractor_get_isUISelectActive_m72E4C5335BDAD2E04144F0EAE0A8328BC3DA8CBB,
	XRBaseControllerInteractor_OnSelectEnter_m2DBA143CCD7C25937592DEA5E19BFB2CD4540E56,
	XRBaseControllerInteractor_OnSelectExit_m3D78EEC75D9220330CC4C281712FA230CBAD8BB0,
	XRBaseControllerInteractor_OnHoverEnter_mC348C0B782B8779F9D0B50D60BFB41999AD91068,
	XRBaseControllerInteractor_OnHoverExit_m7732DD7E34BF1CAC3865D488C11DFCEADB392F1C,
	XRBaseControllerInteractor_SendHapticImpulse_mEF524BFEBFE3752E7D8EF06435B6DA8BFC5FD249,
	XRBaseControllerInteractor__ctor_mCC35C801B5B8C9C8DF13B021BA9AD45542041DF6,
	XRInteractorEvent__ctor_m0D00AE053208EC0079CBD0B502D11E13674A96AF,
	XRBaseInteractor_get_interactionManager_m0524A500D7EA779A49816C2CDDAFE5E174C7279F,
	XRBaseInteractor_set_interactionManager_mC61758909438262074C5FCBC6D41333CF02DF247,
	XRBaseInteractor_get_InteractionLayerMask_m706D28405BA5E3926FD9EEC0D1955159098CF855,
	XRBaseInteractor_set_InteractionLayerMask_m895761A0E88A12DCFE2E1BA2B89208526C3ED5CA,
	XRBaseInteractor_get_attachTransform_mC35D8EB5DD5D4E0FA29C67EE5B5534995B0A9E73,
	XRBaseInteractor_get_selectTarget_m2AB72491DDCE9259810C59A21853D8941334D947,
	XRBaseInteractor_get_startingSelectedInteractable_m92FAD461D1C898A985B2B6ACE4C0407B96A7D21E,
	XRBaseInteractor_get_interactionLayerMask_m8AA1D83AE9A13C8A65DAA2C1B6D83A8A0EDC81D4,
	XRBaseInteractor_get_onHoverEnter_mCE374B1E484877EC9E9786BF3E01DE7CA0F3DF55,
	XRBaseInteractor_set_onHoverEnter_m0C246A4A48EEABD5DAB8ACF865E7C720C8F21B57,
	XRBaseInteractor_get_onHoverExit_mBC1973EFA0BF917797A79D0274D25323F50A828B,
	XRBaseInteractor_set_onHoverExit_mBF8132C6656FF8AD2384E9A14B281321E69EF7A0,
	XRBaseInteractor_get_onSelectEnter_mDBD18EEE886633441903483496C6C80895F9C543,
	XRBaseInteractor_set_onSelectEnter_mFF9830688F6C828F93DE8B1E15F194EA43EE1691,
	XRBaseInteractor_get_onSelectExit_m8F35FFD148A7F8EE1BB7DB0CD4496009CF3C5892,
	XRBaseInteractor_set_onSelectExit_m4D6B0862496ACDE1A2DB8113D621829A8CFD0F66,
	XRBaseInteractor_get_allowHover_m8AA16C59F27DED5103CE26E7E75F62B827C77416,
	XRBaseInteractor_set_allowHover_mE51E161598CADF8153BDD8E8C3006EC0844EEA15,
	XRBaseInteractor_get_allowSelect_mD09EC3B11EC2DC2AD3C51FCA6563AF1EF6ADFA93,
	XRBaseInteractor_set_allowSelect_mFCB46F3E88D5946D281636B0946301F9F0B5EF0A,
	XRBaseInteractor_get_enableInteractions_m776A77C7988AE704740403905F2AA51F74455E60,
	XRBaseInteractor_set_enableInteractions_mF287B3135C4937C6948A6FA83B74AE3FC9A21EE8,
	XRBaseInteractor_EnableInteractions_mD04E011645BF0FA9B6246960B96A5DB38C28836E,
	XRBaseInteractor_Reset_mF3F64F45D5816C4B745EAD7B6556DCAA505FC47E,
	XRBaseInteractor_Awake_mFEBB5E0BCF5C205688878D65F544F9067D4607E2,
	XRBaseInteractor_Start_m50BFCF76917FF7F510DC405A6619CEDB8237AA4E,
	XRBaseInteractor_OnEnable_mA582A33C1F4FF98B6F0E3FBAEF6EB21CC67961A3,
	XRBaseInteractor_OnDisable_m40F9838CF4DA18DC0B6B281992B786C01CC86D74,
	XRBaseInteractor_OnDestroy_mDDE22CB5CEEB46ADD31480DC8453FA27067F04CC,
	XRBaseInteractor_GetHoverTargets_m612455C80FB845FF428EA6D1115CB2C763561228,
	XRBaseInteractor_FindCreateInteractionManager_m3ABCD9402CE04F96ED936CF07A2A3CAFA412A6A7,
	XRBaseInteractor_RegisterWithInteractionMananger_m4E8BFE70DA26D202A996E71AE09E572465C8943F,
	XRBaseInteractor_ClearHoverTargets_m5856C4D188A8987520836A5BE7BA65D51FFB191D,
	XRBaseInteractor_IsOnValidLayerMask_mBC7EE661321AC935E5C5106F17E98DAB76455C97,
	NULL,
	XRBaseInteractor_get_isHoverActive_m28BCFFB444E8C487037906AFC0D71127797CA770,
	XRBaseInteractor_get_isSelectActive_m655312055615991189BB2A15D7A746714B3C46F3,
	XRBaseInteractor_CanHover_m4DA82A0B43D307B7006264EFD743B8FB28BE0B31,
	XRBaseInteractor_CanSelect_m42F071A99050193C815C9D5854AF68301A860A19,
	XRBaseInteractor_get_requireSelectExclusive_m41D4E9822B1EF75314F1CFE282700BE4A0FCF0FB,
	XRBaseInteractor_get_overrideSelectedInteractableMovement_mDEE58B2DC9D4C94E096EC6024EC2F2BA7F356030,
	XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m45FAB49EDD0097503EBC794E38E632877F690BEF,
	XRBaseInteractor_OnHoverEnter_m0A9ADC65D4F36325FD280B77AC59282D582F9B07,
	XRBaseInteractor_OnHoverExit_m624670639393438D40D857526878EFD960EF9912,
	XRBaseInteractor_OnSelectEnter_mFD7BD282D4C4C6A3FE16045E4F2B1103F78314C6,
	XRBaseInteractor_OnSelectExit_m6A8A50C5A1BEDC620DCFC372EBDE43D4AA404736,
	XRBaseInteractor_ProcessInteractor_mAEC1BF7AF8B8424D750EFB8004F6F43852A5CCB7,
	XRBaseInteractor__ctor_m2389520C1806CA9AE2B59EA66A72D8B357E8057D,
	XRDirectInteractor_get_ValidTargets_m2A04723801E832149C52DC797E900A2A0F3A8D0E,
	XRDirectInteractor_InteractableSortComparison_mD65EF60508DE426F7AB037E2B03BE6C6AB430AFA,
	XRDirectInteractor_Awake_m1A178FC5E2A37D208969526C33DD018AF0FC59A0,
	XRDirectInteractor_OnTriggerEnter_m32B796D1DDDD5D572F2F2CC56A16C34908DFD95B,
	XRDirectInteractor_OnTriggerExit_m9E45A7BEEF6FBD8C79AA309FB038F3B158B4E135,
	XRDirectInteractor_GetValidTargets_m49E510BBD1ADF990443A7A5AAD29CA320252525C,
	XRDirectInteractor_CanHover_m8DABE4AE2E19DF7B60B2287543E4E28543B2350C,
	XRDirectInteractor_CanSelect_mD7D6F6D4B56BB13FDCA82F37C9AF5D4DD37425A5,
	XRDirectInteractor__ctor_m9BCE389FD9FC10B07E2B4F97A26DCE4C3FF01737,
	XRRayInteractor_get_lineType_m69D9614AC1F531C7D40AF5A827CAFF2D63F98E17,
	XRRayInteractor_set_lineType_m107B49B31C80C515ACA7C77A1140E5D35FAEA50A,
	XRRayInteractor_get_maxRaycastDistance_m7165049251A0C57C3C9240BA6E8F9E20D9E1923E,
	XRRayInteractor_set_maxRaycastDistance_m22AFACEFD15318EB24834EA7898E4E35F665060C,
	XRRayInteractor_get_referenceFrame_m8B9F83975D5762DFAA3983425FD5D6731290BE2E,
	XRRayInteractor_set_referenceFrame_m69CC444B6BAE2EE4CCB0C9E8AD1B4F19A47AECE4,
	XRRayInteractor_get_Velocity_m59ECD975823AF90697A3E71A16F14D990E500797,
	XRRayInteractor_set_Velocity_mF05C39A7188423E183F8C64832A952D4150A76ED,
	XRRayInteractor_get_Acceleration_m768D0ED7794ADBC971D7A6E76F86E9AB497EC8D8,
	XRRayInteractor_set_Acceleration_m92307B1A32F342DAD6E7F318916353FE2D31725E,
	XRRayInteractor_get_AdditionalFlightTime_mA715F770E9A797BA0C2A207A0AF0B2BCE93B3D50,
	XRRayInteractor_set_AdditionalFlightTime_m4D1DCDB85AD63CE285EAD19B7E2968CE2AF5B80F,
	XRRayInteractor_get_endPointDistance_m8D00D888DA5216ECE3862CCCC801CEB0961BB595,
	XRRayInteractor_set_endPointDistance_m49597E7B05E17046E2BE70837F82A69260C3E0CA,
	XRRayInteractor_get_endPointHeight_m5F66EB6E8F296621A7EA67C8FE94B3C37A6D8F59,
	XRRayInteractor_set_endPointHeight_mBB80755F27FB6563572B7F4280FE1AE1721E7DD0,
	XRRayInteractor_get_controlPointDistance_mB9F75D57BD6587B028CE38D47E1F481E5447A495,
	XRRayInteractor_set_controlPointDistance_m1521446ABFF71F2EF33D5F418885F0E2D2E5A64B,
	XRRayInteractor_get_controlPointHeight_m1AAD564F85FD2F6365CFAEE675A34E94C6D9D48C,
	XRRayInteractor_set_controlPointHeight_m7761B4DB37DE91D0C54E15F20F97B1613487449C,
	XRRayInteractor_get_sampleFrequency_m993DA9CED98253A41EC19516A1DFD9C92BAFB27D,
	XRRayInteractor_set_sampleFrequency_m0B07A62D1C556DF31298DF6E04EAE2A769CAAAD1,
	XRRayInteractor_get_hitDetectionType_m30BCCEB490FD32892428BBBC1C1EC56416328310,
	XRRayInteractor_set_hitDetectionType_mA5AF55C15AC9302F4F9087100871185EE0BF6B1E,
	XRRayInteractor_get_sphereCastRadius_mED19AD64F61D5413B5BFEA77E9E3F50AB7FEDB79,
	XRRayInteractor_set_sphereCastRadius_m2B9599081095234B9E066A2D656D6B644D6CFC20,
	XRRayInteractor_get_raycastMask_m285AC79024FF906CC7FA9C69F7F25CAB6A684BBE,
	XRRayInteractor_set_raycastMask_mD417643CD49C5D1CB73F40F00D107B9ACF6DB7E5,
	XRRayInteractor_get_raycastTriggerInteraction_m3D21554D90B3D75F3B67CAB459432B19AD415A03,
	XRRayInteractor_set_raycastTriggerInteraction_mCBB1567CB7CC52711B85A47DD6D3B2F2108F23E5,
	XRRayInteractor_get_hoverToSelect_m9B985C38B0C7905CEAB8752E690F76B2F21A88EE,
	XRRayInteractor_set_hoverToSelect_m4F985CDB474B582030AA85B93F76BDF00815CCC8,
	XRRayInteractor_get_hoverTimeToSelect_m90834E31EB97172737F150609F7413C0B9482C1A,
	XRRayInteractor_set_hoverTimeToSelect_mDE2CA372995D5A0AC79A39BF62711581A7B06690,
	XRRayInteractor_get_enableUIInteraction_m821A148D23F18A1782765EBBCBD0BB2E7C790CC1,
	XRRayInteractor_set_enableUIInteraction_m6C0841923B80991EE009F1699D02610B211CBA15,
	XRRayInteractor_get_Angle_mB52BA01355416A79BB43795B6FBEDCB98040C0BB,
	XRRayInteractor_get_ValidTargets_m0A4F2287A0ED9829D930C91568EAB060AE8AD7E5,
	XRRayInteractor_get_m_StartTransform_mF3FF8BE0CF9B8A70A7DB3B6DEE49C862C249EB7E,
	XRRayInteractor_RebuildSamplePoints_mA12051974A132F73638084F5DA9444DA59962B76,
	XRRayInteractor_FindOrCreateXRUIInputModule_m6C7E97B899EBBB52BE0D57C2694FF0FEBA10D266,
	XRRayInteractor_OnEnable_mBA6F5370C4AFE61B54E80FF3C0ECCAC324EE3159,
	XRRayInteractor_OnDisable_mE4732DE5B5EE56A6C47BA563AD0CF58BF1E70F6B,
	XRRayInteractor_GetLinePoints_m9735576EA4917C96A841A642608B86DF2915EE7B,
	XRRayInteractor_TryGetHitInfo_m3DFF9A5E6E6032A189181AA6FD391B105933AAE9,
	XRRayInteractor_UpdateUIModel_m5AC12E1086A92D5DC240F4707616F3D03A797968,
	XRRayInteractor_TryGetUIModel_m2C1C217D1BDBBEFDA32D23473A3E641466CE0EF3,
	XRRayInteractor_GetCurrentRaycastHit_m1629DCCB648079BBFE80C45317AA7B750751605B,
	XRRayInteractor_GetCurrentUIRaycastResult_m99F49842196B1AF29127F16EDA58932A76382E21,
	XRRayInteractor_UpdateControlPoints_m067571721401422ECAF256F4432A3136A3D9E1AA,
	XRRayInteractor_CalculateBezierPoint_m3163B78D83E67565E8EBF0F852015D6981C3E954,
	XRRayInteractor_CalculateProjectilePoint_m10200BF900130144930C8580E7F47DE2FF9ED608,
	XRRayInteractor_FindReferenceFrame_mF3227A07A39CAB1B462421953E1D8E111A6B91A7,
	XRRayInteractor_ProcessInteractor_m304BBCD520BED85920893C7A3537DA0599FFDAA2,
	XRRayInteractor_CheckCollidersBetweenPoints_m73B5EC8B3BD6E3D0D6D90C9E57AFDDEE8F98D653,
	XRRayInteractor_GetValidTargets_mD2C50F88BA3F905357C5D70072C800CAF9ACB2D2,
	XRRayInteractor_CanHover_mC4EB027D09FF38A796E8C3A00FBB74B31FB6B462,
	XRRayInteractor_CanSelect_m6089433C736EF15DAD54CD02BAD1ACB8E6107003,
	XRRayInteractor__ctor_m433214E833E8EC0D7CA6D47354F435AC87D2703C,
	XRSocketInteractor_get_showInteractableHoverMeshes_mEB1DF83F62CCE06D1CF062FD112F5255B9E109A9,
	XRSocketInteractor_set_showInteractableHoverMeshes_mC61590004B3774828104B4F1CDB23F458D2673A9,
	XRSocketInteractor_get_interactableHoverMeshMaterial_mEDA7A7C7743746CB9219018FAE3E8FDE87864D47,
	XRSocketInteractor_set_interactableHoverMeshMaterial_m46A16B36DF990A4B31B625C671DEEE2F1339766B,
	XRSocketInteractor_get_socketActive_m8629C92707FCD8DED816AE64EF929E07EBEAB399,
	XRSocketInteractor_set_socketActive_mF223A5ACD38EDE357BED6CB77E9AE1FDD40FE371,
	XRSocketInteractor_get_interactableHoverScale_mBE4CA2E7BC9470068C4D9B1DE679E18240A50D6E,
	XRSocketInteractor_set_interactableHoverScale_m7A3E7229DE0881A7BE788BEF57F49714E5489130,
	XRSocketInteractor_get_recycleDelayTime_mA779E8DCCA14636DFD812DCE7A52DD1D792D7F48,
	XRSocketInteractor_set_recycleDelayTime_mA76B7D29AE438D4554A405D0AB843592B8547252,
	XRSocketInteractor_InteractableSortComparison_mE1085975C84578503975834D933053CDC608D610,
	XRSocketInteractor_Awake_m3249DE7BA9575FE08C854F8C34820266CC50FDB2,
	XRSocketInteractor_OnHoverEnter_m3B4A036366DC7D742EA67E04464145DDA8FDD9B7,
	XRSocketInteractor_OnHoverExit_m2B0F734395998BD1224FB038AC6BBB7DF94B5A81,
	XRSocketInteractor_OnSelectExit_m6C23A0B6A2A23965D0D2B3837F9504D98FFC2D83,
	XRSocketInteractor_ProcessInteractor_m913CC4783E116E7919A13BF6607F839B6A3D5231,
	XRSocketInteractor_OnTriggerEnter_m312DD6E7D953F60A281C365CC133B23D8222A1CC,
	XRSocketInteractor_OnTriggerExit_m9BC079A9A7FC389D5AFAEF6402CCAA01A7CAE6CD,
	XRSocketInteractor_GetInteractableAttachMatrix_mF9A504406BC409C69D89A5EBE442C1E5EC7E34E0,
	XRSocketInteractor_DrawHoveredInteractables_m0AC6B350CB492FBB75DE5FBCFA5FD9DB67FBFFF2,
	XRSocketInteractor_GetValidTargets_m9C01C78D9AC32A77F26D06D09C2BD1D2B795D02F,
	XRSocketInteractor_get_isHoverActive_m6421AC6A23A3F5EF467222E35C62A08013188D5C,
	XRSocketInteractor_get_isSelectActive_m4F3AE351A49F23F85B31840FA7C2E33321498F13,
	XRSocketInteractor_get_requireSelectExclusive_m8DC1D4332B735BF16EC6A31A0798CE192BAEAEA3,
	XRSocketInteractor_get_selectedInteractableMovementTypeOverride_m0618F1F3E7145F23FA3ADEAE1D012A2622226F76,
	XRSocketInteractor_CanSelect_mFB810DEAA003C5253211A45476DA644C0B0BF99B,
	XRSocketInteractor_CanHover_m5719EF6ADCF67346B0473E90A1B37C98221C2970,
	XRSocketInteractor__ctor_mB0085D92313C64FE397CA8C8C1384F6F62977CAB,
	XRInteractionManager_get_interactors_m75F118A92316AFA60642DD5DF0DC0FDA310E12DA,
	XRInteractionManager_get_interactables_m46ED191A4D547C7384FCB9F3FC992C213E30F5D5,
	XRInteractionManager_OnEnable_m405111A8E472033A1F24E66FB5705D38E559BF88,
	XRInteractionManager_OnDisable_m9B22A64A3F161F1B805B72ED8384A886820F99AE,
	XRInteractionManager_OnBeforeRender_m4BB1422C4AAFCFFFD54C4AD32F3C1BB47A28C525,
	XRInteractionManager_ProcessInteractors_mBD9C5510D94031B548509CC2865E0EC7BC94C30A,
	XRInteractionManager_ProcessInteractables_m9D527F569EA357546BAC71A0592684F251291FC0,
	XRInteractionManager_LateUpdate_m5E3864D93DD0E4E2572C37AABD798D70494B6306,
	XRInteractionManager_FixedUpdate_m71F4117FCA47B4FA1AADAD795E15940479D512F7,
	XRInteractionManager_Update_m1741D3A77E5129A979C62D95C63C9BBDA73FCD8F,
	XRInteractionManager_RegisterInteractor_m44ADA7384A1E08BF7ABFD1615CED287034068205,
	XRInteractionManager_UnregisterInteractor_mEF83EB5FFB8B3FEB0E317A7B37AD9202C35A85CF,
	XRInteractionManager_RegisterInteractable_m81AF897E7E94C539A9A6A2BDDB0AF57F671584BE,
	XRInteractionManager_UnregisterInteractable_mEC5E5DA8AF2FF275C2942AC77A460997669E1A8F,
	XRInteractionManager_TryGetInteractableForCollider_mB8869F30597BE71571F7540DF4E946F4127CC05B,
	XRInteractionManager_GetValidTargets_mE6B61F09D67079A619256E89104E7B264B7F5755,
	XRInteractionManager_ForceSelect_m444C94DFCC4D8CB9D95A7DBB240C854EA23C427D,
	XRInteractionManager_ClearInteractorSelection_m3B3884EBC998389C72456AEBC5CEFF04FE741C84,
	XRInteractionManager_ClearInteractorHover_mC90678CA15B445FFE8BA3026BC9FB208DCD0B520,
	XRInteractionManager_SelectEnter_mB91BCE65D82FC7589053F69B27084A1F8C5FAC15,
	XRInteractionManager_SelectExit_m4266F182D5396FAD3409ECE4C8D7DE61BB867078,
	XRInteractionManager_HoverEnter_mC051716D4C05FF94A1410DBB5E9AE59CDDC71C1C,
	XRInteractionManager_HoverExit_m74A5704B91D15BA067E4FF2537337DD62F270073,
	XRInteractionManager_InteractorSelectValidTargets_mAF3592E3D5F8CF6BA2CB0A7F3443CA6740A32D46,
	XRInteractionManager_InteractorHoverValidTargets_mB562C96BC84F091D3E4022D6D973A302F95E9962,
	XRInteractionManager__ctor_m30F956C2FF9995AA89F349C10A6FF2A2050BFDAA,
	LocomotionProvider_get_system_m90AC7397FFA3D20AF8997986D070C25157E12202,
	LocomotionProvider_set_system_mD14CD68037C09DF8034D4A49F3C2F057437D448C,
	LocomotionProvider_Awake_m319D924047BCDAF59A49FDE34D6A2484EBDC721E,
	LocomotionProvider_CanBeginLocomotion_m7474CB758B89D29EF1AA97790BEAFBC78C4A8689,
	LocomotionProvider_BeginLocomotion_m89820B0677BC57D861FC5F83296EE379E9C278B4,
	LocomotionProvider_EndLocomotion_m04D2B0759DBE4B478C97A8FC2B913E534B169F89,
	LocomotionProvider_add_startLocomotion_mCFF63EAFC37996ABF906AE4F8BEB1DF7B009BA64,
	LocomotionProvider_remove_startLocomotion_mE5C113C124FB0792043E7E009A1A36870B12192E,
	LocomotionProvider_add_endLocomotion_m71E025814D3F746CB15A187CD26604939335C6C7,
	LocomotionProvider_remove_endLocomotion_m6F24729D33471877E901B54EE0E3C016F3D79B40,
	LocomotionProvider__ctor_mA9AB6ECD039DBD874A605B02A6BA4B4A5095F2BD,
	LocomotionSystem_get_timeout_m4295FF47DC39F04627416F8B8F668E97B835F56E,
	LocomotionSystem_set_timeout_mED341E185C0E190974D7D662E7C0ECECB01654F3,
	LocomotionSystem_get_xrRig_m1B83D3792E057D7FECD7F6860FD402A11EA7C670,
	LocomotionSystem_set_xrRig_m2466A078FF131165F9D2F21D15D001279CDF2F6B,
	LocomotionSystem_get_Busy_mE14AC351FCB03E9D7BA392B59EA22846C6BB657A,
	LocomotionSystem_RequestExclusiveOperation_mE63F786E28C3D73F03F561E7E7A8677E1FEF7D9A,
	LocomotionSystem_ResetExclusivity_m02A942B4641B4C4870AD4A67CB49F2F28E8C7614,
	LocomotionSystem_FinishExclusiveOperation_m0823B3BE4524830F038C39C761C2BC95847CF731,
	LocomotionSystem_Update_m716EC5E445CBF55CFA1DB65D369022A0DB0FE2F2,
	LocomotionSystem_Awake_m3C61E3D8AA130EE36CC34D63E3270E9C40C4B2EA,
	LocomotionSystem__ctor_m69F7336A303E0D6B3CC183D02DD6057CC1B7318A,
	SnapTurnProvider_get_turnUsage_m9A7456252FE66E68C5D633F928631DB11C07CE36,
	SnapTurnProvider_set_turnUsage_m7EC96F46E738AC17B95F1EC8E6BC1C31DF674C2A,
	SnapTurnProvider_get_controllers_mFC1625466FD1E13DE9089FC4786CB68DF19C58B6,
	SnapTurnProvider_set_controllers_m7D43866D48660809BC1D6497A467A6935E12421D,
	SnapTurnProvider_get_turnAmount_mDA81670D5FFEAEE73131B53C871F3357A3BB7625,
	SnapTurnProvider_set_turnAmount_m779DD8B8F95DF60E7B8E7056FBDD5D33FC3C44B0,
	SnapTurnProvider_get_debounceTime_mD099EFC88D0543E3E49E8D0E54E5DFB3F5F65E48,
	SnapTurnProvider_set_debounceTime_m9E634BB99F4193DDC417F911ED000E25B77744B7,
	SnapTurnProvider_get_deadZone_m1FD6F324B136B3AB40B6B63AFEBCE10751BFBF21,
	SnapTurnProvider_set_deadZone_mA5102E3A68E6C0FB97680AF1272B6F6BF4840D8A,
	SnapTurnProvider_Update_mAA48D563873E5DAA50472CA9F33886FAC7E5A945,
	SnapTurnProvider_EnsureControllerDataListSize_mCC2C823B78A132510AC4B82B62E8B45060C0FD2B,
	SnapTurnProvider_FakeStartTurn_mB7B5E4483B2A369DFC73EEB5535553D474BCF7A4,
	SnapTurnProvider_StartTurn_mD5E37AB69B4C9A39B9EE51801E060750AD23CD63,
	SnapTurnProvider__ctor_m4023B7462EA0BED60E21C2F854382788D17663C1,
	SnapTurnProvider__cctor_m7183A1445A27BFABFFEE79E366521B4CA3902806,
	BaseTeleportationInteractable_get_teleportationProvider_mEB5F711AEA32E94584895626496838A398EAA8CD,
	BaseTeleportationInteractable_set_teleportationProvider_m6569BF87EF7DD8D99FFA2A3F038E8D460BA74D26,
	BaseTeleportationInteractable_get_matchOrientation_m225912F45B1FEF3A1B72E1A97E3A2FB74C09C0C2,
	BaseTeleportationInteractable_set_matchOrientation_m190F2D4F391326F04F7147DD402478CF242B0E03,
	BaseTeleportationInteractable_get_teleportTrigger_mE6F011E002849389B186C18E26AC6B1C5D8003FE,
	BaseTeleportationInteractable_set_teleportTrigger_m5DEA8F17C83662D2FAF502F6BF2C521E9325E388,
	BaseTeleportationInteractable_Awake_m134F34477CD14CD67A0797B26D4F74AA849D7A5B,
	BaseTeleportationInteractable_GenerateTeleportRequest_mDC785801939118EC5360284EF76CD34CF9741CAA,
	BaseTeleportationInteractable_SendTeleportRequest_m098E54A8C71EFA83CB91A531177EE1064440A4D6,
	BaseTeleportationInteractable_OnSelectEnter_m26607CCBC4B600DFBCD2D537D55A8CAB2939545C,
	BaseTeleportationInteractable_OnSelectExit_mF3942411DE00BA86260134262B5FA775C9809CAF,
	BaseTeleportationInteractable_OnActivate_m1E35E2D40EFAEB185BC6AEC65796B97F84D86360,
	BaseTeleportationInteractable_OnDeactivate_m099EE523E74506D53A31224E62A7E371D2177F67,
	BaseTeleportationInteractable__ctor_m4F0BBD2EBF8F6A0DEAE96763AE817A1F3055E404,
	TeleportationAnchor_get_teleportAnchorTransform_m6B549D02B8F75DFEBBEBE5E62CE5DC3AA3129ABB,
	TeleportationAnchor_set_teleportAnchorTransform_mCA4A86C9278E39B14A055532294FD6256A2927B9,
	TeleportationAnchor_OnValidate_m9F822017731812291A11EA3302F9F33A4FAA092D,
	TeleportationAnchor_GenerateTeleportRequest_m4F2DABFE22673CB2FD1662AF3DCBC0FA4A8E977C,
	TeleportationAnchor_OnDrawGizmos_mB7657FFFEFD993F91EA0339A982E2D61A12F5DFA,
	TeleportationAnchor__ctor_m2EF32665CB4536C9BCB3D919496F37AAC9609861,
	TeleportationArea_GenerateTeleportRequest_mF92C0C18328D0C5AD6E88EBA19F7E9DA7D9CB748,
	TeleportationArea__ctor_m5D357C613A823E2C47B7382BB36E9BFC9834D9C0,
	TeleportationProvider_QueueTeleportRequest_mDAAC9DEEA62DF4317F333093C36B0D31D57FD349,
	TeleportationProvider_Update_m217AE96751464DF400B89AADDB8FFACB8005A73C,
	TeleportationProvider__ctor_m759A4088CA464F0681131E18F6A80139BEC6ECBA,
	GizmoHelpers_DrawWirePlaneOriented_m6EECE8744365F829183E391CBC7B33A46105E38E,
	GizmoHelpers_DrawWireCubeOriented_m3E9BD666956DD13D3D98F4510C6A26269B83AAD4,
	GizmoHelpers_DrawAxisArrows_m1CC0C0842A992FE53EE3C08D99FAE169A8A52B6F,
	NULL,
	XRRig_get_rig_m16325CCB21390B2F05097C4C6F65F490A1460AC1,
	XRRig_set_rig_m721C4F2D42B03FE1DC3BEC3D82C4BE885C68572A,
	XRRig_get_cameraFloorOffsetObject_mF76C3E61CD4F1CB19BAF6D5FE2F948B3A264138E,
	XRRig_set_cameraFloorOffsetObject_m4A379E04866CCBADA19BEEE0BBC523E65AEAF6CC,
	XRRig_get_cameraGameObject_m58F01423014802922928F6165F62B8A163EBFDD9,
	XRRig_set_cameraGameObject_m1C2E7F341DADC16F70FE753174646410E51159DF,
	XRRig_get_TrackingOriginMode_m54511194C3D4C5BE8340A4E065A5EA15A377504A,
	XRRig_set_TrackingOriginMode_mACA37604EBF27AA71AB6376616DC1DEEE0A69B7E,
	XRRig_get_trackingSpace_m345A00507105ED4565806FB1F97D57EBC83B4E44,
	XRRig_set_trackingSpace_m8441778B808263BB0D5ABD718F8E99BE8471F7BF,
	XRRig_get_cameraYOffset_m72B07E4CD490EC94A1644DBFF5D0AEA4AA3625B5,
	XRRig_set_cameraYOffset_mE6842FFAAEC9ACA0F2030FC81BA16DE77375FC2E,
	XRRig_get_rigInCameraSpacePos_m766D7B43281AE0F1A68CCDAE970FBF9EE4A15158,
	XRRig_get_cameraInRigSpacePos_m828B57CD2B58880E88C035D391D2FA6A1136EE2C,
	XRRig_get_cameraInRigSpaceHeight_m63D3D88E75333D88893ABDA7165B4A07AF04A425,
	XRRig_UpgradeTrackingSpaceToTrackingOriginMode_m53C631EF6951E0BD2EE03735488804E122B121E6,
	XRRig_Awake_m176BFD1464875C44DE4AB16AD32ECAA0000F2E23,
	XRRig_Start_m6E291BE00FD73FFA55DE55997E1BCF297FF361B6,
	XRRig_OnValidate_m51A585563F541461E88A97C0FAF4695CFFEFA0D8,
	XRRig_TryInitializeCamera_m759EAF84AE8A2E0FADB1DE2E675E27F872897081,
	XRRig_RepeatInitializeCamera_m3BB00D7AC6298C3BFD17D0B463E8A505ACC3CC99,
	XRRig_SetupCamera_m5BDFED6B914201E66B56CBE08D1129E59942D77D,
	XRRig_SetupCamera_m73A1C1692C1A9A3F09F6ECD04BBC84BF775BDE68,
	XRRig_SetupCameraLegacy_mB8A78374B8B9F7AF022D457672B6EE548B910512,
	XRRig_RotateAroundCameraUsingRigUp_m31B8B16233AB236895D6AEC1B4AE71AE967824C8,
	XRRig_RotateAroundCameraPosition_m6E18880AC86ABDB423C768D32C292527E2F13998,
	XRRig_MatchRigUp_mAE3E4F54FF27D95814987AE6929FB469C2286781,
	XRRig_MatchRigUpCameraForward_mA3785D2FE29B8EEDCD3ED57F5B47B648011C976E,
	XRRig_MatchRigUpRigForward_m3C619295B2360F70D6650D8C3CB7422C7DE5DC81,
	XRRig_MoveCameraToWorldLocation_m3CA8830E78C9E1629AE6063D33A13B9B78F7A321,
	XRRig_OnDrawGizmos_m196320CF05C3CC7FB53FA86E42E93516FB1EA276,
	XRRig__ctor_m28B554D72F651B49BA9CFE7AB824ED49EB68289F,
	XRRig__cctor_mB25B8E2255EE3AD909FD5EBF84C63689924D43BD,
	JoystickModel_get_move_m83D23C958A1CA351FDA91DDC1BCE94D92B13C4B2_AdjustorThunk,
	JoystickModel_set_move_m67CCF9D2682BA0A7C7933535927214D515BD553E_AdjustorThunk,
	JoystickModel_get_submitButtonDown_mF8E0291A4C9B76E7248FAF34A77985A728D015D8_AdjustorThunk,
	JoystickModel_set_submitButtonDown_m82D5339F5F822B2362D5298B39D009AE3D25855B_AdjustorThunk,
	JoystickModel_get_submitButtonDelta_m54A995391CF613E8E6E598A20E6AA2C344F6240A_AdjustorThunk,
	JoystickModel_set_submitButtonDelta_m5A50252E0DE0EFC991983AEDB4772A37F01D0D1B_AdjustorThunk,
	JoystickModel_get_cancelButtonDown_m68DB46ED9CAB5AF12DB9371E5E97C752B0E9EC75_AdjustorThunk,
	JoystickModel_set_cancelButtonDown_m242CF5590457AC603A56F77D1626C0A1552E1BBB_AdjustorThunk,
	JoystickModel_get_cancelButtonDelta_mDABC96B31605F56420E31478974E4EF16EA1C789_AdjustorThunk,
	JoystickModel_set_cancelButtonDelta_mCF2503FB0CDE8CB46E11C5087739BAFA24443B0F_AdjustorThunk,
	JoystickModel_get_implementationData_mB685AA91E6CB3036F206E465C5B93489620DF56A_AdjustorThunk,
	JoystickModel_set_implementationData_mA4E28DB4A98DEF4889934E02DB94E2F6C389ED6C_AdjustorThunk,
	JoystickModel_Reset_mFCD687DCA07667BE4FF1FFF30E80F50FC71E6124_AdjustorThunk,
	JoystickModel_OnFrameFinished_m8D2B8F1FA6A00BF63B7AC1B272AC2FB110E05549_AdjustorThunk,
	MouseButtonModel_get_isDown_m27AEA5948516023FD5BC83C295C5F8CE5DDE7253_AdjustorThunk,
	MouseButtonModel_set_isDown_m053FFB273E8260E67C3135F8AC2E4816299A2906_AdjustorThunk,
	MouseButtonModel_get_lastFrameDelta_mD2C353F9AFCFBFA9DA8EA887D0873E2AAB69276C_AdjustorThunk,
	MouseButtonModel_set_lastFrameDelta_mBA68F356F664D2271EB72FFB6B549854C7A18B05_AdjustorThunk,
	MouseButtonModel_Reset_mDF3588426BD02B4C3FBABE9C87DF64CECC6D96B8_AdjustorThunk,
	MouseButtonModel_OnFrameFinished_m66902D752AF7E920EA1480BCA81E82120134E800_AdjustorThunk,
	MouseButtonModel_CopyTo_m448E4998CE711E120CF69D14E944702EC047EAC2_AdjustorThunk,
	MouseButtonModel_CopyFrom_m513879AD7C7FBC253EE932BE1DDF29AD9F8C4847_AdjustorThunk,
	MouseModel_get_pointerId_mD24BC7D61DB8530DF7E7866EEB238E30EA8DB3A3_AdjustorThunk,
	MouseModel_set_pointerId_m827301A0CFAF0D73BB6BFDE3AFC1872586BA65C4_AdjustorThunk,
	MouseModel_get_changedThisFrame_m83E45A1F90A7672359F6BCA794B03FD5DEDF6AF8_AdjustorThunk,
	MouseModel_set_changedThisFrame_m833F02659D05EE961CB3D89C9B045C9BD6659381_AdjustorThunk,
	MouseModel_get_position_m275B4E5FF92FF4B7DD3A24BEDDA0AD070C86A233_AdjustorThunk,
	MouseModel_set_position_mC9F5908867CCEB392DE438B763D36E2590D66AD7_AdjustorThunk,
	MouseModel_get_deltaPosition_m0252301FD99EAFF1E6A3F889CE6B87D6069613A9_AdjustorThunk,
	MouseModel_set_deltaPosition_m5F9E7D8DF5D830349667379EFB2EFF953E4201C1_AdjustorThunk,
	MouseModel_get_scrollPosition_mD7296784A7A3B958AD04D2AC5E86207D71F86DC1_AdjustorThunk,
	MouseModel_set_scrollPosition_mF26341BC9EB8E33AE297B1FFD22148192054B8E6_AdjustorThunk,
	MouseModel_get_scrollDelta_m2E0953E7F952AA3E3ADFE2B0F9E4C6ABBC9F42F6_AdjustorThunk,
	MouseModel_set_scrollDelta_m739DF6E3D48621581393AF9531384BFBAC890C48_AdjustorThunk,
	MouseModel_get_leftButton_m358F56DE6EB3FC9BAE269CD9E60B8195F0F36763_AdjustorThunk,
	MouseModel_set_leftButton_mF39BE4069B31752F6097A443A18C24DC0809982D_AdjustorThunk,
	MouseModel_set_leftButtonPressed_mB8C678C6B8945D252ACB4892D6E7C8EFCD78D442_AdjustorThunk,
	MouseModel_get_rightButton_m88CDF6C0A0322794B3DDD9BCE2ABC5DEA1575C97_AdjustorThunk,
	MouseModel_set_rightButton_mA13E326ABF6838D1D0E3895EF20AAF55C3228CD0_AdjustorThunk,
	MouseModel_set_rightButtonPressed_mCA7F1C430EC0DA33A70E692B164845E30CF89827_AdjustorThunk,
	MouseModel_get_middleButton_m2B2657CCE63992FFEF84EB1E25FAD18DDA386832_AdjustorThunk,
	MouseModel_set_middleButton_m4F8FB3C4D182877503A61E76E18A9BFF1513DD78_AdjustorThunk,
	MouseModel_set_middleButtonPressed_m92B40CEA75E9D1EBF5A1AF0EBA3D5EF317861D75_AdjustorThunk,
	MouseModel__ctor_m865EDFE56B252E91E12529D55DF75ABEC411E5EF_AdjustorThunk,
	MouseModel_OnFrameFinished_m05C103853D5805A20C62F1951FEB605BE6158CF6_AdjustorThunk,
	MouseModel_CopyTo_m4E8A9A1FEE6306BD321301FD6E1ABBA09AE0B720_AdjustorThunk,
	MouseModel_CopyFrom_m6DBF2507A6D626F18D40EC92E329FDA0105C4179_AdjustorThunk,
	TouchModel_get_pointerId_mA6FC68848A544FC0AE876902332DB9EE4CEE1CF3_AdjustorThunk,
	TouchModel_set_pointerId_m2F9D6B74C9BA216895BD6FAB0A0E6C61D72CC230_AdjustorThunk,
	TouchModel_get_selectPhase_mD255DA107D39D9CE074A0A29CC90358589C79CB4_AdjustorThunk,
	TouchModel_set_selectPhase_mD3B758D0FC5A18DC4420A4F90C45608FB684481C_AdjustorThunk,
	TouchModel_get_selectDelta_m10BC9FDD36A6871BCE00CDD3131F10948D7304C0_AdjustorThunk,
	TouchModel_set_selectDelta_m6F0595ABF1D4234F8BA8001FFF8635A6C2DBBB61_AdjustorThunk,
	TouchModel_get_changedThisFrame_mAA9FB3230C6F98A025578DD35672E8DB8E2A7F1D_AdjustorThunk,
	TouchModel_set_changedThisFrame_mEF07D000500150A199867A20E829FAE9FEB65112_AdjustorThunk,
	TouchModel_get_position_m7E5ED3942111B4161343CC9ECF76F03472049815_AdjustorThunk,
	TouchModel_set_position_mA4A6610E16A8E6F81E4971B3C28821865D7F22F6_AdjustorThunk,
	TouchModel_get_deltaPosition_m253E563DE92BFFB8E545D95A18310D6F7D6493C1_AdjustorThunk,
	TouchModel_set_deltaPosition_m8070333DAA1A905BF67329235CDE3B10332D56E9_AdjustorThunk,
	TouchModel__ctor_m1918A09071F3AC531A0FD6F02DD0FD6F2E6F1BA5_AdjustorThunk,
	TouchModel_Reset_m66906BC296B4CD66A60AD3A577BE06AF2C94C788_AdjustorThunk,
	TouchModel_OnFrameFinished_m78332BE60BA57585C80D830807B0FFD4C5EA60C8_AdjustorThunk,
	TouchModel_CopyTo_m28A30540806415BDE23C7088EB9AB3CA5D82C668_AdjustorThunk,
	TouchModel_CopyFrom_mABB6092E8267FB9AB96C9A6EB970F75BB7A7BA82_AdjustorThunk,
	TrackedDeviceEventData__ctor_m9D000221F4423B7645CAD6ADD0212B6923F094D6,
	TrackedDeviceEventData_get_rayPoints_m28D88FDB7E2767AE2768FE4ACEF1139753ADE921,
	TrackedDeviceEventData_set_rayPoints_m9BA0E4D6E45A82995B607F11DA9E04516F090EE1,
	TrackedDeviceEventData_get_rayHitIndex_mCDCCF20598326112CF9841701BC65A9870E59C2F,
	TrackedDeviceEventData_set_rayHitIndex_m1F6A977D2497B6A01679F46F152A5A0BD3E09FBB,
	TrackedDeviceEventData_get_layerMask_mCC4E3FC3DBE17154C10DB69C6437A12C79130D08,
	TrackedDeviceEventData_set_layerMask_m17E07F257B71DBE1D8444C397003FA64ED29F8C7,
	TrackedDeviceGraphicRaycaster_get_canvas_m988AEC308E1E13FC4B75AF431BC0AC287423EBB9,
	TrackedDeviceGraphicRaycaster_get_eventCamera_m93B770F01BEB0D3C7914862E2B9B82EE643A2103,
	TrackedDeviceGraphicRaycaster_Raycast_m8E9CC4101D5754C65196C4647E7A1A84AC1ECDEF,
	TrackedDeviceGraphicRaycaster_FindClosestHit_m72BC91072FE659E18CE38523F541129868ED7FFB,
	TrackedDeviceGraphicRaycaster_FindClosestHit_mF3E5A9A50D1F59852BA7CFCAFAC8696B6975179E,
	TrackedDeviceGraphicRaycaster_PerformRaycasts_m7551E270EBD9058BCE3BEB66A28CC834B2019BBA,
	TrackedDeviceGraphicRaycaster_PerformRaycast_m2BAD3F066AB8B59B606C286B87E21715BD3CB6B7,
	TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_mCAF366E95C766F53176D8FAF34BE7E457773E276,
	TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_m61477CEB7C4295F8A9CCF4A16A6C4007B70A4F83,
	TrackedDeviceGraphicRaycaster__ctor_mDE43A2C0552A6267D8E1DA4A0C6D877306DAC8BC,
	TrackedDeviceGraphicRaycaster__cctor_mA7232584E0E3D76AF8E68032671B6BB4A18715EF,
	TrackedDeviceModel_get_implementationData_mCAB49C3357937CA8CB9C044D45FABA747DC55F05_AdjustorThunk,
	TrackedDeviceModel_get_pointerId_mD0FF45520BF345CE8B873E15D1BE2B729C2D27D5_AdjustorThunk,
	TrackedDeviceModel_set_pointerId_mFF7C1856BCD90F3D2708668DA4FCE5F7A8270A78_AdjustorThunk,
	TrackedDeviceModel_get_maxRaycastDistance_mE355509CDE42A30DD6A1ED2B8CEFBCBE1CFB1A32_AdjustorThunk,
	TrackedDeviceModel_set_maxRaycastDistance_mC26E5F4A629D0008850F717BD3260C47CD12EBF8_AdjustorThunk,
	TrackedDeviceModel_get_select_m38251660639F72711104D52D1D7962FC1D67F19A_AdjustorThunk,
	TrackedDeviceModel_set_select_mACE130EDDD77426A1772469F3F009E417160317D_AdjustorThunk,
	TrackedDeviceModel_get_selectDelta_m47B098C8C85A0EE93A83211020AB00D604EF82BF_AdjustorThunk,
	TrackedDeviceModel_set_selectDelta_m7174A0051C403A2F86E380267AFEBEAC182FF045_AdjustorThunk,
	TrackedDeviceModel_get_changedThisFrame_m99132AF4690ED098D103CF6C1AE64F9D46C1B7F2_AdjustorThunk,
	TrackedDeviceModel_set_changedThisFrame_mFA3101878F06AC8B28A21C6DF1D9DDAA0B8F8F6D_AdjustorThunk,
	TrackedDeviceModel_get_position_mA69AA65D186A58F348657F5CDFCD8F16B8087595_AdjustorThunk,
	TrackedDeviceModel_set_position_mBDA113E82AF63A4729F0C2C0175E57AD8D6FF1D2_AdjustorThunk,
	TrackedDeviceModel_get_orientation_mC6A350F145613009CFA86DEE12E4834C59AC368D_AdjustorThunk,
	TrackedDeviceModel_set_orientation_m5C163A42198861DCED561E56C2D17F694E17DD1C_AdjustorThunk,
	TrackedDeviceModel_get_raycastPoints_m92794D4EA0B62F138C8A7CC11B0B1FFD4DFC7FA2_AdjustorThunk,
	TrackedDeviceModel_set_raycastPoints_m99F499AFEB3CA821D7932944D27A34D1E3C5EFF3_AdjustorThunk,
	TrackedDeviceModel_get_raycastLayerMask_m363F7363B9FB674FBBAC5FCAE2734EFADAC379E8_AdjustorThunk,
	TrackedDeviceModel_set_raycastLayerMask_mE371B8BE9649D9C41C9B9D7B74457FC17E3DE518_AdjustorThunk,
	TrackedDeviceModel__ctor_m75625276E990C86ECFE91F0C1E6A7DAAB940E2D0_AdjustorThunk,
	TrackedDeviceModel_Reset_m9BB80854893C64A471FC3FEC3C3526254DA0D1D1_AdjustorThunk,
	TrackedDeviceModel_OnFrameFinished_mC34ECFF1DF5B4E242E1143200BBB15DF0748237A_AdjustorThunk,
	TrackedDeviceModel_CopyTo_m8EFB5D3DB5E119714FE1FEFE9C5D19F2AA90575A_AdjustorThunk,
	TrackedDeviceModel_CopyFrom_mAC39132B9E0B49594697B4460F0AFB5E856AF202_AdjustorThunk,
	UIInputModule_get_uiCamera_mC981BBAEDDA8D755484CA8A19E692A3DF064BBE7,
	UIInputModule_set_uiCamera_m9E05BADD870B0F7FF5486D12250C84D9610DF235,
	NULL,
	UIInputModule_Process_m05F16F652C1C055981845374C43A8A97CF231DFE,
	UIInputModule_PerformRaycast_m0AFE5A63E32939970FB27513BF9076ED065FBCDC,
	UIInputModule_ProcessMouse_m5C697B37044AAEF1E1CF6EC986891B4B2922D476,
	UIInputModule_ProcessMouseMovement_m4B516FB2B757B72D821BA2CCCFAC4952A5533419,
	UIInputModule_ProcessMouseButton_mF9A5E3EC43D7C70EF2C2D00886D904393D4B4443,
	UIInputModule_ProcessMouseButtonDrag_mDEF2966C52098087125CCBA60714A650F9C66648,
	UIInputModule_ProcessMouseScroll_mEFF04D34B4B034CC19047988BB2385DC8A800E05,
	UIInputModule_ProcessTouch_mF07C36AC9F10E9E9B7F19E3154B999765A55D222,
	UIInputModule_ProcessTrackedDevice_mB1DF1AF69E272CE328403893FB33605DB28582CC,
	UIInputModule_ProcessJoystick_m4FFE76F82B96ED6046CD49118FE01D414B4E8765,
	UIInputModule_GetOrCreateCachedPointerEvent_mFA7338E0D407658F0D89F2848E79DE3EE10DFA1C,
	UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m7339648E449584A86DDBD8801DB8EA79FA40D541,
	UIInputModule_GetOrCreateCachedAxisEvent_m58B3D1B7D59DB97969E7AFFC502A716398D62762,
	UIInputModule__ctor_m8EFCE975AA4801178D24158911CB0DD010C62518,
	NULL,
	NULL,
	XRUIInputModule_get_maxRaycastDistance_mCF1E624E5D27B03A440E42A288AC557C9EFC0AD5,
	XRUIInputModule_set_maxRaycastDistance_mDB06E959A3379F8376FF9EA3EE27DFE6D8812264,
	XRUIInputModule_EnsureInitialized_m04973CB7103DB1C0A8989739E75D5BAA5FEAC7D4,
	XRUIInputModule_Awake_m9B96994F1E07E5003F4B1C75FF71B1D077F1AC69,
	XRUIInputModule_OnEnable_m4FC1BBC0400102BAFE6C8C8AF7362DAEFE5444AE,
	XRUIInputModule_RegisterInteractable_m2480E98E7331EAF0753189065B2ADC4FC796CB10,
	XRUIInputModule_UnregisterInteractable_mC8799EDF5274A739FEB4AE5E6522F232BFAFA3EF,
	XRUIInputModule_GetTrackedDeviceModel_m80B1A753B03C000F932945359C28973C121D8B30,
	XRUIInputModule_DoProcess_mB8CDECC0BC332E569F03FDF7B7BE368ECA3F2570,
	XRUIInputModule_ProcessMouse_m51FE2E0ADBC87D6161D0C453F218B09DF85ED491,
	XRUIInputModule_ProcessTouches_m344B5D739A6557FB87202F13509D027E57CC4337,
	XRUIInputModule__ctor_mE3AAC3931AF2D05519294D9B438FA0121D319A43,
	DragGesture__ctor_mEE1B2B87B41055C50570AB8EEF5BB21135C7C7E0,
	DragGesture_get_FingerId_m3F0E9155632370351892A98E1D09B20A91D85108,
	DragGesture_set_FingerId_mE785F447B5410F96D0A8BCA5E2585BE66E245C99,
	DragGesture_get_StartPosition_mAD54D2A1F886B8DE673B8071999783D24625D2DD,
	DragGesture_set_StartPosition_m926FB8E9858EE6D24ACABF2E994CD3C14831D005,
	DragGesture_get_Position_m06F85393A385574F5F2D61A6AFA8AEA883362E55,
	DragGesture_set_Position_mCCDCCFF6270046499C2592A74FD71FC01DE0BFB3,
	DragGesture_get_Delta_m2C35653E38F6349D2B78DF799D9C721DE13CCF59,
	DragGesture_set_Delta_mDBC232719AA8D6C790FC1D1C6E1DB004BF5D3405,
	DragGesture_CanStart_m4F7FDEDC8D4B562E62B73CBCA0E6CFB1B3E92F60,
	DragGesture_OnStart_mF5584B8CEFACDB7D21FC25E74601D36C3F947B31,
	DragGesture_UpdateGesture_m3400B517C83FF6D144D510681ECB8D965D585968,
	DragGesture_OnCancel_m0428DCC0DEA28601921CA228EE0F3B7B6C368A3A,
	DragGesture_OnFinish_mFC9D15337DB361C202D507B3C40DAC9655E35EEB,
	DragGestureRecognizer_get_m_SlopInches_mF32609E171451759E39C8CE9DB266F0DEE9795CB,
	DragGestureRecognizer_CreateGesture_mD841A9FFA7B4BF13828BA048D942B6EB85DB97B7,
	DragGestureRecognizer_TryCreateGestures_m694AFADB96876AF896557C459A4B440EB5DCD7BE,
	DragGestureRecognizer__ctor_m3CA89FE4900C7FE9B75991BE5F4DF855E78AEF86,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	MockTouch_get_deltaTime_m886BD356BE84D66355562B34F9E6858249FE08B5,
	MockTouch_set_deltaTime_m40C82B1D6158979D0B77CA51F21A4231637A7BF6,
	MockTouch_get_tapCount_mEA1DF0773E789CC4F3636D969EA763CDBF2FF007,
	MockTouch_set_tapCount_m439F8138BA96EB06EFDA4538CC756212655D38CA,
	MockTouch_get_phase_mDD5A621D4100B85CED4BBA70877AC123F5AC039C,
	MockTouch_set_phase_m7208044D032C87397FA43BB744912625A6FFBF4A,
	MockTouch_get_deltaPosition_m738917AC4EFF04FF60F0689E83EF9C6522EC9AF1,
	MockTouch_set_deltaPosition_m4634D79381D9F6385F3EB9DA9BBB9DE040C4B549,
	MockTouch_get_fingerId_mE321C4D0B91BAE2EBEEE08B866161B8FBF7BB874,
	MockTouch_set_fingerId_m539D5015BB2417C1D4ACF57C1BCD544E7DD560A3,
	MockTouch_get_position_m88C8BA71D7E58F0B57214479A0556732003F78ED,
	MockTouch_set_position_mB001DA566D0250D8CF915681D44548045CA0A9DA,
	MockTouch_get_rawPosition_mD3244C058A946CD980AD4931DA71ED5AA134582D,
	MockTouch_set_rawPosition_m7CD233B279D29AA4E0270D0FD4143000B2847336,
	MockTouch_get_Touch_m886DD369688CFC9073BD57948E674327AAA982C3,
	MockTouch__ctor_m86C6649D8B83521B881C31266E4EE843A5EC6915,
	MockTouch__cctor_m75B3A7CC1C87D10CECB879EB8A31BEC85E149E39,
	GestureTouchesUtility_TryFindTouch_mB9DB73CC42445E6CCDE1FCAA7036A4EF1F30CFDB,
	GestureTouchesUtility_PixelsToInches_m9EE885556C2C3FFA95D4523F9652D2F66DED24AF,
	GestureTouchesUtility_InchesToPixels_m34694AFCE76D34C55EAD38F5D6C47DA3F6F2F843,
	GestureTouchesUtility_IsTouchOffScreenEdge_mE4255F6AE7B9C2006CCD54F85084BE669DB845D8,
	GestureTouchesUtility_RaycastFromCamera_mC099E8AD3DE908B762A3B5EB51FBCE955B701EA4,
	GestureTouchesUtility_LockFingerId_mAF14357CC5AA3F2487D4FF999314FAC67E858E2B,
	GestureTouchesUtility_ReleaseFingerId_mB76CF5A6BEFE386B9189B03C7299BAF79AC933AF,
	GestureTouchesUtility_IsFingerIdRetained_m5F2316F7619F10959429FA5623A11BA344861328,
	GestureTouchesUtility_get_Touches_m516613155123117730281CCA07FDE526133A017E,
	GestureTouchesUtility__cctor_m85EF69EBF494F474D263BFD0C8C048BA50B11861,
	PinchGesture__ctor_m822E5323D5EE3C25D80C6121D0BACCAC063D1649,
	PinchGesture_get_FingerId1_mB463C8F4FABB44F07FB88AB6FA917E43EA0CCB61,
	PinchGesture_set_FingerId1_mF0D2DCC3FA5E43CDCB5D30E8F71B49C5647CDF45,
	PinchGesture_get_FingerId2_mBDEDC3FBE5200EF29DCE314A83090013637C6C4D,
	PinchGesture_set_FingerId2_m17F62DE31E9F6854A479D40B5136D382B8B6ACF8,
	PinchGesture_get_StartPosition1_m81C3F71E37D92282B7CF7B6691FBD450FF1E9B9B,
	PinchGesture_set_StartPosition1_m45041BF1E73C5775B1D95B2896300A99345B235D,
	PinchGesture_get_StartPosition2_m8DE6277EF43243A67CEEDA403F616A525C2BA128,
	PinchGesture_set_StartPosition2_mE0AE69D9E9BD762646F934545B3332A8A0422D3B,
	PinchGesture_get_Gap_mDD4307D029D9B28A44F0D615CA113FB5E32D59B7,
	PinchGesture_set_Gap_m7B3AD44B738C7B5173986BC6B5DE8DC9FC1366C4,
	PinchGesture_get_GapDelta_m821292C4E8B5B35DE9585A6A7BB2FCDA8F2DEE58,
	PinchGesture_set_GapDelta_m5167A50D76702DA5163A8208C4F08FA2AC6A947D,
	PinchGesture_CanStart_m67ABDFB5511C82CC9F55B13E2E7A5B02DC73F42A,
	PinchGesture_OnStart_mBD07EA1F4E644D0AF8D9CF9C75E88D2B02355B1D,
	PinchGesture_UpdateGesture_m01E0BE18E23B47253F1603E5643F901BF26EDBAD,
	PinchGesture_OnCancel_mF885A0A19727D854DBC688C22D1D4E461066B54D,
	PinchGesture_OnFinish_m564464E9A0522FEBD48AFB01B7D36B06C05510B8,
	PinchGestureRecognizer_get_m_SlopInches_mD8EB44E2BCCED64E7EC339145F646B385820A3DF,
	PinchGestureRecognizer_get_m_SlopMotionDirectionDegrees_mA52E8E172B0BF7FEF8ADAAD9FD0139A1BA51C1AD,
	PinchGestureRecognizer_CreateGesture_m395FCC58C9FAF25EFA0237814461C2297FE9419F,
	PinchGestureRecognizer_TryCreateGestures_mE2608279FB11818E631353C7C6028D211FD4B6D4,
	PinchGestureRecognizer__ctor_mE432A7DF75369A2CCDECF1EC6A7F38F764B43110,
	TapGesture__ctor_m83F24A5C80F6405C2E1D2A3A1B7F9D8C0C3F3225,
	TapGesture_get_FingerId_mD83DE164580182342062AF51CFCA547F2F0CCE37,
	TapGesture_set_FingerId_m5D91D9AA60CE130B00511467FD8B3878B156C649,
	TapGesture_get_StartPosition_m5B5096E8E9E079FB4D6D592F12CB3F92B67ED548,
	TapGesture_set_StartPosition_mB918274919CEF6E49490576AD7B8BCAF5374F545,
	TapGesture_CanStart_mAEAD687A484F2DA467503F60A9FBD3E984451B80,
	TapGesture_OnStart_mEB43CBAFA7B1025B2F0AC4BC794721941DF93FF6,
	TapGesture_UpdateGesture_m31E3D344E09ECB7897C348AA2C57E2CC6C6C3631,
	TapGesture_OnCancel_m21F54DD075EC3A6C880CFBE850606FCC10553000,
	TapGesture_OnFinish_m155510AFA434FF4F3AEEB243F2F44E22FC56429D,
	TapGestureRecognizer_get_m_SlopInches_m87F15934037BE24E498D4ECF2F77637C99485489,
	TapGestureRecognizer_get_m_TimeSeconds_mFC69E6FBFECB4002174B5D78423874C90922CDF9,
	TapGestureRecognizer_CreateGesture_mB7D66B93A217C245799E006163BC4454F92A569E,
	TapGestureRecognizer_TryCreateGestures_mB23EC9D36727B026B450FB6AE9C104DEACCD9B8C,
	TapGestureRecognizer__ctor_m9B12C5E9E214FD4EFBC7370D51C5F6E879DFE055,
	TwistGesture__ctor_m4A947D2C5ABAD0FDEABE10D93406C488B27C40D1,
	TwistGesture_get_FingerId1_m680DCA9648FA68B7FFDE005E6D1B1E46039E3101,
	TwistGesture_set_FingerId1_mC8859D6D363872F7D4E40451CBA5C628D08E26C1,
	TwistGesture_get_FingerId2_mDE3C5D6676F74CBC94CAD5AC42BC33378319F734,
	TwistGesture_set_FingerId2_mE295378609385DEE20032F4A784068D9A2252D02,
	TwistGesture_get_StartPosition1_m4400A61E18A6A0D1D3784A70E999264A5D9D1CA2,
	TwistGesture_set_StartPosition1_m70111D46F83DB80DEA635B54CBD53E196383C86D,
	TwistGesture_get_StartPosition2_m2ACCFA161BCD2A22128591DAE89BFCF8FBD86FD6,
	TwistGesture_set_StartPosition2_mC4A764E1B22A60E705E3758310DFAB823819F5BE,
	TwistGesture_get_DeltaRotation_mC219DF2A09390CA7E7DF81CBD4E6C695603A8200,
	TwistGesture_set_DeltaRotation_mD3F7DC06480A7D59DC2759AF34F2F66BA17A45FA,
	TwistGesture_CanStart_m37FDB18F0546B744F37E30F608D69BF3822B77DE,
	TwistGesture_OnStart_m0425559871726F0014F222B0DDA87ED9F3C04D3C,
	TwistGesture_UpdateGesture_m54A67B1B6CDE26F0A8852C62EA2AB05C490C6CB8,
	TwistGesture_OnCancel_m2D8693186729995F4649A4028C0235CC46E6F9BB,
	TwistGesture_OnFinish_m1665857275E3CB3A0ADE45D3E8A4538481112AF3,
	TwistGesture_CalculateDeltaRotation_mE8A51C99D9033C4CF180F7B272C458CC71BFD88A,
	TwistGestureRecognizer_get_m_SlopRotation_m00CE1CB708A67BA649CB4ADD8947E413F774E233,
	TwistGestureRecognizer_CreateGesture_mF1694E380A7017A82E02B9F00A42E7E759D92BCE,
	TwistGestureRecognizer_TryCreateGestures_m800512EDB1BC6BFAFADA843B3D5430B472B342D4,
	TwistGestureRecognizer__ctor_m1B1E54D4D5F59EF6BB6BC3B6E19758CC0EBE0D65,
	TwoFingerDragGesture__ctor_m8A1C85FF898CCCC8A5C2D2A9F91B0BEEA6231D52,
	TwoFingerDragGesture_get_FingerId1_mECF5DE6DED6018FCF3BE581512C1549DE7ECA00D,
	TwoFingerDragGesture_set_FingerId1_mA870294382A8DA3D0B5CF927E1F3D22EF8A5EDD5,
	TwoFingerDragGesture_get_FingerId2_m975E38EF68D4AF60189128712F522248F34DA6CF,
	TwoFingerDragGesture_set_FingerId2_m3D676BB86C60643A7FC20B9C8B4DC7131C40B68F,
	TwoFingerDragGesture_get_StartPosition1_m144511C299A814976B1E546B2CC951169DFE4FE5,
	TwoFingerDragGesture_set_StartPosition1_mF8D038F29F50A7029B981D002C2691638C91A892,
	TwoFingerDragGesture_get_StartPosition2_mF46CE8F86C2F216168B87F4E5AC4D8F2932482A1,
	TwoFingerDragGesture_set_StartPosition2_m42E560807EBA8B8ACBDCC65934BD1CF477FBF7EE,
	TwoFingerDragGesture_get_Position_m08ACDBAB1C97088B563EB03BA69A5DEAB4679212,
	TwoFingerDragGesture_set_Position_m327AE3A557F27B37CE486041373DBB9F44BFE03A,
	TwoFingerDragGesture_get_Delta_m428DEF67AD53C1BC0F5208DA667CA0F9698F8C61,
	TwoFingerDragGesture_set_Delta_m24D32C583BBBD8BE058373B4E344FF96DE2DD499,
	TwoFingerDragGesture_CanStart_m9AEF884788BED94D4334E26A7258C65359453E6A,
	TwoFingerDragGesture_OnStart_mD5F012B62A7F67C6924478BDF25BE83F8FF5249D,
	TwoFingerDragGesture_UpdateGesture_mDE6410F1D956B3BBC1EA7A0F0688EC4822A4F996,
	TwoFingerDragGesture_OnCancel_m0AD7342C08D7D870096C1CD6C7D11947130AAF65,
	TwoFingerDragGesture_OnFinish_m37DB88313548889BC4E06B6C062BBCCA3279E84A,
	TwoFingerDragGestureRecognizer_get_m_SlopInches_m4674ABDBDC74A69AF636B910298A31ABC6CB674B,
	TwoFingerDragGestureRecognizer_get_m_AngleThresholdRadians_m4243B0C772CD15E985E3E36894F74EC80F7AA724,
	TwoFingerDragGestureRecognizer_CreateGesture_m1008C6F1BF54B8E4C24D88E2F002D2EB4817F6BF,
	TwoFingerDragGestureRecognizer_TryCreateGestures_m70819A20B70EBDA179AD52CF74849DDF493FC52C,
	TwoFingerDragGestureRecognizer__ctor_mDF64A446841840E772649B68DA129D7BC03E5D20,
	ARAnnotation_get_annotationVisualization_m41C9ECC2D731E190CB04C6B0A523DD2940A49C99,
	ARAnnotation_set_annotationVisualization_m26F475923E2D62E50BD8230A521F7174BD4BA77F,
	ARAnnotation_get_maxFOVCenterOffsetAngle_m139A9E1D99A16B45A8A4848E4373BDF77333CC0A,
	ARAnnotation_set_maxFOVCenterOffsetAngle_mFACB1C98A823477B1466CC9F73EE707B8A056BD3,
	ARAnnotation_get_minAnnotationRange_m24F600F5B1B45341A5B83B7DE9DB7A351FAE1A61,
	ARAnnotation_set_minAnnotationRange_m7946408031CDBDA183E51019E8E15DF0321C17CD,
	ARAnnotation_get_maxAnnotationRange_m6CAAA4E03511ABE5002839D582F36FBB522B5863,
	ARAnnotation_set_maxAnnotationRange_m54EDB11A64ADDCAD93B3C8DB478B265BAF988B0C,
	ARAnnotation__ctor_m31A8E4C80F013DB2B85FFBD6726D51351F85E17F,
	ARAnnotationInteractable_Update_mFB8D1D314DFA8CF5467DBE038F991420659BEE77,
	ARAnnotationInteractable__ctor_m08A4A361FF38F1704CAC2088DD9A1404C62C760C,
	ARBaseGestureInteractable_IsSelectableBy_m6D197C69121E3BFC564037E9153EB9210CCBB6B1,
	ARBaseGestureInteractable_CanStartManipulationForGesture_m70CFFE88CAD2003D500C395207807ABA3DF499D2,
	ARBaseGestureInteractable_CanStartManipulationForGesture_mB398623C2A990707EBB798B277AD112F11EC96D8,
	ARBaseGestureInteractable_CanStartManipulationForGesture_m2A57FB4CB9280CA524E58531B70BC62F949243B8,
	ARBaseGestureInteractable_CanStartManipulationForGesture_m96B9D4A87DEF737691189E5E8B77FAAFECC408BC,
	ARBaseGestureInteractable_CanStartManipulationForGesture_m7CA014101945BEA060BEE9B00E33AC4067CDF33F,
	ARBaseGestureInteractable_OnStartManipulation_m06E2A4D38687CF231A294AB2D616EF797CAFBD3F,
	ARBaseGestureInteractable_OnStartManipulation_mD9A79394A6DA2FB531D93F3D0788AB3FACF837D6,
	ARBaseGestureInteractable_OnStartManipulation_m6CA6274AA91BDE9B405C6E6AE94B83E4A943EEEB,
	ARBaseGestureInteractable_OnStartManipulation_mB3DFF4600C1039071799B7D295EF922E988E4B8D,
	ARBaseGestureInteractable_OnStartManipulation_m123836AC04FAA905A7304A484B5AEECB4CE50126,
	ARBaseGestureInteractable_OnContinueManipulation_m911E66BD38DC6C5399EA5D9198EC02F9E784E29D,
	ARBaseGestureInteractable_OnContinueManipulation_mD7E744245054AA79B3978D2469E6CA54F368073B,
	ARBaseGestureInteractable_OnContinueManipulation_m680B506E96C79D983C7749A92B8B0C640F0DDE3B,
	ARBaseGestureInteractable_OnContinueManipulation_mE01BB2C91BFA53B46C8D97FEB36B74FA67B48E1B,
	ARBaseGestureInteractable_OnContinueManipulation_m38914BFE7ABAD077C33FDDDFA9A6762AB3760044,
	ARBaseGestureInteractable_OnEndManipulation_m588ACA7838F3C2BDF6F7A7CCD141CD07D5C60D98,
	ARBaseGestureInteractable_OnEndManipulation_mF619C26A28371A7F204DE49E31ACB40A662BCFC2,
	ARBaseGestureInteractable_OnEndManipulation_m8BF2B80B9B1B44B7B1DB626A212DC006A4D8DD39,
	ARBaseGestureInteractable_OnEndManipulation_m43B1E695AA6214D5B1882211A9035936030153D0,
	ARBaseGestureInteractable_OnEndManipulation_mFC2C064F9E6602298350F0E861F7AF3C425A784A,
	ARBaseGestureInteractable_get_gestureInteractor_m0CC7D85390F605D2F4C8C9EBEF42C384CC06A3C4,
	ARBaseGestureInteractable_UpdateGestureInteractor_mA4ED0A38842D5E10D6C07FC4B8A8A16964A1B692,
	ARBaseGestureInteractable_IsGameObjectSelected_mB9CD2337B48927B683EBE54E1AEBB379F09859DF,
	ARBaseGestureInteractable_IsHoverableBy_mB7B68749ECD2388DEF5F6C5CF75A982EF932B1E2,
	ARBaseGestureInteractable_ConnectGestureInteractor_m686456BAAF4FABD52FCD9AC28F8ABCF28C4D4A60,
	ARBaseGestureInteractable_DisconnectGestureInteractor_m7C9589ADCAB351BA4923D3B02251711690BB8311,
	ARBaseGestureInteractable_OnGestureStarted_mECABEB89704DF06B212FE49CFC481FCA14183877,
	ARBaseGestureInteractable_OnGestureStarted_mF1909BE94DDAD6B90E198AF5571C935DE7E77C52,
	ARBaseGestureInteractable_OnGestureStarted_m3B1F405EF6AEDBDF2AA965BFC69DC205731153B5,
	ARBaseGestureInteractable_OnGestureStarted_m7D7C805403FE30F4FA250B1AE5DFAAD2E01B9E78,
	ARBaseGestureInteractable_OnGestureStarted_m10819C110A105139DBCB8A214D5DAD1AD87A8543,
	ARBaseGestureInteractable_OnUpdated_mCAB9EB3DD26E4B1A539112CF3DA571BD2BB9E3A2,
	ARBaseGestureInteractable_OnUpdated_m00292EDB76C4AE705FA1568FA847998554FDB09D,
	ARBaseGestureInteractable_OnUpdated_mF365667F724FC961CE35B0923FE06ABCDE306295,
	ARBaseGestureInteractable_OnUpdated_m783A569AE049787F98FDFDED69C605BA42D53095,
	ARBaseGestureInteractable_OnUpdated_m873FA4681EB4C54CCD362AEA6CAEA891C8914463,
	ARBaseGestureInteractable_OnFinished_mB1400D07FB14D00BA251F3A2DCF8C365B16A2EB6,
	ARBaseGestureInteractable_OnFinished_m37035E7E0897B1106A6BF6DFCEB2DE5D1A9D817D,
	ARBaseGestureInteractable_OnFinished_mDC874B472781178E57A76A0FE71D2932B5ED890A,
	ARBaseGestureInteractable_OnFinished_mEC3FE50348B1BA5F30C665C8D75017C185D6DF7F,
	ARBaseGestureInteractable_OnFinished_mBB2773A74E2A5C3D18F82237BFD2FAC117465EFC,
	ARBaseGestureInteractable__ctor_m9D6047BF7D98531682190AC5512ADBEAE39AB1BA,
	ARObjectPlacedEvent__ctor_mBC222061A0E28B7F7FD307C996754EEDE5BFE416,
	ARPlacementInteractable_get_placementPrefab_m1CE36711A723F3EEEF67AFE504B2DF01877012C1,
	ARPlacementInteractable_set_placementPrefab_m6D6C95A2EDE51845AC4D00B83141055AB6FB1A00,
	ARPlacementInteractable_get_onObjectPlaced_m361652546FE762CFD03B055373F7F5DD6BB76C9C,
	ARPlacementInteractable_set_onObjectPlaced_m14C6EE4786BB64473EC87A35C596AACF6F58D2E1,
	ARPlacementInteractable_CanStartManipulationForGesture_m9EB9718DA2388A7ABABF8084AE59CF416BF81989,
	ARPlacementInteractable_OnEndManipulation_m7836E8DE2212BC7FBA9E62DD8C8A8192C2ADE29C,
	ARPlacementInteractable__ctor_m22CD62F8F54931146C5DDD7CA5EDA948CB06F14A,
	ARPlacementInteractable__cctor_m7B3EAD306C33ADDD024EF5FEB2DE557723F882E9,
	ARRotationInteractable_get_rotationRateDegreesDrag_m3555F8EF4D83A78D16FEB056DA6576014488B514,
	ARRotationInteractable_set_rotationRateDegreesDrag_mA0CC7E590989DBFF4B95C88888C19EAE15444977,
	ARRotationInteractable_get_rotationRateDegreesTwist_mB342E58234A4AF1549FC6437E64A15052EB57539,
	ARRotationInteractable_set_rotationRateDegreesTwist_m4E0A7512E205CB4B0D8D089AC1696BAFB7457695,
	ARRotationInteractable_CanStartManipulationForGesture_m620A44E1F2A3CB08190E9D08D4A0BB812F79EDB9,
	ARRotationInteractable_CanStartManipulationForGesture_m8366AF1F32BD4B71C6FE04807EBDF814FC0CC403,
	ARRotationInteractable_OnContinueManipulation_m4EB544ADDEBE659A1B466CE2E6D84A2AA33DB96F,
	ARRotationInteractable_OnContinueManipulation_m7CE229E1EC70427372CF28C515C143CABAA3D707,
	ARRotationInteractable__ctor_mE280554A465D09BCD229A191E717369BC15B4F1A,
	ARScaleInteractable_get_minScale_mD71A5EECE529E3D56BCACEB5C850F4DAC8903C2F,
	ARScaleInteractable_set_minScale_m429E4725D4969EC3F0F164C5984914C46D12D2ED,
	ARScaleInteractable_get_maxScale_m14ADD3C752F96E18C5E4DCB64B8F7D9662DFF9EF,
	ARScaleInteractable_set_maxScale_m9CE7E1F7EF147E4F07FC605E37C1F3D521017877,
	ARScaleInteractable_get_elasticRatioLimit_m4F102E42E15F2F39A79065750DDC81300AB6FCA8,
	ARScaleInteractable_set_elasticRatioLimit_m5F6FBD0E99B3462084407F91F78B51A6BF1B8F44,
	ARScaleInteractable_get_sensitivity_mEEB2CB09EA58A62CD54817E93568BADD2E313306,
	ARScaleInteractable_set_sensitivity_m4FB744FF08E817B52EC4765AAE73414194AC15A1,
	ARScaleInteractable_get_elasticity_mE9E5CCD6C48A052790633CE475943B6878D9762B,
	ARScaleInteractable_set_elasticity_mEFBBCF0D97EBE12B82AF639838367BB54E9479A5,
	ARScaleInteractable_get_m_ScaleDelta_m2338DF233E9FF63E34D6078D662D3DFA777E6607,
	ARScaleInteractable_get_m_ClampedScaleRatio_mFE9CFA94E0D09EDAF99DD9068C4C32E30E76DD85,
	ARScaleInteractable_get_m_CurrentScale_m7731EDD90A94B4FB8E2D8C922584C7511E90AA76,
	ARScaleInteractable_OnEnable_mA15F95E3500AD17F4F37B47ABF9C65F614B33F60,
	ARScaleInteractable_OnValidate_mB7DD33B8580419B0B7254E0D737358E8C6E57C84,
	ARScaleInteractable_CanStartManipulationForGesture_m2915B226DE05663FBC244FB6E7B7406F2166CF39,
	ARScaleInteractable_OnStartManipulation_mA6C1742BFCEE29CE3A7DD9470A916B85830C09C7,
	ARScaleInteractable_OnContinueManipulation_m5534877B9596696784B6CBE38F95EDF63A0F0F11,
	ARScaleInteractable_OnEndManipulation_mB1EE3F09DBBD31A337DBBAA5F0D1B67FF5BF2736,
	ARScaleInteractable_ElasticDelta_m5FE1BCBDF4A9F945F294F85BDE9CD4BF0197F9A3,
	ARScaleInteractable_LateUpdate_m387100E69671B90EFBE6B85EF81F1268B1EBB68C,
	ARScaleInteractable__ctor_m5C97522F8385540CEDE9FDBC25674B9158E70E67,
	ARSelectionInteractable_get_selectionVisualization_mA26426CB0C27349F35158C9B2A169A55C97397D0,
	ARSelectionInteractable_set_selectionVisualization_m8793958C9E31723EAEFEA53B5EF4ED5220CAAB60,
	ARSelectionInteractable_Update_mA24F79A213FB7C257AFB1CF859B0E4C3E615AB84,
	ARSelectionInteractable_IsSelectableBy_m0EB98CE791E1C30D5025F07B85FEDDAF95FFE6E4,
	ARSelectionInteractable_CanStartManipulationForGesture_m73AD1BE853E6E7E2B8297164F956C5A4278D6815,
	ARSelectionInteractable_OnEndManipulation_m5F1FF971B75C1D87146CA98298A63AA53DE96A37,
	ARSelectionInteractable_OnSelectEnter_mA605248EB2C4A998137533D67FCB074EC59B554C,
	ARSelectionInteractable_OnSelectExit_m826A1C34D4633FA415294E623A3B577023FD8039,
	ARSelectionInteractable__ctor_mABB62A057D18673050B30677B23CA5105CCC819F,
	ARTranslationInteractable_get_objectGestureTranslationMode_mF10CA3F5FBD2B4A353D46E21A2088A5B4C3B298F,
	ARTranslationInteractable_set_objectGestureTranslationMode_m12FC78A83FC498490DA77D8B05231D04CD7BB3B6,
	ARTranslationInteractable_get_maxTranslationDistance_mF256545FBB867F9C4F00F8BB0E491F25962CD0FE,
	ARTranslationInteractable_set_maxTranslationDistance_mA6FAEE6F7D7AC084EAEF9F6D0851D8879A77BCBE,
	ARTranslationInteractable_Start_mB97CF2745A7DA6B81A0AD3EBA1B7F2BFD7360E5C,
	ARTranslationInteractable_Update_mA5512613C59ECB1AD8063003B4A3C7FEB2508BDB,
	ARTranslationInteractable_CanStartManipulationForGesture_m3AA6312CA0D35311A8D5853149990741DBD19CAC,
	ARTranslationInteractable_OnStartManipulation_m47EBB72B4F7585880A2DAB79FEBFF677936836A7,
	ARTranslationInteractable_OnContinueManipulation_m6690C473E4BFDD46AB1A74183833B79322EFB8BC,
	ARTranslationInteractable_OnEndManipulation_m89D0E3B6304E1C99858ACC03305DA14B3E38D639,
	ARTranslationInteractable_UpdatePosition_m4615A639C83B46925F85376337A22E23BD9CEE7D,
	ARTranslationInteractable__ctor_m271529AC4D6F2DE46A203936D444E22B57090A4E,
	GestureTransformationUtility_CheckDependentManagers_mD1F6A5EF863A6904FD1977B30ED68666E2CED2A8,
	GestureTransformationUtility_Raycast_m313F9945BF2931B9D7F0BF93C3861BBD0155BB85,
	GestureTransformationUtility_GetBestPlacementPosition_mA9A996D81C1EF46D745A230D4DAAADEB0277162D,
	GestureTransformationUtility_LimitTranslation_mFC66ED17E4745CEE9386555B3BDAE92111FD5597,
	GestureTransformationUtility_IsPlaneTypeAllowed_m2498FF2C6C875D29F6F680130057927A95FB74E0,
	GestureTransformationUtility__cctor_m5C0519A08212761182F5491F78D852B252F4B017,
	ARGestureInteractor_get_Instance_mAB024E13349B591DE7D9762C83707A26B17CACCC,
	ARGestureInteractor_get_DragGestureRecognizer_mD4096A81607DF42C6C59816147C2EFD9DFED770E,
	ARGestureInteractor_get_PinchGestureRecognizer_mA727BAEAE83922C6D601B7DAF1E1DDF61E43E9F4,
	ARGestureInteractor_get_TwoFingerDragGestureRecognizer_m66E0B7D97AD3F8D8677D0C7E037CF00EDFC1C48A,
	ARGestureInteractor_get_TapGestureRecognizer_mDC0D122D93582D0D3498B7D5A05051286CE85181,
	ARGestureInteractor_get_TwistGestureRecognizer_mFE75BE4726DEF9C28C9B5244E53DB424AFE70476,
	ARGestureInteractor_Awake_m4F936F978E4754329D231EA497905559F6603F16,
	ARGestureInteractor_Update_m4FB0A53CE844767936F0119BC5376B5FD664F8E5,
	ARGestureInteractor_GetHorizontalFOV_mE2C25D7D81897A1EFB2555CFE599B99ADEEA02EF,
	ARGestureInteractor_GetValidTargets_m4671EF0EB23139F16214B120AF4C6D34802ECA18,
	ARGestureInteractor__ctor_mA6C679E95419FD7A3153DD42E501990B92C49AD0,
	ARGestureInteractor__cctor_m82E2925F6EA05A8608659A26FB0C363A1E5122FC,
	ButtonInfo__ctor_m318F4A1EB41E8B54177D20087620435E9AD74064_AdjustorThunk,
	Frame__ctor_mCE2D471941F76FB7ABB0383A9F3BD49DE8FFB5FA_AdjustorThunk,
	Frame_ToString_m18C27CDB47B560185DC5AC5BF22750AB7E3149BC_AdjustorThunk,
	U3CU3Ec__cctor_m9DDCBC4B16515D19A5B587C04548009A1D33D826,
	U3CU3Ec__ctor_m061372CF9BEEC0B7A5526DE824428B4CA21E65C9,
	U3CU3Ec_U3CAwakeU3Eb__6_0_m64A8ADCD9A21B4617ED5944E1153CE7265CCE39D,
	RaycastHitComparer_Compare_m37FAF6292792208CFEDCEBE2D5C24B6E194C3286,
	RaycastHitComparer__ctor_m751C364F35A51E01FBDDCA8C7E7F2A42822A3148,
	U3CRepeatInitializeCameraU3Ed__39__ctor_m39CBC9239D0E11C4271A7D6D2376D7414C99AC4B,
	U3CRepeatInitializeCameraU3Ed__39_System_IDisposable_Dispose_mB4A19C1B67D5ABEBF5A878685EC83A0644CDB2CF,
	U3CRepeatInitializeCameraU3Ed__39_MoveNext_mF1AA8466CACF33234171F542520DBF9F8005026D,
	U3CRepeatInitializeCameraU3Ed__39_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB23F2A611687EA649571E6606533B555A55A656D,
	U3CRepeatInitializeCameraU3Ed__39_System_Collections_IEnumerator_Reset_m3D35140D4378BC4397665BF814C2F41DCE1472B7,
	U3CRepeatInitializeCameraU3Ed__39_System_Collections_IEnumerator_get_Current_m45039C6182C0B4914EB0CD87E775871FB58A030E,
	ImplementationData_get_consecutiveMoveCount_mF904135BD9EFA05B2D8E85D9065FA9A4C2839E12_AdjustorThunk,
	ImplementationData_set_consecutiveMoveCount_m6A8BE14485B92674DA53FA3219C6A6FD30838C2C_AdjustorThunk,
	ImplementationData_get_lastMoveDirection_m437248CB1547D4FE2C1484F1E962C69B656FDD6E_AdjustorThunk,
	ImplementationData_set_lastMoveDirection_m4D47C1BE229675F91B6F86178A95B6148A72BCF1_AdjustorThunk,
	ImplementationData_get_lastMoveTime_m5A4AF5393938C80E48F8301F215F9B02868CF27B_AdjustorThunk,
	ImplementationData_set_lastMoveTime_mB6283DED2E1645956730D3F3B855B0E8C9CFD5E8_AdjustorThunk,
	ImplementationData_Reset_mB79C2144A388A4260C2CB3CAB7C5E1C8E1E82672_AdjustorThunk,
	ImplementationData_get_isDragging_m4D5F5F35960E6CAAEC9E07985BF4BB4BA8599E3B_AdjustorThunk,
	ImplementationData_set_isDragging_m2121DA62AD191D8E2FA5851706D2D4FFBF85AE5F_AdjustorThunk,
	ImplementationData_get_pressedTime_m34C48FB6C70DA8380FA7F613BA7D7260A51E0350_AdjustorThunk,
	ImplementationData_set_pressedTime_m25BBECEF789D7E5EF9D67BE9A5C3673F1AD04DF3_AdjustorThunk,
	ImplementationData_get_pressedPosition_mA0F3487E8E853FCD250DFAA49557CD32F2C33F43_AdjustorThunk,
	ImplementationData_set_pressedPosition_m833A5CB97001F3A6D587F8078DE7F456D29E6364_AdjustorThunk,
	ImplementationData_get_pressedRaycast_m79211F0341164D86D235FDEB292D41E7836A8649_AdjustorThunk,
	ImplementationData_set_pressedRaycast_m6F7AF5D5701F8DC7BAC8F1E9D62C885F5ADDA0ED_AdjustorThunk,
	ImplementationData_get_pressedGameObject_m233C98D32B321AD0880F483CA59C29D7D6500A5B_AdjustorThunk,
	ImplementationData_set_pressedGameObject_mF2EAAFB3AC371FC3E2EACC7CFAC1CC138508490A_AdjustorThunk,
	ImplementationData_get_pressedGameObjectRaw_mA82B1E3F48D678133216E397B9EE3A99F72B8147_AdjustorThunk,
	ImplementationData_set_pressedGameObjectRaw_m635640DC36995E7A611BAF83ED52192784224599_AdjustorThunk,
	ImplementationData_get_draggedGameObject_m140D50C1CD83D8025F5DACF504A631DD3F41FD8F_AdjustorThunk,
	ImplementationData_set_draggedGameObject_mF06237076674CA342D2DAB9ABBDD735DAB8C4C2E_AdjustorThunk,
	ImplementationData_Reset_m44E028E047A062B2543EEF8DEC57466C3389E969_AdjustorThunk,
	InternalData_get_hoverTargets_mB6858B6E2DAD03788EEE42AC5ABE5E59174FF8B4_AdjustorThunk,
	InternalData_set_hoverTargets_m263E54223464B7C1A2B4578B2532EA919D1DBC61_AdjustorThunk,
	InternalData_get_pointerTarget_m35808B9C8C4AA1F95F9C6D5E92BD9D94D471C402_AdjustorThunk,
	InternalData_set_pointerTarget_mBD6E5AA1B756B6C3256C3A7F824BCFD93326177F_AdjustorThunk,
	InternalData_Reset_m06FD7ADA3314F09B1639CF9F20685E84B2F062D6_AdjustorThunk,
	ImplementationData_get_hoverTargets_m8C68BFCBE662D18B3DE9264FD8DD0017A9582FB2_AdjustorThunk,
	ImplementationData_set_hoverTargets_m6DA0498FACE3573F7FF98F220D46CE3368D665FC_AdjustorThunk,
	ImplementationData_get_pointerTarget_m15578FC54C5230C16ECE5EC1780A92C8E9BE4CC6_AdjustorThunk,
	ImplementationData_set_pointerTarget_m6798588B6085B4A88CC88590AEFED7EF4CA836CB_AdjustorThunk,
	ImplementationData_get_isDragging_m1386408077E680FE36572276C42BF8B53D2EE3F8_AdjustorThunk,
	ImplementationData_set_isDragging_m37471A055706D58BE430DFA30E04761A98D8D7DC_AdjustorThunk,
	ImplementationData_get_pressedTime_m6DD9BA132280689CE5ECB37B363D958B0152D044_AdjustorThunk,
	ImplementationData_set_pressedTime_m9CAD3C7B7BA96B30FD59B3B990E333B6FB1C9EC4_AdjustorThunk,
	ImplementationData_get_pressedPosition_m777080B865313932CC703D795A83C96E0BE41DC4_AdjustorThunk,
	ImplementationData_set_pressedPosition_mC61452C2EC804C94209A690E37D6C2799E7C7A9C_AdjustorThunk,
	ImplementationData_get_pressedRaycast_m6AA140DEC4DC36B1501EE75BFFA087AAC3B167EC_AdjustorThunk,
	ImplementationData_set_pressedRaycast_mBAB2EA7D44FAF48797F293D69219370C1482CFAC_AdjustorThunk,
	ImplementationData_get_pressedGameObject_m6740A5E50B5943F04B831B4FE5B227609A0DA24E_AdjustorThunk,
	ImplementationData_set_pressedGameObject_mE64200883289E42E745EDCCCE906762AB564D79A_AdjustorThunk,
	ImplementationData_get_pressedGameObjectRaw_m71A3C7E03C1A18CDD6CED39F6848C5F2C66B4169_AdjustorThunk,
	ImplementationData_set_pressedGameObjectRaw_m6880EF51A8A81E2ACC929FB2E7D3ED38ED552D23_AdjustorThunk,
	ImplementationData_get_draggedGameObject_mB89A3426D35F7C0C4046BAA60754CFCD28339D5E_AdjustorThunk,
	ImplementationData_set_draggedGameObject_mDE467651B72DB5FDBBA8763D5E77C4CB54D58993_AdjustorThunk,
	ImplementationData_Reset_m87518738139AD004CF2973B09E5CDC10422B7A95_AdjustorThunk,
	RaycastHitData__ctor_mA1D633A7E340AEB0F3759A9B105E91E4335CBEA0_AdjustorThunk,
	RaycastHitData_get_graphic_m02D753644C4209BE852CF58D5C05E8B12ED3BB53_AdjustorThunk,
	RaycastHitData_set_graphic_m20B98A559C0ABC27F0A4E4FEBEA5EF0BED75A29A_AdjustorThunk,
	RaycastHitData_get_worldHitPosition_m287486D2AD9C2A3CEABD43522FCF4A214E6461F1_AdjustorThunk,
	RaycastHitData_set_worldHitPosition_mD07C999C6DED87A024C4C08BC024B7C80DC2D896_AdjustorThunk,
	RaycastHitData_get_screenPosition_m801EED488C4B748D97EFADC04DE58AB7D3BDD3EA_AdjustorThunk,
	RaycastHitData_set_screenPosition_mD7200EE2F7CAF57BEE53553F5255BC584CB2F4F4_AdjustorThunk,
	RaycastHitData_get_distance_m7C78E670D250A1E97DEA800DC76E50C9222140BD_AdjustorThunk,
	RaycastHitData_set_distance_m5A3557D88FB3F597F6B7B028837707AE2022EB77_AdjustorThunk,
	RaycastHitComparer_Compare_m8C82B6BCABDB214A38B3CFF3FBCE2C71604445CC,
	RaycastHitComparer__ctor_mDB8188CFC41A7F5597F5EA937D0E07F86CAC5849,
	ImplementationData_get_hoverTargets_mBBFE6CEF8CEA13D0D1014AE391A0B79D5DE336E4_AdjustorThunk,
	ImplementationData_set_hoverTargets_m9BB0D124829D89D7A55FBD4E1093FF9412339393_AdjustorThunk,
	ImplementationData_get_pointerTarget_m2FBB82C4207E95A8E32607A921845B77C55D73A5_AdjustorThunk,
	ImplementationData_set_pointerTarget_m5CB23ED3A7AFA95F297836ABC2BF3F92AB9B463E_AdjustorThunk,
	ImplementationData_get_isDragging_mEAD1B7E29E488989B846BF21770C1908173BB46C_AdjustorThunk,
	ImplementationData_set_isDragging_m4AD1D6DC7AB414D521AC82576F2DC3E5D6F5C0FF_AdjustorThunk,
	ImplementationData_get_pressedTime_mF5E2F4964CF0EDB11549D601911C786729B65A01_AdjustorThunk,
	ImplementationData_set_pressedTime_m55B204D98739CB7F1A6009E5218B3CB03A4506A8_AdjustorThunk,
	ImplementationData_get_pressedPosition_m7F65A43AC6B2278EEB19013F76E2DB34D96058FA_AdjustorThunk,
	ImplementationData_set_pressedPosition_m7F670B7C4EF2A61E87487D890469AB18C5361DCC_AdjustorThunk,
	ImplementationData_get_pressedRaycast_mC2E0007565F77E61EB53258EA94166C41B8FB767_AdjustorThunk,
	ImplementationData_set_pressedRaycast_mEB7F9A7CA494DF249D361866F0149287A3E32421_AdjustorThunk,
	ImplementationData_get_lastFrameRaycast_mDED8918A4858DEFF035D9F8F7C327312D524004E_AdjustorThunk,
	ImplementationData_set_lastFrameRaycast_m61FEC0C088F11550783614BBE08382B79B0DC1C3_AdjustorThunk,
	ImplementationData_get_lastFrameRaycastResultPositionInLine_mD65E900115A3B64CC51048EAB89B30CC94D6D79F_AdjustorThunk,
	ImplementationData_set_lastFrameRaycastResultPositionInLine_m26D3562D1DAC83E1AC05031FF357AE474C3BA14A_AdjustorThunk,
	ImplementationData_get_pressedGameObject_m033F4F1733D1AA2EC7E3C9CB1955F4FAEA358BE4_AdjustorThunk,
	ImplementationData_set_pressedGameObject_m0165FDFFAF3E8EC7CE24FF171C6D0367C2FBA747_AdjustorThunk,
	ImplementationData_get_pressedGameObjectRaw_mE828869D7B93632E47A967253DBC1D6153E0F192_AdjustorThunk,
	ImplementationData_set_pressedGameObjectRaw_m8EA5959ED8D09766FE22CC9E6581F9B75E4E9E50_AdjustorThunk,
	ImplementationData_get_draggedGameObject_m9A5A09599A59211A8D59E561537241B9F8364AA7_AdjustorThunk,
	ImplementationData_set_draggedGameObject_mA0382FCD9AD185977C37E21161F8361A10774453_AdjustorThunk,
	ImplementationData_Reset_m4310073E858CFF95C8433CAF719F763A51711C39_AdjustorThunk,
	RegisteredInteractable__ctor_mA01A1DF22ED5A191D6398755DA30BB47E268B9E1_AdjustorThunk,
	RegisteredTouch__ctor_m87F932AEA7B1C4846CE455D57466FC7B956576AA_AdjustorThunk,
};
static const int32_t s_InvokerIndices[1119] = 
{
	2175,
	3,
	10,
	32,
	114,
	31,
	114,
	31,
	14,
	26,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	706,
	307,
	14,
	26,
	14,
	114,
	31,
	14,
	26,
	14,
	26,
	2176,
	2176,
	2176,
	2177,
	114,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	23,
	805,
	613,
	22,
	23,
	1340,
	2178,
	23,
	114,
	31,
	14,
	26,
	14,
	26,
	114,
	31,
	114,
	31,
	432,
	432,
	23,
	23,
	23,
	23,
	2179,
	23,
	308,
	23,
	14,
	432,
	2180,
	23,
	23,
	23,
	1204,
	1205,
	114,
	31,
	114,
	31,
	14,
	26,
	23,
	23,
	31,
	26,
	26,
	26,
	26,
	23,
	23,
	14,
	26,
	14,
	1953,
	1717,
	14,
	114,
	31,
	114,
	31,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	23,
	23,
	23,
	192,
	9,
	9,
	9,
	26,
	26,
	26,
	26,
	26,
	14,
	26,
	26,
	26,
	26,
	32,
	23,
	14,
	26,
	706,
	307,
	10,
	32,
	114,
	31,
	114,
	31,
	706,
	307,
	706,
	307,
	114,
	31,
	114,
	31,
	706,
	307,
	706,
	307,
	114,
	31,
	706,
	307,
	706,
	307,
	706,
	307,
	114,
	31,
	114,
	31,
	14,
	23,
	32,
	2181,
	2182,
	307,
	1906,
	1906,
	1906,
	26,
	23,
	26,
	26,
	26,
	9,
	23,
	23,
	23,
	2181,
	23,
	23,
	9,
	114,
	771,
	2183,
	706,
	307,
	114,
	31,
	706,
	307,
	14,
	26,
	14,
	26,
	14,
	26,
	114,
	31,
	706,
	307,
	706,
	307,
	14,
	26,
	114,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	114,
	9,
	114,
	23,
	706,
	307,
	14,
	26,
	706,
	307,
	114,
	31,
	114,
	31,
	706,
	307,
	114,
	31,
	1953,
	1717,
	114,
	31,
	23,
	23,
	23,
	23,
	2184,
	771,
	114,
	23,
	26,
	26,
	23,
	10,
	32,
	114,
	31,
	114,
	31,
	14,
	26,
	114,
	31,
	14,
	26,
	114,
	31,
	14,
	26,
	114,
	31,
	14,
	26,
	114,
	31,
	706,
	307,
	706,
	307,
	114,
	31,
	706,
	307,
	706,
	307,
	114,
	31,
	706,
	307,
	706,
	307,
	114,
	31,
	706,
	307,
	706,
	307,
	14,
	23,
	23,
	32,
	114,
	114,
	26,
	26,
	26,
	26,
	2178,
	23,
	23,
	14,
	26,
	1953,
	1717,
	14,
	14,
	14,
	1953,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	114,
	31,
	114,
	31,
	114,
	31,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	9,
	26,
	114,
	114,
	9,
	9,
	114,
	114,
	2185,
	26,
	26,
	26,
	26,
	32,
	23,
	14,
	41,
	23,
	26,
	26,
	26,
	9,
	9,
	23,
	10,
	32,
	706,
	307,
	14,
	26,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	10,
	32,
	10,
	32,
	706,
	307,
	1953,
	1717,
	10,
	32,
	114,
	31,
	706,
	307,
	114,
	31,
	706,
	14,
	14,
	23,
	23,
	23,
	23,
	771,
	2183,
	6,
	822,
	822,
	771,
	23,
	2186,
	2186,
	23,
	32,
	2187,
	26,
	9,
	9,
	23,
	114,
	31,
	14,
	26,
	114,
	31,
	706,
	307,
	706,
	307,
	41,
	23,
	26,
	26,
	26,
	32,
	26,
	26,
	2188,
	23,
	26,
	114,
	114,
	114,
	2185,
	9,
	9,
	23,
	14,
	14,
	23,
	23,
	23,
	32,
	32,
	23,
	23,
	23,
	26,
	26,
	26,
	26,
	28,
	113,
	27,
	26,
	27,
	27,
	27,
	27,
	27,
	27,
	27,
	23,
	14,
	26,
	23,
	114,
	114,
	114,
	26,
	26,
	26,
	26,
	23,
	706,
	307,
	14,
	26,
	114,
	116,
	23,
	116,
	23,
	23,
	23,
	10,
	32,
	14,
	26,
	706,
	307,
	706,
	307,
	706,
	307,
	23,
	23,
	31,
	307,
	23,
	3,
	14,
	26,
	10,
	32,
	10,
	32,
	23,
	2189,
	26,
	26,
	26,
	26,
	26,
	23,
	14,
	26,
	23,
	2189,
	23,
	23,
	2189,
	23,
	2190,
	23,
	23,
	2191,
	2191,
	1323,
	-1,
	14,
	26,
	14,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	706,
	307,
	1159,
	1159,
	706,
	23,
	23,
	23,
	23,
	23,
	14,
	114,
	9,
	32,
	460,
	2192,
	1171,
	1507,
	1507,
	1171,
	23,
	23,
	3,
	1170,
	1345,
	114,
	31,
	10,
	32,
	114,
	31,
	10,
	32,
	2193,
	2194,
	23,
	23,
	114,
	31,
	10,
	32,
	23,
	23,
	26,
	26,
	10,
	32,
	114,
	31,
	1170,
	1345,
	1170,
	1345,
	1170,
	1345,
	1170,
	1345,
	2195,
	2196,
	31,
	2195,
	2196,
	31,
	2195,
	2196,
	31,
	32,
	23,
	26,
	26,
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	1170,
	1345,
	1170,
	1345,
	32,
	23,
	23,
	26,
	26,
	26,
	14,
	26,
	10,
	32,
	1953,
	1717,
	14,
	14,
	27,
	2184,
	2197,
	27,
	2198,
	2199,
	2200,
	23,
	3,
	2203,
	10,
	32,
	706,
	307,
	114,
	31,
	10,
	32,
	114,
	31,
	1159,
	1160,
	1346,
	1347,
	14,
	26,
	1953,
	1717,
	32,
	31,
	23,
	26,
	26,
	14,
	26,
	23,
	23,
	2204,
	6,
	26,
	62,
	892,
	26,
	6,
	2205,
	6,
	14,
	14,
	14,
	23,
	6,
	822,
	706,
	307,
	23,
	23,
	23,
	26,
	26,
	772,
	23,
	23,
	23,
	23,
	2207,
	10,
	32,
	1170,
	1345,
	1170,
	1345,
	1170,
	1345,
	114,
	23,
	114,
	23,
	23,
	706,
	2208,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	706,
	307,
	10,
	32,
	10,
	32,
	1170,
	1345,
	10,
	32,
	1170,
	1345,
	1170,
	1345,
	2209,
	23,
	3,
	2093,
	413,
	413,
	2210,
	2211,
	133,
	133,
	46,
	4,
	3,
	2212,
	10,
	32,
	10,
	32,
	1170,
	1345,
	1170,
	1345,
	706,
	307,
	706,
	307,
	114,
	23,
	114,
	23,
	23,
	706,
	706,
	2213,
	23,
	23,
	2207,
	10,
	32,
	1170,
	1345,
	114,
	23,
	114,
	23,
	23,
	706,
	706,
	2208,
	23,
	23,
	2212,
	10,
	32,
	10,
	32,
	1170,
	1345,
	1170,
	1345,
	706,
	307,
	114,
	23,
	114,
	23,
	23,
	2214,
	706,
	2213,
	23,
	23,
	2212,
	10,
	32,
	10,
	32,
	1170,
	1345,
	1170,
	1345,
	1170,
	1345,
	1170,
	1345,
	114,
	23,
	114,
	23,
	23,
	706,
	706,
	2213,
	23,
	23,
	14,
	26,
	706,
	307,
	706,
	307,
	706,
	307,
	23,
	23,
	23,
	9,
	9,
	9,
	9,
	9,
	9,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	4,
	49,
	114,
	9,
	23,
	23,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	23,
	23,
	14,
	26,
	14,
	26,
	9,
	26,
	23,
	3,
	706,
	307,
	706,
	307,
	9,
	9,
	26,
	26,
	23,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	307,
	706,
	706,
	706,
	23,
	23,
	9,
	26,
	26,
	26,
	706,
	23,
	23,
	14,
	26,
	23,
	9,
	9,
	26,
	26,
	26,
	23,
	10,
	32,
	706,
	307,
	23,
	23,
	9,
	26,
	26,
	26,
	23,
	23,
	49,
	2215,
	2216,
	1269,
	53,
	3,
	4,
	14,
	14,
	14,
	14,
	14,
	23,
	23,
	192,
	26,
	23,
	3,
	136,
	2180,
	14,
	3,
	23,
	9,
	1955,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	10,
	32,
	10,
	32,
	706,
	307,
	23,
	114,
	31,
	706,
	307,
	1170,
	1345,
	1942,
	1943,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	14,
	26,
	14,
	26,
	23,
	14,
	26,
	14,
	26,
	114,
	31,
	706,
	307,
	1170,
	1345,
	1942,
	1943,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	2201,
	14,
	26,
	1159,
	1160,
	1170,
	1345,
	706,
	307,
	2202,
	23,
	14,
	26,
	14,
	26,
	114,
	31,
	706,
	307,
	1170,
	1345,
	1942,
	1943,
	1942,
	1943,
	10,
	32,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	136,
	2206,
};
static const Il2CppTokenRangePair s_rgctxIndices[3] = 
{
	{ 0x02000031, { 3, 15 } },
	{ 0x02000032, { 18, 20 } },
	{ 0x0600022F, { 0, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[38] = 
{
	{ (Il2CppRGCTXDataType)2, 23088 },
	{ (Il2CppRGCTXDataType)2, 23090 },
	{ (Il2CppRGCTXDataType)2, 24276 },
	{ (Il2CppRGCTXDataType)3, 21021 },
	{ (Il2CppRGCTXDataType)2, 23156 },
	{ (Il2CppRGCTXDataType)3, 21022 },
	{ (Il2CppRGCTXDataType)3, 21023 },
	{ (Il2CppRGCTXDataType)3, 21024 },
	{ (Il2CppRGCTXDataType)3, 21025 },
	{ (Il2CppRGCTXDataType)3, 21026 },
	{ (Il2CppRGCTXDataType)2, 23155 },
	{ (Il2CppRGCTXDataType)3, 21027 },
	{ (Il2CppRGCTXDataType)3, 21028 },
	{ (Il2CppRGCTXDataType)3, 21029 },
	{ (Il2CppRGCTXDataType)3, 21030 },
	{ (Il2CppRGCTXDataType)3, 21031 },
	{ (Il2CppRGCTXDataType)3, 21032 },
	{ (Il2CppRGCTXDataType)3, 21033 },
	{ (Il2CppRGCTXDataType)2, 23162 },
	{ (Il2CppRGCTXDataType)3, 21034 },
	{ (Il2CppRGCTXDataType)3, 21035 },
	{ (Il2CppRGCTXDataType)3, 21036 },
	{ (Il2CppRGCTXDataType)2, 23163 },
	{ (Il2CppRGCTXDataType)3, 21037 },
	{ (Il2CppRGCTXDataType)3, 21038 },
	{ (Il2CppRGCTXDataType)3, 21039 },
	{ (Il2CppRGCTXDataType)3, 21040 },
	{ (Il2CppRGCTXDataType)3, 21041 },
	{ (Il2CppRGCTXDataType)3, 21042 },
	{ (Il2CppRGCTXDataType)3, 21043 },
	{ (Il2CppRGCTXDataType)3, 21044 },
	{ (Il2CppRGCTXDataType)3, 21045 },
	{ (Il2CppRGCTXDataType)3, 21046 },
	{ (Il2CppRGCTXDataType)3, 21047 },
	{ (Il2CppRGCTXDataType)3, 21048 },
	{ (Il2CppRGCTXDataType)3, 21049 },
	{ (Il2CppRGCTXDataType)2, 24277 },
	{ (Il2CppRGCTXDataType)3, 21050 },
};
extern const Il2CppCodeGenModule g_Unity_XR_Interaction_ToolkitCodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_Interaction_ToolkitCodeGenModule = 
{
	"Unity.XR.Interaction.Toolkit.dll",
	1119,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	3,
	s_rgctxIndices,
	38,
	s_rgctxValues,
	NULL,
};
