﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Exception System.Linq.Error::ArgumentNull(System.String)
extern void Error_ArgumentNull_mCA126ED8F4F3B343A70E201C44B3A509690F1EA7 ();
// 0x00000002 System.Exception System.Linq.Error::ArgumentOutOfRange(System.String)
extern void Error_ArgumentOutOfRange_mACFCB068F4E0C4EEF9E6EDDD59E798901C32C6C9 ();
// 0x00000003 System.Exception System.Linq.Error::MoreThanOneElement()
extern void Error_MoreThanOneElement_mD96D1249F5D42379E9417302B5F33DD99B51C863 ();
// 0x00000004 System.Exception System.Linq.Error::MoreThanOneMatch()
extern void Error_MoreThanOneMatch_m85C3617F782E9F2333FC1FDF42821BE069F24623 ();
// 0x00000005 System.Exception System.Linq.Error::NoElements()
extern void Error_NoElements_m17188AC2CF25EB359A4E1DDE9518A98598791136 ();
// 0x00000006 System.Exception System.Linq.Error::NotSupported()
extern void Error_NotSupported_mD771E9977E8BE0B8298A582AB0BB74D1CF10900D ();
// 0x00000007 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::Where(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000008 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::Select(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TResult>)
// 0x00000009 System.Func`2<TSource,System.Boolean> System.Linq.Enumerable::CombinePredicates(System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,System.Boolean>)
// 0x0000000A System.Func`2<TSource,TResult> System.Linq.Enumerable::CombineSelectors(System.Func`2<TSource,TMiddle>,System.Func`2<TMiddle,TResult>)
// 0x0000000B System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::SelectMany(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Collections.Generic.IEnumerable`1<TResult>>)
// 0x0000000C System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::SelectManyIterator(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Collections.Generic.IEnumerable`1<TResult>>)
// 0x0000000D System.Linq.IOrderedEnumerable`1<TSource> System.Linq.Enumerable::OrderBy(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>)
// 0x0000000E System.Linq.IOrderedEnumerable`1<TSource> System.Linq.Enumerable::ThenBy(System.Linq.IOrderedEnumerable`1<TSource>,System.Func`2<TSource,TKey>)
// 0x0000000F System.Collections.Generic.IEnumerable`1<System.Linq.IGrouping`2<TKey,TSource>> System.Linq.Enumerable::GroupBy(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>)
// 0x00000010 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::Union(System.Collections.Generic.IEnumerable`1<TSource>,System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000011 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::UnionIterator(System.Collections.Generic.IEnumerable`1<TSource>,System.Collections.Generic.IEnumerable`1<TSource>,System.Collections.Generic.IEqualityComparer`1<TSource>)
// 0x00000012 TSource[] System.Linq.Enumerable::ToArray(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000013 System.Collections.Generic.List`1<TSource> System.Linq.Enumerable::ToList(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000014 System.Collections.Generic.Dictionary`2<TKey,TElement> System.Linq.Enumerable::ToDictionary(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>,System.Func`2<TSource,TElement>)
// 0x00000015 System.Collections.Generic.Dictionary`2<TKey,TElement> System.Linq.Enumerable::ToDictionary(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>,System.Func`2<TSource,TElement>,System.Collections.Generic.IEqualityComparer`1<TKey>)
// 0x00000016 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::Cast(System.Collections.IEnumerable)
// 0x00000017 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::CastIterator(System.Collections.IEnumerable)
// 0x00000018 TSource System.Linq.Enumerable::First(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000019 TSource System.Linq.Enumerable::FirstOrDefault(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x0000001A TSource System.Linq.Enumerable::Last(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x0000001B TSource System.Linq.Enumerable::LastOrDefault(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x0000001C TSource System.Linq.Enumerable::Single(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x0000001D TSource System.Linq.Enumerable::SingleOrDefault(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x0000001E TSource System.Linq.Enumerable::SingleOrDefault(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x0000001F System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable::Empty()
// 0x00000020 System.Boolean System.Linq.Enumerable::Any(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000021 System.Boolean System.Linq.Enumerable::Any(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000022 System.Boolean System.Linq.Enumerable::All(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000023 System.Int32 System.Linq.Enumerable::Count(System.Collections.Generic.IEnumerable`1<TSource>)
// 0x00000024 System.Boolean System.Linq.Enumerable::Contains(System.Collections.Generic.IEnumerable`1<TSource>,TSource)
// 0x00000025 System.Boolean System.Linq.Enumerable::Contains(System.Collections.Generic.IEnumerable`1<TSource>,TSource,System.Collections.Generic.IEqualityComparer`1<TSource>)
// 0x00000026 System.Void System.Linq.Enumerable_Iterator`1::.ctor()
// 0x00000027 TSource System.Linq.Enumerable_Iterator`1::get_Current()
// 0x00000028 System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_Iterator`1::Clone()
// 0x00000029 System.Void System.Linq.Enumerable_Iterator`1::Dispose()
// 0x0000002A System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable_Iterator`1::GetEnumerator()
// 0x0000002B System.Boolean System.Linq.Enumerable_Iterator`1::MoveNext()
// 0x0000002C System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_Iterator`1::Select(System.Func`2<TSource,TResult>)
// 0x0000002D System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_Iterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x0000002E System.Object System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerator.get_Current()
// 0x0000002F System.Collections.IEnumerator System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000030 System.Void System.Linq.Enumerable_Iterator`1::System.Collections.IEnumerator.Reset()
// 0x00000031 System.Void System.Linq.Enumerable_WhereEnumerableIterator`1::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x00000032 System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereEnumerableIterator`1::Clone()
// 0x00000033 System.Void System.Linq.Enumerable_WhereEnumerableIterator`1::Dispose()
// 0x00000034 System.Boolean System.Linq.Enumerable_WhereEnumerableIterator`1::MoveNext()
// 0x00000035 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereEnumerableIterator`1::Select(System.Func`2<TSource,TResult>)
// 0x00000036 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereEnumerableIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x00000037 System.Void System.Linq.Enumerable_WhereArrayIterator`1::.ctor(TSource[],System.Func`2<TSource,System.Boolean>)
// 0x00000038 System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereArrayIterator`1::Clone()
// 0x00000039 System.Boolean System.Linq.Enumerable_WhereArrayIterator`1::MoveNext()
// 0x0000003A System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereArrayIterator`1::Select(System.Func`2<TSource,TResult>)
// 0x0000003B System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereArrayIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x0000003C System.Void System.Linq.Enumerable_WhereListIterator`1::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>)
// 0x0000003D System.Linq.Enumerable_Iterator`1<TSource> System.Linq.Enumerable_WhereListIterator`1::Clone()
// 0x0000003E System.Boolean System.Linq.Enumerable_WhereListIterator`1::MoveNext()
// 0x0000003F System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereListIterator`1::Select(System.Func`2<TSource,TResult>)
// 0x00000040 System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable_WhereListIterator`1::Where(System.Func`2<TSource,System.Boolean>)
// 0x00000041 System.Void System.Linq.Enumerable_WhereSelectEnumerableIterator`2::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
// 0x00000042 System.Linq.Enumerable_Iterator`1<TResult> System.Linq.Enumerable_WhereSelectEnumerableIterator`2::Clone()
// 0x00000043 System.Void System.Linq.Enumerable_WhereSelectEnumerableIterator`2::Dispose()
// 0x00000044 System.Boolean System.Linq.Enumerable_WhereSelectEnumerableIterator`2::MoveNext()
// 0x00000045 System.Collections.Generic.IEnumerable`1<TResult2> System.Linq.Enumerable_WhereSelectEnumerableIterator`2::Select(System.Func`2<TResult,TResult2>)
// 0x00000046 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereSelectEnumerableIterator`2::Where(System.Func`2<TResult,System.Boolean>)
// 0x00000047 System.Void System.Linq.Enumerable_WhereSelectArrayIterator`2::.ctor(TSource[],System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
// 0x00000048 System.Linq.Enumerable_Iterator`1<TResult> System.Linq.Enumerable_WhereSelectArrayIterator`2::Clone()
// 0x00000049 System.Boolean System.Linq.Enumerable_WhereSelectArrayIterator`2::MoveNext()
// 0x0000004A System.Collections.Generic.IEnumerable`1<TResult2> System.Linq.Enumerable_WhereSelectArrayIterator`2::Select(System.Func`2<TResult,TResult2>)
// 0x0000004B System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereSelectArrayIterator`2::Where(System.Func`2<TResult,System.Boolean>)
// 0x0000004C System.Void System.Linq.Enumerable_WhereSelectListIterator`2::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
// 0x0000004D System.Linq.Enumerable_Iterator`1<TResult> System.Linq.Enumerable_WhereSelectListIterator`2::Clone()
// 0x0000004E System.Boolean System.Linq.Enumerable_WhereSelectListIterator`2::MoveNext()
// 0x0000004F System.Collections.Generic.IEnumerable`1<TResult2> System.Linq.Enumerable_WhereSelectListIterator`2::Select(System.Func`2<TResult,TResult2>)
// 0x00000050 System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable_WhereSelectListIterator`2::Where(System.Func`2<TResult,System.Boolean>)
// 0x00000051 System.Void System.Linq.Enumerable_<>c__DisplayClass6_0`1::.ctor()
// 0x00000052 System.Boolean System.Linq.Enumerable_<>c__DisplayClass6_0`1::<CombinePredicates>b__0(TSource)
// 0x00000053 System.Void System.Linq.Enumerable_<>c__DisplayClass7_0`3::.ctor()
// 0x00000054 TResult System.Linq.Enumerable_<>c__DisplayClass7_0`3::<CombineSelectors>b__0(TSource)
// 0x00000055 System.Void System.Linq.Enumerable_<SelectManyIterator>d__17`2::.ctor(System.Int32)
// 0x00000056 System.Void System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.IDisposable.Dispose()
// 0x00000057 System.Boolean System.Linq.Enumerable_<SelectManyIterator>d__17`2::MoveNext()
// 0x00000058 System.Void System.Linq.Enumerable_<SelectManyIterator>d__17`2::<>m__Finally1()
// 0x00000059 System.Void System.Linq.Enumerable_<SelectManyIterator>d__17`2::<>m__Finally2()
// 0x0000005A TResult System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.Collections.Generic.IEnumerator<TResult>.get_Current()
// 0x0000005B System.Void System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.Collections.IEnumerator.Reset()
// 0x0000005C System.Object System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.Collections.IEnumerator.get_Current()
// 0x0000005D System.Collections.Generic.IEnumerator`1<TResult> System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.Collections.Generic.IEnumerable<TResult>.GetEnumerator()
// 0x0000005E System.Collections.IEnumerator System.Linq.Enumerable_<SelectManyIterator>d__17`2::System.Collections.IEnumerable.GetEnumerator()
// 0x0000005F System.Void System.Linq.Enumerable_<UnionIterator>d__71`1::.ctor(System.Int32)
// 0x00000060 System.Void System.Linq.Enumerable_<UnionIterator>d__71`1::System.IDisposable.Dispose()
// 0x00000061 System.Boolean System.Linq.Enumerable_<UnionIterator>d__71`1::MoveNext()
// 0x00000062 System.Void System.Linq.Enumerable_<UnionIterator>d__71`1::<>m__Finally1()
// 0x00000063 System.Void System.Linq.Enumerable_<UnionIterator>d__71`1::<>m__Finally2()
// 0x00000064 TSource System.Linq.Enumerable_<UnionIterator>d__71`1::System.Collections.Generic.IEnumerator<TSource>.get_Current()
// 0x00000065 System.Void System.Linq.Enumerable_<UnionIterator>d__71`1::System.Collections.IEnumerator.Reset()
// 0x00000066 System.Object System.Linq.Enumerable_<UnionIterator>d__71`1::System.Collections.IEnumerator.get_Current()
// 0x00000067 System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable_<UnionIterator>d__71`1::System.Collections.Generic.IEnumerable<TSource>.GetEnumerator()
// 0x00000068 System.Collections.IEnumerator System.Linq.Enumerable_<UnionIterator>d__71`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000069 System.Void System.Linq.Enumerable_<CastIterator>d__99`1::.ctor(System.Int32)
// 0x0000006A System.Void System.Linq.Enumerable_<CastIterator>d__99`1::System.IDisposable.Dispose()
// 0x0000006B System.Boolean System.Linq.Enumerable_<CastIterator>d__99`1::MoveNext()
// 0x0000006C System.Void System.Linq.Enumerable_<CastIterator>d__99`1::<>m__Finally1()
// 0x0000006D TResult System.Linq.Enumerable_<CastIterator>d__99`1::System.Collections.Generic.IEnumerator<TResult>.get_Current()
// 0x0000006E System.Void System.Linq.Enumerable_<CastIterator>d__99`1::System.Collections.IEnumerator.Reset()
// 0x0000006F System.Object System.Linq.Enumerable_<CastIterator>d__99`1::System.Collections.IEnumerator.get_Current()
// 0x00000070 System.Collections.Generic.IEnumerator`1<TResult> System.Linq.Enumerable_<CastIterator>d__99`1::System.Collections.Generic.IEnumerable<TResult>.GetEnumerator()
// 0x00000071 System.Collections.IEnumerator System.Linq.Enumerable_<CastIterator>d__99`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000072 System.Void System.Linq.EmptyEnumerable`1::.cctor()
// 0x00000073 System.Func`2<TElement,TElement> System.Linq.IdentityFunction`1::get_Instance()
// 0x00000074 System.Void System.Linq.IdentityFunction`1_<>c::.cctor()
// 0x00000075 System.Void System.Linq.IdentityFunction`1_<>c::.ctor()
// 0x00000076 TElement System.Linq.IdentityFunction`1_<>c::<get_Instance>b__1_0(TElement)
// 0x00000077 System.Linq.IOrderedEnumerable`1<TElement> System.Linq.IOrderedEnumerable`1::CreateOrderedEnumerable(System.Func`2<TElement,TKey>,System.Collections.Generic.IComparer`1<TKey>,System.Boolean)
// 0x00000078 System.Linq.Lookup`2<TKey,TElement> System.Linq.Lookup`2::Create(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>,System.Func`2<TSource,TElement>,System.Collections.Generic.IEqualityComparer`1<TKey>)
// 0x00000079 System.Void System.Linq.Lookup`2::.ctor(System.Collections.Generic.IEqualityComparer`1<TKey>)
// 0x0000007A System.Collections.Generic.IEnumerator`1<System.Linq.IGrouping`2<TKey,TElement>> System.Linq.Lookup`2::GetEnumerator()
// 0x0000007B System.Collections.IEnumerator System.Linq.Lookup`2::System.Collections.IEnumerable.GetEnumerator()
// 0x0000007C System.Int32 System.Linq.Lookup`2::InternalGetHashCode(TKey)
// 0x0000007D System.Linq.Lookup`2_Grouping<TKey,TElement> System.Linq.Lookup`2::GetGrouping(TKey,System.Boolean)
// 0x0000007E System.Void System.Linq.Lookup`2::Resize()
// 0x0000007F System.Void System.Linq.Lookup`2_Grouping::Add(TElement)
// 0x00000080 System.Collections.Generic.IEnumerator`1<TElement> System.Linq.Lookup`2_Grouping::GetEnumerator()
// 0x00000081 System.Collections.IEnumerator System.Linq.Lookup`2_Grouping::System.Collections.IEnumerable.GetEnumerator()
// 0x00000082 System.Int32 System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.get_Count()
// 0x00000083 System.Boolean System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.get_IsReadOnly()
// 0x00000084 System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.Add(TElement)
// 0x00000085 System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.Clear()
// 0x00000086 System.Boolean System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.Contains(TElement)
// 0x00000087 System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.CopyTo(TElement[],System.Int32)
// 0x00000088 System.Boolean System.Linq.Lookup`2_Grouping::System.Collections.Generic.ICollection<TElement>.Remove(TElement)
// 0x00000089 System.Int32 System.Linq.Lookup`2_Grouping::System.Collections.Generic.IList<TElement>.IndexOf(TElement)
// 0x0000008A System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.IList<TElement>.Insert(System.Int32,TElement)
// 0x0000008B System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.IList<TElement>.RemoveAt(System.Int32)
// 0x0000008C TElement System.Linq.Lookup`2_Grouping::System.Collections.Generic.IList<TElement>.get_Item(System.Int32)
// 0x0000008D System.Void System.Linq.Lookup`2_Grouping::System.Collections.Generic.IList<TElement>.set_Item(System.Int32,TElement)
// 0x0000008E System.Void System.Linq.Lookup`2_Grouping::.ctor()
// 0x0000008F System.Void System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::.ctor(System.Int32)
// 0x00000090 System.Void System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::System.IDisposable.Dispose()
// 0x00000091 System.Boolean System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::MoveNext()
// 0x00000092 TElement System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::System.Collections.Generic.IEnumerator<TElement>.get_Current()
// 0x00000093 System.Void System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::System.Collections.IEnumerator.Reset()
// 0x00000094 System.Object System.Linq.Lookup`2_Grouping_<GetEnumerator>d__7::System.Collections.IEnumerator.get_Current()
// 0x00000095 System.Void System.Linq.Lookup`2_<GetEnumerator>d__12::.ctor(System.Int32)
// 0x00000096 System.Void System.Linq.Lookup`2_<GetEnumerator>d__12::System.IDisposable.Dispose()
// 0x00000097 System.Boolean System.Linq.Lookup`2_<GetEnumerator>d__12::MoveNext()
// 0x00000098 System.Linq.IGrouping`2<TKey,TElement> System.Linq.Lookup`2_<GetEnumerator>d__12::System.Collections.Generic.IEnumerator<System.Linq.IGrouping<TKey,TElement>>.get_Current()
// 0x00000099 System.Void System.Linq.Lookup`2_<GetEnumerator>d__12::System.Collections.IEnumerator.Reset()
// 0x0000009A System.Object System.Linq.Lookup`2_<GetEnumerator>d__12::System.Collections.IEnumerator.get_Current()
// 0x0000009B System.Void System.Linq.Set`1::.ctor(System.Collections.Generic.IEqualityComparer`1<TElement>)
// 0x0000009C System.Boolean System.Linq.Set`1::Add(TElement)
// 0x0000009D System.Boolean System.Linq.Set`1::Find(TElement,System.Boolean)
// 0x0000009E System.Void System.Linq.Set`1::Resize()
// 0x0000009F System.Int32 System.Linq.Set`1::InternalGetHashCode(TElement)
// 0x000000A0 System.Void System.Linq.GroupedEnumerable`3::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,TKey>,System.Func`2<TSource,TElement>,System.Collections.Generic.IEqualityComparer`1<TKey>)
// 0x000000A1 System.Collections.Generic.IEnumerator`1<System.Linq.IGrouping`2<TKey,TElement>> System.Linq.GroupedEnumerable`3::GetEnumerator()
// 0x000000A2 System.Collections.IEnumerator System.Linq.GroupedEnumerable`3::System.Collections.IEnumerable.GetEnumerator()
// 0x000000A3 System.Collections.Generic.IEnumerator`1<TElement> System.Linq.OrderedEnumerable`1::GetEnumerator()
// 0x000000A4 System.Linq.EnumerableSorter`1<TElement> System.Linq.OrderedEnumerable`1::GetEnumerableSorter(System.Linq.EnumerableSorter`1<TElement>)
// 0x000000A5 System.Collections.IEnumerator System.Linq.OrderedEnumerable`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000000A6 System.Linq.IOrderedEnumerable`1<TElement> System.Linq.OrderedEnumerable`1::System.Linq.IOrderedEnumerable<TElement>.CreateOrderedEnumerable(System.Func`2<TElement,TKey>,System.Collections.Generic.IComparer`1<TKey>,System.Boolean)
// 0x000000A7 System.Void System.Linq.OrderedEnumerable`1::.ctor()
// 0x000000A8 System.Void System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::.ctor(System.Int32)
// 0x000000A9 System.Void System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::System.IDisposable.Dispose()
// 0x000000AA System.Boolean System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::MoveNext()
// 0x000000AB TElement System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::System.Collections.Generic.IEnumerator<TElement>.get_Current()
// 0x000000AC System.Void System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::System.Collections.IEnumerator.Reset()
// 0x000000AD System.Object System.Linq.OrderedEnumerable`1_<GetEnumerator>d__1::System.Collections.IEnumerator.get_Current()
// 0x000000AE System.Void System.Linq.OrderedEnumerable`2::.ctor(System.Collections.Generic.IEnumerable`1<TElement>,System.Func`2<TElement,TKey>,System.Collections.Generic.IComparer`1<TKey>,System.Boolean)
// 0x000000AF System.Linq.EnumerableSorter`1<TElement> System.Linq.OrderedEnumerable`2::GetEnumerableSorter(System.Linq.EnumerableSorter`1<TElement>)
// 0x000000B0 System.Void System.Linq.EnumerableSorter`1::ComputeKeys(TElement[],System.Int32)
// 0x000000B1 System.Int32 System.Linq.EnumerableSorter`1::CompareKeys(System.Int32,System.Int32)
// 0x000000B2 System.Int32[] System.Linq.EnumerableSorter`1::Sort(TElement[],System.Int32)
// 0x000000B3 System.Void System.Linq.EnumerableSorter`1::QuickSort(System.Int32[],System.Int32,System.Int32)
// 0x000000B4 System.Void System.Linq.EnumerableSorter`1::.ctor()
// 0x000000B5 System.Void System.Linq.EnumerableSorter`2::.ctor(System.Func`2<TElement,TKey>,System.Collections.Generic.IComparer`1<TKey>,System.Boolean,System.Linq.EnumerableSorter`1<TElement>)
// 0x000000B6 System.Void System.Linq.EnumerableSorter`2::ComputeKeys(TElement[],System.Int32)
// 0x000000B7 System.Int32 System.Linq.EnumerableSorter`2::CompareKeys(System.Int32,System.Int32)
// 0x000000B8 System.Void System.Linq.Buffer`1::.ctor(System.Collections.Generic.IEnumerable`1<TElement>)
// 0x000000B9 TElement[] System.Linq.Buffer`1::ToArray()
// 0x000000BA System.Void System.Collections.Generic.HashSet`1::.ctor()
// 0x000000BB System.Void System.Collections.Generic.HashSet`1::.ctor(System.Collections.Generic.IEqualityComparer`1<T>)
// 0x000000BC System.Void System.Collections.Generic.HashSet`1::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x000000BD System.Void System.Collections.Generic.HashSet`1::System.Collections.Generic.ICollection<T>.Add(T)
// 0x000000BE System.Void System.Collections.Generic.HashSet`1::Clear()
// 0x000000BF System.Boolean System.Collections.Generic.HashSet`1::Contains(T)
// 0x000000C0 System.Void System.Collections.Generic.HashSet`1::CopyTo(T[],System.Int32)
// 0x000000C1 System.Boolean System.Collections.Generic.HashSet`1::Remove(T)
// 0x000000C2 System.Int32 System.Collections.Generic.HashSet`1::get_Count()
// 0x000000C3 System.Boolean System.Collections.Generic.HashSet`1::System.Collections.Generic.ICollection<T>.get_IsReadOnly()
// 0x000000C4 System.Collections.Generic.HashSet`1_Enumerator<T> System.Collections.Generic.HashSet`1::GetEnumerator()
// 0x000000C5 System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.HashSet`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x000000C6 System.Collections.IEnumerator System.Collections.Generic.HashSet`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000000C7 System.Void System.Collections.Generic.HashSet`1::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x000000C8 System.Void System.Collections.Generic.HashSet`1::OnDeserialization(System.Object)
// 0x000000C9 System.Boolean System.Collections.Generic.HashSet`1::Add(T)
// 0x000000CA System.Void System.Collections.Generic.HashSet`1::CopyTo(T[])
// 0x000000CB System.Void System.Collections.Generic.HashSet`1::CopyTo(T[],System.Int32,System.Int32)
// 0x000000CC System.Void System.Collections.Generic.HashSet`1::Initialize(System.Int32)
// 0x000000CD System.Void System.Collections.Generic.HashSet`1::IncreaseCapacity()
// 0x000000CE System.Void System.Collections.Generic.HashSet`1::SetCapacity(System.Int32)
// 0x000000CF System.Boolean System.Collections.Generic.HashSet`1::AddIfNotPresent(T)
// 0x000000D0 System.Int32 System.Collections.Generic.HashSet`1::InternalGetHashCode(T)
// 0x000000D1 System.Void System.Collections.Generic.HashSet`1_Enumerator::.ctor(System.Collections.Generic.HashSet`1<T>)
// 0x000000D2 System.Void System.Collections.Generic.HashSet`1_Enumerator::Dispose()
// 0x000000D3 System.Boolean System.Collections.Generic.HashSet`1_Enumerator::MoveNext()
// 0x000000D4 T System.Collections.Generic.HashSet`1_Enumerator::get_Current()
// 0x000000D5 System.Object System.Collections.Generic.HashSet`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x000000D6 System.Void System.Collections.Generic.HashSet`1_Enumerator::System.Collections.IEnumerator.Reset()
static Il2CppMethodPointer s_methodPointers[214] = 
{
	Error_ArgumentNull_mCA126ED8F4F3B343A70E201C44B3A509690F1EA7,
	Error_ArgumentOutOfRange_mACFCB068F4E0C4EEF9E6EDDD59E798901C32C6C9,
	Error_MoreThanOneElement_mD96D1249F5D42379E9417302B5F33DD99B51C863,
	Error_MoreThanOneMatch_m85C3617F782E9F2333FC1FDF42821BE069F24623,
	Error_NoElements_m17188AC2CF25EB359A4E1DDE9518A98598791136,
	Error_NotSupported_mD771E9977E8BE0B8298A582AB0BB74D1CF10900D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
static const int32_t s_InvokerIndices[214] = 
{
	0,
	0,
	4,
	4,
	4,
	4,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
};
static const Il2CppTokenRangePair s_rgctxIndices[67] = 
{
	{ 0x02000004, { 103, 4 } },
	{ 0x02000005, { 107, 9 } },
	{ 0x02000006, { 118, 7 } },
	{ 0x02000007, { 127, 10 } },
	{ 0x02000008, { 139, 11 } },
	{ 0x02000009, { 153, 9 } },
	{ 0x0200000A, { 165, 12 } },
	{ 0x0200000B, { 180, 1 } },
	{ 0x0200000C, { 181, 2 } },
	{ 0x0200000D, { 183, 12 } },
	{ 0x0200000E, { 195, 12 } },
	{ 0x0200000F, { 207, 6 } },
	{ 0x02000010, { 213, 2 } },
	{ 0x02000011, { 215, 4 } },
	{ 0x02000012, { 219, 3 } },
	{ 0x02000015, { 222, 17 } },
	{ 0x02000016, { 243, 5 } },
	{ 0x02000017, { 248, 1 } },
	{ 0x02000019, { 249, 8 } },
	{ 0x0200001B, { 257, 4 } },
	{ 0x0200001C, { 261, 3 } },
	{ 0x0200001D, { 266, 5 } },
	{ 0x0200001E, { 271, 7 } },
	{ 0x0200001F, { 278, 3 } },
	{ 0x02000020, { 281, 7 } },
	{ 0x02000021, { 288, 4 } },
	{ 0x02000022, { 292, 21 } },
	{ 0x02000024, { 313, 2 } },
	{ 0x06000007, { 0, 10 } },
	{ 0x06000008, { 10, 10 } },
	{ 0x06000009, { 20, 5 } },
	{ 0x0600000A, { 25, 5 } },
	{ 0x0600000B, { 30, 1 } },
	{ 0x0600000C, { 31, 2 } },
	{ 0x0600000D, { 33, 2 } },
	{ 0x0600000E, { 35, 1 } },
	{ 0x0600000F, { 36, 4 } },
	{ 0x06000010, { 40, 1 } },
	{ 0x06000011, { 41, 2 } },
	{ 0x06000012, { 43, 3 } },
	{ 0x06000013, { 46, 2 } },
	{ 0x06000014, { 48, 1 } },
	{ 0x06000015, { 49, 7 } },
	{ 0x06000016, { 56, 2 } },
	{ 0x06000017, { 58, 2 } },
	{ 0x06000018, { 60, 4 } },
	{ 0x06000019, { 64, 4 } },
	{ 0x0600001A, { 68, 4 } },
	{ 0x0600001B, { 72, 3 } },
	{ 0x0600001C, { 75, 4 } },
	{ 0x0600001D, { 79, 4 } },
	{ 0x0600001E, { 83, 3 } },
	{ 0x0600001F, { 86, 1 } },
	{ 0x06000020, { 87, 1 } },
	{ 0x06000021, { 88, 3 } },
	{ 0x06000022, { 91, 3 } },
	{ 0x06000023, { 94, 2 } },
	{ 0x06000024, { 96, 2 } },
	{ 0x06000025, { 98, 5 } },
	{ 0x06000035, { 116, 2 } },
	{ 0x0600003A, { 125, 2 } },
	{ 0x0600003F, { 137, 2 } },
	{ 0x06000045, { 150, 3 } },
	{ 0x0600004A, { 162, 3 } },
	{ 0x0600004F, { 177, 3 } },
	{ 0x06000078, { 239, 4 } },
	{ 0x060000A6, { 264, 2 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[315] = 
{
	{ (Il2CppRGCTXDataType)2, 24093 },
	{ (Il2CppRGCTXDataType)3, 20429 },
	{ (Il2CppRGCTXDataType)2, 24094 },
	{ (Il2CppRGCTXDataType)2, 24095 },
	{ (Il2CppRGCTXDataType)3, 20430 },
	{ (Il2CppRGCTXDataType)2, 24096 },
	{ (Il2CppRGCTXDataType)2, 24097 },
	{ (Il2CppRGCTXDataType)3, 20431 },
	{ (Il2CppRGCTXDataType)2, 24098 },
	{ (Il2CppRGCTXDataType)3, 20432 },
	{ (Il2CppRGCTXDataType)2, 24099 },
	{ (Il2CppRGCTXDataType)3, 20433 },
	{ (Il2CppRGCTXDataType)2, 24100 },
	{ (Il2CppRGCTXDataType)2, 24101 },
	{ (Il2CppRGCTXDataType)3, 20434 },
	{ (Il2CppRGCTXDataType)2, 24102 },
	{ (Il2CppRGCTXDataType)2, 24103 },
	{ (Il2CppRGCTXDataType)3, 20435 },
	{ (Il2CppRGCTXDataType)2, 24104 },
	{ (Il2CppRGCTXDataType)3, 20436 },
	{ (Il2CppRGCTXDataType)2, 24105 },
	{ (Il2CppRGCTXDataType)3, 20437 },
	{ (Il2CppRGCTXDataType)3, 20438 },
	{ (Il2CppRGCTXDataType)2, 17945 },
	{ (Il2CppRGCTXDataType)3, 20439 },
	{ (Il2CppRGCTXDataType)2, 24106 },
	{ (Il2CppRGCTXDataType)3, 20440 },
	{ (Il2CppRGCTXDataType)3, 20441 },
	{ (Il2CppRGCTXDataType)2, 17952 },
	{ (Il2CppRGCTXDataType)3, 20442 },
	{ (Il2CppRGCTXDataType)3, 20443 },
	{ (Il2CppRGCTXDataType)2, 24107 },
	{ (Il2CppRGCTXDataType)3, 20444 },
	{ (Il2CppRGCTXDataType)2, 24108 },
	{ (Il2CppRGCTXDataType)3, 20445 },
	{ (Il2CppRGCTXDataType)3, 20446 },
	{ (Il2CppRGCTXDataType)3, 20447 },
	{ (Il2CppRGCTXDataType)2, 24109 },
	{ (Il2CppRGCTXDataType)2, 24110 },
	{ (Il2CppRGCTXDataType)3, 20448 },
	{ (Il2CppRGCTXDataType)3, 20449 },
	{ (Il2CppRGCTXDataType)2, 24111 },
	{ (Il2CppRGCTXDataType)3, 20450 },
	{ (Il2CppRGCTXDataType)2, 24112 },
	{ (Il2CppRGCTXDataType)3, 20451 },
	{ (Il2CppRGCTXDataType)3, 20452 },
	{ (Il2CppRGCTXDataType)2, 17988 },
	{ (Il2CppRGCTXDataType)3, 20453 },
	{ (Il2CppRGCTXDataType)3, 20454 },
	{ (Il2CppRGCTXDataType)2, 18003 },
	{ (Il2CppRGCTXDataType)3, 20455 },
	{ (Il2CppRGCTXDataType)2, 17996 },
	{ (Il2CppRGCTXDataType)2, 24113 },
	{ (Il2CppRGCTXDataType)3, 20456 },
	{ (Il2CppRGCTXDataType)3, 20457 },
	{ (Il2CppRGCTXDataType)3, 20458 },
	{ (Il2CppRGCTXDataType)2, 18004 },
	{ (Il2CppRGCTXDataType)3, 20459 },
	{ (Il2CppRGCTXDataType)2, 24114 },
	{ (Il2CppRGCTXDataType)3, 20460 },
	{ (Il2CppRGCTXDataType)2, 24115 },
	{ (Il2CppRGCTXDataType)2, 24116 },
	{ (Il2CppRGCTXDataType)2, 18008 },
	{ (Il2CppRGCTXDataType)2, 24117 },
	{ (Il2CppRGCTXDataType)2, 24118 },
	{ (Il2CppRGCTXDataType)2, 24119 },
	{ (Il2CppRGCTXDataType)2, 18010 },
	{ (Il2CppRGCTXDataType)2, 24120 },
	{ (Il2CppRGCTXDataType)2, 24121 },
	{ (Il2CppRGCTXDataType)2, 24122 },
	{ (Il2CppRGCTXDataType)2, 18012 },
	{ (Il2CppRGCTXDataType)2, 24123 },
	{ (Il2CppRGCTXDataType)2, 18014 },
	{ (Il2CppRGCTXDataType)2, 24124 },
	{ (Il2CppRGCTXDataType)3, 20461 },
	{ (Il2CppRGCTXDataType)2, 24125 },
	{ (Il2CppRGCTXDataType)2, 24126 },
	{ (Il2CppRGCTXDataType)2, 18017 },
	{ (Il2CppRGCTXDataType)2, 24127 },
	{ (Il2CppRGCTXDataType)2, 24128 },
	{ (Il2CppRGCTXDataType)2, 24129 },
	{ (Il2CppRGCTXDataType)2, 18019 },
	{ (Il2CppRGCTXDataType)2, 24130 },
	{ (Il2CppRGCTXDataType)2, 18021 },
	{ (Il2CppRGCTXDataType)2, 24131 },
	{ (Il2CppRGCTXDataType)3, 20462 },
	{ (Il2CppRGCTXDataType)2, 24132 },
	{ (Il2CppRGCTXDataType)2, 18026 },
	{ (Il2CppRGCTXDataType)2, 18028 },
	{ (Il2CppRGCTXDataType)2, 24133 },
	{ (Il2CppRGCTXDataType)3, 20463 },
	{ (Il2CppRGCTXDataType)2, 18031 },
	{ (Il2CppRGCTXDataType)2, 24134 },
	{ (Il2CppRGCTXDataType)3, 20464 },
	{ (Il2CppRGCTXDataType)2, 24135 },
	{ (Il2CppRGCTXDataType)2, 18034 },
	{ (Il2CppRGCTXDataType)2, 24136 },
	{ (Il2CppRGCTXDataType)3, 20465 },
	{ (Il2CppRGCTXDataType)3, 20466 },
	{ (Il2CppRGCTXDataType)2, 24137 },
	{ (Il2CppRGCTXDataType)2, 18038 },
	{ (Il2CppRGCTXDataType)2, 24138 },
	{ (Il2CppRGCTXDataType)2, 18040 },
	{ (Il2CppRGCTXDataType)3, 20467 },
	{ (Il2CppRGCTXDataType)3, 20468 },
	{ (Il2CppRGCTXDataType)2, 18043 },
	{ (Il2CppRGCTXDataType)3, 20469 },
	{ (Il2CppRGCTXDataType)3, 20470 },
	{ (Il2CppRGCTXDataType)2, 18055 },
	{ (Il2CppRGCTXDataType)2, 24139 },
	{ (Il2CppRGCTXDataType)3, 20471 },
	{ (Il2CppRGCTXDataType)3, 20472 },
	{ (Il2CppRGCTXDataType)2, 18057 },
	{ (Il2CppRGCTXDataType)2, 23970 },
	{ (Il2CppRGCTXDataType)3, 20473 },
	{ (Il2CppRGCTXDataType)3, 20474 },
	{ (Il2CppRGCTXDataType)2, 24140 },
	{ (Il2CppRGCTXDataType)3, 20475 },
	{ (Il2CppRGCTXDataType)3, 20476 },
	{ (Il2CppRGCTXDataType)2, 18067 },
	{ (Il2CppRGCTXDataType)2, 24141 },
	{ (Il2CppRGCTXDataType)3, 20477 },
	{ (Il2CppRGCTXDataType)3, 20478 },
	{ (Il2CppRGCTXDataType)3, 19711 },
	{ (Il2CppRGCTXDataType)3, 20479 },
	{ (Il2CppRGCTXDataType)2, 24142 },
	{ (Il2CppRGCTXDataType)3, 20480 },
	{ (Il2CppRGCTXDataType)3, 20481 },
	{ (Il2CppRGCTXDataType)2, 18079 },
	{ (Il2CppRGCTXDataType)2, 24143 },
	{ (Il2CppRGCTXDataType)3, 20482 },
	{ (Il2CppRGCTXDataType)3, 20483 },
	{ (Il2CppRGCTXDataType)3, 20484 },
	{ (Il2CppRGCTXDataType)3, 20485 },
	{ (Il2CppRGCTXDataType)3, 20486 },
	{ (Il2CppRGCTXDataType)3, 19717 },
	{ (Il2CppRGCTXDataType)3, 20487 },
	{ (Il2CppRGCTXDataType)2, 24144 },
	{ (Il2CppRGCTXDataType)3, 20488 },
	{ (Il2CppRGCTXDataType)3, 20489 },
	{ (Il2CppRGCTXDataType)2, 18092 },
	{ (Il2CppRGCTXDataType)2, 24145 },
	{ (Il2CppRGCTXDataType)3, 20490 },
	{ (Il2CppRGCTXDataType)3, 20491 },
	{ (Il2CppRGCTXDataType)2, 18094 },
	{ (Il2CppRGCTXDataType)2, 24146 },
	{ (Il2CppRGCTXDataType)3, 20492 },
	{ (Il2CppRGCTXDataType)3, 20493 },
	{ (Il2CppRGCTXDataType)2, 24147 },
	{ (Il2CppRGCTXDataType)3, 20494 },
	{ (Il2CppRGCTXDataType)3, 20495 },
	{ (Il2CppRGCTXDataType)2, 24148 },
	{ (Il2CppRGCTXDataType)3, 20496 },
	{ (Il2CppRGCTXDataType)3, 20497 },
	{ (Il2CppRGCTXDataType)2, 18109 },
	{ (Il2CppRGCTXDataType)2, 24149 },
	{ (Il2CppRGCTXDataType)3, 20498 },
	{ (Il2CppRGCTXDataType)3, 20499 },
	{ (Il2CppRGCTXDataType)3, 20500 },
	{ (Il2CppRGCTXDataType)3, 19728 },
	{ (Il2CppRGCTXDataType)2, 24150 },
	{ (Il2CppRGCTXDataType)3, 20501 },
	{ (Il2CppRGCTXDataType)3, 20502 },
	{ (Il2CppRGCTXDataType)2, 24151 },
	{ (Il2CppRGCTXDataType)3, 20503 },
	{ (Il2CppRGCTXDataType)3, 20504 },
	{ (Il2CppRGCTXDataType)2, 18125 },
	{ (Il2CppRGCTXDataType)2, 24152 },
	{ (Il2CppRGCTXDataType)3, 20505 },
	{ (Il2CppRGCTXDataType)3, 20506 },
	{ (Il2CppRGCTXDataType)3, 20507 },
	{ (Il2CppRGCTXDataType)3, 20508 },
	{ (Il2CppRGCTXDataType)3, 20509 },
	{ (Il2CppRGCTXDataType)3, 20510 },
	{ (Il2CppRGCTXDataType)3, 19734 },
	{ (Il2CppRGCTXDataType)2, 24153 },
	{ (Il2CppRGCTXDataType)3, 20511 },
	{ (Il2CppRGCTXDataType)3, 20512 },
	{ (Il2CppRGCTXDataType)2, 24154 },
	{ (Il2CppRGCTXDataType)3, 20513 },
	{ (Il2CppRGCTXDataType)3, 20514 },
	{ (Il2CppRGCTXDataType)3, 20515 },
	{ (Il2CppRGCTXDataType)3, 20516 },
	{ (Il2CppRGCTXDataType)3, 20517 },
	{ (Il2CppRGCTXDataType)3, 20518 },
	{ (Il2CppRGCTXDataType)2, 24155 },
	{ (Il2CppRGCTXDataType)2, 24156 },
	{ (Il2CppRGCTXDataType)3, 20519 },
	{ (Il2CppRGCTXDataType)2, 18160 },
	{ (Il2CppRGCTXDataType)2, 18154 },
	{ (Il2CppRGCTXDataType)3, 20520 },
	{ (Il2CppRGCTXDataType)2, 18153 },
	{ (Il2CppRGCTXDataType)2, 24157 },
	{ (Il2CppRGCTXDataType)3, 20521 },
	{ (Il2CppRGCTXDataType)3, 20522 },
	{ (Il2CppRGCTXDataType)3, 20523 },
	{ (Il2CppRGCTXDataType)3, 20524 },
	{ (Il2CppRGCTXDataType)2, 24158 },
	{ (Il2CppRGCTXDataType)3, 20525 },
	{ (Il2CppRGCTXDataType)2, 18176 },
	{ (Il2CppRGCTXDataType)2, 18168 },
	{ (Il2CppRGCTXDataType)3, 20526 },
	{ (Il2CppRGCTXDataType)3, 20527 },
	{ (Il2CppRGCTXDataType)2, 18167 },
	{ (Il2CppRGCTXDataType)2, 24159 },
	{ (Il2CppRGCTXDataType)3, 20528 },
	{ (Il2CppRGCTXDataType)3, 20529 },
	{ (Il2CppRGCTXDataType)3, 20530 },
	{ (Il2CppRGCTXDataType)2, 18180 },
	{ (Il2CppRGCTXDataType)3, 20531 },
	{ (Il2CppRGCTXDataType)2, 24160 },
	{ (Il2CppRGCTXDataType)3, 20532 },
	{ (Il2CppRGCTXDataType)3, 20533 },
	{ (Il2CppRGCTXDataType)2, 24161 },
	{ (Il2CppRGCTXDataType)2, 24162 },
	{ (Il2CppRGCTXDataType)2, 24163 },
	{ (Il2CppRGCTXDataType)3, 20534 },
	{ (Il2CppRGCTXDataType)2, 18192 },
	{ (Il2CppRGCTXDataType)3, 20535 },
	{ (Il2CppRGCTXDataType)2, 24164 },
	{ (Il2CppRGCTXDataType)3, 20536 },
	{ (Il2CppRGCTXDataType)2, 24164 },
	{ (Il2CppRGCTXDataType)2, 18220 },
	{ (Il2CppRGCTXDataType)3, 20537 },
	{ (Il2CppRGCTXDataType)3, 20538 },
	{ (Il2CppRGCTXDataType)3, 20539 },
	{ (Il2CppRGCTXDataType)3, 20540 },
	{ (Il2CppRGCTXDataType)2, 24165 },
	{ (Il2CppRGCTXDataType)2, 24166 },
	{ (Il2CppRGCTXDataType)2, 24167 },
	{ (Il2CppRGCTXDataType)3, 20541 },
	{ (Il2CppRGCTXDataType)3, 20542 },
	{ (Il2CppRGCTXDataType)2, 18216 },
	{ (Il2CppRGCTXDataType)2, 18219 },
	{ (Il2CppRGCTXDataType)3, 20543 },
	{ (Il2CppRGCTXDataType)3, 20544 },
	{ (Il2CppRGCTXDataType)2, 18223 },
	{ (Il2CppRGCTXDataType)3, 20545 },
	{ (Il2CppRGCTXDataType)2, 24168 },
	{ (Il2CppRGCTXDataType)2, 18213 },
	{ (Il2CppRGCTXDataType)2, 24169 },
	{ (Il2CppRGCTXDataType)3, 20546 },
	{ (Il2CppRGCTXDataType)3, 20547 },
	{ (Il2CppRGCTXDataType)3, 20548 },
	{ (Il2CppRGCTXDataType)2, 24170 },
	{ (Il2CppRGCTXDataType)3, 20549 },
	{ (Il2CppRGCTXDataType)3, 20550 },
	{ (Il2CppRGCTXDataType)3, 20551 },
	{ (Il2CppRGCTXDataType)2, 18238 },
	{ (Il2CppRGCTXDataType)3, 20552 },
	{ (Il2CppRGCTXDataType)2, 24171 },
	{ (Il2CppRGCTXDataType)2, 24172 },
	{ (Il2CppRGCTXDataType)3, 20553 },
	{ (Il2CppRGCTXDataType)3, 20554 },
	{ (Il2CppRGCTXDataType)2, 18259 },
	{ (Il2CppRGCTXDataType)3, 20555 },
	{ (Il2CppRGCTXDataType)2, 18260 },
	{ (Il2CppRGCTXDataType)3, 20556 },
	{ (Il2CppRGCTXDataType)2, 24173 },
	{ (Il2CppRGCTXDataType)3, 20557 },
	{ (Il2CppRGCTXDataType)3, 20558 },
	{ (Il2CppRGCTXDataType)2, 24174 },
	{ (Il2CppRGCTXDataType)3, 20559 },
	{ (Il2CppRGCTXDataType)3, 20560 },
	{ (Il2CppRGCTXDataType)2, 24175 },
	{ (Il2CppRGCTXDataType)3, 20561 },
	{ (Il2CppRGCTXDataType)2, 24176 },
	{ (Il2CppRGCTXDataType)3, 20562 },
	{ (Il2CppRGCTXDataType)3, 20563 },
	{ (Il2CppRGCTXDataType)3, 20564 },
	{ (Il2CppRGCTXDataType)2, 18295 },
	{ (Il2CppRGCTXDataType)3, 20565 },
	{ (Il2CppRGCTXDataType)2, 18303 },
	{ (Il2CppRGCTXDataType)3, 20566 },
	{ (Il2CppRGCTXDataType)2, 24177 },
	{ (Il2CppRGCTXDataType)2, 24178 },
	{ (Il2CppRGCTXDataType)3, 20567 },
	{ (Il2CppRGCTXDataType)3, 20568 },
	{ (Il2CppRGCTXDataType)3, 20569 },
	{ (Il2CppRGCTXDataType)3, 20570 },
	{ (Il2CppRGCTXDataType)3, 20571 },
	{ (Il2CppRGCTXDataType)3, 20572 },
	{ (Il2CppRGCTXDataType)2, 18319 },
	{ (Il2CppRGCTXDataType)2, 24179 },
	{ (Il2CppRGCTXDataType)3, 20573 },
	{ (Il2CppRGCTXDataType)3, 20574 },
	{ (Il2CppRGCTXDataType)2, 18323 },
	{ (Il2CppRGCTXDataType)3, 20575 },
	{ (Il2CppRGCTXDataType)2, 24180 },
	{ (Il2CppRGCTXDataType)2, 18333 },
	{ (Il2CppRGCTXDataType)2, 18331 },
	{ (Il2CppRGCTXDataType)2, 24181 },
	{ (Il2CppRGCTXDataType)3, 20576 },
	{ (Il2CppRGCTXDataType)2, 24182 },
	{ (Il2CppRGCTXDataType)3, 20577 },
	{ (Il2CppRGCTXDataType)3, 20578 },
	{ (Il2CppRGCTXDataType)3, 20579 },
	{ (Il2CppRGCTXDataType)2, 18337 },
	{ (Il2CppRGCTXDataType)3, 20580 },
	{ (Il2CppRGCTXDataType)3, 20581 },
	{ (Il2CppRGCTXDataType)2, 18340 },
	{ (Il2CppRGCTXDataType)3, 20582 },
	{ (Il2CppRGCTXDataType)1, 24183 },
	{ (Il2CppRGCTXDataType)2, 18339 },
	{ (Il2CppRGCTXDataType)3, 20583 },
	{ (Il2CppRGCTXDataType)1, 18339 },
	{ (Il2CppRGCTXDataType)1, 18337 },
	{ (Il2CppRGCTXDataType)2, 24184 },
	{ (Il2CppRGCTXDataType)2, 18339 },
	{ (Il2CppRGCTXDataType)3, 20584 },
	{ (Il2CppRGCTXDataType)3, 20585 },
	{ (Il2CppRGCTXDataType)3, 20586 },
	{ (Il2CppRGCTXDataType)2, 18338 },
	{ (Il2CppRGCTXDataType)3, 20587 },
	{ (Il2CppRGCTXDataType)2, 18351 },
};
extern const Il2CppCodeGenModule g_System_CoreCodeGenModule;
const Il2CppCodeGenModule g_System_CoreCodeGenModule = 
{
	"System.Core.dll",
	214,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	67,
	s_rgctxIndices,
	315,
	s_rgctxValues,
	NULL,
};
