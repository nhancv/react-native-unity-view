﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 <id>j__TPar <>f__AnonymousType0`4::get_id()
// 0x00000002 <seq>j__TPar <>f__AnonymousType0`4::get_seq()
// 0x00000003 <name>j__TPar <>f__AnonymousType0`4::get_name()
// 0x00000004 <data>j__TPar <>f__AnonymousType0`4::get_data()
// 0x00000005 System.Void <>f__AnonymousType0`4::.ctor(<id>j__TPar,<seq>j__TPar,<name>j__TPar,<data>j__TPar)
// 0x00000006 System.Boolean <>f__AnonymousType0`4::Equals(System.Object)
// 0x00000007 System.Int32 <>f__AnonymousType0`4::GetHashCode()
// 0x00000008 System.String <>f__AnonymousType0`4::ToString()
// 0x00000009 System.Single ARFeatheredPlaneMeshVisualizer::get_featheringWidth()
extern void ARFeatheredPlaneMeshVisualizer_get_featheringWidth_mD474743D2E8E4CE3078FCD70A52B70111EC99500 ();
// 0x0000000A System.Void ARFeatheredPlaneMeshVisualizer::set_featheringWidth(System.Single)
extern void ARFeatheredPlaneMeshVisualizer_set_featheringWidth_m1974473A6C2BB2AED083691C8079E6F9A83398EC ();
// 0x0000000B System.Void ARFeatheredPlaneMeshVisualizer::Awake()
extern void ARFeatheredPlaneMeshVisualizer_Awake_mBFDBB9E8B393BD7BA784845A0C7692848E9C61E2 ();
// 0x0000000C System.Void ARFeatheredPlaneMeshVisualizer::OnEnable()
extern void ARFeatheredPlaneMeshVisualizer_OnEnable_m3A77938D2FE2C6A653A7E13B90DB6C9DEEB06A9A ();
// 0x0000000D System.Void ARFeatheredPlaneMeshVisualizer::OnDisable()
extern void ARFeatheredPlaneMeshVisualizer_OnDisable_m9DE1EB0F00D7F7AC754CE4633569BB8C8687C67A ();
// 0x0000000E System.Void ARFeatheredPlaneMeshVisualizer::ARPlane_boundaryUpdated(UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs)
extern void ARFeatheredPlaneMeshVisualizer_ARPlane_boundaryUpdated_mC88C42F35A3B243C83E9D24DCC9545F7E9E6BA28 ();
// 0x0000000F System.Void ARFeatheredPlaneMeshVisualizer::GenerateBoundaryUVs(UnityEngine.Mesh)
extern void ARFeatheredPlaneMeshVisualizer_GenerateBoundaryUVs_mCEA3823DDAED557BA0B92214D15AB25EC75065D8 ();
// 0x00000010 System.Void ARFeatheredPlaneMeshVisualizer::.ctor()
extern void ARFeatheredPlaneMeshVisualizer__ctor_mA9417DD97EC611603602EAE0302A80E71CF93890 ();
// 0x00000011 System.Void ARFeatheredPlaneMeshVisualizer::.cctor()
extern void ARFeatheredPlaneMeshVisualizer__cctor_mC697317BB4FB496A10AFA8C2E73E27AF8A5538A1 ();
// 0x00000012 System.Void FadePlaneOnBoundaryChange::OnEnable()
extern void FadePlaneOnBoundaryChange_OnEnable_mDE7F5846CEE8C9C0790C64394C9290F01C46E5CE ();
// 0x00000013 System.Void FadePlaneOnBoundaryChange::OnDisable()
extern void FadePlaneOnBoundaryChange_OnDisable_m7A0F29D256D7FB3D80E57C8C32A90E82C24BAA13 ();
// 0x00000014 System.Void FadePlaneOnBoundaryChange::Update()
extern void FadePlaneOnBoundaryChange_Update_m97ECC6F4BFA94FC49F95234F510F3F0E2A2630BE ();
// 0x00000015 System.Void FadePlaneOnBoundaryChange::PlaneOnBoundaryChanged(UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs)
extern void FadePlaneOnBoundaryChange_PlaneOnBoundaryChanged_m09B93DDCD1F281F8EA00FF95C8CFB6779923A4A1 ();
// 0x00000016 System.Void FadePlaneOnBoundaryChange::.ctor()
extern void FadePlaneOnBoundaryChange__ctor_m76BB07073C419951499094E08C1F40C376C0C3E0 ();
// 0x00000017 System.Boolean Extensions::IsEmpty(System.Object[])
extern void Extensions_IsEmpty_m5334C44A9B1BE5FE28D190CC961505281956AC85 ();
// 0x00000018 UnityEngine.XR.ARFoundation.ARCameraManager LightEstimation::get_cameraManager()
extern void LightEstimation_get_cameraManager_m24B7FBD82A85B1749F413E9463CF4819E87F179A ();
// 0x00000019 System.Void LightEstimation::set_cameraManager(UnityEngine.XR.ARFoundation.ARCameraManager)
extern void LightEstimation_set_cameraManager_m7DB56BE796AD559495B811205370EDC3ECEC6D03 ();
// 0x0000001A System.Nullable`1<System.Single> LightEstimation::get_brightness()
extern void LightEstimation_get_brightness_mC492132D55ECD6A3BDC2CEDD92BB36B2FA4DEE91 ();
// 0x0000001B System.Void LightEstimation::set_brightness(System.Nullable`1<System.Single>)
extern void LightEstimation_set_brightness_m753DF62923B281F038A993C8AC3E0224DE4138E9 ();
// 0x0000001C System.Nullable`1<System.Single> LightEstimation::get_colorTemperature()
extern void LightEstimation_get_colorTemperature_m14AA85A63C4872E42A7AA541F843573FD5460F60 ();
// 0x0000001D System.Void LightEstimation::set_colorTemperature(System.Nullable`1<System.Single>)
extern void LightEstimation_set_colorTemperature_m67869580BD0D33B4AA3F327B4E824354E16BF1FD ();
// 0x0000001E System.Nullable`1<UnityEngine.Color> LightEstimation::get_colorCorrection()
extern void LightEstimation_get_colorCorrection_m25920670C31027CC61B0A3B94CC77D1FF27C6D78 ();
// 0x0000001F System.Void LightEstimation::set_colorCorrection(System.Nullable`1<UnityEngine.Color>)
extern void LightEstimation_set_colorCorrection_mE50133CC495B31263C6FD2871F1AABC70576B96F ();
// 0x00000020 System.Void LightEstimation::Awake()
extern void LightEstimation_Awake_m810C5DDEF38182C155ED925189FCEE5A6156ED0F ();
// 0x00000021 System.Void LightEstimation::OnEnable()
extern void LightEstimation_OnEnable_m14852BF0988F64CA2BD06CAF46F3F01E0E4ABD8C ();
// 0x00000022 System.Void LightEstimation::OnDisable()
extern void LightEstimation_OnDisable_mB4EE490FD2CE5C671376ED02803EEEC99DCB6941 ();
// 0x00000023 System.Void LightEstimation::FrameChanged(UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs)
extern void LightEstimation_FrameChanged_mB8C2FF65FE6F8AEDA4D055B124B953CF88ABBD82 ();
// 0x00000024 System.Void LightEstimation::.ctor()
extern void LightEstimation__ctor_m1D22C524A3F3BACE47DAD18291C9A7265A768E14 ();
// 0x00000025 UnityEngine.UI.Text LightEstimationUI::get_brightnessText()
extern void LightEstimationUI_get_brightnessText_m7F65458F05254E408F53555C86E31618897A188C ();
// 0x00000026 System.Void LightEstimationUI::set_brightnessText(UnityEngine.UI.Text)
extern void LightEstimationUI_set_brightnessText_mDFBFF1F5FB0D355FDF05D107742931CB5758AC9B ();
// 0x00000027 UnityEngine.UI.Text LightEstimationUI::get_colorTemperatureText()
extern void LightEstimationUI_get_colorTemperatureText_m0CBAA2260308B9F8493371EDC9938801CEA3CE16 ();
// 0x00000028 System.Void LightEstimationUI::set_colorTemperatureText(UnityEngine.UI.Text)
extern void LightEstimationUI_set_colorTemperatureText_m20919E84A4E61BD8121458771747CA3AC480347E ();
// 0x00000029 UnityEngine.UI.Text LightEstimationUI::get_colorCorrectionText()
extern void LightEstimationUI_get_colorCorrectionText_m326B278B8F32CD173155F0C4CD50CCB620D6333A ();
// 0x0000002A System.Void LightEstimationUI::set_colorCorrectionText(UnityEngine.UI.Text)
extern void LightEstimationUI_set_colorCorrectionText_m07025B98225700EEE39B67772F838FCE483E7966 ();
// 0x0000002B System.Void LightEstimationUI::Awake()
extern void LightEstimationUI_Awake_mEC1481B8E47A406471C4F6EE3C233C2046C20A30 ();
// 0x0000002C System.Void LightEstimationUI::Update()
extern void LightEstimationUI_Update_m1F562A15FAA7E347CB89E653508686007351E9FC ();
// 0x0000002D System.Void LightEstimationUI::SetUIValue(System.Nullable`1<T>,UnityEngine.UI.Text)
// 0x0000002E System.Void LightEstimationUI::.ctor()
extern void LightEstimationUI__ctor_m0F952651523E92202593A6E1498864137A6C9B59 ();
// 0x0000002F System.Void ARInstructions::OnInstructionsFinished()
extern void ARInstructions_OnInstructionsFinished_mE1F81E306657E7CC453E8D354698ABE793868AEB ();
// 0x00000030 System.Void ARInstructions::StartInstructions()
extern void ARInstructions_StartInstructions_m102E599F3DB1E48E644B47FE1A5AC5B4229DBBF0 ();
// 0x00000031 System.Void ARInstructions::.ctor()
extern void ARInstructions__ctor_mF3D5A25531DB279C2A471C6310DE4D5EE41B2D76 ();
// 0x00000032 System.Void GameFlowManager::.ctor()
extern void GameFlowManager__ctor_m71A7B0808984589B8930E24D5D469603EC7C6602 ();
// 0x00000033 System.Void SequenceInstance::.ctor()
extern void SequenceInstance__ctor_mBD67863D37A3EE4114B831273218665FE13D93CE ();
// 0x00000034 System.Void NewBehaviourScript::Start()
extern void NewBehaviourScript_Start_mDB573B0B04591BBF1CDC10C7C835851EBF8D17F2 ();
// 0x00000035 System.Void NewBehaviourScript::Update()
extern void NewBehaviourScript_Update_mAA0BE51F329DE556FA585E93DD1B9CF6D917A85C ();
// 0x00000036 System.Void NewBehaviourScript::.ctor()
extern void NewBehaviourScript__ctor_mC87DFFB91971C9C20A9487A744F5E68D74FB05FE ();
// 0x00000037 System.Void StepInstance::OnStepExecute()
extern void StepInstance_OnStepExecute_mC39BA3388FEC6D4652683060326C19FBAAA8FA14 ();
// 0x00000038 System.Void StepInstance::.ctor()
extern void StepInstance__ctor_mD34550755E27228A6BE250BF6BEE1F7DE8A61D9B ();
// 0x00000039 System.Void PlaceableSphere::.ctor()
extern void PlaceableSphere__ctor_m1828D4657B50F7919354D23ABCB774FFDF19C790 ();
// 0x0000003A System.Void RaycastPlaceObject::OnObjectPlaced(UnityEngine.GameObject)
extern void RaycastPlaceObject_OnObjectPlaced_mEBE9BBB877612EB27FDE465ECAF07AF9A105EBFF ();
// 0x0000003B System.Void RaycastPlaceObject::.ctor()
extern void RaycastPlaceObject__ctor_m26508017E673D2655E62D7061E664B77A5F9F90F ();
// 0x0000003C System.Void FirebaseFunctionsHandler::GetServerTime()
extern void FirebaseFunctionsHandler_GetServerTime_m5A6B449B5B0D8575F601CF71D4C22B74556C1E0B ();
// 0x0000003D System.Collections.IEnumerator FirebaseFunctionsHandler::ServerTimeRequest()
extern void FirebaseFunctionsHandler_ServerTimeRequest_mE3F1E20EAB00D63B3764D0A668FFB770C4213992 ();
// 0x0000003E System.Void FirebaseFunctionsHandler::.ctor()
extern void FirebaseFunctionsHandler__ctor_mFF0AE00D335F81016D5D9CFCB4BA0A2F8DD014E1 ();
// 0x0000003F System.Void ARObjectPlacedEvent::.ctor()
extern void ARObjectPlacedEvent__ctor_m29FB684BCD21DCAD7319DA47FB17585B4D0FB822 ();
// 0x00000040 UnityEngine.GameObject ARPlacementInteractable::get_placementPrefab()
extern void ARPlacementInteractable_get_placementPrefab_m34C8DF43AAAA5C330C49AAFCE7820462A5EC3083 ();
// 0x00000041 System.Void ARPlacementInteractable::set_placementPrefab(UnityEngine.GameObject)
extern void ARPlacementInteractable_set_placementPrefab_mA76E2E795A374C8CF9942070E69C9A737B2DC460 ();
// 0x00000042 ARObjectPlacedEvent ARPlacementInteractable::get_onObjectPlaced()
extern void ARPlacementInteractable_get_onObjectPlaced_m6C460822435E912121DBEA096CD4248293A61588 ();
// 0x00000043 System.Void ARPlacementInteractable::set_onObjectPlaced(ARObjectPlacedEvent)
extern void ARPlacementInteractable_set_onObjectPlaced_mCE8E93B983FCA98C617B4719711157206BD2B6E5 ();
// 0x00000044 System.Action`1<UnityEngine.GameObject> ARPlacementInteractable::get_PlacedObject()
extern void ARPlacementInteractable_get_PlacedObject_m9BBAA73F542063B4460FB0015DF2C3B4878C7C82 ();
// 0x00000045 System.Void ARPlacementInteractable::set_PlacedObject(System.Action`1<UnityEngine.GameObject>)
extern void ARPlacementInteractable_set_PlacedObject_mBBC52679850877E2AF501850BA01CC22D00FE21B ();
// 0x00000046 System.Void ARPlacementInteractable::Start()
extern void ARPlacementInteractable_Start_mAC256A39EEF3A4B5EF23F4286850037CE36C4775 ();
// 0x00000047 System.Boolean ARPlacementInteractable::CanStartManipulationForGesture(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARPlacementInteractable_CanStartManipulationForGesture_m85DEFF4C47446C3340D931140ACEBD2096E708B6 ();
// 0x00000048 System.Void ARPlacementInteractable::OnEndManipulation(UnityEngine.XR.Interaction.Toolkit.AR.TapGesture)
extern void ARPlacementInteractable_OnEndManipulation_m2DEE8C7294C6960E2DEB7F23078E3A56DC648882 ();
// 0x00000049 System.Void ARPlacementInteractable::.ctor()
extern void ARPlacementInteractable__ctor_m12430A2562FDC79102864C9C469D9743B84944D4 ();
// 0x0000004A System.Void ARPlacementInteractable::.cctor()
extern void ARPlacementInteractable__cctor_mB9A813B343054FFFD6C46B7F5414CEC83BBBB970 ();
// 0x0000004B System.Void StreamScreen::OnEnable()
extern void StreamScreen_OnEnable_m250DD8C2FBA040A1B9F4C7B227BF529FF92A27A5 ();
// 0x0000004C System.Void StreamScreen::OnDisable()
extern void StreamScreen_OnDisable_m3D674E4730E4CF4958182F18B4A812593FD32BB6 ();
// 0x0000004D System.Void StreamScreen::UpdateVideoInfo(System.Single,System.UInt64,System.Int32,System.Int64)
extern void StreamScreen_UpdateVideoInfo_m8DBA33C7138C8E255CFDE884B08E7AC5738A3444 ();
// 0x0000004E System.Void StreamScreen::.ctor()
extern void StreamScreen__ctor_mA5DF26C0B0C9C3276C76FB841EE5BB98D14F0D84 ();
// 0x0000004F System.Void TapToPlaceStreamApp::OnEnable()
extern void TapToPlaceStreamApp_OnEnable_m2FACE137E41F59F4988DB52B5CAFFF286EAAFB54 ();
// 0x00000050 System.Void TapToPlaceStreamApp::OnDisable()
extern void TapToPlaceStreamApp_OnDisable_m8DD87DB7655F3C340A9CCCE9659FB4118D3270A0 ();
// 0x00000051 System.Void TapToPlaceStreamApp::Awake()
extern void TapToPlaceStreamApp_Awake_mA8BF3D0EAE252A3299D8D682079FDF70C5DC52B9 ();
// 0x00000052 System.Void TapToPlaceStreamApp::Update()
extern void TapToPlaceStreamApp_Update_m96AA99C4F6635B6DA5DFABC1B01182160C5A2799 ();
// 0x00000053 System.Void TapToPlaceStreamApp::CompareServerTime(System.DateTime)
extern void TapToPlaceStreamApp_CompareServerTime_mEB6B7E160EF576EA75FFA369E8D0824EF4C08E80 ();
// 0x00000054 System.Void TapToPlaceStreamApp::UpdateTime()
extern void TapToPlaceStreamApp_UpdateTime_m2FCBD23EA09FCCA6946D1EE41F1F75BA3B86EDA6 ();
// 0x00000055 System.Void TapToPlaceStreamApp::ObjectPlaced(UnityEngine.GameObject)
extern void TapToPlaceStreamApp_ObjectPlaced_m6B56B16571F87B902ABE4F398A1DB47DB31B45E2 ();
// 0x00000056 System.Collections.IEnumerator TapToPlaceStreamApp::FadeOut()
extern void TapToPlaceStreamApp_FadeOut_mFA3C230BC1C6837C8045719BF445856318CBD7A3 ();
// 0x00000057 System.Void TapToPlaceStreamApp::EnablePointPlaneTracking()
extern void TapToPlaceStreamApp_EnablePointPlaneTracking_m2AF0D5DD1B21915EB84FE710BC27A58E874B41B4 ();
// 0x00000058 System.Void TapToPlaceStreamApp::DisablePointPlaneTracking()
extern void TapToPlaceStreamApp_DisablePointPlaneTracking_m4BC269FDFB8C55377A948E6C30E4B4C9949E70E0 ();
// 0x00000059 System.Void TapToPlaceStreamApp::ShowCounterScreen()
extern void TapToPlaceStreamApp_ShowCounterScreen_mAF73CB3E7C50CBE4E40CE2605CB5804B05100737 ();
// 0x0000005A System.Void TapToPlaceStreamApp::ShowLoadScreen()
extern void TapToPlaceStreamApp_ShowLoadScreen_mCCD7F7A8E9E1088AA296FA760FE4238366D3FD86 ();
// 0x0000005B System.Void TapToPlaceStreamApp::ShowPlaceARScreen()
extern void TapToPlaceStreamApp_ShowPlaceARScreen_mB07CA82C78508B916B85BA69C5D298F67273A70E ();
// 0x0000005C System.Void TapToPlaceStreamApp::ShowStreamScreen()
extern void TapToPlaceStreamApp_ShowStreamScreen_mD7060FAD7F136BBAE2F90FCC103FFE992BDD91FF ();
// 0x0000005D System.Void TapToPlaceStreamApp::HideAllScreens()
extern void TapToPlaceStreamApp_HideAllScreens_m90CFA2838FC984624627BC3DE4C508259ED85A2A ();
// 0x0000005E System.Void TapToPlaceStreamApp::OnStartButtonPressed()
extern void TapToPlaceStreamApp_OnStartButtonPressed_mBFE0FA80C2E31B2FFE747F7BC6193BD34C7B2295 ();
// 0x0000005F System.Void TapToPlaceStreamApp::.ctor()
extern void TapToPlaceStreamApp__ctor_mD72CB8ED180EE138043AAB8ECAD84595B8012582 ();
// 0x00000060 System.Void VideoFollowCamera::Update()
extern void VideoFollowCamera_Update_m4B01DD6038F835E61AF9D323C62932CA0C27C09B ();
// 0x00000061 System.Void VideoFollowCamera::.ctor()
extern void VideoFollowCamera__ctor_m39A8466074590400FF5680A89E47821323971D83 ();
// 0x00000062 System.Void VideoStream::OnEnable()
extern void VideoStream_OnEnable_m7A382675CE297676EF3AA42EC7D00726FF042E9E ();
// 0x00000063 System.Void VideoStream::OnDisable()
extern void VideoStream_OnDisable_m465011F052CA1E6C5B540BF5DF20CD1C242802C4 ();
// 0x00000064 System.Void VideoStream::Awake()
extern void VideoStream_Awake_mAA3A263F51F4B2EEECBBF3FC821376C1BDEFE2FC ();
// 0x00000065 System.Void VideoStream::FrameDropped(UnityEngine.Video.VideoPlayer)
extern void VideoStream_FrameDropped_m88E7AECFD53ACF7681513453C16619DF9C7A374A ();
// 0x00000066 System.Void VideoStream::Start()
extern void VideoStream_Start_mACD2E9D0AB7C3FBA5EC8F878438F3879F67E4216 ();
// 0x00000067 System.Void VideoStream::Update()
extern void VideoStream_Update_m82955553F7B5E58F2CC6E9A7C5455F82CE300041 ();
// 0x00000068 System.Void VideoStream::ObjectPlaced(UnityEngine.GameObject)
extern void VideoStream_ObjectPlaced_mD8037656A580A2CB06DEE42A70C914FA1441E339 ();
// 0x00000069 System.Void VideoStream::PlayVideoFromURL(System.String)
extern void VideoStream_PlayVideoFromURL_m7EE386EE83A68CCF0F94AC664F083C8D5E072F0B ();
// 0x0000006A System.Void VideoStream::PrepareCompleted(UnityEngine.Video.VideoPlayer)
extern void VideoStream_PrepareCompleted_mF485ECE1C7198716739131816A6B01E3CCEED902 ();
// 0x0000006B System.Void VideoStream::.ctor()
extern void VideoStream__ctor_m644AE4BBFED2B549C40524FA8C127A2403C9B591 ();
// 0x0000006C MessageHandler MessageHandler::Deserialize(System.String)
extern void MessageHandler_Deserialize_mA9693BA8D2C9FD955FEA9DD8E48D55E6584BB8DE ();
// 0x0000006D T MessageHandler::getData()
// 0x0000006E System.Void MessageHandler::.ctor(System.Int32,System.String,System.String,Newtonsoft.Json.Linq.JToken)
extern void MessageHandler__ctor_mD413687341FACD003432FE926B76CC1DE2E78EFC ();
// 0x0000006F System.Void MessageHandler::send(System.Object)
extern void MessageHandler_send_m0BF4951456C3CA50EEF785A982A6F10D92BD0C5E ();
// 0x00000070 System.Void UnityMessage::.ctor()
extern void UnityMessage__ctor_m76E68BAF631BE07953E806CA26C480BF23B2ED45 ();
// 0x00000071 System.Void UnityMessageManager::onUnityMessage(System.String)
extern void UnityMessageManager_onUnityMessage_mC3031C4585567E720F536DB4EE28B0C20AB8A7C4 ();
// 0x00000072 System.Int32 UnityMessageManager::generateId()
extern void UnityMessageManager_generateId_m39045BEBA86C4467AD5549DFA0DDCDF9A7A9CB89 ();
// 0x00000073 UnityMessageManager UnityMessageManager::get_Instance()
extern void UnityMessageManager_get_Instance_m3571F06844422C9D5B2ADE29D69AE7B9E63ACF16 ();
// 0x00000074 System.Void UnityMessageManager::set_Instance(UnityMessageManager)
extern void UnityMessageManager_set_Instance_m25A5E4940172A7950BA2EED339C161A0C74B05AE ();
// 0x00000075 System.Void UnityMessageManager::add_OnMessage(UnityMessageManager_MessageDelegate)
extern void UnityMessageManager_add_OnMessage_m7B623FDD1EB187BC9593C933D5E01766FC8DB344 ();
// 0x00000076 System.Void UnityMessageManager::remove_OnMessage(UnityMessageManager_MessageDelegate)
extern void UnityMessageManager_remove_OnMessage_mE747C20C6838E183F2C60960D2C697D7997588F4 ();
// 0x00000077 System.Void UnityMessageManager::add_OnRNMessage(UnityMessageManager_MessageHandlerDelegate)
extern void UnityMessageManager_add_OnRNMessage_mD1D6F59672DB48353711FBD7CC5A1C5573FF33FA ();
// 0x00000078 System.Void UnityMessageManager::remove_OnRNMessage(UnityMessageManager_MessageHandlerDelegate)
extern void UnityMessageManager_remove_OnRNMessage_m12B8512E35DC119F3800C8C8A05442F9C0A19B5E ();
// 0x00000079 System.Void UnityMessageManager::.cctor()
extern void UnityMessageManager__cctor_mDD0387729BD393CF289CB737BC70BF82CFAC885B ();
// 0x0000007A System.Void UnityMessageManager::Awake()
extern void UnityMessageManager_Awake_mCBF7274D38E90447257210355EEBED184FF0C035 ();
// 0x0000007B System.Void UnityMessageManager::SendMessageToRN(System.String)
extern void UnityMessageManager_SendMessageToRN_m7FA689191F69A7BD1CAF2218D61EE8BCE156B250 ();
// 0x0000007C System.Void UnityMessageManager::SendMessageToRN(UnityMessage)
extern void UnityMessageManager_SendMessageToRN_m810379DB93ACA8FB4F37914CA49BA677BDE94E3E ();
// 0x0000007D System.Void UnityMessageManager::onMessage(System.String)
extern void UnityMessageManager_onMessage_mD1704644A461EFD311809BB58F82D36898713485 ();
// 0x0000007E System.Void UnityMessageManager::onRNMessage(System.String)
extern void UnityMessageManager_onRNMessage_m47BA244DB7A9E9A2486007E2F5217A03FFFC1AF8 ();
// 0x0000007F System.Void UnityMessageManager::.ctor()
extern void UnityMessageManager__ctor_mFB3651A2237E489ED8746D5B8FC5B5AB95FE7CE7 ();
// 0x00000080 System.Void SimpleRotation::Start()
extern void SimpleRotation_Start_m92FD4E0D2D86410CADDBAF345572BD88BA16EC4E ();
// 0x00000081 System.Void SimpleRotation::Update()
extern void SimpleRotation_Update_m7C8026B0F80C7F6E6E52DCE1848658D8CE2F7036 ();
// 0x00000082 System.Void SimpleRotation::.ctor()
extern void SimpleRotation__ctor_mA92E3B8B8BDE059266EE4CBC0FFDA04A80A341CE ();
// 0x00000083 System.Void VolumetricLight::add_CustomRenderEvent(System.Action`4<VolumetricLightRenderer,VolumetricLight,UnityEngine.Rendering.CommandBuffer,UnityEngine.Matrix4x4>)
extern void VolumetricLight_add_CustomRenderEvent_m5F578D63BA4FE7C5EB24C8EAA9DA8A6CF3A27E4D ();
// 0x00000084 System.Void VolumetricLight::remove_CustomRenderEvent(System.Action`4<VolumetricLightRenderer,VolumetricLight,UnityEngine.Rendering.CommandBuffer,UnityEngine.Matrix4x4>)
extern void VolumetricLight_remove_CustomRenderEvent_m17FE11F5EF66E93327F6000F8C286879FEE4BF4B ();
// 0x00000085 UnityEngine.Light VolumetricLight::get_Light()
extern void VolumetricLight_get_Light_mE13DE46B4CE49D1DFF8EB2E6A8424C2C96D554B0 ();
// 0x00000086 UnityEngine.Material VolumetricLight::get_VolumetricMaterial()
extern void VolumetricLight_get_VolumetricMaterial_m62B71FAA82F843072613663271797F37F849EC4C ();
// 0x00000087 System.Void VolumetricLight::Start()
extern void VolumetricLight_Start_m0FB5FB04760E281D3768D82E79CEA039976C04E2 ();
// 0x00000088 System.Void VolumetricLight::OnEnable()
extern void VolumetricLight_OnEnable_mFF31A3523069C4B4F3BF99B0994EA150C2A440E5 ();
// 0x00000089 System.Void VolumetricLight::OnDisable()
extern void VolumetricLight_OnDisable_m3D4F13D8B01F89C7A7EFA70D155089501B9D824F ();
// 0x0000008A System.Void VolumetricLight::OnDestroy()
extern void VolumetricLight_OnDestroy_m33B9A828BAA1D70645EC459623537C215E8768A9 ();
// 0x0000008B System.Void VolumetricLight::VolumetricLightRenderer_PreRenderEvent(VolumetricLightRenderer,UnityEngine.Matrix4x4)
extern void VolumetricLight_VolumetricLightRenderer_PreRenderEvent_mF1B9F6D6C44948EA8BEEE6D2E1E0FC4FDF85C917 ();
// 0x0000008C System.Void VolumetricLight::SetupPointLight(VolumetricLightRenderer,UnityEngine.Matrix4x4)
extern void VolumetricLight_SetupPointLight_m9A6001320D9196313892DA54B048256E27E6EA38 ();
// 0x0000008D System.Void VolumetricLight::SetupSpotLight(VolumetricLightRenderer,UnityEngine.Matrix4x4)
extern void VolumetricLight_SetupSpotLight_m66E51E57DCD619F710E8FBAD4ADB3816488EACA3 ();
// 0x0000008E System.Void VolumetricLight::SetupDirectionalLight(VolumetricLightRenderer,UnityEngine.Matrix4x4)
extern void VolumetricLight_SetupDirectionalLight_m79F401CEEFD8C459A34CFDDB30F28F88D2B99863 ();
// 0x0000008F System.Boolean VolumetricLight::IsCameraInPointLightBounds()
extern void VolumetricLight_IsCameraInPointLightBounds_mB935C28B4C4934B3A31DC6A5E979CDC1DB49D9BF ();
// 0x00000090 System.Boolean VolumetricLight::IsCameraInSpotLightBounds()
extern void VolumetricLight_IsCameraInSpotLightBounds_m0C01AF49DE1D2E9C8CB5DC9CBDD1690FCC724C26 ();
// 0x00000091 System.Void VolumetricLight::.ctor()
extern void VolumetricLight__ctor_m8DBB74ECBDB728246D019E0EBA4B9DD740026B45 ();
// 0x00000092 System.Void VolumetricLightRenderer::add_PreRenderEvent(System.Action`2<VolumetricLightRenderer,UnityEngine.Matrix4x4>)
extern void VolumetricLightRenderer_add_PreRenderEvent_m46F9DE23B194053E3FF2C6C4E28EB023FBA163E7 ();
// 0x00000093 System.Void VolumetricLightRenderer::remove_PreRenderEvent(System.Action`2<VolumetricLightRenderer,UnityEngine.Matrix4x4>)
extern void VolumetricLightRenderer_remove_PreRenderEvent_m1387FDC15F430340A9A4271FE6E44F8ACAB45A71 ();
// 0x00000094 UnityEngine.Rendering.CommandBuffer VolumetricLightRenderer::get_GlobalCommandBuffer()
extern void VolumetricLightRenderer_get_GlobalCommandBuffer_mADC9AFC324D1F911F36492D8D5C8B0D428502D8F ();
// 0x00000095 UnityEngine.Material VolumetricLightRenderer::GetLightMaterial()
extern void VolumetricLightRenderer_GetLightMaterial_m76DB6BB6B7C61E6B7507F78ACD0365FCAA0E28ED ();
// 0x00000096 UnityEngine.Mesh VolumetricLightRenderer::GetPointLightMesh()
extern void VolumetricLightRenderer_GetPointLightMesh_mB2EBE424F5B7CA8E0557229361177E9ED2ECEE25 ();
// 0x00000097 UnityEngine.Mesh VolumetricLightRenderer::GetSpotLightMesh()
extern void VolumetricLightRenderer_GetSpotLightMesh_m8177173207F35013308B4510BCCB71123C8E622B ();
// 0x00000098 UnityEngine.RenderTexture VolumetricLightRenderer::GetVolumeLightBuffer()
extern void VolumetricLightRenderer_GetVolumeLightBuffer_m3F6D02E1EDFBF5E4E9A6F15A5FFE3E4A4210D6FF ();
// 0x00000099 UnityEngine.RenderTexture VolumetricLightRenderer::GetVolumeLightDepthBuffer()
extern void VolumetricLightRenderer_GetVolumeLightDepthBuffer_m7BBF777031ACBC96CA1F93058046925CD9F18F60 ();
// 0x0000009A UnityEngine.Texture VolumetricLightRenderer::GetDefaultSpotCookie()
extern void VolumetricLightRenderer_GetDefaultSpotCookie_mE0FB42A6BC3BF4B487596A47210327383E2450E6 ();
// 0x0000009B System.Void VolumetricLightRenderer::Awake()
extern void VolumetricLightRenderer_Awake_m0C087A330DBD21C1D98B54FC82F8C6234468174D ();
// 0x0000009C System.Void VolumetricLightRenderer::OnEnable()
extern void VolumetricLightRenderer_OnEnable_m75E74068FE961AAB8508F366E1C1ABFA9F5128EB ();
// 0x0000009D System.Void VolumetricLightRenderer::OnDisable()
extern void VolumetricLightRenderer_OnDisable_mA2E01460A0C511F0CB85780D5DFFC283E69B6EE5 ();
// 0x0000009E System.Void VolumetricLightRenderer::ChangeResolution()
extern void VolumetricLightRenderer_ChangeResolution_m0E875395EC88C49074DBE346D115E3704A3F6EBF ();
// 0x0000009F System.Void VolumetricLightRenderer::OnPreRender()
extern void VolumetricLightRenderer_OnPreRender_m64494C7F39FD8D66A1565CC7EAD6EFF172DEFE5E ();
// 0x000000A0 System.Void VolumetricLightRenderer::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void VolumetricLightRenderer_OnRenderImage_m89C9C4C4E5BDC8B473FC56049F02CF5B94D81C68 ();
// 0x000000A1 System.Void VolumetricLightRenderer::UpdateMaterialParameters()
extern void VolumetricLightRenderer_UpdateMaterialParameters_mC6D299CB253E20588054FF08B1C5D2E20181CB2C ();
// 0x000000A2 System.Void VolumetricLightRenderer::Update()
extern void VolumetricLightRenderer_Update_m1387974B3CA934B288E55392C6BB0D710A997781 ();
// 0x000000A3 System.Void VolumetricLightRenderer::LoadNoise3dTexture()
extern void VolumetricLightRenderer_LoadNoise3dTexture_mF11E9CF22E40F5108C2A616971249C1CD9A3C3C1 ();
// 0x000000A4 System.Void VolumetricLightRenderer::GenerateDitherTexture()
extern void VolumetricLightRenderer_GenerateDitherTexture_m5B5032722588872701A98ECA252654E306A57A6A ();
// 0x000000A5 UnityEngine.Mesh VolumetricLightRenderer::CreateSpotLightMesh()
extern void VolumetricLightRenderer_CreateSpotLightMesh_mBF678FA1E816ECC7DF89333EFA21CA630EB641BA ();
// 0x000000A6 System.Void VolumetricLightRenderer::.ctor()
extern void VolumetricLightRenderer__ctor_mC32662CA37A430D5060785F4D0EC6B2FD5BF21A8 ();
// 0x000000A7 System.Void DisableDebugPlaneOnDevice::Start()
extern void DisableDebugPlaneOnDevice_Start_m58E89A7A64CBD4B35949E3DEEA470CF94E84E3FD ();
// 0x000000A8 System.Void DisableDebugPlaneOnDevice::Update()
extern void DisableDebugPlaneOnDevice_Update_m30E5344FEAD531907B625E756FC9758259D4C262 ();
// 0x000000A9 System.Void DisableDebugPlaneOnDevice::.ctor()
extern void DisableDebugPlaneOnDevice__ctor_m2BB46F0FF2BFCFD7A102A3C8C5D824099FC8D4B1 ();
// 0x000000AA UnityEngine.GameObject PlaceOnPlane::get_placedPrefab()
extern void PlaceOnPlane_get_placedPrefab_m8BE503732673256269CC147604214CC9CEC5A5D7 ();
// 0x000000AB System.Void PlaceOnPlane::set_placedPrefab(UnityEngine.GameObject)
extern void PlaceOnPlane_set_placedPrefab_m601FE0C886487501C434553A8871D097BFEE0133 ();
// 0x000000AC UnityEngine.GameObject PlaceOnPlane::get_spawnedObject()
extern void PlaceOnPlane_get_spawnedObject_m23014A9362CFD88019EB00F266ADC5580C3BF8C0 ();
// 0x000000AD System.Void PlaceOnPlane::set_spawnedObject(UnityEngine.GameObject)
extern void PlaceOnPlane_set_spawnedObject_m037A1D5F8BD6B8B918BED3BF5C575E4A7EFB0B07 ();
// 0x000000AE System.Void PlaceOnPlane::Awake()
extern void PlaceOnPlane_Awake_mE85A120DA51619398754C88AE48C78A329B5D265 ();
// 0x000000AF System.Void PlaceOnPlane::Update()
extern void PlaceOnPlane_Update_m4905A7CB017E0A01BC99DACBBDB168AC3A96345C ();
// 0x000000B0 System.Void PlaceOnPlane::.ctor()
extern void PlaceOnPlane__ctor_mECF29DC898119BD47C75A1D3845F362668A10AB0 ();
// 0x000000B1 System.Void PlaceOnPlane::.cctor()
extern void PlaceOnPlane__cctor_m99BEA781E46A1FB9FAF672FAF883E92F9B1D8E4A ();
// 0x000000B2 System.Int32 SetTargetFramerate::get_targetFrameRate()
extern void SetTargetFramerate_get_targetFrameRate_m579F2515B47C6AED7C15840378E09DCAC905BA0A ();
// 0x000000B3 System.Void SetTargetFramerate::set_targetFrameRate(System.Int32)
extern void SetTargetFramerate_set_targetFrameRate_mDB1BDA3814C4D100425882BA156D4282E6FD8CF9 ();
// 0x000000B4 System.Void SetTargetFramerate::SetFrameRate()
extern void SetTargetFramerate_SetFrameRate_mE68C50A15CF1D5ADD34AA2C9F557F507D3B846BA ();
// 0x000000B5 System.Void SetTargetFramerate::Start()
extern void SetTargetFramerate_Start_m1F24F3BD2EB04D89DD18A850B3977190DF16D55C ();
// 0x000000B6 System.Void SetTargetFramerate::.ctor()
extern void SetTargetFramerate__ctor_m2194CBB6140143CDEA43A0AD1C33B562CBF8441B ();
// 0x000000B7 System.Void SwitchPlacementPrefab::SwapToChair()
extern void SwitchPlacementPrefab_SwapToChair_m244ECCC5B50418449483DA771316174603B2F113 ();
// 0x000000B8 System.Void SwitchPlacementPrefab::SwapToTable()
extern void SwitchPlacementPrefab_SwapToTable_m12EB75430BD66E3976E37046FD67D407C720B247 ();
// 0x000000B9 System.Void SwitchPlacementPrefab::SwapToKitchenChair()
extern void SwitchPlacementPrefab_SwapToKitchenChair_m23D79DAA08FC45B598A9BE6970784E2559D731DB ();
// 0x000000BA System.Void SwitchPlacementPrefab::SwapToKitchenTable1()
extern void SwitchPlacementPrefab_SwapToKitchenTable1_m68ED9A37ECF624211743853E30F2D79CAB87F216 ();
// 0x000000BB System.Void SwitchPlacementPrefab::SwapToKitchenTable2()
extern void SwitchPlacementPrefab_SwapToKitchenTable2_mCFB6732E7D62DD2BD5DB1610B61C3DE108CF5E3D ();
// 0x000000BC System.Void SwitchPlacementPrefab::SwapToTVTable()
extern void SwitchPlacementPrefab_SwapToTVTable_mFF3CCC4A5B984569CF2CED5B74C1B062AEAE7D09 ();
// 0x000000BD System.Void SwitchPlacementPrefab::.ctor()
extern void SwitchPlacementPrefab__ctor_mE2825C15E5C8BC19BCADD6283A96CC254E832587 ();
// 0x000000BE UnityEngine.Material UnityStandardAssets.ImageEffects.PostEffectsBase::CheckShaderAndCreateMaterial(UnityEngine.Shader,UnityEngine.Material)
extern void PostEffectsBase_CheckShaderAndCreateMaterial_m1515D02A58527017FACB2B6AC601B5E67B65C865 ();
// 0x000000BF UnityEngine.Material UnityStandardAssets.ImageEffects.PostEffectsBase::CreateMaterial(UnityEngine.Shader,UnityEngine.Material)
extern void PostEffectsBase_CreateMaterial_mA2EDA33D7CD6FA380975DA46597540AAB17B89AE ();
// 0x000000C0 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::OnEnable()
extern void PostEffectsBase_OnEnable_mFEA4058D703A6A068ECFA899FCCF6CEC8E742967 ();
// 0x000000C1 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport()
extern void PostEffectsBase_CheckSupport_m33F744872944BE0FB9A9FBF5FB73CF1CC62BD012 ();
// 0x000000C2 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckResources()
extern void PostEffectsBase_CheckResources_m31A44EE19F985DCD4D3242F9197BF1435F1C8094 ();
// 0x000000C3 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::Start()
extern void PostEffectsBase_Start_mA2E9CD553BD5AB2AD1963EC250854408434701F1 ();
// 0x000000C4 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport(System.Boolean)
extern void PostEffectsBase_CheckSupport_mB308BE6390C0474C92E742A561F90423C1502C04 ();
// 0x000000C5 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport(System.Boolean,System.Boolean)
extern void PostEffectsBase_CheckSupport_mB672E1075EC2C7E643A512D22CFB3000CC681636 ();
// 0x000000C6 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::Dx11Support()
extern void PostEffectsBase_Dx11Support_m51594DC020FEA76B63FC6804CAB21D88B8497C75 ();
// 0x000000C7 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::ReportAutoDisable()
extern void PostEffectsBase_ReportAutoDisable_mEFEF901F4F2DC5EDBC11340F930760EF8B10645C ();
// 0x000000C8 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckShader(UnityEngine.Shader)
extern void PostEffectsBase_CheckShader_mE87A8B176C2F6264E568AD9EFFE7A64F9057CB43 ();
// 0x000000C9 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::NotSupported()
extern void PostEffectsBase_NotSupported_mD5139A9AE6103E7BF485626371A61B4C146C035C ();
// 0x000000CA System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::DrawBorder(UnityEngine.RenderTexture,UnityEngine.Material)
extern void PostEffectsBase_DrawBorder_m3B6891159B6BFFA4621F38DCE1648176C0DC4C2B ();
// 0x000000CB System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::.ctor()
extern void PostEffectsBase__ctor_m440C9B609EF88230A2EB266FD3E6C624431E1368 ();
// 0x000000CC System.Boolean UnityStandardAssets.ImageEffects.Tonemapping::CheckResources()
extern void Tonemapping_CheckResources_mF10047DA83F89CF8C93C7A263245A501404DBB95 ();
// 0x000000CD System.Single UnityStandardAssets.ImageEffects.Tonemapping::UpdateCurve()
extern void Tonemapping_UpdateCurve_m3ACD656292CF96ECD6A1F684554D94D44EFDF1C7 ();
// 0x000000CE System.Void UnityStandardAssets.ImageEffects.Tonemapping::OnDisable()
extern void Tonemapping_OnDisable_m39886645752B0190BBB4A5643C3941E57C591677 ();
// 0x000000CF System.Boolean UnityStandardAssets.ImageEffects.Tonemapping::CreateInternalRenderTexture()
extern void Tonemapping_CreateInternalRenderTexture_m57DA5B1E686F03D4C4E99D4920DBC5AFAF1835AF ();
// 0x000000D0 System.Void UnityStandardAssets.ImageEffects.Tonemapping::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Tonemapping_OnRenderImage_mC820173AF7A5683200AC7D0CA2A68FB940BDBAA0 ();
// 0x000000D1 System.Void UnityStandardAssets.ImageEffects.Tonemapping::.ctor()
extern void Tonemapping__ctor_m37B1A6CFAB1CBD05E8FB154AAED049B7FEB40E01 ();
// 0x000000D2 UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient_Blend UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::get_BlendMode()
extern void UIGradient_get_BlendMode_m1168901DBA41CF9361B7F7EF09050A1F7DC8330A ();
// 0x000000D3 System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::set_BlendMode(UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient_Blend)
extern void UIGradient_set_BlendMode_m3F8C4653A82F6795062FAFD08380AC7A423A5494 ();
// 0x000000D4 UnityEngine.Gradient UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::get_EffectGradient()
extern void UIGradient_get_EffectGradient_m6300D753D94AE39A72369CC1A5194CD61D9BBD72 ();
// 0x000000D5 System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::set_EffectGradient(UnityEngine.Gradient)
extern void UIGradient_set_EffectGradient_m653BD6E0C53B3AFD93885E08B661C89A19A5509A ();
// 0x000000D6 UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient_Type UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::get_GradientType()
extern void UIGradient_get_GradientType_mFF299EFB2F678C4E1F765BBDB960DAA9FD546191 ();
// 0x000000D7 System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::set_GradientType(UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient_Type)
extern void UIGradient_set_GradientType_m3D88A70BFBFA4ED2BB31906FB8972325AD6180FA ();
// 0x000000D8 System.Single UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::get_Offset()
extern void UIGradient_get_Offset_m56CD9E0188D76A3E58FE39885A92793F20276B2C ();
// 0x000000D9 System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::set_Offset(System.Single)
extern void UIGradient_set_Offset_m7C26071BF10274F114B6B8A1EE73201AF300B869 ();
// 0x000000DA System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void UIGradient_ModifyMesh_m42048F4A65BEDDFC6089044BEEDB9E3397547B72 ();
// 0x000000DB UnityEngine.Color UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::BlendColor(UnityEngine.Color,UnityEngine.Color)
extern void UIGradient_BlendColor_m14F90F0EB9C55D35BD335A72CAD6159E33D41049 ();
// 0x000000DC System.Void UnityEngine.UI.Michsky.UI.ModernUIPack.UIGradient::.ctor()
extern void UIGradient__ctor_m3CB1CE1543D5DE89949E3AAA2D64184E941D4F0B ();
// 0x000000DD System.Void Michsky.UI.ModernUIPack.AnimatedIconHandler::Start()
extern void AnimatedIconHandler_Start_m83A633F84879EB3896A3E36607E53D846CC83065 ();
// 0x000000DE System.Void Michsky.UI.ModernUIPack.AnimatedIconHandler::ClickEvent()
extern void AnimatedIconHandler_ClickEvent_m3FEA8D973ACD7A71D23CA5CEC5B1F575A6E36464 ();
// 0x000000DF System.Void Michsky.UI.ModernUIPack.AnimatedIconHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void AnimatedIconHandler_OnPointerEnter_m826017ECDFDE4610EEAD10999861FFA64BB517D9 ();
// 0x000000E0 System.Void Michsky.UI.ModernUIPack.AnimatedIconHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void AnimatedIconHandler_OnPointerExit_m48C0BBF67BE2A5D39D3B4CFD995209B1F809B8A8 ();
// 0x000000E1 System.Void Michsky.UI.ModernUIPack.AnimatedIconHandler::.ctor()
extern void AnimatedIconHandler__ctor_mD306EA3C98F80C29FAC1FBD78EFEC18111E787B6 ();
// 0x000000E2 System.Void Michsky.UI.ModernUIPack.ButtonManager::Start()
extern void ButtonManager_Start_mC4D90AFFDE30D638AC31F2EAE75D4E8AD1C8D1F3 ();
// 0x000000E3 System.Void Michsky.UI.ModernUIPack.ButtonManager::UpdateUI()
extern void ButtonManager_UpdateUI_mAB64F1349A616F1FE987D878794C866F65E28859 ();
// 0x000000E4 System.Void Michsky.UI.ModernUIPack.ButtonManager::.ctor()
extern void ButtonManager__ctor_m2E9A78987D3D370B68AEF2654676032F5C39756D ();
// 0x000000E5 System.Void Michsky.UI.ModernUIPack.ButtonManagerBasic::Start()
extern void ButtonManagerBasic_Start_m3B4D414931820D9CBDD7B4C7062032B6550118B2 ();
// 0x000000E6 System.Void Michsky.UI.ModernUIPack.ButtonManagerBasic::UpdateUI()
extern void ButtonManagerBasic_UpdateUI_m0214862E81488419B458D1CDA980E31406E847C8 ();
// 0x000000E7 System.Void Michsky.UI.ModernUIPack.ButtonManagerBasic::.ctor()
extern void ButtonManagerBasic__ctor_mD4DD378461B235FFC19FFD696F1FAC0CFF5D6D18 ();
// 0x000000E8 System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicIcon::Start()
extern void ButtonManagerBasicIcon_Start_mEDEFE353C5C0D4802644674A209C4D962A01E64C ();
// 0x000000E9 System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicIcon::UpdateUI()
extern void ButtonManagerBasicIcon_UpdateUI_m31B6D7E205E8E16B3C53F88FD020D642689D71DA ();
// 0x000000EA System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicIcon::.ctor()
extern void ButtonManagerBasicIcon__ctor_m33A15CFF1ED3FC2EB97480F7C57E238FAEECFD56 ();
// 0x000000EB System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicWithIcon::Start()
extern void ButtonManagerBasicWithIcon_Start_mFF9D86D3D22271E0921F147ED5425DFAD05C0299 ();
// 0x000000EC System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicWithIcon::UpdateUI()
extern void ButtonManagerBasicWithIcon_UpdateUI_m9FBC1B87B3099897916839379B20E947973A4213 ();
// 0x000000ED System.Void Michsky.UI.ModernUIPack.ButtonManagerBasicWithIcon::.ctor()
extern void ButtonManagerBasicWithIcon__ctor_m452D087EA1D48074FA8E04EACE3BB764F158D25E ();
// 0x000000EE System.Void Michsky.UI.ModernUIPack.ButtonManagerIcon::Start()
extern void ButtonManagerIcon_Start_m8D4A54D859213C72748C0E3478BD95B15516AF50 ();
// 0x000000EF System.Void Michsky.UI.ModernUIPack.ButtonManagerIcon::UpdateUI()
extern void ButtonManagerIcon_UpdateUI_m452285692A9BB97DD9C870C6C9D7734049256681 ();
// 0x000000F0 System.Void Michsky.UI.ModernUIPack.ButtonManagerIcon::.ctor()
extern void ButtonManagerIcon__ctor_mDAEF160669934DF94E545AEE8353CF10871AC4FA ();
// 0x000000F1 System.Void Michsky.UI.ModernUIPack.ButtonManagerWithIcon::Start()
extern void ButtonManagerWithIcon_Start_m68DEE1D411D5259627CF0897113E30F129366A67 ();
// 0x000000F2 System.Void Michsky.UI.ModernUIPack.ButtonManagerWithIcon::UpdateUI()
extern void ButtonManagerWithIcon_UpdateUI_m009BA1877E2B35C12B5CFEEE2328350D3D1DE9C8 ();
// 0x000000F3 System.Void Michsky.UI.ModernUIPack.ButtonManagerWithIcon::.ctor()
extern void ButtonManagerWithIcon__ctor_m727659356C3EB16C800D13B4538F517E2DE6BB38 ();
// 0x000000F4 System.Void Michsky.UI.ModernUIPack.DemoManager::Start()
extern void DemoManager_Start_m2AA76E0B6D76F990304356A00B6C7FB7F29FDDC9 ();
// 0x000000F5 System.Void Michsky.UI.ModernUIPack.DemoManager::Update()
extern void DemoManager_Update_m86D4E49827143B9059EB02A83BAFC318EE85BFBF ();
// 0x000000F6 System.Void Michsky.UI.ModernUIPack.DemoManager::EnableScrolling()
extern void DemoManager_EnableScrolling_m8AB80D35132F7BA29BAAF1F383E2EF7D1449CFE5 ();
// 0x000000F7 System.Void Michsky.UI.ModernUIPack.DemoManager::DisableScrolling()
extern void DemoManager_DisableScrolling_m41D172F9B5A886F977F82014C60A00AED4F796D4 ();
// 0x000000F8 System.Void Michsky.UI.ModernUIPack.DemoManager::PanelAnim(System.Int32)
extern void DemoManager_PanelAnim_mA20E49EA8D56C0F0546C5EEAB16E8B65CFE676DB ();
// 0x000000F9 System.Void Michsky.UI.ModernUIPack.DemoManager::.ctor()
extern void DemoManager__ctor_m439A173D74C6021FEC756C932C8970D37528C883 ();
// 0x000000FA System.Void Michsky.UI.ModernUIPack.DemoScrollForMore::Update()
extern void DemoScrollForMore_Update_mB4AE120D37A338B490540F8CB4EC243E2C0F9F8F ();
// 0x000000FB System.Void Michsky.UI.ModernUIPack.DemoScrollForMore::.ctor()
extern void DemoScrollForMore__ctor_m0D234EC80A0D14413B6F4BFA8F925397E61E88C3 ();
// 0x000000FC System.Void Michsky.UI.ModernUIPack.DemoScrollManager::Update()
extern void DemoScrollManager_Update_m14614A8609890DFF1E6FC8554E7C116836B6CC6F ();
// 0x000000FD System.Void Michsky.UI.ModernUIPack.DemoScrollManager::GoToPanel(System.Single)
extern void DemoScrollManager_GoToPanel_mFC97815D2C104E04325E53E1AB0225703DFFAABA ();
// 0x000000FE System.Void Michsky.UI.ModernUIPack.DemoScrollManager::.ctor()
extern void DemoScrollManager__ctor_mFE9D9A55AB6D2B40E3ED2837AA4FCF9E4261F493 ();
// 0x000000FF System.Void Michsky.UI.ModernUIPack.DemoTopButton::Start()
extern void DemoTopButton_Start_m0D81501992E3B1D35DCE5ECB987B0B6E2C7B282F ();
// 0x00000100 System.Void Michsky.UI.ModernUIPack.DemoTopButton::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void DemoTopButton_OnPointerEnter_mF523EEB206750282E233CB8EB9FFF97A869BD003 ();
// 0x00000101 System.Void Michsky.UI.ModernUIPack.DemoTopButton::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void DemoTopButton_OnPointerExit_m5226C43ED047BE58AF88A653FED3F7C31863CE5D ();
// 0x00000102 System.Void Michsky.UI.ModernUIPack.DemoTopButton::.ctor()
extern void DemoTopButton__ctor_mF1F346F8CC60102DFEF568760390905D5A24DAED ();
// 0x00000103 System.Void Michsky.UI.ModernUIPack.DemoTopListShadow::Start()
extern void DemoTopListShadow_Start_m7FAAE60AEB23CF62277818DF5ABD53CD817D5652 ();
// 0x00000104 System.Void Michsky.UI.ModernUIPack.DemoTopListShadow::Update()
extern void DemoTopListShadow_Update_mBAFAED5C58391468A1D62410502D56EC612B132B ();
// 0x00000105 System.Void Michsky.UI.ModernUIPack.DemoTopListShadow::ScrollUp()
extern void DemoTopListShadow_ScrollUp_m32BFCCD649493BDC2DED47BB8B51081A0E601385 ();
// 0x00000106 System.Void Michsky.UI.ModernUIPack.DemoTopListShadow::ScrollDown()
extern void DemoTopListShadow_ScrollDown_m5DD358BABCF3191D8C9D2EAAED6AC95DE29E6008 ();
// 0x00000107 System.Void Michsky.UI.ModernUIPack.DemoTopListShadow::.ctor()
extern void DemoTopListShadow__ctor_m570C56429CDF41012DE141DE9E70E887C55699CB ();
// 0x00000108 System.Void Michsky.UI.ModernUIPack.LaunchURL::urlLinkOrWeb()
extern void LaunchURL_urlLinkOrWeb_m32EB9AA547A020ECB9A770BF5322DC49641D7CB2 ();
// 0x00000109 System.Void Michsky.UI.ModernUIPack.LaunchURL::.ctor()
extern void LaunchURL__ctor_mF49C6E2C2E00F6C6780ED9272E60F64344489E28 ();
// 0x0000010A System.Void Michsky.UI.ModernUIPack.CustomDropdown::Start()
extern void CustomDropdown_Start_m9B8C92CEBCFCEAE2FCD4663F20A4B1A8E11AB8F4 ();
// 0x0000010B System.Void Michsky.UI.ModernUIPack.CustomDropdown::SetupDropdown()
extern void CustomDropdown_SetupDropdown_m345C94CA17B4BD50BE27A95F4ABE370A826C3725 ();
// 0x0000010C System.Void Michsky.UI.ModernUIPack.CustomDropdown::ChangeDropdownInfo(System.Int32)
extern void CustomDropdown_ChangeDropdownInfo_mB46280CAF0831A45EC8725308EDC91F5A9A34520 ();
// 0x0000010D System.Void Michsky.UI.ModernUIPack.CustomDropdown::Animate()
extern void CustomDropdown_Animate_m39ACD9CCBFE2C02E2E989FCD3758887F9AF59C6C ();
// 0x0000010E System.Void Michsky.UI.ModernUIPack.CustomDropdown::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void CustomDropdown_OnPointerExit_m5A12ADCC9F4FBE84D95BA5CFDB1455F79A1B2A34 ();
// 0x0000010F System.Void Michsky.UI.ModernUIPack.CustomDropdown::UpdateValues()
extern void CustomDropdown_UpdateValues_m9E09A21FE49F7CF2DEE8C2754582F70CA0F41DD5 ();
// 0x00000110 System.Void Michsky.UI.ModernUIPack.CustomDropdown::CreateNewItem()
extern void CustomDropdown_CreateNewItem_mBF9845837ABDABD33BAEB3157667F19E506D38A7 ();
// 0x00000111 System.Void Michsky.UI.ModernUIPack.CustomDropdown::SetItemTitle(System.String)
extern void CustomDropdown_SetItemTitle_m50E46AE796D7DCF0A4CBEB108A3543A563C86F26 ();
// 0x00000112 System.Void Michsky.UI.ModernUIPack.CustomDropdown::SetItemIcon(UnityEngine.Sprite)
extern void CustomDropdown_SetItemIcon_m188771491EFB456C1377715360F9EC039D2F0301 ();
// 0x00000113 System.Void Michsky.UI.ModernUIPack.CustomDropdown::.ctor()
extern void CustomDropdown__ctor_m76849B9F95D77B27767982C6971AF629270A2D25 ();
// 0x00000114 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::Start()
extern void DropdownMultiSelect_Start_m5FD64747E865E7BA97007EDF55F4F68EB1467F69 ();
// 0x00000115 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::SetupDropdown()
extern void DropdownMultiSelect_SetupDropdown_mC1ECB49315AC3D76BCAFB94F4DABACC894D09149 ();
// 0x00000116 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::UpdateToggle(System.Boolean)
extern void DropdownMultiSelect_UpdateToggle_m73A0416FFDE662C4794C3A8592D4FE4EEA7C4E3D ();
// 0x00000117 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::SaveToggle(System.Boolean)
extern void DropdownMultiSelect_SaveToggle_m323B65B6A34C8FA5F39E0E5510325E076D212ADE ();
// 0x00000118 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::Animate()
extern void DropdownMultiSelect_Animate_mEAE2312A27E7D9B9209D156D50B77EDCDB38B328 ();
// 0x00000119 System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void DropdownMultiSelect_OnPointerExit_mA8E92756B21CFE07C83056BFCDCCD324162C314C ();
// 0x0000011A System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::UpdateValues()
extern void DropdownMultiSelect_UpdateValues_m0F2F71F8AF3D08828C3265979F5449773B16FEB5 ();
// 0x0000011B System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::CreateNewItem()
extern void DropdownMultiSelect_CreateNewItem_m5ABA3AEEF4D5C6EC8DC192E8865C9643AEE84739 ();
// 0x0000011C System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::SetItemTitle(System.String)
extern void DropdownMultiSelect_SetItemTitle_m5A8578FFF97BB9085C0D867318B2C229314EF8B3 ();
// 0x0000011D System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect::.ctor()
extern void DropdownMultiSelect__ctor_m13126F9DD1E31E70B74036BCA4CF092B37F0F885 ();
// 0x0000011E System.Void Michsky.UI.ModernUIPack.LayoutGroupPositionFix::Start()
extern void LayoutGroupPositionFix_Start_mCD4A4C91BD865A793909A9BD68E80D223BE1D0E9 ();
// 0x0000011F System.Collections.IEnumerator Michsky.UI.ModernUIPack.LayoutGroupPositionFix::ExecuteAfterTime(System.Single)
extern void LayoutGroupPositionFix_ExecuteAfterTime_mB66EBE5D8FDEB47A9F1E38BBADAC354E9EB24469 ();
// 0x00000120 System.Void Michsky.UI.ModernUIPack.LayoutGroupPositionFix::.ctor()
extern void LayoutGroupPositionFix__ctor_m075C80DF21585D1742507461F0ED2AC0A0FE0A7F ();
// 0x00000121 System.Void Michsky.UI.ModernUIPack.UIElementInFront::Start()
extern void UIElementInFront_Start_m28DD4D73C03D39F0FE86E509D979511616CDF12A ();
// 0x00000122 System.Void Michsky.UI.ModernUIPack.UIElementInFront::.ctor()
extern void UIElementInFront__ctor_m583C22F19C9C13972AC38BCA426A0936518BD68B ();
// 0x00000123 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::Start()
extern void HorizontalSelector_Start_m420FDDA862FD0DA0721BF66DD7C42CE445CF7532 ();
// 0x00000124 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::SetupSelector()
extern void HorizontalSelector_SetupSelector_m969D2AF256C44F2BC85DED7849358898D5D0A837 ();
// 0x00000125 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::PreviousClick()
extern void HorizontalSelector_PreviousClick_m445E254CFE108885D49608D6FFAD2A3EFCD90E76 ();
// 0x00000126 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::ForwardClick()
extern void HorizontalSelector_ForwardClick_mEBC38D0148E534CBABFCA5D4DBDB5492A873A5F6 ();
// 0x00000127 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::CreateNewItem(System.String)
extern void HorizontalSelector_CreateNewItem_m25DAB314235C4082FE0D4442C8D944D209062B56 ();
// 0x00000128 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::UpdateUI()
extern void HorizontalSelector_UpdateUI_m41747A31D5D80AC2CF36C3CB2058348B0C6DDD52 ();
// 0x00000129 System.Void Michsky.UI.ModernUIPack.HorizontalSelector::.ctor()
extern void HorizontalSelector__ctor_mD5CD83C2578C980A40DB8C556345B27FC204AD58 ();
// 0x0000012A System.Void Michsky.UI.ModernUIPack.CustomInputField::Start()
extern void CustomInputField_Start_mE6F9065CE11326E68BB86FE34C61651649FD2C96 ();
// 0x0000012B System.Void Michsky.UI.ModernUIPack.CustomInputField::Update()
extern void CustomInputField_Update_mB30BCE2093B9B495D18B263711AE3BCF0AFE1FF7 ();
// 0x0000012C System.Void Michsky.UI.ModernUIPack.CustomInputField::Animate()
extern void CustomInputField_Animate_m73372C2FFD304B4483DDF5751085BAE4C2C45520 ();
// 0x0000012D System.Void Michsky.UI.ModernUIPack.CustomInputField::FieldTrigger()
extern void CustomInputField_FieldTrigger_mA24AC2B35F254EF8ABD4A9564F1FF25CF2CB78A7 ();
// 0x0000012E System.Void Michsky.UI.ModernUIPack.CustomInputField::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void CustomInputField_OnPointerClick_m1C1FEC207B42529258CE3E95DC5D10BF7CC02388 ();
// 0x0000012F System.Void Michsky.UI.ModernUIPack.CustomInputField::.ctor()
extern void CustomInputField__ctor_mFC7784CD17A6409C274B1AE513FC39A911A144E6 ();
// 0x00000130 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::Start()
extern void ModalWindowManager_Start_m91BB8D746149045752443AF1283ED3DF5607AF77 ();
// 0x00000131 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::UpdateUI()
extern void ModalWindowManager_UpdateUI_m95FD97AEDF15968D99B35DED9D13817AF5BDB80C ();
// 0x00000132 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::OpenWindow()
extern void ModalWindowManager_OpenWindow_m4C9606BFDBE313C217F0545B0274B10CFF849119 ();
// 0x00000133 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::CloseWindow()
extern void ModalWindowManager_CloseWindow_m609F0A8E57B4EEC3624BA41FE54FD053C93B670A ();
// 0x00000134 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::AnimateWindow()
extern void ModalWindowManager_AnimateWindow_m3403B78B60DEAB42AD37D5A5D2CAFA7C981FBAC4 ();
// 0x00000135 System.Void Michsky.UI.ModernUIPack.ModalWindowManager::.ctor()
extern void ModalWindowManager__ctor_m8B817291D67F2B4A592D4EC0513D699BF21286D7 ();
// 0x00000136 System.Void Michsky.UI.ModernUIPack.ModalWindowTabs::Start()
extern void ModalWindowTabs_Start_m373A46F736A1F54ED2A9E8611EDEA798D77AD322 ();
// 0x00000137 System.Void Michsky.UI.ModernUIPack.ModalWindowTabs::PanelAnim(System.Int32)
extern void ModalWindowTabs_PanelAnim_m681BCB77B2428F0325136BF9DB08D7A3FBD172C0 ();
// 0x00000138 System.Void Michsky.UI.ModernUIPack.ModalWindowTabs::.ctor()
extern void ModalWindowTabs__ctor_m42AC1B2285726B608DD2318AB4F0B676C70F9F52 ();
// 0x00000139 System.Void Michsky.UI.ModernUIPack.NotificationManager::Start()
extern void NotificationManager_Start_m866E79950CD6A33099E3B8C186C3D77D66D82758 ();
// 0x0000013A System.Collections.IEnumerator Michsky.UI.ModernUIPack.NotificationManager::StartTimer()
extern void NotificationManager_StartTimer_m0E3128E26D9863C0FD7B066BACDBF13C00554BA0 ();
// 0x0000013B System.Void Michsky.UI.ModernUIPack.NotificationManager::OpenNotification()
extern void NotificationManager_OpenNotification_m7653433D2486400A870C827583336F4710F8E50E ();
// 0x0000013C System.Void Michsky.UI.ModernUIPack.NotificationManager::CloseNotification()
extern void NotificationManager_CloseNotification_m015B9BED28D9232BEBC11F0F311500E26A3C0715 ();
// 0x0000013D System.Void Michsky.UI.ModernUIPack.NotificationManager::UpdateUI()
extern void NotificationManager_UpdateUI_m3C65CB7048E854BE3496B3221B9426C30E1DCA89 ();
// 0x0000013E System.Void Michsky.UI.ModernUIPack.NotificationManager::.ctor()
extern void NotificationManager__ctor_m549C96C90315034A3D8B8227611816733DA53A72 ();
// 0x0000013F System.Void Michsky.UI.ModernUIPack.PBFilled::Start()
extern void PBFilled_Start_m592E9A99C5B81E00E3774629A3AF3056453A9D54 ();
// 0x00000140 System.Void Michsky.UI.ModernUIPack.PBFilled::Update()
extern void PBFilled_Update_m3283151606AC4B30E165115B25C6BB6781F166BA ();
// 0x00000141 System.Void Michsky.UI.ModernUIPack.PBFilled::.ctor()
extern void PBFilled__ctor_m9404A96DC805A4536A5D5BF274158D57C372ECA0 ();
// 0x00000142 System.Void Michsky.UI.ModernUIPack.ProgressBar::Start()
extern void ProgressBar_Start_m130112E65882CC2B4553945EC01C7FB74197D9D8 ();
// 0x00000143 System.Void Michsky.UI.ModernUIPack.ProgressBar::Update()
extern void ProgressBar_Update_mF9D95F7B60D3A8D82C6E2B92E204CB2408707E39 ();
// 0x00000144 System.Void Michsky.UI.ModernUIPack.ProgressBar::.ctor()
extern void ProgressBar__ctor_mEE391D1A30B63D9D4FEA3EFAA1490979A63776AB ();
// 0x00000145 System.Void Michsky.UI.ModernUIPack.DropdownSamples::GenerateItem()
extern void DropdownSamples_GenerateItem_mCECF868A2026E4A9BFD0CB6EF98F885FE8225CB3 ();
// 0x00000146 System.Void Michsky.UI.ModernUIPack.DropdownSamples::GenerateListItems()
extern void DropdownSamples_GenerateListItems_mC4DBD6A333A7CCF3C8980532756047ED8AE967BD ();
// 0x00000147 System.Void Michsky.UI.ModernUIPack.DropdownSamples::.ctor()
extern void DropdownSamples__ctor_mCEEF1B1FF601440F1114015A22E2368E3E65DE97 ();
// 0x00000148 System.Void Michsky.UI.ModernUIPack.HorizontalSelectorSamples::GenerateItem()
extern void HorizontalSelectorSamples_GenerateItem_m85A74F2EFFF8F6D850F67F29B8707476B7036050 ();
// 0x00000149 System.Void Michsky.UI.ModernUIPack.HorizontalSelectorSamples::GenerateListItems()
extern void HorizontalSelectorSamples_GenerateListItems_mA9E51EA70C5761E813DBB3072B19BC9FDF37F011 ();
// 0x0000014A System.Void Michsky.UI.ModernUIPack.HorizontalSelectorSamples::.ctor()
extern void HorizontalSelectorSamples__ctor_m7F08CF41AB31D5B936693433FC47FDD7FF016A38 ();
// 0x0000014B System.Single Michsky.UI.ModernUIPack.RadialSlider::get_SliderAngle()
extern void RadialSlider_get_SliderAngle_m2F68FE0B6FE806DEE30DDD568B81559B1A520680 ();
// 0x0000014C System.Void Michsky.UI.ModernUIPack.RadialSlider::set_SliderAngle(System.Single)
extern void RadialSlider_set_SliderAngle_m5DEC6FBBF6E17E2838629AFC4A6E1F3D21D0F47A ();
// 0x0000014D System.Single Michsky.UI.ModernUIPack.RadialSlider::get_SliderValue()
extern void RadialSlider_get_SliderValue_mF5E2EE95ECF52F6ACF8026B8F41849481BDA3188 ();
// 0x0000014E System.Void Michsky.UI.ModernUIPack.RadialSlider::set_SliderValue(System.Single)
extern void RadialSlider_set_SliderValue_mB0F70E928770EFF49B9FFBE3AE33E4A5ECCDFAFA ();
// 0x0000014F System.Single Michsky.UI.ModernUIPack.RadialSlider::get_SliderValueRaw()
extern void RadialSlider_get_SliderValueRaw_mCB5809B3441D775C705FD7957D0201B839931455 ();
// 0x00000150 System.Void Michsky.UI.ModernUIPack.RadialSlider::set_SliderValueRaw(System.Single)
extern void RadialSlider_set_SliderValueRaw_mE49E76059E4C0423774945DAB3E70D56D344630E ();
// 0x00000151 System.Void Michsky.UI.ModernUIPack.RadialSlider::Awake()
extern void RadialSlider_Awake_mB1F97E796CF9B60C7BDA342A9C447C016D1EBD7F ();
// 0x00000152 System.Void Michsky.UI.ModernUIPack.RadialSlider::Start()
extern void RadialSlider_Start_mC632D09CA4BBE3A83D98114BF81E6AF0FD25996C ();
// 0x00000153 System.Void Michsky.UI.ModernUIPack.RadialSlider::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void RadialSlider_OnPointerDown_m65EB96C505611DDB05690492EE2DC6C39D2F0442 ();
// 0x00000154 System.Void Michsky.UI.ModernUIPack.RadialSlider::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void RadialSlider_OnPointerUp_m652E4D2FC8304679AB16C4ADF5A3CD9F0CC2399F ();
// 0x00000155 System.Void Michsky.UI.ModernUIPack.RadialSlider::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void RadialSlider_OnDrag_m64B5A32508FB49437ED6FD483A348A4C56818519 ();
// 0x00000156 System.Void Michsky.UI.ModernUIPack.RadialSlider::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void RadialSlider_OnPointerEnter_m61E5A7678601CB3E877618F03F29E5E79766FBC5 ();
// 0x00000157 System.Void Michsky.UI.ModernUIPack.RadialSlider::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void RadialSlider_OnPointerExit_mE4B4DC0EB62E54B78E638B8963DF37E7BB5F4728 ();
// 0x00000158 System.Void Michsky.UI.ModernUIPack.RadialSlider::LoadState()
extern void RadialSlider_LoadState_mCBE4C9B210442E2636052A8A21D139AB7E8D2A6E ();
// 0x00000159 System.Void Michsky.UI.ModernUIPack.RadialSlider::SaveState()
extern void RadialSlider_SaveState_m76609516117861BFFD30747925345966809BDFFD ();
// 0x0000015A System.Void Michsky.UI.ModernUIPack.RadialSlider::UpdateUI()
extern void RadialSlider_UpdateUI_m389B8D8E3D0C04876C280031CE0C501896D89401 ();
// 0x0000015B System.Boolean Michsky.UI.ModernUIPack.RadialSlider::HasValueChanged()
extern void RadialSlider_HasValueChanged_m6D160A2C32190FF558D2EB1E7FD227B7F913999B ();
// 0x0000015C System.Void Michsky.UI.ModernUIPack.RadialSlider::HandleSliderMouseInput(UnityEngine.EventSystems.PointerEventData,System.Boolean)
extern void RadialSlider_HandleSliderMouseInput_m0AE7C7027A8A5B2F8707ADD8FACE71A56BEDBF03 ();
// 0x0000015D System.Void Michsky.UI.ModernUIPack.RadialSlider::.ctor()
extern void RadialSlider__ctor_mB3D34D67AC1A2F5B77CBCE757894DE5766D33EB3 ();
// 0x0000015E System.Void Michsky.UI.ModernUIPack.RangeMaxSlider::Start()
extern void RangeMaxSlider_Start_m357BC53DCAA3D9762657D1EB363AB35A119880DC ();
// 0x0000015F System.Void Michsky.UI.ModernUIPack.RangeMaxSlider::Set(System.Single,System.Boolean)
extern void RangeMaxSlider_Set_mC43F85DF34EF3D19FD61C35ACA2473078545CF23 ();
// 0x00000160 System.Void Michsky.UI.ModernUIPack.RangeMaxSlider::Refresh(System.Single)
extern void RangeMaxSlider_Refresh_mFC4F1CA522DE8B7AA74588A862E09E19932655B5 ();
// 0x00000161 System.Void Michsky.UI.ModernUIPack.RangeMaxSlider::.ctor()
extern void RangeMaxSlider__ctor_m706DEB2EF5B26827899085C1FE4205B19B92512A ();
// 0x00000162 System.Void Michsky.UI.ModernUIPack.RangeMinSlider::Set(System.Single,System.Boolean)
extern void RangeMinSlider_Set_mED20494CFDB176D6C3538E3C49B01B2168BD06E1 ();
// 0x00000163 System.Void Michsky.UI.ModernUIPack.RangeMinSlider::Refresh(System.Single)
extern void RangeMinSlider_Refresh_mC0E7ABC2DB11EA614DA7D15F34E695163311E554 ();
// 0x00000164 System.Void Michsky.UI.ModernUIPack.RangeMinSlider::.ctor()
extern void RangeMinSlider__ctor_m666CFC794D0D280458E380B8D1EF3165CFEBCF74 ();
// 0x00000165 System.Single Michsky.UI.ModernUIPack.RangeSlider::get_CurrentLowerValue()
extern void RangeSlider_get_CurrentLowerValue_m13B0BF63AE92697E0D52D0C96E644E191E2EF4D7 ();
// 0x00000166 System.Single Michsky.UI.ModernUIPack.RangeSlider::get_CurrentUpperValue()
extern void RangeSlider_get_CurrentUpperValue_m6C96F75153AE3385A1A6B738A24CA220F4F518C9 ();
// 0x00000167 System.Void Michsky.UI.ModernUIPack.RangeSlider::Awake()
extern void RangeSlider_Awake_mB858EF2216638FFE428BBCFC0D15B05E58F619B0 ();
// 0x00000168 System.Void Michsky.UI.ModernUIPack.RangeSlider::.ctor()
extern void RangeSlider__ctor_mAAA1444242DFC9E7D1CC485075DE10A5DAAED47D ();
// 0x00000169 System.Void Michsky.UI.ModernUIPack.SliderManager::Start()
extern void SliderManager_Start_m3BC26542ACDC3A5208A63BB1F09FF3AB4746DD3F ();
// 0x0000016A System.Void Michsky.UI.ModernUIPack.SliderManager::Update()
extern void SliderManager_Update_mAD5F4697168CBE7925B754435C3371BC3382F493 ();
// 0x0000016B System.Void Michsky.UI.ModernUIPack.SliderManager::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void SliderManager_OnPointerEnter_m2F3A80A1E30CF4CD56F526549C5848BF440AD775 ();
// 0x0000016C System.Void Michsky.UI.ModernUIPack.SliderManager::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void SliderManager_OnPointerExit_m6E7DD08F9D4D472DD9509D17822241DF6DA87DF9 ();
// 0x0000016D System.Void Michsky.UI.ModernUIPack.SliderManager::.ctor()
extern void SliderManager__ctor_m43D3FF258686EAE388C393C696165A65FF760962 ();
// 0x0000016E System.Void Michsky.UI.ModernUIPack.SliderManager::<Start>b__13_0(System.Single)
extern void SliderManager_U3CStartU3Eb__13_0_m684A20E715F2631D45EC532CB4F1FAB1189F89A8 ();
// 0x0000016F System.Void Michsky.UI.ModernUIPack.SwitchManager::Start()
extern void SwitchManager_Start_mE4BB73F45A887BF0458E66F226B8D9001F711D78 ();
// 0x00000170 System.Void Michsky.UI.ModernUIPack.SwitchManager::OnEnable()
extern void SwitchManager_OnEnable_m1A68870C73DE4C2821FD445AE4504B9974B95FE8 ();
// 0x00000171 System.Void Michsky.UI.ModernUIPack.SwitchManager::AnimateSwitch()
extern void SwitchManager_AnimateSwitch_m4AE2A0F1CF070E8C797F38F19B995FDA213FD0F0 ();
// 0x00000172 System.Void Michsky.UI.ModernUIPack.SwitchManager::.ctor()
extern void SwitchManager__ctor_m251356A16CE706E7747FD971E80B37FA393C3388 ();
// 0x00000173 System.Void Michsky.UI.ModernUIPack.ToggleAnim::Start()
extern void ToggleAnim_Start_mC125F2E043738F2FFE36E167CB7F760EDF890912 ();
// 0x00000174 System.Void Michsky.UI.ModernUIPack.ToggleAnim::TaskOnClick(System.Boolean)
extern void ToggleAnim_TaskOnClick_m1B19B8989377304BC0909A1FB9DA30EFC23A4C1E ();
// 0x00000175 System.Void Michsky.UI.ModernUIPack.ToggleAnim::.ctor()
extern void ToggleAnim__ctor_mCA4543FA577F4D634241E32ECAD681209EA50825 ();
// 0x00000176 System.Void Michsky.UI.ModernUIPack.TooltipContent::Start()
extern void TooltipContent_Start_m84BF7C415D28B68B7580FEC496CE78E70C511438 ();
// 0x00000177 System.Void Michsky.UI.ModernUIPack.TooltipContent::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TooltipContent_OnPointerEnter_m05E49892F8E3272EDA9413AE6A6FA24E97033A3D ();
// 0x00000178 System.Void Michsky.UI.ModernUIPack.TooltipContent::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TooltipContent_OnPointerExit_m050BA890120C62A09E7DB90B48E6D689801F3FB4 ();
// 0x00000179 System.Void Michsky.UI.ModernUIPack.TooltipContent::.ctor()
extern void TooltipContent__ctor_m51A12AF5B7A61DA992568EAE04D9D0C651B88F83 ();
// 0x0000017A System.Void Michsky.UI.ModernUIPack.TooltipManager::Start()
extern void TooltipManager_Start_mD3F6A959EF19264F6B5EC37370AB872E8235D2BF ();
// 0x0000017B System.Void Michsky.UI.ModernUIPack.TooltipManager::Update()
extern void TooltipManager_Update_mE12F24E23B78F7763BCE16D77FB7EEF9C2AE5C85 ();
// 0x0000017C System.Void Michsky.UI.ModernUIPack.TooltipManager::CheckForBounds()
extern void TooltipManager_CheckForBounds_m9756D03FCE1665D41F5FE9FFD72CE0C488119076 ();
// 0x0000017D System.Void Michsky.UI.ModernUIPack.TooltipManager::.ctor()
extern void TooltipManager__ctor_mEEE42A4A2C7A6E82BF707EDA33BFDE5AFB0672FD ();
// 0x0000017E System.Void Michsky.UI.ModernUIPack.UIManager::.ctor()
extern void UIManager__ctor_mEE16638C3129624572B2E0EAF2FA6CBB54FE6553 ();
// 0x0000017F System.Void Michsky.UI.ModernUIPack.UIManagerAnimatedIcon::OnEnable()
extern void UIManagerAnimatedIcon_OnEnable_m08AD9B127A015FF4DFB753F369B5E797963EF068 ();
// 0x00000180 System.Void Michsky.UI.ModernUIPack.UIManagerAnimatedIcon::Awake()
extern void UIManagerAnimatedIcon_Awake_m26A38363A9FFB99F25FE936C846663F297F4EDBB ();
// 0x00000181 System.Void Michsky.UI.ModernUIPack.UIManagerAnimatedIcon::LateUpdate()
extern void UIManagerAnimatedIcon_LateUpdate_m9DB317D0383324A7572F11101165A6C8D564D3F6 ();
// 0x00000182 System.Void Michsky.UI.ModernUIPack.UIManagerAnimatedIcon::UpdateAnimatedIcon()
extern void UIManagerAnimatedIcon_UpdateAnimatedIcon_m7AB60B9371AEF2EBF50A2F1C446B37F1CBCB79E9 ();
// 0x00000183 System.Void Michsky.UI.ModernUIPack.UIManagerAnimatedIcon::.ctor()
extern void UIManagerAnimatedIcon__ctor_m9FD2C6D71277E573903C65313A22C6471341C510 ();
// 0x00000184 System.Void Michsky.UI.ModernUIPack.UIManagerButton::OnEnable()
extern void UIManagerButton_OnEnable_m6D22F8C15BB035DBDE96C522EF424CE6CBA2D2E3 ();
// 0x00000185 System.Void Michsky.UI.ModernUIPack.UIManagerButton::Awake()
extern void UIManagerButton_Awake_m8AB5038399646DF59763F2BE97BBA1536CB02FC4 ();
// 0x00000186 System.Void Michsky.UI.ModernUIPack.UIManagerButton::LateUpdate()
extern void UIManagerButton_LateUpdate_m3ECCFC4FA77CFF27615F0C4E5DF710F77ECAA234 ();
// 0x00000187 System.Void Michsky.UI.ModernUIPack.UIManagerButton::UpdateButton()
extern void UIManagerButton_UpdateButton_m748F7B7C43DF77160A09E9EC87A49BD4767E14E0 ();
// 0x00000188 System.Void Michsky.UI.ModernUIPack.UIManagerButton::.ctor()
extern void UIManagerButton__ctor_m7BAF8F359A03B8EC4C7951CD2563208A6B2EFDC0 ();
// 0x00000189 System.Void Michsky.UI.ModernUIPack.UIManagerDropdown::OnEnable()
extern void UIManagerDropdown_OnEnable_m1D71EA90AADC812ACA0986AEA04E920C4C2697FD ();
// 0x0000018A System.Void Michsky.UI.ModernUIPack.UIManagerDropdown::Awake()
extern void UIManagerDropdown_Awake_m399BF46E83533EC32F219B528937B15A963510AF ();
// 0x0000018B System.Void Michsky.UI.ModernUIPack.UIManagerDropdown::LateUpdate()
extern void UIManagerDropdown_LateUpdate_m5D97FA0A3E3165B24DF0E5F51A27F2F159BD85CE ();
// 0x0000018C System.Void Michsky.UI.ModernUIPack.UIManagerDropdown::UpdateDropdown()
extern void UIManagerDropdown_UpdateDropdown_m3075775EFC1438B7BC1B687EAED376A988142DFD ();
// 0x0000018D System.Void Michsky.UI.ModernUIPack.UIManagerDropdown::.ctor()
extern void UIManagerDropdown__ctor_m500E146E169FF6A67AEA4AAC1B41EF1427325649 ();
// 0x0000018E System.Void Michsky.UI.ModernUIPack.UIManagerHSelector::OnEnable()
extern void UIManagerHSelector_OnEnable_m1C2D92798600E655E234AF62C46ABBA5D989DFFA ();
// 0x0000018F System.Void Michsky.UI.ModernUIPack.UIManagerHSelector::Awake()
extern void UIManagerHSelector_Awake_m03A6BF8A35915216DB792FB9C901358678A0781C ();
// 0x00000190 System.Void Michsky.UI.ModernUIPack.UIManagerHSelector::LateUpdate()
extern void UIManagerHSelector_LateUpdate_mB33CF2640A40E2E3603A9FD361497AA169DBF237 ();
// 0x00000191 System.Void Michsky.UI.ModernUIPack.UIManagerHSelector::UpdateSelector()
extern void UIManagerHSelector_UpdateSelector_m1564B1D4E43E67F4388C001E65A021A38A63E9C4 ();
// 0x00000192 System.Void Michsky.UI.ModernUIPack.UIManagerHSelector::.ctor()
extern void UIManagerHSelector__ctor_m63236A6406C84868E412EDC1DA7CB7F346C75C7E ();
// 0x00000193 System.Void Michsky.UI.ModernUIPack.UIManagerInputField::OnEnable()
extern void UIManagerInputField_OnEnable_mADE97BA393CFD0C64ED0E27AF75C03BED37A3A81 ();
// 0x00000194 System.Void Michsky.UI.ModernUIPack.UIManagerInputField::Awake()
extern void UIManagerInputField_Awake_m34B352211E6A380E5016E701DB92C40E8246F641 ();
// 0x00000195 System.Void Michsky.UI.ModernUIPack.UIManagerInputField::LateUpdate()
extern void UIManagerInputField_LateUpdate_mD78626A0398CAEBE832AA272926624C133BE8311 ();
// 0x00000196 System.Void Michsky.UI.ModernUIPack.UIManagerInputField::UpdateDropdown()
extern void UIManagerInputField_UpdateDropdown_m7263BE114AA0CF246D0D7110C7B220D9C230CEC5 ();
// 0x00000197 System.Void Michsky.UI.ModernUIPack.UIManagerInputField::.ctor()
extern void UIManagerInputField__ctor_m0865F6C6CA881FC4EA473BAB5BC85129A3F0BBF8 ();
// 0x00000198 System.Void Michsky.UI.ModernUIPack.UIManagerModalWindow::OnEnable()
extern void UIManagerModalWindow_OnEnable_mA42A2373B6116B36AC8527FB13E7283DE014250F ();
// 0x00000199 System.Void Michsky.UI.ModernUIPack.UIManagerModalWindow::Awake()
extern void UIManagerModalWindow_Awake_mAEAF4B2A53D9717A98C2D74D1D1C57A066BF6521 ();
// 0x0000019A System.Void Michsky.UI.ModernUIPack.UIManagerModalWindow::LateUpdate()
extern void UIManagerModalWindow_LateUpdate_mFFF55907252B363BD4BBEE19B17EC369B989B578 ();
// 0x0000019B System.Void Michsky.UI.ModernUIPack.UIManagerModalWindow::UpdateDropdown()
extern void UIManagerModalWindow_UpdateDropdown_m4AE048C7B1CE3D73B042B49813106F37599BAD7E ();
// 0x0000019C System.Void Michsky.UI.ModernUIPack.UIManagerModalWindow::.ctor()
extern void UIManagerModalWindow__ctor_mA10CCAE7B399FD7582C356CE9112C775F69E7F08 ();
// 0x0000019D System.Void Michsky.UI.ModernUIPack.UIManagerNotification::OnEnable()
extern void UIManagerNotification_OnEnable_mE7F57DF3849004EA470BD5FA862B7348728DB242 ();
// 0x0000019E System.Void Michsky.UI.ModernUIPack.UIManagerNotification::Awake()
extern void UIManagerNotification_Awake_m9E8080359C1C964A54CFCB89740464848A31B5F2 ();
// 0x0000019F System.Void Michsky.UI.ModernUIPack.UIManagerNotification::LateUpdate()
extern void UIManagerNotification_LateUpdate_mA6AE864AAB448ED397028851E6ACD5AF22C94EAD ();
// 0x000001A0 System.Void Michsky.UI.ModernUIPack.UIManagerNotification::UpdateDropdown()
extern void UIManagerNotification_UpdateDropdown_m0CDFD09F5C5A86C06141C29007DB1D1B61225A47 ();
// 0x000001A1 System.Void Michsky.UI.ModernUIPack.UIManagerNotification::.ctor()
extern void UIManagerNotification__ctor_m6FE5D45DF942F2A04065B0179AF8787F4FE30259 ();
// 0x000001A2 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBar::OnEnable()
extern void UIManagerProgressBar_OnEnable_mF1EB166E3E1E04CCB9AA0459EFC8C6860FECD852 ();
// 0x000001A3 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBar::Awake()
extern void UIManagerProgressBar_Awake_m55A57026E070E9B2663A84CCF35A6C283CF13277 ();
// 0x000001A4 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBar::LateUpdate()
extern void UIManagerProgressBar_LateUpdate_m65559D0DE21CBE40AF4E237D3DD0790B23B3A97A ();
// 0x000001A5 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBar::UpdateDropdown()
extern void UIManagerProgressBar_UpdateDropdown_m8A5B495714218F0400B177074B18CBC9F2117134 ();
// 0x000001A6 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBar::.ctor()
extern void UIManagerProgressBar__ctor_mD4FC98406E640B02ABF1589EB17633C82B593DDD ();
// 0x000001A7 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBarLoop::OnEnable()
extern void UIManagerProgressBarLoop_OnEnable_m7F0D34FF8E6264DEFB2F55486B4348D4FF98248C ();
// 0x000001A8 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBarLoop::Awake()
extern void UIManagerProgressBarLoop_Awake_mDA23DFF33D2B9F8D906FFF5396A098457F3077EE ();
// 0x000001A9 System.Void Michsky.UI.ModernUIPack.UIManagerProgressBarLoop::LateUpdate()
extern void UIManagerProgressBarLoop_LateUpdate_m9F91871EE3D2D62CDB894431DA4ED43709343F5E ();
// 0x000001AA System.Void Michsky.UI.ModernUIPack.UIManagerProgressBarLoop::UpdateDropdown()
extern void UIManagerProgressBarLoop_UpdateDropdown_m74F043FC3DBA662E957E74AA0F8AB965F0F4BE1E ();
// 0x000001AB System.Void Michsky.UI.ModernUIPack.UIManagerProgressBarLoop::.ctor()
extern void UIManagerProgressBarLoop__ctor_mF04DC25B44CB38BB6354729190CA3B1A6BF8B20C ();
// 0x000001AC System.Void Michsky.UI.ModernUIPack.UIManagerScrollbar::OnEnable()
extern void UIManagerScrollbar_OnEnable_m50C372ABC6487D823F380C155F5A22F321E2ED68 ();
// 0x000001AD System.Void Michsky.UI.ModernUIPack.UIManagerScrollbar::Awake()
extern void UIManagerScrollbar_Awake_mAC060DDA44B11151F1E1E9470E11AC67393683B2 ();
// 0x000001AE System.Void Michsky.UI.ModernUIPack.UIManagerScrollbar::LateUpdate()
extern void UIManagerScrollbar_LateUpdate_m0AAD7F558DDD6E8FFDD853AE8180D5B12F0A3666 ();
// 0x000001AF System.Void Michsky.UI.ModernUIPack.UIManagerScrollbar::UpdateDropdown()
extern void UIManagerScrollbar_UpdateDropdown_mBEA9080EB04A8AE1DF71FB23E136B1F75C641524 ();
// 0x000001B0 System.Void Michsky.UI.ModernUIPack.UIManagerScrollbar::.ctor()
extern void UIManagerScrollbar__ctor_m5C64EFC4569014C3E7E8C42F135145A2724A23C3 ();
// 0x000001B1 System.Void Michsky.UI.ModernUIPack.UIManagerSlider::OnEnable()
extern void UIManagerSlider_OnEnable_mE7A55268926485AF3C10E21EDAA5C71035031E26 ();
// 0x000001B2 System.Void Michsky.UI.ModernUIPack.UIManagerSlider::Awake()
extern void UIManagerSlider_Awake_m31327220FC1F214275B73473860181906E3D8BCB ();
// 0x000001B3 System.Void Michsky.UI.ModernUIPack.UIManagerSlider::LateUpdate()
extern void UIManagerSlider_LateUpdate_m290DFBCE85B2030BCE3D4ADA14543599E4618E27 ();
// 0x000001B4 System.Void Michsky.UI.ModernUIPack.UIManagerSlider::UpdateDropdown()
extern void UIManagerSlider_UpdateDropdown_m87A22C513A1B8E17F06310B2867212C3A1235B12 ();
// 0x000001B5 System.Void Michsky.UI.ModernUIPack.UIManagerSlider::.ctor()
extern void UIManagerSlider__ctor_m3E9960F74EFE37E403612B780D976FC565B3FDD3 ();
// 0x000001B6 System.Void Michsky.UI.ModernUIPack.UIManagerSwitch::OnEnable()
extern void UIManagerSwitch_OnEnable_mCC6CE3740430A6C56377615BF70B66F5A6D09E32 ();
// 0x000001B7 System.Void Michsky.UI.ModernUIPack.UIManagerSwitch::Awake()
extern void UIManagerSwitch_Awake_m29756F27ECDDEF88C36021D9411305B115ED127F ();
// 0x000001B8 System.Void Michsky.UI.ModernUIPack.UIManagerSwitch::LateUpdate()
extern void UIManagerSwitch_LateUpdate_mE8907F9E00D486F10A3494808EB8A31AB5F43995 ();
// 0x000001B9 System.Void Michsky.UI.ModernUIPack.UIManagerSwitch::UpdateDropdown()
extern void UIManagerSwitch_UpdateDropdown_m0E29FE475C8CFB85EFCBA4C9653BBBA4004ECB28 ();
// 0x000001BA System.Void Michsky.UI.ModernUIPack.UIManagerSwitch::.ctor()
extern void UIManagerSwitch__ctor_m2C49F0AB0236F65C6308F2B39BF2314A9219F34D ();
// 0x000001BB System.Void Michsky.UI.ModernUIPack.UIManagerToggle::OnEnable()
extern void UIManagerToggle_OnEnable_m4F09FC4C25A1CFB9FE29732DECFBC6FFE6601D16 ();
// 0x000001BC System.Void Michsky.UI.ModernUIPack.UIManagerToggle::Awake()
extern void UIManagerToggle_Awake_m372F88317ACC58CA2492CFEFAF8F1F4662ED0D29 ();
// 0x000001BD System.Void Michsky.UI.ModernUIPack.UIManagerToggle::LateUpdate()
extern void UIManagerToggle_LateUpdate_m596B7AD2D05CCB4B66FA18E8FCF12EBC043F4D2E ();
// 0x000001BE System.Void Michsky.UI.ModernUIPack.UIManagerToggle::UpdateDropdown()
extern void UIManagerToggle_UpdateDropdown_m6E55DB99150EF3F56AA98AF2C544442D82A1578C ();
// 0x000001BF System.Void Michsky.UI.ModernUIPack.UIManagerToggle::.ctor()
extern void UIManagerToggle__ctor_m53514BD5AEE83BE20E889EB0FBBC93B2A29B6856 ();
// 0x000001C0 System.Void Michsky.UI.ModernUIPack.UIManagerTooltip::OnEnable()
extern void UIManagerTooltip_OnEnable_mD318213FAD0650C88B2DE2854ECAEF4B1EBE1E78 ();
// 0x000001C1 System.Void Michsky.UI.ModernUIPack.UIManagerTooltip::Awake()
extern void UIManagerTooltip_Awake_m1FB0FBDAB9DADD274E6F0E7AE5DDCF4CB2F34323 ();
// 0x000001C2 System.Void Michsky.UI.ModernUIPack.UIManagerTooltip::LateUpdate()
extern void UIManagerTooltip_LateUpdate_m2374E53CA127AE70038499E429D0FDB2D23B7571 ();
// 0x000001C3 System.Void Michsky.UI.ModernUIPack.UIManagerTooltip::UpdateDropdown()
extern void UIManagerTooltip_UpdateDropdown_m3AC180B35BFA790354DDAD2505AAD20DC0130B95 ();
// 0x000001C4 System.Void Michsky.UI.ModernUIPack.UIManagerTooltip::.ctor()
extern void UIManagerTooltip__ctor_mF558B7D7B87BD7103693F535B7EFED8AF263326E ();
// 0x000001C5 System.Void Michsky.UI.ModernUIPack.WindowDragger::Start()
extern void WindowDragger_Start_m8732312CA9EE4AF03A3BE29CB52CC917F225542B ();
// 0x000001C6 UnityEngine.RectTransform Michsky.UI.ModernUIPack.WindowDragger::get_DragObjectInternal()
extern void WindowDragger_get_DragObjectInternal_mD24357FC946129148D9B2BDB8C385567EF5569C4 ();
// 0x000001C7 UnityEngine.RectTransform Michsky.UI.ModernUIPack.WindowDragger::get_DragAreaInternal()
extern void WindowDragger_get_DragAreaInternal_mF05C62C00BBF784FDF184F1A13FC9688AB3C9956 ();
// 0x000001C8 System.Void Michsky.UI.ModernUIPack.WindowDragger::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void WindowDragger_OnBeginDrag_m8C583486665B7D7656AC1BE1AE9C21CCD93F3F5B ();
// 0x000001C9 System.Void Michsky.UI.ModernUIPack.WindowDragger::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void WindowDragger_OnDrag_mCDCB4104FC5721AAA3FAE96B7D5F4E4F15DB95C7 ();
// 0x000001CA System.Void Michsky.UI.ModernUIPack.WindowDragger::ClampToArea()
extern void WindowDragger_ClampToArea_m5BC8A904A03FBE8E925EB2E445C605B497B6A98D ();
// 0x000001CB System.Void Michsky.UI.ModernUIPack.WindowDragger::.ctor()
extern void WindowDragger__ctor_m1AEBCC2027050C2A15D2184EAEE293B8D1FAE106 ();
// 0x000001CC System.Void Arcade.SDK.ARFoundationHelper::add_PlanesChanged(System.Action`1<UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs>)
extern void ARFoundationHelper_add_PlanesChanged_m49B80EA31B002073494813F6F7E133E377A3524D ();
// 0x000001CD System.Void Arcade.SDK.ARFoundationHelper::remove_PlanesChanged(System.Action`1<UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs>)
extern void ARFoundationHelper_remove_PlanesChanged_mF2C37669962AE51E979E2B50056C9A29E43EE4DC ();
// 0x000001CE System.Void Arcade.SDK.ARFoundationHelper::add_ARSessionChanged(System.Action`1<UnityEngine.XR.ARFoundation.ARSessionStateChangedEventArgs>)
extern void ARFoundationHelper_add_ARSessionChanged_mB4C07534C1161D6DADAA3599AA32F0DB4C9F33E9 ();
// 0x000001CF System.Void Arcade.SDK.ARFoundationHelper::remove_ARSessionChanged(System.Action`1<UnityEngine.XR.ARFoundation.ARSessionStateChangedEventArgs>)
extern void ARFoundationHelper_remove_ARSessionChanged_m22E839465B1EBF5BA6DBE1DB18BC9B22A7A0FDFF ();
// 0x000001D0 UnityEngine.XR.ARFoundation.ARRaycastManager Arcade.SDK.ARFoundationHelper::get_RaycastManager()
extern void ARFoundationHelper_get_RaycastManager_mC43B64FEEC43BF9F3DC1E54CC67CD6FED1021BCE ();
// 0x000001D1 System.Void Arcade.SDK.ARFoundationHelper::set_RaycastManager(UnityEngine.XR.ARFoundation.ARRaycastManager)
extern void ARFoundationHelper_set_RaycastManager_mD03A583FFB7D66B751593C3BB080549DF7B3E138 ();
// 0x000001D2 System.Void Arcade.SDK.ARFoundationHelper::Awake()
extern void ARFoundationHelper_Awake_m1A002F3DA637BD76005AACFD157F8A71DE62815E ();
// 0x000001D3 System.Void Arcade.SDK.ARFoundationHelper::OnEnable()
extern void ARFoundationHelper_OnEnable_mE18AE70D539C94064125B09D1CF19B63F4EAAECA ();
// 0x000001D4 System.Void Arcade.SDK.ARFoundationHelper::OnDisable()
extern void ARFoundationHelper_OnDisable_mEE18D5656946EA8C93D5D232A034110F2A7E568A ();
// 0x000001D5 System.Void Arcade.SDK.ARFoundationHelper::OnPlaneChanged(UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs)
extern void ARFoundationHelper_OnPlaneChanged_m5AE992453388D8D0C36B0D18F95D9673378C8F5C ();
// 0x000001D6 System.Void Arcade.SDK.ARFoundationHelper::OnSessionStateChanged(UnityEngine.XR.ARFoundation.ARSessionStateChangedEventArgs)
extern void ARFoundationHelper_OnSessionStateChanged_mC3F945145429648409915A5B176A8BD7C0604185 ();
// 0x000001D7 System.Void Arcade.SDK.ARFoundationHelper::.ctor()
extern void ARFoundationHelper__ctor_mA0FAA8E1A8AF1CE232A893F09F4E9B72DD8F48EF ();
// 0x000001D8 System.Void Arcade.SDK.DebugTools.DebugHelper::LogMessage(System.String,Arcade.SDK.DebugTools.DebugHelper_MESSAGE_TYPE)
extern void DebugHelper_LogMessage_mAC9309DD0B62B95B56DB38D41E6185394F7A775A ();
// 0x000001D9 System.Void Arcade.SDK.DebugTools.DebugHelper::.ctor()
extern void DebugHelper__ctor_mEA8789D7A3E0E7B61D23C8841D95F86411E32CC6 ();
// 0x000001DA System.Void Arcade.SDK.DebugTools.DebugHelper::.cctor()
extern void DebugHelper__cctor_mFD751D3CBB1F1292B77246BC707F9669C0396B60 ();
// 0x000001DB System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::add_ARInstructionsStarted(System.Action)
extern void ArcadeSDK_ARInstructions_add_ARInstructionsStarted_m132824EE28453B46997CA918FCB4CC0F4853E62B ();
// 0x000001DC System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::remove_ARInstructionsStarted(System.Action)
extern void ArcadeSDK_ARInstructions_remove_ARInstructionsStarted_m522FCF6B62EA55CA8CB494A42D019CFD448BD6DD ();
// 0x000001DD System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::OnEnable()
extern void ArcadeSDK_ARInstructions_OnEnable_m182F5675CBFAF31EB670D2FB69A3CC49F286026E ();
// 0x000001DE System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::OnDisable()
extern void ArcadeSDK_ARInstructions_OnDisable_m84BC0FC60AAEFC61B9EE931BB18E6CD53255745D ();
// 0x000001DF System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::Start()
extern void ArcadeSDK_ARInstructions_Start_mA3A50BF08FA6FF5127D92EDE4D2F55A68EDFC862 ();
// 0x000001E0 System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::StartInstructions()
extern void ArcadeSDK_ARInstructions_StartInstructions_m689E84A802BFB9E9CCE3F492B6FAEAF5E4322AE6 ();
// 0x000001E1 System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::OnObjectPlaced(UnityEngine.GameObject)
extern void ArcadeSDK_ARInstructions_OnObjectPlaced_m26A9F2267BAB57423475794EBE065E69644FD4D8 ();
// 0x000001E2 System.Collections.IEnumerator Arcade.SDK.UI.ArcadeSDK_ARInstructions::InstructionCoroutine()
extern void ArcadeSDK_ARInstructions_InstructionCoroutine_m16242EC9590AC799644BFEE978A7B975C7A1028B ();
// 0x000001E3 System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::OnInstructionsFinished()
extern void ArcadeSDK_ARInstructions_OnInstructionsFinished_m2BF83590C77DFF752E4B6593C904CBFC0C3486AA ();
// 0x000001E4 System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions::.ctor()
extern void ArcadeSDK_ARInstructions__ctor_mBE19751DD1519BAA92DEE206109C2EB250C901F3 ();
// 0x000001E5 System.Void Arcade.SDK.AR.ArcadeSDK_GameFlowManager::Awake()
extern void ArcadeSDK_GameFlowManager_Awake_m7AB86199D68D3207243424577A62DCB94FCF2291 ();
// 0x000001E6 System.Void Arcade.SDK.AR.ArcadeSDK_GameFlowManager::JumpToStepInSequence(System.Int32,System.Int32)
extern void ArcadeSDK_GameFlowManager_JumpToStepInSequence_m476D6F6A30855C8D83790BA4E5C878EC2138206F ();
// 0x000001E7 System.Void Arcade.SDK.AR.ArcadeSDK_GameFlowManager::TakeStep()
extern void ArcadeSDK_GameFlowManager_TakeStep_m2792A976E0EC7C6568F7648BE145DC199C690B61 ();
// 0x000001E8 System.Boolean Arcade.SDK.AR.ArcadeSDK_GameFlowManager::IncrementSequence()
extern void ArcadeSDK_GameFlowManager_IncrementSequence_mC4A1E0239D9EE58D081226C3492E9A220DAB5F2A ();
// 0x000001E9 System.Void Arcade.SDK.AR.ArcadeSDK_GameFlowManager::OnFinishedAllSequences()
extern void ArcadeSDK_GameFlowManager_OnFinishedAllSequences_m7975A1A8E4FA4F9413E12430FBB26D8EFADD62F1 ();
// 0x000001EA System.Void Arcade.SDK.AR.ArcadeSDK_GameFlowManager::.ctor()
extern void ArcadeSDK_GameFlowManager__ctor_mD9F5CC03D3F297876B6F3C9F49188E8C524B05FC ();
// 0x000001EB System.Int32 Arcade.SDK.AR.ArcadeSDK_Sequence::get_CurrentStep()
extern void ArcadeSDK_Sequence_get_CurrentStep_m84B836CBAB56FBD49CCD9A18634FCDF5999D890C ();
// 0x000001EC System.Void Arcade.SDK.AR.ArcadeSDK_Sequence::set_CurrentStep(System.Int32)
extern void ArcadeSDK_Sequence_set_CurrentStep_mF0611F514A95AA81C420CA377D2C28874CC82404 ();
// 0x000001ED Arcade.SDK.AR.ArcadeSDK_Step[] Arcade.SDK.AR.ArcadeSDK_Sequence::get_SequenceSteps()
extern void ArcadeSDK_Sequence_get_SequenceSteps_m2A7C9A19AF2DA1DD9502F89B8AE662ACC4B0A523 ();
// 0x000001EE System.Void Arcade.SDK.AR.ArcadeSDK_Sequence::set_SequenceSteps(Arcade.SDK.AR.ArcadeSDK_Step[])
extern void ArcadeSDK_Sequence_set_SequenceSteps_m94D0397448BBEE700CB20AC86B25EB751A13B61E ();
// 0x000001EF System.Void Arcade.SDK.AR.ArcadeSDK_Sequence::Awake()
extern void ArcadeSDK_Sequence_Awake_m464F5CAE3DE79FB2C0EB638FB827DD02D2D812D6 ();
// 0x000001F0 System.Boolean Arcade.SDK.AR.ArcadeSDK_Sequence::IncrementStep()
extern void ArcadeSDK_Sequence_IncrementStep_mCD1C76D5029342AD7EA24784FDAC7225FAEA01F8 ();
// 0x000001F1 System.Void Arcade.SDK.AR.ArcadeSDK_Sequence::ExecuteStep()
extern void ArcadeSDK_Sequence_ExecuteStep_m640FDFE198D5890AF9547E5D0F34B3ED6911AAF1 ();
// 0x000001F2 System.Void Arcade.SDK.AR.ArcadeSDK_Sequence::.ctor()
extern void ArcadeSDK_Sequence__ctor_mE288F54F694085C5EA8C04FE42BDD85DBD5E6322 ();
// 0x000001F3 System.Void Arcade.SDK.AR.ArcadeSDK_Step::ExecuteStep()
extern void ArcadeSDK_Step_ExecuteStep_m14D02E8F13FFB594F114764FA681971B92CC5476 ();
// 0x000001F4 System.Void Arcade.SDK.AR.ArcadeSDK_Step::OnStepExecute()
extern void ArcadeSDK_Step_OnStepExecute_mF14342216080CBA4A4623E5CB961BAA1A884F03E ();
// 0x000001F5 System.Void Arcade.SDK.AR.ArcadeSDK_Step::.ctor()
extern void ArcadeSDK_Step__ctor_mEBFA95AEFB3B9BE50C4C357F04C17BEF06AC00B6 ();
// 0x000001F6 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::add_PlacedObject(Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler)
extern void ArcadeSDK_PlaceObjOnPlane_add_PlacedObject_m73B5B0602E4EEFE329936FC95F5C0A240F5AF5A9 ();
// 0x000001F7 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::remove_PlacedObject(Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler)
extern void ArcadeSDK_PlaceObjOnPlane_remove_PlacedObject_mC685016556C65A15E164906F66AA9FC3608C2FA5 ();
// 0x000001F8 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::Start()
extern void ArcadeSDK_PlaceObjOnPlane_Start_mA26AD6BC0EF0CFF5A851B771B4D3E6F3D36894F1 ();
// 0x000001F9 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::OnObjectPlaced(UnityEngine.GameObject)
extern void ArcadeSDK_PlaceObjOnPlane_OnObjectPlaced_mD2097AE2C51839C4F37ABC5C8193BA32DC27F2C3 ();
// 0x000001FA System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::Update()
extern void ArcadeSDK_PlaceObjOnPlane_Update_m905D1AD9E5EE183E1F8AC327911EF177C4277958 ();
// 0x000001FB System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::.ctor()
extern void ArcadeSDK_PlaceObjOnPlane__ctor_mEC0FF472FA6CAD228AE71286571BDFB5EB7C89C6 ();
// 0x000001FC System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane::.cctor()
extern void ArcadeSDK_PlaceObjOnPlane__cctor_m2793AC81E12165B887ECEC51C2F3397B694AC331 ();
// 0x000001FD System.Void Arcade.SDK.AR.PlaceObjOnPlane::add_PlacedObject(Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler)
extern void PlaceObjOnPlane_add_PlacedObject_m13837B8C6E72E292B15902C120B43E07E2D78FFB ();
// 0x000001FE System.Void Arcade.SDK.AR.PlaceObjOnPlane::remove_PlacedObject(Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler)
extern void PlaceObjOnPlane_remove_PlacedObject_m8EEC085023541C1ED897510B16E5AF4A6EA47AE1 ();
// 0x000001FF System.Void Arcade.SDK.AR.PlaceObjOnPlane::Start()
extern void PlaceObjOnPlane_Start_m5AFD5A6CE6C7D390A3F496D3DE26991730ABBFA0 ();
// 0x00000200 System.Void Arcade.SDK.AR.PlaceObjOnPlane::OnObjectPlaced(UnityEngine.GameObject)
extern void PlaceObjOnPlane_OnObjectPlaced_mB510338AFAEE133D8DAE38FC702B5460A1804329 ();
// 0x00000201 System.Void Arcade.SDK.AR.PlaceObjOnPlane::Update()
extern void PlaceObjOnPlane_Update_mA0932FE222EDF406990C8ADFFE0547AC3EB57BBD ();
// 0x00000202 System.Void Arcade.SDK.AR.PlaceObjOnPlane::.ctor()
extern void PlaceObjOnPlane__ctor_mBA81D35FA930322BED1DA1CF58B18094A4CA12C8 ();
// 0x00000203 System.Void Arcade.SDK.AR.PlaceObjOnPlane::.cctor()
extern void PlaceObjOnPlane__cctor_m4CDA914EEF3C79B2A8A174E44A23DAA114DF420B ();
// 0x00000204 System.Void FirebaseFunctionsHandler_<ServerTimeRequest>d__3::.ctor(System.Int32)
extern void U3CServerTimeRequestU3Ed__3__ctor_m0A143372A59B2DFE325FD5BADE95491624FB794B ();
// 0x00000205 System.Void FirebaseFunctionsHandler_<ServerTimeRequest>d__3::System.IDisposable.Dispose()
extern void U3CServerTimeRequestU3Ed__3_System_IDisposable_Dispose_mD309A99CE74CB1F1D15FF44FFE8A68B8671EB971 ();
// 0x00000206 System.Boolean FirebaseFunctionsHandler_<ServerTimeRequest>d__3::MoveNext()
extern void U3CServerTimeRequestU3Ed__3_MoveNext_mAA87D0FB0C4E4298F44E5785A5143D9474B81BC4 ();
// 0x00000207 System.Void FirebaseFunctionsHandler_<ServerTimeRequest>d__3::<>m__Finally1()
extern void U3CServerTimeRequestU3Ed__3_U3CU3Em__Finally1_m16A15191753AD6499159289F40DBB916BF031180 ();
// 0x00000208 System.Object FirebaseFunctionsHandler_<ServerTimeRequest>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CServerTimeRequestU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8176A93445A743B07AE56BF1C5E00BF3C4BC18F0 ();
// 0x00000209 System.Void FirebaseFunctionsHandler_<ServerTimeRequest>d__3::System.Collections.IEnumerator.Reset()
extern void U3CServerTimeRequestU3Ed__3_System_Collections_IEnumerator_Reset_m08C000765843749E133792CF80C02E3C72642FA9 ();
// 0x0000020A System.Object FirebaseFunctionsHandler_<ServerTimeRequest>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CServerTimeRequestU3Ed__3_System_Collections_IEnumerator_get_Current_m37C3EB069FAB49815AF9CB2B863A04009DA7B2EC ();
// 0x0000020B System.Void TapToPlaceStreamApp_<FadeOut>d__23::.ctor(System.Int32)
extern void U3CFadeOutU3Ed__23__ctor_mE307004006FA47D11B91CA4EAE4E3A8119500A73 ();
// 0x0000020C System.Void TapToPlaceStreamApp_<FadeOut>d__23::System.IDisposable.Dispose()
extern void U3CFadeOutU3Ed__23_System_IDisposable_Dispose_m375CC44491B3D0AF6DBC4F9CE52A3A264617E0E2 ();
// 0x0000020D System.Boolean TapToPlaceStreamApp_<FadeOut>d__23::MoveNext()
extern void U3CFadeOutU3Ed__23_MoveNext_mA40D9F09BF9C09E4FD72CF240923E4132CE9B044 ();
// 0x0000020E System.Object TapToPlaceStreamApp_<FadeOut>d__23::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFadeOutU3Ed__23_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA5E3C5E2F59696518065ECC5488E508D15B3EFFB ();
// 0x0000020F System.Void TapToPlaceStreamApp_<FadeOut>d__23::System.Collections.IEnumerator.Reset()
extern void U3CFadeOutU3Ed__23_System_Collections_IEnumerator_Reset_m8E5896B8ADF22F5BE6B67479D6E1BB4B8C6C9601 ();
// 0x00000210 System.Object TapToPlaceStreamApp_<FadeOut>d__23::System.Collections.IEnumerator.get_Current()
extern void U3CFadeOutU3Ed__23_System_Collections_IEnumerator_get_Current_m08259204FC954B35B0267DBBE1DE3E0C75FC34B2 ();
// 0x00000211 System.Void UnityMessageManager_MessageDelegate::.ctor(System.Object,System.IntPtr)
extern void MessageDelegate__ctor_m3EA48B06536871149F1A43C905528166D49F48C8 ();
// 0x00000212 System.Void UnityMessageManager_MessageDelegate::Invoke(System.String)
extern void MessageDelegate_Invoke_m2D199E1633D3EFBEA727164B8A3F7888E6A4F801 ();
// 0x00000213 System.IAsyncResult UnityMessageManager_MessageDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void MessageDelegate_BeginInvoke_m89C256246D24A40498952C82CDD615B3507E4BA4 ();
// 0x00000214 System.Void UnityMessageManager_MessageDelegate::EndInvoke(System.IAsyncResult)
extern void MessageDelegate_EndInvoke_m778326112BD3D26CB9DE0FFC335E9A1A9353BC35 ();
// 0x00000215 System.Void UnityMessageManager_MessageHandlerDelegate::.ctor(System.Object,System.IntPtr)
extern void MessageHandlerDelegate__ctor_m58386047CB442F144728F0A568B26FDDDB0EE6EA ();
// 0x00000216 System.Void UnityMessageManager_MessageHandlerDelegate::Invoke(MessageHandler)
extern void MessageHandlerDelegate_Invoke_mF982647CDFA5782B9ABAF328FF4070492A364B43 ();
// 0x00000217 System.IAsyncResult UnityMessageManager_MessageHandlerDelegate::BeginInvoke(MessageHandler,System.AsyncCallback,System.Object)
extern void MessageHandlerDelegate_BeginInvoke_mFDBB4C951CAC28A4F0E08666050BB3F266FA927E ();
// 0x00000218 System.Void UnityMessageManager_MessageHandlerDelegate::EndInvoke(System.IAsyncResult)
extern void MessageHandlerDelegate_EndInvoke_m9BC3850452E21DEBBF15C7598D811D4D744633A6 ();
// 0x00000219 System.Void Michsky.UI.ModernUIPack.CustomDropdown_Item::.ctor()
extern void Item__ctor_m7FDB3BB2A80D464FA6A3636D1248C2A7F3C80CB9 ();
// 0x0000021A System.Void Michsky.UI.ModernUIPack.CustomDropdown_<>c__DisplayClass34_0::.ctor()
extern void U3CU3Ec__DisplayClass34_0__ctor_m6C5806C4FF3B7606C63C72B01F436E5966D66118 ();
// 0x0000021B System.Void Michsky.UI.ModernUIPack.CustomDropdown_<>c__DisplayClass34_0::<SetupDropdown>b__0()
extern void U3CU3Ec__DisplayClass34_0_U3CSetupDropdownU3Eb__0_m60264FF94DB05B4C3E60003B3F7B9D89D923D484 ();
// 0x0000021C System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect_ToggleEvent::.ctor()
extern void ToggleEvent__ctor_mD0237BFA9FD53C25A1D13D1BA5EB40AADBABEE97 ();
// 0x0000021D System.Void Michsky.UI.ModernUIPack.DropdownMultiSelect_Item::.ctor()
extern void Item__ctor_m2CEE0564043FB355C50DA89E013FCDE741D4FE1A ();
// 0x0000021E System.Void Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::.ctor(System.Int32)
extern void U3CExecuteAfterTimeU3Ed__2__ctor_mAB8A660ED8B646B33BDD0C613B1D3E6F581730BA ();
// 0x0000021F System.Void Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::System.IDisposable.Dispose()
extern void U3CExecuteAfterTimeU3Ed__2_System_IDisposable_Dispose_mD49E0BB97702AADB740296D196CBDC4A0D313967 ();
// 0x00000220 System.Boolean Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::MoveNext()
extern void U3CExecuteAfterTimeU3Ed__2_MoveNext_mDDA8CF1256456D74A2121F93C13DB32D26822A76 ();
// 0x00000221 System.Object Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CExecuteAfterTimeU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF23868AA78B16C3DD4D4535741CAE6A0AE975766 ();
// 0x00000222 System.Void Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::System.Collections.IEnumerator.Reset()
extern void U3CExecuteAfterTimeU3Ed__2_System_Collections_IEnumerator_Reset_m4B040CD4B6EDA3D0DDAA11CD1EF4D1C49B64B279 ();
// 0x00000223 System.Object Michsky.UI.ModernUIPack.LayoutGroupPositionFix_<ExecuteAfterTime>d__2::System.Collections.IEnumerator.get_Current()
extern void U3CExecuteAfterTimeU3Ed__2_System_Collections_IEnumerator_get_Current_mD41B7ECDBC26C90F0BCCBE429AEE6194805D421A ();
// 0x00000224 System.Void Michsky.UI.ModernUIPack.HorizontalSelector_Item::.ctor()
extern void Item__ctor_m5D12669827721A49D747A3A40FEE5BAEB9470B1E ();
// 0x00000225 System.Void Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::.ctor(System.Int32)
extern void U3CStartTimerU3Ed__13__ctor_m5FB37EAEA922EA030ABCADF033D88EE7988C7829 ();
// 0x00000226 System.Void Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::System.IDisposable.Dispose()
extern void U3CStartTimerU3Ed__13_System_IDisposable_Dispose_m20AA61FF22F14F7CABCC6C372C8F7482E5C37288 ();
// 0x00000227 System.Boolean Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::MoveNext()
extern void U3CStartTimerU3Ed__13_MoveNext_mCBD5A6A563D18B592907440BF444AFB5CBF6DE6F ();
// 0x00000228 System.Object Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartTimerU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m076F66F7EE38E255B85F8531E75470D7FB8EC2B5 ();
// 0x00000229 System.Void Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::System.Collections.IEnumerator.Reset()
extern void U3CStartTimerU3Ed__13_System_Collections_IEnumerator_Reset_m79F18CCA6E4B7674D94331D22645FD8804CB5A19 ();
// 0x0000022A System.Object Michsky.UI.ModernUIPack.NotificationManager_<StartTimer>d__13::System.Collections.IEnumerator.get_Current()
extern void U3CStartTimerU3Ed__13_System_Collections_IEnumerator_get_Current_m7F990B8896FB7FB5510DA961882A5C9E18BAAD9F ();
// 0x0000022B System.Void Michsky.UI.ModernUIPack.RadialSlider_SliderEvent::.ctor()
extern void SliderEvent__ctor_m91C687DFEC324787F1A1D6E0E43EFFAEF2777A1E ();
// 0x0000022C System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::.ctor(System.Int32)
extern void U3CInstructionCoroutineU3Ed__14__ctor_m75C7510551615F813FA31562C7D6D90F12EED018 ();
// 0x0000022D System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::System.IDisposable.Dispose()
extern void U3CInstructionCoroutineU3Ed__14_System_IDisposable_Dispose_m27CA3353F3079144A1981476D39B34716F5E83DA ();
// 0x0000022E System.Boolean Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::MoveNext()
extern void U3CInstructionCoroutineU3Ed__14_MoveNext_mECF6D1623CAD7D0D5334EBD101BB405D74FF7F90 ();
// 0x0000022F System.Object Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CInstructionCoroutineU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m740D20671B312E85D460579A52CF30713AA2A51A ();
// 0x00000230 System.Void Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::System.Collections.IEnumerator.Reset()
extern void U3CInstructionCoroutineU3Ed__14_System_Collections_IEnumerator_Reset_mE34BFE4149B5EA716A9D775B6DBCE87CE8DE7082 ();
// 0x00000231 System.Object Arcade.SDK.UI.ArcadeSDK_ARInstructions_<InstructionCoroutine>d__14::System.Collections.IEnumerator.get_Current()
extern void U3CInstructionCoroutineU3Ed__14_System_Collections_IEnumerator_get_Current_mA8120800ADC1BD972D99998EA4B4AE1D48B3F677 ();
// 0x00000232 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler::.ctor(System.Object,System.IntPtr)
extern void PlacedObjectHandler__ctor_m0710FADAD56B5D82703F2C08329AAD4CF0D6D7E7 ();
// 0x00000233 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler::Invoke(UnityEngine.GameObject)
extern void PlacedObjectHandler_Invoke_mB02665CD25CCE70CA4D991461945927533ADBD17 ();
// 0x00000234 System.IAsyncResult Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void PlacedObjectHandler_BeginInvoke_m6A682CD9CE5831E08E9B9CCC8E82815EE56B6317 ();
// 0x00000235 System.Void Arcade.SDK.AR.ArcadeSDK_PlaceObjOnPlane_PlacedObjectHandler::EndInvoke(System.IAsyncResult)
extern void PlacedObjectHandler_EndInvoke_m90D8A9E876CD25E418D5FCB6550189D8D66B83A3 ();
// 0x00000236 System.Void Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler::.ctor(System.Object,System.IntPtr)
extern void PlacedObjectHandler__ctor_m95E81591B2457ECE0A157242A16CD34C47AFF348 ();
// 0x00000237 System.Void Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler::Invoke(UnityEngine.GameObject)
extern void PlacedObjectHandler_Invoke_m53EA39110892223E9D93691BD7A233F3D34AA386 ();
// 0x00000238 System.IAsyncResult Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void PlacedObjectHandler_BeginInvoke_m55FA0E50F39DCF24D8CF340BFF43BF973D5C7ED9 ();
// 0x00000239 System.Void Arcade.SDK.AR.PlaceObjOnPlane_PlacedObjectHandler::EndInvoke(System.IAsyncResult)
extern void PlacedObjectHandler_EndInvoke_m1DFC5CC2E166C2AF48243DCEB208A44EEE34EE2D ();
static Il2CppMethodPointer s_methodPointers[569] = 
{
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ARFeatheredPlaneMeshVisualizer_get_featheringWidth_mD474743D2E8E4CE3078FCD70A52B70111EC99500,
	ARFeatheredPlaneMeshVisualizer_set_featheringWidth_m1974473A6C2BB2AED083691C8079E6F9A83398EC,
	ARFeatheredPlaneMeshVisualizer_Awake_mBFDBB9E8B393BD7BA784845A0C7692848E9C61E2,
	ARFeatheredPlaneMeshVisualizer_OnEnable_m3A77938D2FE2C6A653A7E13B90DB6C9DEEB06A9A,
	ARFeatheredPlaneMeshVisualizer_OnDisable_m9DE1EB0F00D7F7AC754CE4633569BB8C8687C67A,
	ARFeatheredPlaneMeshVisualizer_ARPlane_boundaryUpdated_mC88C42F35A3B243C83E9D24DCC9545F7E9E6BA28,
	ARFeatheredPlaneMeshVisualizer_GenerateBoundaryUVs_mCEA3823DDAED557BA0B92214D15AB25EC75065D8,
	ARFeatheredPlaneMeshVisualizer__ctor_mA9417DD97EC611603602EAE0302A80E71CF93890,
	ARFeatheredPlaneMeshVisualizer__cctor_mC697317BB4FB496A10AFA8C2E73E27AF8A5538A1,
	FadePlaneOnBoundaryChange_OnEnable_mDE7F5846CEE8C9C0790C64394C9290F01C46E5CE,
	FadePlaneOnBoundaryChange_OnDisable_m7A0F29D256D7FB3D80E57C8C32A90E82C24BAA13,
	FadePlaneOnBoundaryChange_Update_m97ECC6F4BFA94FC49F95234F510F3F0E2A2630BE,
	FadePlaneOnBoundaryChange_PlaneOnBoundaryChanged_m09B93DDCD1F281F8EA00FF95C8CFB6779923A4A1,
	FadePlaneOnBoundaryChange__ctor_m76BB07073C419951499094E08C1F40C376C0C3E0,
	Extensions_IsEmpty_m5334C44A9B1BE5FE28D190CC961505281956AC85,
	LightEstimation_get_cameraManager_m24B7FBD82A85B1749F413E9463CF4819E87F179A,
	LightEstimation_set_cameraManager_m7DB56BE796AD559495B811205370EDC3ECEC6D03,
	LightEstimation_get_brightness_mC492132D55ECD6A3BDC2CEDD92BB36B2FA4DEE91,
	LightEstimation_set_brightness_m753DF62923B281F038A993C8AC3E0224DE4138E9,
	LightEstimation_get_colorTemperature_m14AA85A63C4872E42A7AA541F843573FD5460F60,
	LightEstimation_set_colorTemperature_m67869580BD0D33B4AA3F327B4E824354E16BF1FD,
	LightEstimation_get_colorCorrection_m25920670C31027CC61B0A3B94CC77D1FF27C6D78,
	LightEstimation_set_colorCorrection_mE50133CC495B31263C6FD2871F1AABC70576B96F,
	LightEstimation_Awake_m810C5DDEF38182C155ED925189FCEE5A6156ED0F,
	LightEstimation_OnEnable_m14852BF0988F64CA2BD06CAF46F3F01E0E4ABD8C,
	LightEstimation_OnDisable_mB4EE490FD2CE5C671376ED02803EEEC99DCB6941,
	LightEstimation_FrameChanged_mB8C2FF65FE6F8AEDA4D055B124B953CF88ABBD82,
	LightEstimation__ctor_m1D22C524A3F3BACE47DAD18291C9A7265A768E14,
	LightEstimationUI_get_brightnessText_m7F65458F05254E408F53555C86E31618897A188C,
	LightEstimationUI_set_brightnessText_mDFBFF1F5FB0D355FDF05D107742931CB5758AC9B,
	LightEstimationUI_get_colorTemperatureText_m0CBAA2260308B9F8493371EDC9938801CEA3CE16,
	LightEstimationUI_set_colorTemperatureText_m20919E84A4E61BD8121458771747CA3AC480347E,
	LightEstimationUI_get_colorCorrectionText_m326B278B8F32CD173155F0C4CD50CCB620D6333A,
	LightEstimationUI_set_colorCorrectionText_m07025B98225700EEE39B67772F838FCE483E7966,
	LightEstimationUI_Awake_mEC1481B8E47A406471C4F6EE3C233C2046C20A30,
	LightEstimationUI_Update_m1F562A15FAA7E347CB89E653508686007351E9FC,
	NULL,
	LightEstimationUI__ctor_m0F952651523E92202593A6E1498864137A6C9B59,
	ARInstructions_OnInstructionsFinished_mE1F81E306657E7CC453E8D354698ABE793868AEB,
	ARInstructions_StartInstructions_m102E599F3DB1E48E644B47FE1A5AC5B4229DBBF0,
	ARInstructions__ctor_mF3D5A25531DB279C2A471C6310DE4D5EE41B2D76,
	GameFlowManager__ctor_m71A7B0808984589B8930E24D5D469603EC7C6602,
	SequenceInstance__ctor_mBD67863D37A3EE4114B831273218665FE13D93CE,
	NewBehaviourScript_Start_mDB573B0B04591BBF1CDC10C7C835851EBF8D17F2,
	NewBehaviourScript_Update_mAA0BE51F329DE556FA585E93DD1B9CF6D917A85C,
	NewBehaviourScript__ctor_mC87DFFB91971C9C20A9487A744F5E68D74FB05FE,
	StepInstance_OnStepExecute_mC39BA3388FEC6D4652683060326C19FBAAA8FA14,
	StepInstance__ctor_mD34550755E27228A6BE250BF6BEE1F7DE8A61D9B,
	PlaceableSphere__ctor_m1828D4657B50F7919354D23ABCB774FFDF19C790,
	RaycastPlaceObject_OnObjectPlaced_mEBE9BBB877612EB27FDE465ECAF07AF9A105EBFF,
	RaycastPlaceObject__ctor_m26508017E673D2655E62D7061E664B77A5F9F90F,
	FirebaseFunctionsHandler_GetServerTime_m5A6B449B5B0D8575F601CF71D4C22B74556C1E0B,
	FirebaseFunctionsHandler_ServerTimeRequest_mE3F1E20EAB00D63B3764D0A668FFB770C4213992,
	FirebaseFunctionsHandler__ctor_mFF0AE00D335F81016D5D9CFCB4BA0A2F8DD014E1,
	ARObjectPlacedEvent__ctor_m29FB684BCD21DCAD7319DA47FB17585B4D0FB822,
	ARPlacementInteractable_get_placementPrefab_m34C8DF43AAAA5C330C49AAFCE7820462A5EC3083,
	ARPlacementInteractable_set_placementPrefab_mA76E2E795A374C8CF9942070E69C9A737B2DC460,
	ARPlacementInteractable_get_onObjectPlaced_m6C460822435E912121DBEA096CD4248293A61588,
	ARPlacementInteractable_set_onObjectPlaced_mCE8E93B983FCA98C617B4719711157206BD2B6E5,
	ARPlacementInteractable_get_PlacedObject_m9BBAA73F542063B4460FB0015DF2C3B4878C7C82,
	ARPlacementInteractable_set_PlacedObject_mBBC52679850877E2AF501850BA01CC22D00FE21B,
	ARPlacementInteractable_Start_mAC256A39EEF3A4B5EF23F4286850037CE36C4775,
	ARPlacementInteractable_CanStartManipulationForGesture_m85DEFF4C47446C3340D931140ACEBD2096E708B6,
	ARPlacementInteractable_OnEndManipulation_m2DEE8C7294C6960E2DEB7F23078E3A56DC648882,
	ARPlacementInteractable__ctor_m12430A2562FDC79102864C9C469D9743B84944D4,
	ARPlacementInteractable__cctor_mB9A813B343054FFFD6C46B7F5414CEC83BBBB970,
	StreamScreen_OnEnable_m250DD8C2FBA040A1B9F4C7B227BF529FF92A27A5,
	StreamScreen_OnDisable_m3D674E4730E4CF4958182F18B4A812593FD32BB6,
	StreamScreen_UpdateVideoInfo_m8DBA33C7138C8E255CFDE884B08E7AC5738A3444,
	StreamScreen__ctor_mA5DF26C0B0C9C3276C76FB841EE5BB98D14F0D84,
	TapToPlaceStreamApp_OnEnable_m2FACE137E41F59F4988DB52B5CAFFF286EAAFB54,
	TapToPlaceStreamApp_OnDisable_m8DD87DB7655F3C340A9CCCE9659FB4118D3270A0,
	TapToPlaceStreamApp_Awake_mA8BF3D0EAE252A3299D8D682079FDF70C5DC52B9,
	TapToPlaceStreamApp_Update_m96AA99C4F6635B6DA5DFABC1B01182160C5A2799,
	TapToPlaceStreamApp_CompareServerTime_mEB6B7E160EF576EA75FFA369E8D0824EF4C08E80,
	TapToPlaceStreamApp_UpdateTime_m2FCBD23EA09FCCA6946D1EE41F1F75BA3B86EDA6,
	TapToPlaceStreamApp_ObjectPlaced_m6B56B16571F87B902ABE4F398A1DB47DB31B45E2,
	TapToPlaceStreamApp_FadeOut_mFA3C230BC1C6837C8045719BF445856318CBD7A3,
	TapToPlaceStreamApp_EnablePointPlaneTracking_m2AF0D5DD1B21915EB84FE710BC27A58E874B41B4,
	TapToPlaceStreamApp_DisablePointPlaneTracking_m4BC269FDFB8C55377A948E6C30E4B4C9949E70E0,
	TapToPlaceStreamApp_ShowCounterScreen_mAF73CB3E7C50CBE4E40CE2605CB5804B05100737,
	TapToPlaceStreamApp_ShowLoadScreen_mCCD7F7A8E9E1088AA296FA760FE4238366D3FD86,
	TapToPlaceStreamApp_ShowPlaceARScreen_mB07CA82C78508B916B85BA69C5D298F67273A70E,
	TapToPlaceStreamApp_ShowStreamScreen_mD7060FAD7F136BBAE2F90FCC103FFE992BDD91FF,
	TapToPlaceStreamApp_HideAllScreens_m90CFA2838FC984624627BC3DE4C508259ED85A2A,
	TapToPlaceStreamApp_OnStartButtonPressed_mBFE0FA80C2E31B2FFE747F7BC6193BD34C7B2295,
	TapToPlaceStreamApp__ctor_mD72CB8ED180EE138043AAB8ECAD84595B8012582,
	VideoFollowCamera_Update_m4B01DD6038F835E61AF9D323C62932CA0C27C09B,
	VideoFollowCamera__ctor_m39A8466074590400FF5680A89E47821323971D83,
	VideoStream_OnEnable_m7A382675CE297676EF3AA42EC7D00726FF042E9E,
	VideoStream_OnDisable_m465011F052CA1E6C5B540BF5DF20CD1C242802C4,
	VideoStream_Awake_mAA3A263F51F4B2EEECBBF3FC821376C1BDEFE2FC,
	VideoStream_FrameDropped_m88E7AECFD53ACF7681513453C16619DF9C7A374A,
	VideoStream_Start_mACD2E9D0AB7C3FBA5EC8F878438F3879F67E4216,
	VideoStream_Update_m82955553F7B5E58F2CC6E9A7C5455F82CE300041,
	VideoStream_ObjectPlaced_mD8037656A580A2CB06DEE42A70C914FA1441E339,
	VideoStream_PlayVideoFromURL_m7EE386EE83A68CCF0F94AC664F083C8D5E072F0B,
	VideoStream_PrepareCompleted_mF485ECE1C7198716739131816A6B01E3CCEED902,
	VideoStream__ctor_m644AE4BBFED2B549C40524FA8C127A2403C9B591,
	MessageHandler_Deserialize_mA9693BA8D2C9FD955FEA9DD8E48D55E6584BB8DE,
	NULL,
	MessageHandler__ctor_mD413687341FACD003432FE926B76CC1DE2E78EFC,
	MessageHandler_send_m0BF4951456C3CA50EEF785A982A6F10D92BD0C5E,
	UnityMessage__ctor_m76E68BAF631BE07953E806CA26C480BF23B2ED45,
	UnityMessageManager_onUnityMessage_mC3031C4585567E720F536DB4EE28B0C20AB8A7C4,
	UnityMessageManager_generateId_m39045BEBA86C4467AD5549DFA0DDCDF9A7A9CB89,
	UnityMessageManager_get_Instance_m3571F06844422C9D5B2ADE29D69AE7B9E63ACF16,
	UnityMessageManager_set_Instance_m25A5E4940172A7950BA2EED339C161A0C74B05AE,
	UnityMessageManager_add_OnMessage_m7B623FDD1EB187BC9593C933D5E01766FC8DB344,
	UnityMessageManager_remove_OnMessage_mE747C20C6838E183F2C60960D2C697D7997588F4,
	UnityMessageManager_add_OnRNMessage_mD1D6F59672DB48353711FBD7CC5A1C5573FF33FA,
	UnityMessageManager_remove_OnRNMessage_m12B8512E35DC119F3800C8C8A05442F9C0A19B5E,
	UnityMessageManager__cctor_mDD0387729BD393CF289CB737BC70BF82CFAC885B,
	UnityMessageManager_Awake_mCBF7274D38E90447257210355EEBED184FF0C035,
	UnityMessageManager_SendMessageToRN_m7FA689191F69A7BD1CAF2218D61EE8BCE156B250,
	UnityMessageManager_SendMessageToRN_m810379DB93ACA8FB4F37914CA49BA677BDE94E3E,
	UnityMessageManager_onMessage_mD1704644A461EFD311809BB58F82D36898713485,
	UnityMessageManager_onRNMessage_m47BA244DB7A9E9A2486007E2F5217A03FFFC1AF8,
	UnityMessageManager__ctor_mFB3651A2237E489ED8746D5B8FC5B5AB95FE7CE7,
	SimpleRotation_Start_m92FD4E0D2D86410CADDBAF345572BD88BA16EC4E,
	SimpleRotation_Update_m7C8026B0F80C7F6E6E52DCE1848658D8CE2F7036,
	SimpleRotation__ctor_mA92E3B8B8BDE059266EE4CBC0FFDA04A80A341CE,
	VolumetricLight_add_CustomRenderEvent_m5F578D63BA4FE7C5EB24C8EAA9DA8A6CF3A27E4D,
	VolumetricLight_remove_CustomRenderEvent_m17FE11F5EF66E93327F6000F8C286879FEE4BF4B,
	VolumetricLight_get_Light_mE13DE46B4CE49D1DFF8EB2E6A8424C2C96D554B0,
	VolumetricLight_get_VolumetricMaterial_m62B71FAA82F843072613663271797F37F849EC4C,
	VolumetricLight_Start_m0FB5FB04760E281D3768D82E79CEA039976C04E2,
	VolumetricLight_OnEnable_mFF31A3523069C4B4F3BF99B0994EA150C2A440E5,
	VolumetricLight_OnDisable_m3D4F13D8B01F89C7A7EFA70D155089501B9D824F,
	VolumetricLight_OnDestroy_m33B9A828BAA1D70645EC459623537C215E8768A9,
	VolumetricLight_VolumetricLightRenderer_PreRenderEvent_mF1B9F6D6C44948EA8BEEE6D2E1E0FC4FDF85C917,
	VolumetricLight_SetupPointLight_m9A6001320D9196313892DA54B048256E27E6EA38,
	VolumetricLight_SetupSpotLight_m66E51E57DCD619F710E8FBAD4ADB3816488EACA3,
	VolumetricLight_SetupDirectionalLight_m79F401CEEFD8C459A34CFDDB30F28F88D2B99863,
	VolumetricLight_IsCameraInPointLightBounds_mB935C28B4C4934B3A31DC6A5E979CDC1DB49D9BF,
	VolumetricLight_IsCameraInSpotLightBounds_m0C01AF49DE1D2E9C8CB5DC9CBDD1690FCC724C26,
	VolumetricLight__ctor_m8DBB74ECBDB728246D019E0EBA4B9DD740026B45,
	VolumetricLightRenderer_add_PreRenderEvent_m46F9DE23B194053E3FF2C6C4E28EB023FBA163E7,
	VolumetricLightRenderer_remove_PreRenderEvent_m1387FDC15F430340A9A4271FE6E44F8ACAB45A71,
	VolumetricLightRenderer_get_GlobalCommandBuffer_mADC9AFC324D1F911F36492D8D5C8B0D428502D8F,
	VolumetricLightRenderer_GetLightMaterial_m76DB6BB6B7C61E6B7507F78ACD0365FCAA0E28ED,
	VolumetricLightRenderer_GetPointLightMesh_mB2EBE424F5B7CA8E0557229361177E9ED2ECEE25,
	VolumetricLightRenderer_GetSpotLightMesh_m8177173207F35013308B4510BCCB71123C8E622B,
	VolumetricLightRenderer_GetVolumeLightBuffer_m3F6D02E1EDFBF5E4E9A6F15A5FFE3E4A4210D6FF,
	VolumetricLightRenderer_GetVolumeLightDepthBuffer_m7BBF777031ACBC96CA1F93058046925CD9F18F60,
	VolumetricLightRenderer_GetDefaultSpotCookie_mE0FB42A6BC3BF4B487596A47210327383E2450E6,
	VolumetricLightRenderer_Awake_m0C087A330DBD21C1D98B54FC82F8C6234468174D,
	VolumetricLightRenderer_OnEnable_m75E74068FE961AAB8508F366E1C1ABFA9F5128EB,
	VolumetricLightRenderer_OnDisable_mA2E01460A0C511F0CB85780D5DFFC283E69B6EE5,
	VolumetricLightRenderer_ChangeResolution_m0E875395EC88C49074DBE346D115E3704A3F6EBF,
	VolumetricLightRenderer_OnPreRender_m64494C7F39FD8D66A1565CC7EAD6EFF172DEFE5E,
	VolumetricLightRenderer_OnRenderImage_m89C9C4C4E5BDC8B473FC56049F02CF5B94D81C68,
	VolumetricLightRenderer_UpdateMaterialParameters_mC6D299CB253E20588054FF08B1C5D2E20181CB2C,
	VolumetricLightRenderer_Update_m1387974B3CA934B288E55392C6BB0D710A997781,
	VolumetricLightRenderer_LoadNoise3dTexture_mF11E9CF22E40F5108C2A616971249C1CD9A3C3C1,
	VolumetricLightRenderer_GenerateDitherTexture_m5B5032722588872701A98ECA252654E306A57A6A,
	VolumetricLightRenderer_CreateSpotLightMesh_mBF678FA1E816ECC7DF89333EFA21CA630EB641BA,
	VolumetricLightRenderer__ctor_mC32662CA37A430D5060785F4D0EC6B2FD5BF21A8,
	DisableDebugPlaneOnDevice_Start_m58E89A7A64CBD4B35949E3DEEA470CF94E84E3FD,
	DisableDebugPlaneOnDevice_Update_m30E5344FEAD531907B625E756FC9758259D4C262,
	DisableDebugPlaneOnDevice__ctor_m2BB46F0FF2BFCFD7A102A3C8C5D824099FC8D4B1,
	PlaceOnPlane_get_placedPrefab_m8BE503732673256269CC147604214CC9CEC5A5D7,
	PlaceOnPlane_set_placedPrefab_m601FE0C886487501C434553A8871D097BFEE0133,
	PlaceOnPlane_get_spawnedObject_m23014A9362CFD88019EB00F266ADC5580C3BF8C0,
	PlaceOnPlane_set_spawnedObject_m037A1D5F8BD6B8B918BED3BF5C575E4A7EFB0B07,
	PlaceOnPlane_Awake_mE85A120DA51619398754C88AE48C78A329B5D265,
	PlaceOnPlane_Update_m4905A7CB017E0A01BC99DACBBDB168AC3A96345C,
	PlaceOnPlane__ctor_mECF29DC898119BD47C75A1D3845F362668A10AB0,
	PlaceOnPlane__cctor_m99BEA781E46A1FB9FAF672FAF883E92F9B1D8E4A,
	SetTargetFramerate_get_targetFrameRate_m579F2515B47C6AED7C15840378E09DCAC905BA0A,
	SetTargetFramerate_set_targetFrameRate_mDB1BDA3814C4D100425882BA156D4282E6FD8CF9,
	SetTargetFramerate_SetFrameRate_mE68C50A15CF1D5ADD34AA2C9F557F507D3B846BA,
	SetTargetFramerate_Start_m1F24F3BD2EB04D89DD18A850B3977190DF16D55C,
	SetTargetFramerate__ctor_m2194CBB6140143CDEA43A0AD1C33B562CBF8441B,
	SwitchPlacementPrefab_SwapToChair_m244ECCC5B50418449483DA771316174603B2F113,
	SwitchPlacementPrefab_SwapToTable_m12EB75430BD66E3976E37046FD67D407C720B247,
	SwitchPlacementPrefab_SwapToKitchenChair_m23D79DAA08FC45B598A9BE6970784E2559D731DB,
	SwitchPlacementPrefab_SwapToKitchenTable1_m68ED9A37ECF624211743853E30F2D79CAB87F216,
	SwitchPlacementPrefab_SwapToKitchenTable2_mCFB6732E7D62DD2BD5DB1610B61C3DE108CF5E3D,
	SwitchPlacementPrefab_SwapToTVTable_mFF3CCC4A5B984569CF2CED5B74C1B062AEAE7D09,
	SwitchPlacementPrefab__ctor_mE2825C15E5C8BC19BCADD6283A96CC254E832587,
	PostEffectsBase_CheckShaderAndCreateMaterial_m1515D02A58527017FACB2B6AC601B5E67B65C865,
	PostEffectsBase_CreateMaterial_mA2EDA33D7CD6FA380975DA46597540AAB17B89AE,
	PostEffectsBase_OnEnable_mFEA4058D703A6A068ECFA899FCCF6CEC8E742967,
	PostEffectsBase_CheckSupport_m33F744872944BE0FB9A9FBF5FB73CF1CC62BD012,
	PostEffectsBase_CheckResources_m31A44EE19F985DCD4D3242F9197BF1435F1C8094,
	PostEffectsBase_Start_mA2E9CD553BD5AB2AD1963EC250854408434701F1,
	PostEffectsBase_CheckSupport_mB308BE6390C0474C92E742A561F90423C1502C04,
	PostEffectsBase_CheckSupport_mB672E1075EC2C7E643A512D22CFB3000CC681636,
	PostEffectsBase_Dx11Support_m51594DC020FEA76B63FC6804CAB21D88B8497C75,
	PostEffectsBase_ReportAutoDisable_mEFEF901F4F2DC5EDBC11340F930760EF8B10645C,
	PostEffectsBase_CheckShader_mE87A8B176C2F6264E568AD9EFFE7A64F9057CB43,
	PostEffectsBase_NotSupported_mD5139A9AE6103E7BF485626371A61B4C146C035C,
	PostEffectsBase_DrawBorder_m3B6891159B6BFFA4621F38DCE1648176C0DC4C2B,
	PostEffectsBase__ctor_m440C9B609EF88230A2EB266FD3E6C624431E1368,
	Tonemapping_CheckResources_mF10047DA83F89CF8C93C7A263245A501404DBB95,
	Tonemapping_UpdateCurve_m3ACD656292CF96ECD6A1F684554D94D44EFDF1C7,
	Tonemapping_OnDisable_m39886645752B0190BBB4A5643C3941E57C591677,
	Tonemapping_CreateInternalRenderTexture_m57DA5B1E686F03D4C4E99D4920DBC5AFAF1835AF,
	Tonemapping_OnRenderImage_mC820173AF7A5683200AC7D0CA2A68FB940BDBAA0,
	Tonemapping__ctor_m37B1A6CFAB1CBD05E8FB154AAED049B7FEB40E01,
	UIGradient_get_BlendMode_m1168901DBA41CF9361B7F7EF09050A1F7DC8330A,
	UIGradient_set_BlendMode_m3F8C4653A82F6795062FAFD08380AC7A423A5494,
	UIGradient_get_EffectGradient_m6300D753D94AE39A72369CC1A5194CD61D9BBD72,
	UIGradient_set_EffectGradient_m653BD6E0C53B3AFD93885E08B661C89A19A5509A,
	UIGradient_get_GradientType_mFF299EFB2F678C4E1F765BBDB960DAA9FD546191,
	UIGradient_set_GradientType_m3D88A70BFBFA4ED2BB31906FB8972325AD6180FA,
	UIGradient_get_Offset_m56CD9E0188D76A3E58FE39885A92793F20276B2C,
	UIGradient_set_Offset_m7C26071BF10274F114B6B8A1EE73201AF300B869,
	UIGradient_ModifyMesh_m42048F4A65BEDDFC6089044BEEDB9E3397547B72,
	UIGradient_BlendColor_m14F90F0EB9C55D35BD335A72CAD6159E33D41049,
	UIGradient__ctor_m3CB1CE1543D5DE89949E3AAA2D64184E941D4F0B,
	AnimatedIconHandler_Start_m83A633F84879EB3896A3E36607E53D846CC83065,
	AnimatedIconHandler_ClickEvent_m3FEA8D973ACD7A71D23CA5CEC5B1F575A6E36464,
	AnimatedIconHandler_OnPointerEnter_m826017ECDFDE4610EEAD10999861FFA64BB517D9,
	AnimatedIconHandler_OnPointerExit_m48C0BBF67BE2A5D39D3B4CFD995209B1F809B8A8,
	AnimatedIconHandler__ctor_mD306EA3C98F80C29FAC1FBD78EFEC18111E787B6,
	ButtonManager_Start_mC4D90AFFDE30D638AC31F2EAE75D4E8AD1C8D1F3,
	ButtonManager_UpdateUI_mAB64F1349A616F1FE987D878794C866F65E28859,
	ButtonManager__ctor_m2E9A78987D3D370B68AEF2654676032F5C39756D,
	ButtonManagerBasic_Start_m3B4D414931820D9CBDD7B4C7062032B6550118B2,
	ButtonManagerBasic_UpdateUI_m0214862E81488419B458D1CDA980E31406E847C8,
	ButtonManagerBasic__ctor_mD4DD378461B235FFC19FFD696F1FAC0CFF5D6D18,
	ButtonManagerBasicIcon_Start_mEDEFE353C5C0D4802644674A209C4D962A01E64C,
	ButtonManagerBasicIcon_UpdateUI_m31B6D7E205E8E16B3C53F88FD020D642689D71DA,
	ButtonManagerBasicIcon__ctor_m33A15CFF1ED3FC2EB97480F7C57E238FAEECFD56,
	ButtonManagerBasicWithIcon_Start_mFF9D86D3D22271E0921F147ED5425DFAD05C0299,
	ButtonManagerBasicWithIcon_UpdateUI_m9FBC1B87B3099897916839379B20E947973A4213,
	ButtonManagerBasicWithIcon__ctor_m452D087EA1D48074FA8E04EACE3BB764F158D25E,
	ButtonManagerIcon_Start_m8D4A54D859213C72748C0E3478BD95B15516AF50,
	ButtonManagerIcon_UpdateUI_m452285692A9BB97DD9C870C6C9D7734049256681,
	ButtonManagerIcon__ctor_mDAEF160669934DF94E545AEE8353CF10871AC4FA,
	ButtonManagerWithIcon_Start_m68DEE1D411D5259627CF0897113E30F129366A67,
	ButtonManagerWithIcon_UpdateUI_m009BA1877E2B35C12B5CFEEE2328350D3D1DE9C8,
	ButtonManagerWithIcon__ctor_m727659356C3EB16C800D13B4538F517E2DE6BB38,
	DemoManager_Start_m2AA76E0B6D76F990304356A00B6C7FB7F29FDDC9,
	DemoManager_Update_m86D4E49827143B9059EB02A83BAFC318EE85BFBF,
	DemoManager_EnableScrolling_m8AB80D35132F7BA29BAAF1F383E2EF7D1449CFE5,
	DemoManager_DisableScrolling_m41D172F9B5A886F977F82014C60A00AED4F796D4,
	DemoManager_PanelAnim_mA20E49EA8D56C0F0546C5EEAB16E8B65CFE676DB,
	DemoManager__ctor_m439A173D74C6021FEC756C932C8970D37528C883,
	DemoScrollForMore_Update_mB4AE120D37A338B490540F8CB4EC243E2C0F9F8F,
	DemoScrollForMore__ctor_m0D234EC80A0D14413B6F4BFA8F925397E61E88C3,
	DemoScrollManager_Update_m14614A8609890DFF1E6FC8554E7C116836B6CC6F,
	DemoScrollManager_GoToPanel_mFC97815D2C104E04325E53E1AB0225703DFFAABA,
	DemoScrollManager__ctor_mFE9D9A55AB6D2B40E3ED2837AA4FCF9E4261F493,
	DemoTopButton_Start_m0D81501992E3B1D35DCE5ECB987B0B6E2C7B282F,
	DemoTopButton_OnPointerEnter_mF523EEB206750282E233CB8EB9FFF97A869BD003,
	DemoTopButton_OnPointerExit_m5226C43ED047BE58AF88A653FED3F7C31863CE5D,
	DemoTopButton__ctor_mF1F346F8CC60102DFEF568760390905D5A24DAED,
	DemoTopListShadow_Start_m7FAAE60AEB23CF62277818DF5ABD53CD817D5652,
	DemoTopListShadow_Update_mBAFAED5C58391468A1D62410502D56EC612B132B,
	DemoTopListShadow_ScrollUp_m32BFCCD649493BDC2DED47BB8B51081A0E601385,
	DemoTopListShadow_ScrollDown_m5DD358BABCF3191D8C9D2EAAED6AC95DE29E6008,
	DemoTopListShadow__ctor_m570C56429CDF41012DE141DE9E70E887C55699CB,
	LaunchURL_urlLinkOrWeb_m32EB9AA547A020ECB9A770BF5322DC49641D7CB2,
	LaunchURL__ctor_mF49C6E2C2E00F6C6780ED9272E60F64344489E28,
	CustomDropdown_Start_m9B8C92CEBCFCEAE2FCD4663F20A4B1A8E11AB8F4,
	CustomDropdown_SetupDropdown_m345C94CA17B4BD50BE27A95F4ABE370A826C3725,
	CustomDropdown_ChangeDropdownInfo_mB46280CAF0831A45EC8725308EDC91F5A9A34520,
	CustomDropdown_Animate_m39ACD9CCBFE2C02E2E989FCD3758887F9AF59C6C,
	CustomDropdown_OnPointerExit_m5A12ADCC9F4FBE84D95BA5CFDB1455F79A1B2A34,
	CustomDropdown_UpdateValues_m9E09A21FE49F7CF2DEE8C2754582F70CA0F41DD5,
	CustomDropdown_CreateNewItem_mBF9845837ABDABD33BAEB3157667F19E506D38A7,
	CustomDropdown_SetItemTitle_m50E46AE796D7DCF0A4CBEB108A3543A563C86F26,
	CustomDropdown_SetItemIcon_m188771491EFB456C1377715360F9EC039D2F0301,
	CustomDropdown__ctor_m76849B9F95D77B27767982C6971AF629270A2D25,
	DropdownMultiSelect_Start_m5FD64747E865E7BA97007EDF55F4F68EB1467F69,
	DropdownMultiSelect_SetupDropdown_mC1ECB49315AC3D76BCAFB94F4DABACC894D09149,
	DropdownMultiSelect_UpdateToggle_m73A0416FFDE662C4794C3A8592D4FE4EEA7C4E3D,
	DropdownMultiSelect_SaveToggle_m323B65B6A34C8FA5F39E0E5510325E076D212ADE,
	DropdownMultiSelect_Animate_mEAE2312A27E7D9B9209D156D50B77EDCDB38B328,
	DropdownMultiSelect_OnPointerExit_mA8E92756B21CFE07C83056BFCDCCD324162C314C,
	DropdownMultiSelect_UpdateValues_m0F2F71F8AF3D08828C3265979F5449773B16FEB5,
	DropdownMultiSelect_CreateNewItem_m5ABA3AEEF4D5C6EC8DC192E8865C9643AEE84739,
	DropdownMultiSelect_SetItemTitle_m5A8578FFF97BB9085C0D867318B2C229314EF8B3,
	DropdownMultiSelect__ctor_m13126F9DD1E31E70B74036BCA4CF092B37F0F885,
	LayoutGroupPositionFix_Start_mCD4A4C91BD865A793909A9BD68E80D223BE1D0E9,
	LayoutGroupPositionFix_ExecuteAfterTime_mB66EBE5D8FDEB47A9F1E38BBADAC354E9EB24469,
	LayoutGroupPositionFix__ctor_m075C80DF21585D1742507461F0ED2AC0A0FE0A7F,
	UIElementInFront_Start_m28DD4D73C03D39F0FE86E509D979511616CDF12A,
	UIElementInFront__ctor_m583C22F19C9C13972AC38BCA426A0936518BD68B,
	HorizontalSelector_Start_m420FDDA862FD0DA0721BF66DD7C42CE445CF7532,
	HorizontalSelector_SetupSelector_m969D2AF256C44F2BC85DED7849358898D5D0A837,
	HorizontalSelector_PreviousClick_m445E254CFE108885D49608D6FFAD2A3EFCD90E76,
	HorizontalSelector_ForwardClick_mEBC38D0148E534CBABFCA5D4DBDB5492A873A5F6,
	HorizontalSelector_CreateNewItem_m25DAB314235C4082FE0D4442C8D944D209062B56,
	HorizontalSelector_UpdateUI_m41747A31D5D80AC2CF36C3CB2058348B0C6DDD52,
	HorizontalSelector__ctor_mD5CD83C2578C980A40DB8C556345B27FC204AD58,
	CustomInputField_Start_mE6F9065CE11326E68BB86FE34C61651649FD2C96,
	CustomInputField_Update_mB30BCE2093B9B495D18B263711AE3BCF0AFE1FF7,
	CustomInputField_Animate_m73372C2FFD304B4483DDF5751085BAE4C2C45520,
	CustomInputField_FieldTrigger_mA24AC2B35F254EF8ABD4A9564F1FF25CF2CB78A7,
	CustomInputField_OnPointerClick_m1C1FEC207B42529258CE3E95DC5D10BF7CC02388,
	CustomInputField__ctor_mFC7784CD17A6409C274B1AE513FC39A911A144E6,
	ModalWindowManager_Start_m91BB8D746149045752443AF1283ED3DF5607AF77,
	ModalWindowManager_UpdateUI_m95FD97AEDF15968D99B35DED9D13817AF5BDB80C,
	ModalWindowManager_OpenWindow_m4C9606BFDBE313C217F0545B0274B10CFF849119,
	ModalWindowManager_CloseWindow_m609F0A8E57B4EEC3624BA41FE54FD053C93B670A,
	ModalWindowManager_AnimateWindow_m3403B78B60DEAB42AD37D5A5D2CAFA7C981FBAC4,
	ModalWindowManager__ctor_m8B817291D67F2B4A592D4EC0513D699BF21286D7,
	ModalWindowTabs_Start_m373A46F736A1F54ED2A9E8611EDEA798D77AD322,
	ModalWindowTabs_PanelAnim_m681BCB77B2428F0325136BF9DB08D7A3FBD172C0,
	ModalWindowTabs__ctor_m42AC1B2285726B608DD2318AB4F0B676C70F9F52,
	NotificationManager_Start_m866E79950CD6A33099E3B8C186C3D77D66D82758,
	NotificationManager_StartTimer_m0E3128E26D9863C0FD7B066BACDBF13C00554BA0,
	NotificationManager_OpenNotification_m7653433D2486400A870C827583336F4710F8E50E,
	NotificationManager_CloseNotification_m015B9BED28D9232BEBC11F0F311500E26A3C0715,
	NotificationManager_UpdateUI_m3C65CB7048E854BE3496B3221B9426C30E1DCA89,
	NotificationManager__ctor_m549C96C90315034A3D8B8227611816733DA53A72,
	PBFilled_Start_m592E9A99C5B81E00E3774629A3AF3056453A9D54,
	PBFilled_Update_m3283151606AC4B30E165115B25C6BB6781F166BA,
	PBFilled__ctor_m9404A96DC805A4536A5D5BF274158D57C372ECA0,
	ProgressBar_Start_m130112E65882CC2B4553945EC01C7FB74197D9D8,
	ProgressBar_Update_mF9D95F7B60D3A8D82C6E2B92E204CB2408707E39,
	ProgressBar__ctor_mEE391D1A30B63D9D4FEA3EFAA1490979A63776AB,
	DropdownSamples_GenerateItem_mCECF868A2026E4A9BFD0CB6EF98F885FE8225CB3,
	DropdownSamples_GenerateListItems_mC4DBD6A333A7CCF3C8980532756047ED8AE967BD,
	DropdownSamples__ctor_mCEEF1B1FF601440F1114015A22E2368E3E65DE97,
	HorizontalSelectorSamples_GenerateItem_m85A74F2EFFF8F6D850F67F29B8707476B7036050,
	HorizontalSelectorSamples_GenerateListItems_mA9E51EA70C5761E813DBB3072B19BC9FDF37F011,
	HorizontalSelectorSamples__ctor_m7F08CF41AB31D5B936693433FC47FDD7FF016A38,
	RadialSlider_get_SliderAngle_m2F68FE0B6FE806DEE30DDD568B81559B1A520680,
	RadialSlider_set_SliderAngle_m5DEC6FBBF6E17E2838629AFC4A6E1F3D21D0F47A,
	RadialSlider_get_SliderValue_mF5E2EE95ECF52F6ACF8026B8F41849481BDA3188,
	RadialSlider_set_SliderValue_mB0F70E928770EFF49B9FFBE3AE33E4A5ECCDFAFA,
	RadialSlider_get_SliderValueRaw_mCB5809B3441D775C705FD7957D0201B839931455,
	RadialSlider_set_SliderValueRaw_mE49E76059E4C0423774945DAB3E70D56D344630E,
	RadialSlider_Awake_mB1F97E796CF9B60C7BDA342A9C447C016D1EBD7F,
	RadialSlider_Start_mC632D09CA4BBE3A83D98114BF81E6AF0FD25996C,
	RadialSlider_OnPointerDown_m65EB96C505611DDB05690492EE2DC6C39D2F0442,
	RadialSlider_OnPointerUp_m652E4D2FC8304679AB16C4ADF5A3CD9F0CC2399F,
	RadialSlider_OnDrag_m64B5A32508FB49437ED6FD483A348A4C56818519,
	RadialSlider_OnPointerEnter_m61E5A7678601CB3E877618F03F29E5E79766FBC5,
	RadialSlider_OnPointerExit_mE4B4DC0EB62E54B78E638B8963DF37E7BB5F4728,
	RadialSlider_LoadState_mCBE4C9B210442E2636052A8A21D139AB7E8D2A6E,
	RadialSlider_SaveState_m76609516117861BFFD30747925345966809BDFFD,
	RadialSlider_UpdateUI_m389B8D8E3D0C04876C280031CE0C501896D89401,
	RadialSlider_HasValueChanged_m6D160A2C32190FF558D2EB1E7FD227B7F913999B,
	RadialSlider_HandleSliderMouseInput_m0AE7C7027A8A5B2F8707ADD8FACE71A56BEDBF03,
	RadialSlider__ctor_mB3D34D67AC1A2F5B77CBCE757894DE5766D33EB3,
	RangeMaxSlider_Start_m357BC53DCAA3D9762657D1EB363AB35A119880DC,
	RangeMaxSlider_Set_mC43F85DF34EF3D19FD61C35ACA2473078545CF23,
	RangeMaxSlider_Refresh_mFC4F1CA522DE8B7AA74588A862E09E19932655B5,
	RangeMaxSlider__ctor_m706DEB2EF5B26827899085C1FE4205B19B92512A,
	RangeMinSlider_Set_mED20494CFDB176D6C3538E3C49B01B2168BD06E1,
	RangeMinSlider_Refresh_mC0E7ABC2DB11EA614DA7D15F34E695163311E554,
	RangeMinSlider__ctor_m666CFC794D0D280458E380B8D1EF3165CFEBCF74,
	RangeSlider_get_CurrentLowerValue_m13B0BF63AE92697E0D52D0C96E644E191E2EF4D7,
	RangeSlider_get_CurrentUpperValue_m6C96F75153AE3385A1A6B738A24CA220F4F518C9,
	RangeSlider_Awake_mB858EF2216638FFE428BBCFC0D15B05E58F619B0,
	RangeSlider__ctor_mAAA1444242DFC9E7D1CC485075DE10A5DAAED47D,
	SliderManager_Start_m3BC26542ACDC3A5208A63BB1F09FF3AB4746DD3F,
	SliderManager_Update_mAD5F4697168CBE7925B754435C3371BC3382F493,
	SliderManager_OnPointerEnter_m2F3A80A1E30CF4CD56F526549C5848BF440AD775,
	SliderManager_OnPointerExit_m6E7DD08F9D4D472DD9509D17822241DF6DA87DF9,
	SliderManager__ctor_m43D3FF258686EAE388C393C696165A65FF760962,
	SliderManager_U3CStartU3Eb__13_0_m684A20E715F2631D45EC532CB4F1FAB1189F89A8,
	SwitchManager_Start_mE4BB73F45A887BF0458E66F226B8D9001F711D78,
	SwitchManager_OnEnable_m1A68870C73DE4C2821FD445AE4504B9974B95FE8,
	SwitchManager_AnimateSwitch_m4AE2A0F1CF070E8C797F38F19B995FDA213FD0F0,
	SwitchManager__ctor_m251356A16CE706E7747FD971E80B37FA393C3388,
	ToggleAnim_Start_mC125F2E043738F2FFE36E167CB7F760EDF890912,
	ToggleAnim_TaskOnClick_m1B19B8989377304BC0909A1FB9DA30EFC23A4C1E,
	ToggleAnim__ctor_mCA4543FA577F4D634241E32ECAD681209EA50825,
	TooltipContent_Start_m84BF7C415D28B68B7580FEC496CE78E70C511438,
	TooltipContent_OnPointerEnter_m05E49892F8E3272EDA9413AE6A6FA24E97033A3D,
	TooltipContent_OnPointerExit_m050BA890120C62A09E7DB90B48E6D689801F3FB4,
	TooltipContent__ctor_m51A12AF5B7A61DA992568EAE04D9D0C651B88F83,
	TooltipManager_Start_mD3F6A959EF19264F6B5EC37370AB872E8235D2BF,
	TooltipManager_Update_mE12F24E23B78F7763BCE16D77FB7EEF9C2AE5C85,
	TooltipManager_CheckForBounds_m9756D03FCE1665D41F5FE9FFD72CE0C488119076,
	TooltipManager__ctor_mEEE42A4A2C7A6E82BF707EDA33BFDE5AFB0672FD,
	UIManager__ctor_mEE16638C3129624572B2E0EAF2FA6CBB54FE6553,
	UIManagerAnimatedIcon_OnEnable_m08AD9B127A015FF4DFB753F369B5E797963EF068,
	UIManagerAnimatedIcon_Awake_m26A38363A9FFB99F25FE936C846663F297F4EDBB,
	UIManagerAnimatedIcon_LateUpdate_m9DB317D0383324A7572F11101165A6C8D564D3F6,
	UIManagerAnimatedIcon_UpdateAnimatedIcon_m7AB60B9371AEF2EBF50A2F1C446B37F1CBCB79E9,
	UIManagerAnimatedIcon__ctor_m9FD2C6D71277E573903C65313A22C6471341C510,
	UIManagerButton_OnEnable_m6D22F8C15BB035DBDE96C522EF424CE6CBA2D2E3,
	UIManagerButton_Awake_m8AB5038399646DF59763F2BE97BBA1536CB02FC4,
	UIManagerButton_LateUpdate_m3ECCFC4FA77CFF27615F0C4E5DF710F77ECAA234,
	UIManagerButton_UpdateButton_m748F7B7C43DF77160A09E9EC87A49BD4767E14E0,
	UIManagerButton__ctor_m7BAF8F359A03B8EC4C7951CD2563208A6B2EFDC0,
	UIManagerDropdown_OnEnable_m1D71EA90AADC812ACA0986AEA04E920C4C2697FD,
	UIManagerDropdown_Awake_m399BF46E83533EC32F219B528937B15A963510AF,
	UIManagerDropdown_LateUpdate_m5D97FA0A3E3165B24DF0E5F51A27F2F159BD85CE,
	UIManagerDropdown_UpdateDropdown_m3075775EFC1438B7BC1B687EAED376A988142DFD,
	UIManagerDropdown__ctor_m500E146E169FF6A67AEA4AAC1B41EF1427325649,
	UIManagerHSelector_OnEnable_m1C2D92798600E655E234AF62C46ABBA5D989DFFA,
	UIManagerHSelector_Awake_m03A6BF8A35915216DB792FB9C901358678A0781C,
	UIManagerHSelector_LateUpdate_mB33CF2640A40E2E3603A9FD361497AA169DBF237,
	UIManagerHSelector_UpdateSelector_m1564B1D4E43E67F4388C001E65A021A38A63E9C4,
	UIManagerHSelector__ctor_m63236A6406C84868E412EDC1DA7CB7F346C75C7E,
	UIManagerInputField_OnEnable_mADE97BA393CFD0C64ED0E27AF75C03BED37A3A81,
	UIManagerInputField_Awake_m34B352211E6A380E5016E701DB92C40E8246F641,
	UIManagerInputField_LateUpdate_mD78626A0398CAEBE832AA272926624C133BE8311,
	UIManagerInputField_UpdateDropdown_m7263BE114AA0CF246D0D7110C7B220D9C230CEC5,
	UIManagerInputField__ctor_m0865F6C6CA881FC4EA473BAB5BC85129A3F0BBF8,
	UIManagerModalWindow_OnEnable_mA42A2373B6116B36AC8527FB13E7283DE014250F,
	UIManagerModalWindow_Awake_mAEAF4B2A53D9717A98C2D74D1D1C57A066BF6521,
	UIManagerModalWindow_LateUpdate_mFFF55907252B363BD4BBEE19B17EC369B989B578,
	UIManagerModalWindow_UpdateDropdown_m4AE048C7B1CE3D73B042B49813106F37599BAD7E,
	UIManagerModalWindow__ctor_mA10CCAE7B399FD7582C356CE9112C775F69E7F08,
	UIManagerNotification_OnEnable_mE7F57DF3849004EA470BD5FA862B7348728DB242,
	UIManagerNotification_Awake_m9E8080359C1C964A54CFCB89740464848A31B5F2,
	UIManagerNotification_LateUpdate_mA6AE864AAB448ED397028851E6ACD5AF22C94EAD,
	UIManagerNotification_UpdateDropdown_m0CDFD09F5C5A86C06141C29007DB1D1B61225A47,
	UIManagerNotification__ctor_m6FE5D45DF942F2A04065B0179AF8787F4FE30259,
	UIManagerProgressBar_OnEnable_mF1EB166E3E1E04CCB9AA0459EFC8C6860FECD852,
	UIManagerProgressBar_Awake_m55A57026E070E9B2663A84CCF35A6C283CF13277,
	UIManagerProgressBar_LateUpdate_m65559D0DE21CBE40AF4E237D3DD0790B23B3A97A,
	UIManagerProgressBar_UpdateDropdown_m8A5B495714218F0400B177074B18CBC9F2117134,
	UIManagerProgressBar__ctor_mD4FC98406E640B02ABF1589EB17633C82B593DDD,
	UIManagerProgressBarLoop_OnEnable_m7F0D34FF8E6264DEFB2F55486B4348D4FF98248C,
	UIManagerProgressBarLoop_Awake_mDA23DFF33D2B9F8D906FFF5396A098457F3077EE,
	UIManagerProgressBarLoop_LateUpdate_m9F91871EE3D2D62CDB894431DA4ED43709343F5E,
	UIManagerProgressBarLoop_UpdateDropdown_m74F043FC3DBA662E957E74AA0F8AB965F0F4BE1E,
	UIManagerProgressBarLoop__ctor_mF04DC25B44CB38BB6354729190CA3B1A6BF8B20C,
	UIManagerScrollbar_OnEnable_m50C372ABC6487D823F380C155F5A22F321E2ED68,
	UIManagerScrollbar_Awake_mAC060DDA44B11151F1E1E9470E11AC67393683B2,
	UIManagerScrollbar_LateUpdate_m0AAD7F558DDD6E8FFDD853AE8180D5B12F0A3666,
	UIManagerScrollbar_UpdateDropdown_mBEA9080EB04A8AE1DF71FB23E136B1F75C641524,
	UIManagerScrollbar__ctor_m5C64EFC4569014C3E7E8C42F135145A2724A23C3,
	UIManagerSlider_OnEnable_mE7A55268926485AF3C10E21EDAA5C71035031E26,
	UIManagerSlider_Awake_m31327220FC1F214275B73473860181906E3D8BCB,
	UIManagerSlider_LateUpdate_m290DFBCE85B2030BCE3D4ADA14543599E4618E27,
	UIManagerSlider_UpdateDropdown_m87A22C513A1B8E17F06310B2867212C3A1235B12,
	UIManagerSlider__ctor_m3E9960F74EFE37E403612B780D976FC565B3FDD3,
	UIManagerSwitch_OnEnable_mCC6CE3740430A6C56377615BF70B66F5A6D09E32,
	UIManagerSwitch_Awake_m29756F27ECDDEF88C36021D9411305B115ED127F,
	UIManagerSwitch_LateUpdate_mE8907F9E00D486F10A3494808EB8A31AB5F43995,
	UIManagerSwitch_UpdateDropdown_m0E29FE475C8CFB85EFCBA4C9653BBBA4004ECB28,
	UIManagerSwitch__ctor_m2C49F0AB0236F65C6308F2B39BF2314A9219F34D,
	UIManagerToggle_OnEnable_m4F09FC4C25A1CFB9FE29732DECFBC6FFE6601D16,
	UIManagerToggle_Awake_m372F88317ACC58CA2492CFEFAF8F1F4662ED0D29,
	UIManagerToggle_LateUpdate_m596B7AD2D05CCB4B66FA18E8FCF12EBC043F4D2E,
	UIManagerToggle_UpdateDropdown_m6E55DB99150EF3F56AA98AF2C544442D82A1578C,
	UIManagerToggle__ctor_m53514BD5AEE83BE20E889EB0FBBC93B2A29B6856,
	UIManagerTooltip_OnEnable_mD318213FAD0650C88B2DE2854ECAEF4B1EBE1E78,
	UIManagerTooltip_Awake_m1FB0FBDAB9DADD274E6F0E7AE5DDCF4CB2F34323,
	UIManagerTooltip_LateUpdate_m2374E53CA127AE70038499E429D0FDB2D23B7571,
	UIManagerTooltip_UpdateDropdown_m3AC180B35BFA790354DDAD2505AAD20DC0130B95,
	UIManagerTooltip__ctor_mF558B7D7B87BD7103693F535B7EFED8AF263326E,
	WindowDragger_Start_m8732312CA9EE4AF03A3BE29CB52CC917F225542B,
	WindowDragger_get_DragObjectInternal_mD24357FC946129148D9B2BDB8C385567EF5569C4,
	WindowDragger_get_DragAreaInternal_mF05C62C00BBF784FDF184F1A13FC9688AB3C9956,
	WindowDragger_OnBeginDrag_m8C583486665B7D7656AC1BE1AE9C21CCD93F3F5B,
	WindowDragger_OnDrag_mCDCB4104FC5721AAA3FAE96B7D5F4E4F15DB95C7,
	WindowDragger_ClampToArea_m5BC8A904A03FBE8E925EB2E445C605B497B6A98D,
	WindowDragger__ctor_m1AEBCC2027050C2A15D2184EAEE293B8D1FAE106,
	ARFoundationHelper_add_PlanesChanged_m49B80EA31B002073494813F6F7E133E377A3524D,
	ARFoundationHelper_remove_PlanesChanged_mF2C37669962AE51E979E2B50056C9A29E43EE4DC,
	ARFoundationHelper_add_ARSessionChanged_mB4C07534C1161D6DADAA3599AA32F0DB4C9F33E9,
	ARFoundationHelper_remove_ARSessionChanged_m22E839465B1EBF5BA6DBE1DB18BC9B22A7A0FDFF,
	ARFoundationHelper_get_RaycastManager_mC43B64FEEC43BF9F3DC1E54CC67CD6FED1021BCE,
	ARFoundationHelper_set_RaycastManager_mD03A583FFB7D66B751593C3BB080549DF7B3E138,
	ARFoundationHelper_Awake_m1A002F3DA637BD76005AACFD157F8A71DE62815E,
	ARFoundationHelper_OnEnable_mE18AE70D539C94064125B09D1CF19B63F4EAAECA,
	ARFoundationHelper_OnDisable_mEE18D5656946EA8C93D5D232A034110F2A7E568A,
	ARFoundationHelper_OnPlaneChanged_m5AE992453388D8D0C36B0D18F95D9673378C8F5C,
	ARFoundationHelper_OnSessionStateChanged_mC3F945145429648409915A5B176A8BD7C0604185,
	ARFoundationHelper__ctor_mA0FAA8E1A8AF1CE232A893F09F4E9B72DD8F48EF,
	DebugHelper_LogMessage_mAC9309DD0B62B95B56DB38D41E6185394F7A775A,
	DebugHelper__ctor_mEA8789D7A3E0E7B61D23C8841D95F86411E32CC6,
	DebugHelper__cctor_mFD751D3CBB1F1292B77246BC707F9669C0396B60,
	ArcadeSDK_ARInstructions_add_ARInstructionsStarted_m132824EE28453B46997CA918FCB4CC0F4853E62B,
	ArcadeSDK_ARInstructions_remove_ARInstructionsStarted_m522FCF6B62EA55CA8CB494A42D019CFD448BD6DD,
	ArcadeSDK_ARInstructions_OnEnable_m182F5675CBFAF31EB670D2FB69A3CC49F286026E,
	ArcadeSDK_ARInstructions_OnDisable_m84BC0FC60AAEFC61B9EE931BB18E6CD53255745D,
	ArcadeSDK_ARInstructions_Start_mA3A50BF08FA6FF5127D92EDE4D2F55A68EDFC862,
	ArcadeSDK_ARInstructions_StartInstructions_m689E84A802BFB9E9CCE3F492B6FAEAF5E4322AE6,
	ArcadeSDK_ARInstructions_OnObjectPlaced_m26A9F2267BAB57423475794EBE065E69644FD4D8,
	ArcadeSDK_ARInstructions_InstructionCoroutine_m16242EC9590AC799644BFEE978A7B975C7A1028B,
	ArcadeSDK_ARInstructions_OnInstructionsFinished_m2BF83590C77DFF752E4B6593C904CBFC0C3486AA,
	ArcadeSDK_ARInstructions__ctor_mBE19751DD1519BAA92DEE206109C2EB250C901F3,
	ArcadeSDK_GameFlowManager_Awake_m7AB86199D68D3207243424577A62DCB94FCF2291,
	ArcadeSDK_GameFlowManager_JumpToStepInSequence_m476D6F6A30855C8D83790BA4E5C878EC2138206F,
	ArcadeSDK_GameFlowManager_TakeStep_m2792A976E0EC7C6568F7648BE145DC199C690B61,
	ArcadeSDK_GameFlowManager_IncrementSequence_mC4A1E0239D9EE58D081226C3492E9A220DAB5F2A,
	ArcadeSDK_GameFlowManager_OnFinishedAllSequences_m7975A1A8E4FA4F9413E12430FBB26D8EFADD62F1,
	ArcadeSDK_GameFlowManager__ctor_mD9F5CC03D3F297876B6F3C9F49188E8C524B05FC,
	ArcadeSDK_Sequence_get_CurrentStep_m84B836CBAB56FBD49CCD9A18634FCDF5999D890C,
	ArcadeSDK_Sequence_set_CurrentStep_mF0611F514A95AA81C420CA377D2C28874CC82404,
	ArcadeSDK_Sequence_get_SequenceSteps_m2A7C9A19AF2DA1DD9502F89B8AE662ACC4B0A523,
	ArcadeSDK_Sequence_set_SequenceSteps_m94D0397448BBEE700CB20AC86B25EB751A13B61E,
	ArcadeSDK_Sequence_Awake_m464F5CAE3DE79FB2C0EB638FB827DD02D2D812D6,
	ArcadeSDK_Sequence_IncrementStep_mCD1C76D5029342AD7EA24784FDAC7225FAEA01F8,
	ArcadeSDK_Sequence_ExecuteStep_m640FDFE198D5890AF9547E5D0F34B3ED6911AAF1,
	ArcadeSDK_Sequence__ctor_mE288F54F694085C5EA8C04FE42BDD85DBD5E6322,
	ArcadeSDK_Step_ExecuteStep_m14D02E8F13FFB594F114764FA681971B92CC5476,
	ArcadeSDK_Step_OnStepExecute_mF14342216080CBA4A4623E5CB961BAA1A884F03E,
	ArcadeSDK_Step__ctor_mEBFA95AEFB3B9BE50C4C357F04C17BEF06AC00B6,
	ArcadeSDK_PlaceObjOnPlane_add_PlacedObject_m73B5B0602E4EEFE329936FC95F5C0A240F5AF5A9,
	ArcadeSDK_PlaceObjOnPlane_remove_PlacedObject_mC685016556C65A15E164906F66AA9FC3608C2FA5,
	ArcadeSDK_PlaceObjOnPlane_Start_mA26AD6BC0EF0CFF5A851B771B4D3E6F3D36894F1,
	ArcadeSDK_PlaceObjOnPlane_OnObjectPlaced_mD2097AE2C51839C4F37ABC5C8193BA32DC27F2C3,
	ArcadeSDK_PlaceObjOnPlane_Update_m905D1AD9E5EE183E1F8AC327911EF177C4277958,
	ArcadeSDK_PlaceObjOnPlane__ctor_mEC0FF472FA6CAD228AE71286571BDFB5EB7C89C6,
	ArcadeSDK_PlaceObjOnPlane__cctor_m2793AC81E12165B887ECEC51C2F3397B694AC331,
	PlaceObjOnPlane_add_PlacedObject_m13837B8C6E72E292B15902C120B43E07E2D78FFB,
	PlaceObjOnPlane_remove_PlacedObject_m8EEC085023541C1ED897510B16E5AF4A6EA47AE1,
	PlaceObjOnPlane_Start_m5AFD5A6CE6C7D390A3F496D3DE26991730ABBFA0,
	PlaceObjOnPlane_OnObjectPlaced_mB510338AFAEE133D8DAE38FC702B5460A1804329,
	PlaceObjOnPlane_Update_mA0932FE222EDF406990C8ADFFE0547AC3EB57BBD,
	PlaceObjOnPlane__ctor_mBA81D35FA930322BED1DA1CF58B18094A4CA12C8,
	PlaceObjOnPlane__cctor_m4CDA914EEF3C79B2A8A174E44A23DAA114DF420B,
	U3CServerTimeRequestU3Ed__3__ctor_m0A143372A59B2DFE325FD5BADE95491624FB794B,
	U3CServerTimeRequestU3Ed__3_System_IDisposable_Dispose_mD309A99CE74CB1F1D15FF44FFE8A68B8671EB971,
	U3CServerTimeRequestU3Ed__3_MoveNext_mAA87D0FB0C4E4298F44E5785A5143D9474B81BC4,
	U3CServerTimeRequestU3Ed__3_U3CU3Em__Finally1_m16A15191753AD6499159289F40DBB916BF031180,
	U3CServerTimeRequestU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8176A93445A743B07AE56BF1C5E00BF3C4BC18F0,
	U3CServerTimeRequestU3Ed__3_System_Collections_IEnumerator_Reset_m08C000765843749E133792CF80C02E3C72642FA9,
	U3CServerTimeRequestU3Ed__3_System_Collections_IEnumerator_get_Current_m37C3EB069FAB49815AF9CB2B863A04009DA7B2EC,
	U3CFadeOutU3Ed__23__ctor_mE307004006FA47D11B91CA4EAE4E3A8119500A73,
	U3CFadeOutU3Ed__23_System_IDisposable_Dispose_m375CC44491B3D0AF6DBC4F9CE52A3A264617E0E2,
	U3CFadeOutU3Ed__23_MoveNext_mA40D9F09BF9C09E4FD72CF240923E4132CE9B044,
	U3CFadeOutU3Ed__23_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA5E3C5E2F59696518065ECC5488E508D15B3EFFB,
	U3CFadeOutU3Ed__23_System_Collections_IEnumerator_Reset_m8E5896B8ADF22F5BE6B67479D6E1BB4B8C6C9601,
	U3CFadeOutU3Ed__23_System_Collections_IEnumerator_get_Current_m08259204FC954B35B0267DBBE1DE3E0C75FC34B2,
	MessageDelegate__ctor_m3EA48B06536871149F1A43C905528166D49F48C8,
	MessageDelegate_Invoke_m2D199E1633D3EFBEA727164B8A3F7888E6A4F801,
	MessageDelegate_BeginInvoke_m89C256246D24A40498952C82CDD615B3507E4BA4,
	MessageDelegate_EndInvoke_m778326112BD3D26CB9DE0FFC335E9A1A9353BC35,
	MessageHandlerDelegate__ctor_m58386047CB442F144728F0A568B26FDDDB0EE6EA,
	MessageHandlerDelegate_Invoke_mF982647CDFA5782B9ABAF328FF4070492A364B43,
	MessageHandlerDelegate_BeginInvoke_mFDBB4C951CAC28A4F0E08666050BB3F266FA927E,
	MessageHandlerDelegate_EndInvoke_m9BC3850452E21DEBBF15C7598D811D4D744633A6,
	Item__ctor_m7FDB3BB2A80D464FA6A3636D1248C2A7F3C80CB9,
	U3CU3Ec__DisplayClass34_0__ctor_m6C5806C4FF3B7606C63C72B01F436E5966D66118,
	U3CU3Ec__DisplayClass34_0_U3CSetupDropdownU3Eb__0_m60264FF94DB05B4C3E60003B3F7B9D89D923D484,
	ToggleEvent__ctor_mD0237BFA9FD53C25A1D13D1BA5EB40AADBABEE97,
	Item__ctor_m2CEE0564043FB355C50DA89E013FCDE741D4FE1A,
	U3CExecuteAfterTimeU3Ed__2__ctor_mAB8A660ED8B646B33BDD0C613B1D3E6F581730BA,
	U3CExecuteAfterTimeU3Ed__2_System_IDisposable_Dispose_mD49E0BB97702AADB740296D196CBDC4A0D313967,
	U3CExecuteAfterTimeU3Ed__2_MoveNext_mDDA8CF1256456D74A2121F93C13DB32D26822A76,
	U3CExecuteAfterTimeU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF23868AA78B16C3DD4D4535741CAE6A0AE975766,
	U3CExecuteAfterTimeU3Ed__2_System_Collections_IEnumerator_Reset_m4B040CD4B6EDA3D0DDAA11CD1EF4D1C49B64B279,
	U3CExecuteAfterTimeU3Ed__2_System_Collections_IEnumerator_get_Current_mD41B7ECDBC26C90F0BCCBE429AEE6194805D421A,
	Item__ctor_m5D12669827721A49D747A3A40FEE5BAEB9470B1E,
	U3CStartTimerU3Ed__13__ctor_m5FB37EAEA922EA030ABCADF033D88EE7988C7829,
	U3CStartTimerU3Ed__13_System_IDisposable_Dispose_m20AA61FF22F14F7CABCC6C372C8F7482E5C37288,
	U3CStartTimerU3Ed__13_MoveNext_mCBD5A6A563D18B592907440BF444AFB5CBF6DE6F,
	U3CStartTimerU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m076F66F7EE38E255B85F8531E75470D7FB8EC2B5,
	U3CStartTimerU3Ed__13_System_Collections_IEnumerator_Reset_m79F18CCA6E4B7674D94331D22645FD8804CB5A19,
	U3CStartTimerU3Ed__13_System_Collections_IEnumerator_get_Current_m7F990B8896FB7FB5510DA961882A5C9E18BAAD9F,
	SliderEvent__ctor_m91C687DFEC324787F1A1D6E0E43EFFAEF2777A1E,
	U3CInstructionCoroutineU3Ed__14__ctor_m75C7510551615F813FA31562C7D6D90F12EED018,
	U3CInstructionCoroutineU3Ed__14_System_IDisposable_Dispose_m27CA3353F3079144A1981476D39B34716F5E83DA,
	U3CInstructionCoroutineU3Ed__14_MoveNext_mECF6D1623CAD7D0D5334EBD101BB405D74FF7F90,
	U3CInstructionCoroutineU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m740D20671B312E85D460579A52CF30713AA2A51A,
	U3CInstructionCoroutineU3Ed__14_System_Collections_IEnumerator_Reset_mE34BFE4149B5EA716A9D775B6DBCE87CE8DE7082,
	U3CInstructionCoroutineU3Ed__14_System_Collections_IEnumerator_get_Current_mA8120800ADC1BD972D99998EA4B4AE1D48B3F677,
	PlacedObjectHandler__ctor_m0710FADAD56B5D82703F2C08329AAD4CF0D6D7E7,
	PlacedObjectHandler_Invoke_mB02665CD25CCE70CA4D991461945927533ADBD17,
	PlacedObjectHandler_BeginInvoke_m6A682CD9CE5831E08E9B9CCC8E82815EE56B6317,
	PlacedObjectHandler_EndInvoke_m90D8A9E876CD25E418D5FCB6550189D8D66B83A3,
	PlacedObjectHandler__ctor_m95E81591B2457ECE0A157242A16CD34C47AFF348,
	PlacedObjectHandler_Invoke_m53EA39110892223E9D93691BD7A233F3D34AA386,
	PlacedObjectHandler_BeginInvoke_m55FA0E50F39DCF24D8CF340BFF43BF973D5C7ED9,
	PlacedObjectHandler_EndInvoke_m1DFC5CC2E166C2AF48243DCEB208A44EEE34EE2D,
};
static const int32_t s_InvokerIndices[569] = 
{
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	706,
	307,
	23,
	23,
	23,
	1788,
	26,
	23,
	3,
	23,
	23,
	23,
	1788,
	23,
	94,
	14,
	26,
	1745,
	1746,
	1745,
	1746,
	1768,
	1769,
	23,
	23,
	23,
	1736,
	23,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	-1,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	14,
	23,
	23,
	14,
	26,
	14,
	26,
	4,
	122,
	23,
	9,
	26,
	23,
	3,
	23,
	23,
	2296,
	23,
	23,
	23,
	23,
	23,
	298,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	26,
	26,
	26,
	23,
	0,
	-1,
	40,
	26,
	23,
	122,
	131,
	4,
	122,
	26,
	26,
	26,
	26,
	3,
	23,
	26,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	26,
	26,
	14,
	14,
	23,
	23,
	23,
	23,
	1202,
	1202,
	1202,
	1202,
	114,
	114,
	23,
	122,
	122,
	14,
	4,
	4,
	4,
	14,
	14,
	4,
	23,
	23,
	23,
	23,
	23,
	27,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	14,
	26,
	14,
	26,
	23,
	23,
	23,
	3,
	10,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	113,
	113,
	23,
	114,
	114,
	23,
	187,
	638,
	114,
	23,
	9,
	23,
	27,
	23,
	114,
	706,
	23,
	114,
	27,
	23,
	10,
	32,
	14,
	26,
	10,
	32,
	706,
	307,
	26,
	2297,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	307,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	26,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	31,
	31,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	1875,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	706,
	307,
	706,
	307,
	706,
	307,
	23,
	23,
	26,
	26,
	26,
	26,
	26,
	23,
	23,
	23,
	114,
	428,
	23,
	23,
	1910,
	307,
	23,
	1910,
	307,
	23,
	706,
	706,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	307,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	14,
	26,
	26,
	23,
	23,
	122,
	122,
	122,
	122,
	4,
	122,
	23,
	23,
	23,
	2298,
	1759,
	23,
	342,
	23,
	3,
	122,
	122,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	169,
	23,
	114,
	23,
	23,
	10,
	32,
	14,
	26,
	23,
	114,
	23,
	23,
	23,
	23,
	23,
	122,
	122,
	23,
	26,
	23,
	23,
	3,
	122,
	122,
	23,
	26,
	23,
	23,
	3,
	32,
	23,
	114,
	23,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	102,
	26,
	177,
	26,
	102,
	26,
	177,
	26,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	102,
	26,
	177,
	26,
	102,
	26,
	177,
	26,
};
static const Il2CppTokenRangePair s_rgctxIndices[3] = 
{
	{ 0x02000002, { 0, 21 } },
	{ 0x0600002D, { 21, 3 } },
	{ 0x0600006D, { 24, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[25] = 
{
	{ (Il2CppRGCTXDataType)2, 24281 },
	{ (Il2CppRGCTXDataType)3, 21060 },
	{ (Il2CppRGCTXDataType)2, 24282 },
	{ (Il2CppRGCTXDataType)3, 21061 },
	{ (Il2CppRGCTXDataType)3, 21062 },
	{ (Il2CppRGCTXDataType)2, 24283 },
	{ (Il2CppRGCTXDataType)3, 21063 },
	{ (Il2CppRGCTXDataType)3, 21064 },
	{ (Il2CppRGCTXDataType)2, 24284 },
	{ (Il2CppRGCTXDataType)3, 21065 },
	{ (Il2CppRGCTXDataType)3, 21066 },
	{ (Il2CppRGCTXDataType)2, 24285 },
	{ (Il2CppRGCTXDataType)3, 21067 },
	{ (Il2CppRGCTXDataType)3, 21068 },
	{ (Il2CppRGCTXDataType)3, 21069 },
	{ (Il2CppRGCTXDataType)3, 21070 },
	{ (Il2CppRGCTXDataType)3, 21071 },
	{ (Il2CppRGCTXDataType)2, 23571 },
	{ (Il2CppRGCTXDataType)2, 23572 },
	{ (Il2CppRGCTXDataType)2, 23573 },
	{ (Il2CppRGCTXDataType)2, 23574 },
	{ (Il2CppRGCTXDataType)3, 21072 },
	{ (Il2CppRGCTXDataType)3, 21073 },
	{ (Il2CppRGCTXDataType)2, 23592 },
	{ (Il2CppRGCTXDataType)3, 21074 },
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	569,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	3,
	s_rgctxIndices,
	25,
	s_rgctxValues,
	NULL,
};
