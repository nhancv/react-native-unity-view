﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// System.Action`1<UnityEngine.Font>
struct Action_1_t795662E553415ECF2DD0F8EEB9BA170C3670F37C;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2/Entry<System.UInt32,UnityEngine.TextCore.Glyph>[]
struct EntryU5BU5D_t37E9617E226D86E561DB40C949C802D0BDD9EA7C;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.UInt32,UnityEngine.TextCore.Glyph>
struct KeyCollection_tCA93C0003B8D83B0D961EE1112AE8D5B93EF68B5;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.UInt32,UnityEngine.TextCore.Glyph>
struct ValueCollection_t5FE81206161B562F8D76FEF5056A57DF5FBD8E6F;
// System.Collections.Generic.Dictionary`2<System.UInt32,System.Object>
struct Dictionary_2_t9D3330644BF8CBACB84AB5EA2438CFB219E5D4D7;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph>
struct Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B;
// System.Collections.Generic.IEqualityComparer`1<System.UInt32>
struct IEqualityComparer_1_t8D13638D3E8C85B2BF37618A54F8C19DD8DF2523;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D;
// System.Collections.Generic.List`1<System.UInt32>
struct List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>
struct List_1_t8B3AA8D740B2E10383225037638055610A7BE123;
// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>
struct List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
// System.String
struct String_t;
// System.UInt32[]
struct UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB;
// System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.Font
struct Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26;
// UnityEngine.Font/FontTextureRebuildCallback
struct FontTextureRebuildCallback_tD700C63BB1A449E3A0464C81701E981677D3021C;
// UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0;
// UnityEngine.TextCore.Glyph
struct Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4;
// UnityEngine.TextCore.GlyphRect[]
struct GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2;
// UnityEngine.TextCore.Glyph[]
struct GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F;
// UnityEngine.TextCore.LowLevel.FontEngine
struct FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC;
// UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[]
struct GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662;
// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[]
struct GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;

IL2CPP_EXTERN_C RuntimeClass* Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteralD18BC4FA20EAFF07786EFFB312284C46A3CE5251;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2__ctor_mD40472A556EEC9DFC4FC7FFB8413799EAAACB65E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m4A32B5B2CCE68FC874FEF42E9B23320FAF0828D3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m1AA0C2D8B9692306C4D1AD0F721F4DAB85734BC5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_RuntimeMethod_var;
IL2CPP_EXTERN_C const uint32_t FontEngine_GetFaceInfo_mB4B6045A34FEBFE58EB401216E930F50364B0A41_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_GetGlyphPairAdjustmentTable_m1FC9B74860076DCCECBCE77EEA38737FB32DF24B_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_InitializeFontEngine_m1C7695D66160277DE576EB9D8BA749849BDC24B7_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_LoadFontFace_mFEBC3184605C0BD37A83021F6B47E5C3FA3FAD3C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_RenderGlyphsToTexture_m6A61FED7FC28A80B730C4B2C492A8E802DD2EB80_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_TryAddGlyphToTexture_mD70AEC0FDCEE818B4366C78FF662464F13112172_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_TryAddGlyphsToTexture_mFC834881F6DB0867C01A9902A879C13ED66404A4_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_TryGetGlyphWithIndexValue_m75A9F7605232FAF4D9948E2E7BDFFB01A8FD5178_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_TryGetGlyphWithUnicodeValue_mBC940303E740DC1897FCA6247D048266298BE00C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine_TryPackGlyphInAtlas_m0E9E8FBBC64AF69CB1DEB3C8A2EF862222C3B8EA_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t FontEngine__cctor_m17164EA5533727BA15D0E56719925E8AA986F7BC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphRect__cctor_m5AD2AC6BB42D6536F8F6E2F4369BA400354BFC35_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t GlyphRect_get_zero_mA40D939BFBFB8D3A7301CA4A6D99A1DBDFC34736_MetadataUsageId;

struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
struct UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB;
struct GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2;
struct GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F;
struct GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662;
struct GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t4A787D254F43BB4671F752CC6B293B5F6EC1F97D 
{
public:

public:
};


// System.Object

struct Il2CppArrayBounds;

// System.Array


// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph>
struct  Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t37E9617E226D86E561DB40C949C802D0BDD9EA7C* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_tCA93C0003B8D83B0D961EE1112AE8D5B93EF68B5 * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_t5FE81206161B562F8D76FEF5056A57DF5FBD8E6F * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___buckets_0), (void*)value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___entries_1)); }
	inline EntryU5BU5D_t37E9617E226D86E561DB40C949C802D0BDD9EA7C* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t37E9617E226D86E561DB40C949C802D0BDD9EA7C** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t37E9617E226D86E561DB40C949C802D0BDD9EA7C* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___entries_1), (void*)value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___comparer_6), (void*)value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___keys_7)); }
	inline KeyCollection_tCA93C0003B8D83B0D961EE1112AE8D5B93EF68B5 * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_tCA93C0003B8D83B0D961EE1112AE8D5B93EF68B5 ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_tCA93C0003B8D83B0D961EE1112AE8D5B93EF68B5 * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keys_7), (void*)value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ___values_8)); }
	inline ValueCollection_t5FE81206161B562F8D76FEF5056A57DF5FBD8E6F * get_values_8() const { return ___values_8; }
	inline ValueCollection_t5FE81206161B562F8D76FEF5056A57DF5FBD8E6F ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_t5FE81206161B562F8D76FEF5056A57DF5FBD8E6F * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___values_8), (void*)value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_9), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Object>
struct  List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D, ____items_1)); }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* get__items_1() const { return ____items_1; }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D_StaticFields, ____emptyArray_5)); }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.UInt32>
struct  List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E, ____items_1)); }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* get__items_1() const { return ____items_1; }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E_StaticFields, ____emptyArray_5)); }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* get__emptyArray_5() const { return ____emptyArray_5; }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>
struct  List_1_t8B3AA8D740B2E10383225037638055610A7BE123  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t8B3AA8D740B2E10383225037638055610A7BE123, ____items_1)); }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* get__items_1() const { return ____items_1; }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t8B3AA8D740B2E10383225037638055610A7BE123, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t8B3AA8D740B2E10383225037638055610A7BE123, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t8B3AA8D740B2E10383225037638055610A7BE123, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t8B3AA8D740B2E10383225037638055610A7BE123_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t8B3AA8D740B2E10383225037638055610A7BE123_StaticFields, ____emptyArray_5)); }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* get__emptyArray_5() const { return ____emptyArray_5; }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>
struct  List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65, ____items_1)); }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* get__items_1() const { return ____items_1; }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65_StaticFields, ____emptyArray_5)); }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* get__emptyArray_5() const { return ____emptyArray_5; }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// UnityEngine.TextCore.LowLevel.FontEngine
struct  FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC  : public RuntimeObject
{
public:

public:
};

struct FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields
{
public:
	// UnityEngine.TextCore.LowLevel.FontEngine UnityEngine.TextCore.LowLevel.FontEngine::s_Instance
	FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * ___s_Instance_0;
	// UnityEngine.TextCore.Glyph[] UnityEngine.TextCore.LowLevel.FontEngine::s_Glyphs
	GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* ___s_Glyphs_1;
	// System.UInt32[] UnityEngine.TextCore.LowLevel.FontEngine::s_GlyphIndexes_MarshallingArray
	UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___s_GlyphIndexes_MarshallingArray_2;
	// UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[] UnityEngine.TextCore.LowLevel.FontEngine::s_GlyphMarshallingStruct_IN
	GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___s_GlyphMarshallingStruct_IN_3;
	// UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[] UnityEngine.TextCore.LowLevel.FontEngine::s_GlyphMarshallingStruct_OUT
	GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___s_GlyphMarshallingStruct_OUT_4;
	// UnityEngine.TextCore.GlyphRect[] UnityEngine.TextCore.LowLevel.FontEngine::s_FreeGlyphRects
	GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___s_FreeGlyphRects_5;
	// UnityEngine.TextCore.GlyphRect[] UnityEngine.TextCore.LowLevel.FontEngine::s_UsedGlyphRects
	GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___s_UsedGlyphRects_6;
	// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::s_PairAdjustmentRecords_MarshallingArray
	GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* ___s_PairAdjustmentRecords_MarshallingArray_7;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph> UnityEngine.TextCore.LowLevel.FontEngine::s_GlyphLookupDictionary
	Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B * ___s_GlyphLookupDictionary_8;

public:
	inline static int32_t get_offset_of_s_Instance_0() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_Instance_0)); }
	inline FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * get_s_Instance_0() const { return ___s_Instance_0; }
	inline FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC ** get_address_of_s_Instance_0() { return &___s_Instance_0; }
	inline void set_s_Instance_0(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * value)
	{
		___s_Instance_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Instance_0), (void*)value);
	}

	inline static int32_t get_offset_of_s_Glyphs_1() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_Glyphs_1)); }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* get_s_Glyphs_1() const { return ___s_Glyphs_1; }
	inline GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** get_address_of_s_Glyphs_1() { return &___s_Glyphs_1; }
	inline void set_s_Glyphs_1(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* value)
	{
		___s_Glyphs_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Glyphs_1), (void*)value);
	}

	inline static int32_t get_offset_of_s_GlyphIndexes_MarshallingArray_2() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_GlyphIndexes_MarshallingArray_2)); }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* get_s_GlyphIndexes_MarshallingArray_2() const { return ___s_GlyphIndexes_MarshallingArray_2; }
	inline UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB** get_address_of_s_GlyphIndexes_MarshallingArray_2() { return &___s_GlyphIndexes_MarshallingArray_2; }
	inline void set_s_GlyphIndexes_MarshallingArray_2(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* value)
	{
		___s_GlyphIndexes_MarshallingArray_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_GlyphIndexes_MarshallingArray_2), (void*)value);
	}

	inline static int32_t get_offset_of_s_GlyphMarshallingStruct_IN_3() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_GlyphMarshallingStruct_IN_3)); }
	inline GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* get_s_GlyphMarshallingStruct_IN_3() const { return ___s_GlyphMarshallingStruct_IN_3; }
	inline GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662** get_address_of_s_GlyphMarshallingStruct_IN_3() { return &___s_GlyphMarshallingStruct_IN_3; }
	inline void set_s_GlyphMarshallingStruct_IN_3(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* value)
	{
		___s_GlyphMarshallingStruct_IN_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_GlyphMarshallingStruct_IN_3), (void*)value);
	}

	inline static int32_t get_offset_of_s_GlyphMarshallingStruct_OUT_4() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_GlyphMarshallingStruct_OUT_4)); }
	inline GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* get_s_GlyphMarshallingStruct_OUT_4() const { return ___s_GlyphMarshallingStruct_OUT_4; }
	inline GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662** get_address_of_s_GlyphMarshallingStruct_OUT_4() { return &___s_GlyphMarshallingStruct_OUT_4; }
	inline void set_s_GlyphMarshallingStruct_OUT_4(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* value)
	{
		___s_GlyphMarshallingStruct_OUT_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_GlyphMarshallingStruct_OUT_4), (void*)value);
	}

	inline static int32_t get_offset_of_s_FreeGlyphRects_5() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_FreeGlyphRects_5)); }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* get_s_FreeGlyphRects_5() const { return ___s_FreeGlyphRects_5; }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2** get_address_of_s_FreeGlyphRects_5() { return &___s_FreeGlyphRects_5; }
	inline void set_s_FreeGlyphRects_5(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* value)
	{
		___s_FreeGlyphRects_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_FreeGlyphRects_5), (void*)value);
	}

	inline static int32_t get_offset_of_s_UsedGlyphRects_6() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_UsedGlyphRects_6)); }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* get_s_UsedGlyphRects_6() const { return ___s_UsedGlyphRects_6; }
	inline GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2** get_address_of_s_UsedGlyphRects_6() { return &___s_UsedGlyphRects_6; }
	inline void set_s_UsedGlyphRects_6(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* value)
	{
		___s_UsedGlyphRects_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_UsedGlyphRects_6), (void*)value);
	}

	inline static int32_t get_offset_of_s_PairAdjustmentRecords_MarshallingArray_7() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_PairAdjustmentRecords_MarshallingArray_7)); }
	inline GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* get_s_PairAdjustmentRecords_MarshallingArray_7() const { return ___s_PairAdjustmentRecords_MarshallingArray_7; }
	inline GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7** get_address_of_s_PairAdjustmentRecords_MarshallingArray_7() { return &___s_PairAdjustmentRecords_MarshallingArray_7; }
	inline void set_s_PairAdjustmentRecords_MarshallingArray_7(GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* value)
	{
		___s_PairAdjustmentRecords_MarshallingArray_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_PairAdjustmentRecords_MarshallingArray_7), (void*)value);
	}

	inline static int32_t get_offset_of_s_GlyphLookupDictionary_8() { return static_cast<int32_t>(offsetof(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields, ___s_GlyphLookupDictionary_8)); }
	inline Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B * get_s_GlyphLookupDictionary_8() const { return ___s_GlyphLookupDictionary_8; }
	inline Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B ** get_address_of_s_GlyphLookupDictionary_8() { return &___s_GlyphLookupDictionary_8; }
	inline void set_s_GlyphLookupDictionary_8(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B * value)
	{
		___s_GlyphLookupDictionary_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_GlyphLookupDictionary_8), (void*)value);
	}
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.UInt32
struct  UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// UnityEngine.TextCore.FaceInfo
struct  FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 
{
public:
	// System.String UnityEngine.TextCore.FaceInfo::m_FamilyName
	String_t* ___m_FamilyName_0;
	// System.String UnityEngine.TextCore.FaceInfo::m_StyleName
	String_t* ___m_StyleName_1;
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_PointSize
	int32_t ___m_PointSize_2;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Scale
	float ___m_Scale_3;
	// System.Single UnityEngine.TextCore.FaceInfo::m_LineHeight
	float ___m_LineHeight_4;
	// System.Single UnityEngine.TextCore.FaceInfo::m_AscentLine
	float ___m_AscentLine_5;
	// System.Single UnityEngine.TextCore.FaceInfo::m_CapLine
	float ___m_CapLine_6;
	// System.Single UnityEngine.TextCore.FaceInfo::m_MeanLine
	float ___m_MeanLine_7;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Baseline
	float ___m_Baseline_8;
	// System.Single UnityEngine.TextCore.FaceInfo::m_DescentLine
	float ___m_DescentLine_9;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptOffset
	float ___m_SuperscriptOffset_10;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptSize
	float ___m_SuperscriptSize_11;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptOffset
	float ___m_SubscriptOffset_12;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptSize
	float ___m_SubscriptSize_13;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineOffset
	float ___m_UnderlineOffset_14;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineThickness
	float ___m_UnderlineThickness_15;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughOffset
	float ___m_StrikethroughOffset_16;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughThickness
	float ___m_StrikethroughThickness_17;
	// System.Single UnityEngine.TextCore.FaceInfo::m_TabWidth
	float ___m_TabWidth_18;

public:
	inline static int32_t get_offset_of_m_FamilyName_0() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_FamilyName_0)); }
	inline String_t* get_m_FamilyName_0() const { return ___m_FamilyName_0; }
	inline String_t** get_address_of_m_FamilyName_0() { return &___m_FamilyName_0; }
	inline void set_m_FamilyName_0(String_t* value)
	{
		___m_FamilyName_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FamilyName_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StyleName_1() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_StyleName_1)); }
	inline String_t* get_m_StyleName_1() const { return ___m_StyleName_1; }
	inline String_t** get_address_of_m_StyleName_1() { return &___m_StyleName_1; }
	inline void set_m_StyleName_1(String_t* value)
	{
		___m_StyleName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StyleName_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_PointSize_2() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_PointSize_2)); }
	inline int32_t get_m_PointSize_2() const { return ___m_PointSize_2; }
	inline int32_t* get_address_of_m_PointSize_2() { return &___m_PointSize_2; }
	inline void set_m_PointSize_2(int32_t value)
	{
		___m_PointSize_2 = value;
	}

	inline static int32_t get_offset_of_m_Scale_3() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_Scale_3)); }
	inline float get_m_Scale_3() const { return ___m_Scale_3; }
	inline float* get_address_of_m_Scale_3() { return &___m_Scale_3; }
	inline void set_m_Scale_3(float value)
	{
		___m_Scale_3 = value;
	}

	inline static int32_t get_offset_of_m_LineHeight_4() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_LineHeight_4)); }
	inline float get_m_LineHeight_4() const { return ___m_LineHeight_4; }
	inline float* get_address_of_m_LineHeight_4() { return &___m_LineHeight_4; }
	inline void set_m_LineHeight_4(float value)
	{
		___m_LineHeight_4 = value;
	}

	inline static int32_t get_offset_of_m_AscentLine_5() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_AscentLine_5)); }
	inline float get_m_AscentLine_5() const { return ___m_AscentLine_5; }
	inline float* get_address_of_m_AscentLine_5() { return &___m_AscentLine_5; }
	inline void set_m_AscentLine_5(float value)
	{
		___m_AscentLine_5 = value;
	}

	inline static int32_t get_offset_of_m_CapLine_6() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_CapLine_6)); }
	inline float get_m_CapLine_6() const { return ___m_CapLine_6; }
	inline float* get_address_of_m_CapLine_6() { return &___m_CapLine_6; }
	inline void set_m_CapLine_6(float value)
	{
		___m_CapLine_6 = value;
	}

	inline static int32_t get_offset_of_m_MeanLine_7() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_MeanLine_7)); }
	inline float get_m_MeanLine_7() const { return ___m_MeanLine_7; }
	inline float* get_address_of_m_MeanLine_7() { return &___m_MeanLine_7; }
	inline void set_m_MeanLine_7(float value)
	{
		___m_MeanLine_7 = value;
	}

	inline static int32_t get_offset_of_m_Baseline_8() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_Baseline_8)); }
	inline float get_m_Baseline_8() const { return ___m_Baseline_8; }
	inline float* get_address_of_m_Baseline_8() { return &___m_Baseline_8; }
	inline void set_m_Baseline_8(float value)
	{
		___m_Baseline_8 = value;
	}

	inline static int32_t get_offset_of_m_DescentLine_9() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_DescentLine_9)); }
	inline float get_m_DescentLine_9() const { return ___m_DescentLine_9; }
	inline float* get_address_of_m_DescentLine_9() { return &___m_DescentLine_9; }
	inline void set_m_DescentLine_9(float value)
	{
		___m_DescentLine_9 = value;
	}

	inline static int32_t get_offset_of_m_SuperscriptOffset_10() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_SuperscriptOffset_10)); }
	inline float get_m_SuperscriptOffset_10() const { return ___m_SuperscriptOffset_10; }
	inline float* get_address_of_m_SuperscriptOffset_10() { return &___m_SuperscriptOffset_10; }
	inline void set_m_SuperscriptOffset_10(float value)
	{
		___m_SuperscriptOffset_10 = value;
	}

	inline static int32_t get_offset_of_m_SuperscriptSize_11() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_SuperscriptSize_11)); }
	inline float get_m_SuperscriptSize_11() const { return ___m_SuperscriptSize_11; }
	inline float* get_address_of_m_SuperscriptSize_11() { return &___m_SuperscriptSize_11; }
	inline void set_m_SuperscriptSize_11(float value)
	{
		___m_SuperscriptSize_11 = value;
	}

	inline static int32_t get_offset_of_m_SubscriptOffset_12() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_SubscriptOffset_12)); }
	inline float get_m_SubscriptOffset_12() const { return ___m_SubscriptOffset_12; }
	inline float* get_address_of_m_SubscriptOffset_12() { return &___m_SubscriptOffset_12; }
	inline void set_m_SubscriptOffset_12(float value)
	{
		___m_SubscriptOffset_12 = value;
	}

	inline static int32_t get_offset_of_m_SubscriptSize_13() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_SubscriptSize_13)); }
	inline float get_m_SubscriptSize_13() const { return ___m_SubscriptSize_13; }
	inline float* get_address_of_m_SubscriptSize_13() { return &___m_SubscriptSize_13; }
	inline void set_m_SubscriptSize_13(float value)
	{
		___m_SubscriptSize_13 = value;
	}

	inline static int32_t get_offset_of_m_UnderlineOffset_14() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_UnderlineOffset_14)); }
	inline float get_m_UnderlineOffset_14() const { return ___m_UnderlineOffset_14; }
	inline float* get_address_of_m_UnderlineOffset_14() { return &___m_UnderlineOffset_14; }
	inline void set_m_UnderlineOffset_14(float value)
	{
		___m_UnderlineOffset_14 = value;
	}

	inline static int32_t get_offset_of_m_UnderlineThickness_15() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_UnderlineThickness_15)); }
	inline float get_m_UnderlineThickness_15() const { return ___m_UnderlineThickness_15; }
	inline float* get_address_of_m_UnderlineThickness_15() { return &___m_UnderlineThickness_15; }
	inline void set_m_UnderlineThickness_15(float value)
	{
		___m_UnderlineThickness_15 = value;
	}

	inline static int32_t get_offset_of_m_StrikethroughOffset_16() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_StrikethroughOffset_16)); }
	inline float get_m_StrikethroughOffset_16() const { return ___m_StrikethroughOffset_16; }
	inline float* get_address_of_m_StrikethroughOffset_16() { return &___m_StrikethroughOffset_16; }
	inline void set_m_StrikethroughOffset_16(float value)
	{
		___m_StrikethroughOffset_16 = value;
	}

	inline static int32_t get_offset_of_m_StrikethroughThickness_17() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_StrikethroughThickness_17)); }
	inline float get_m_StrikethroughThickness_17() const { return ___m_StrikethroughThickness_17; }
	inline float* get_address_of_m_StrikethroughThickness_17() { return &___m_StrikethroughThickness_17; }
	inline void set_m_StrikethroughThickness_17(float value)
	{
		___m_StrikethroughThickness_17 = value;
	}

	inline static int32_t get_offset_of_m_TabWidth_18() { return static_cast<int32_t>(offsetof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8, ___m_TabWidth_18)); }
	inline float get_m_TabWidth_18() const { return ___m_TabWidth_18; }
	inline float* get_address_of_m_TabWidth_18() { return &___m_TabWidth_18; }
	inline void set_m_TabWidth_18(float value)
	{
		___m_TabWidth_18 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_pinvoke
{
	char* ___m_FamilyName_0;
	char* ___m_StyleName_1;
	int32_t ___m_PointSize_2;
	float ___m_Scale_3;
	float ___m_LineHeight_4;
	float ___m_AscentLine_5;
	float ___m_CapLine_6;
	float ___m_MeanLine_7;
	float ___m_Baseline_8;
	float ___m_DescentLine_9;
	float ___m_SuperscriptOffset_10;
	float ___m_SuperscriptSize_11;
	float ___m_SubscriptOffset_12;
	float ___m_SubscriptSize_13;
	float ___m_UnderlineOffset_14;
	float ___m_UnderlineThickness_15;
	float ___m_StrikethroughOffset_16;
	float ___m_StrikethroughThickness_17;
	float ___m_TabWidth_18;
};
// Native definition for COM marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_com
{
	Il2CppChar* ___m_FamilyName_0;
	Il2CppChar* ___m_StyleName_1;
	int32_t ___m_PointSize_2;
	float ___m_Scale_3;
	float ___m_LineHeight_4;
	float ___m_AscentLine_5;
	float ___m_CapLine_6;
	float ___m_MeanLine_7;
	float ___m_Baseline_8;
	float ___m_DescentLine_9;
	float ___m_SuperscriptOffset_10;
	float ___m_SuperscriptSize_11;
	float ___m_SubscriptOffset_12;
	float ___m_SubscriptSize_13;
	float ___m_UnderlineOffset_14;
	float ___m_UnderlineThickness_15;
	float ___m_StrikethroughOffset_16;
	float ___m_StrikethroughThickness_17;
	float ___m_TabWidth_18;
};

// UnityEngine.TextCore.GlyphMetrics
struct  GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB 
{
public:
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Width
	float ___m_Width_0;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Height
	float ___m_Height_1;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingX
	float ___m_HorizontalBearingX_2;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingY
	float ___m_HorizontalBearingY_3;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalAdvance
	float ___m_HorizontalAdvance_4;

public:
	inline static int32_t get_offset_of_m_Width_0() { return static_cast<int32_t>(offsetof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB, ___m_Width_0)); }
	inline float get_m_Width_0() const { return ___m_Width_0; }
	inline float* get_address_of_m_Width_0() { return &___m_Width_0; }
	inline void set_m_Width_0(float value)
	{
		___m_Width_0 = value;
	}

	inline static int32_t get_offset_of_m_Height_1() { return static_cast<int32_t>(offsetof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB, ___m_Height_1)); }
	inline float get_m_Height_1() const { return ___m_Height_1; }
	inline float* get_address_of_m_Height_1() { return &___m_Height_1; }
	inline void set_m_Height_1(float value)
	{
		___m_Height_1 = value;
	}

	inline static int32_t get_offset_of_m_HorizontalBearingX_2() { return static_cast<int32_t>(offsetof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB, ___m_HorizontalBearingX_2)); }
	inline float get_m_HorizontalBearingX_2() const { return ___m_HorizontalBearingX_2; }
	inline float* get_address_of_m_HorizontalBearingX_2() { return &___m_HorizontalBearingX_2; }
	inline void set_m_HorizontalBearingX_2(float value)
	{
		___m_HorizontalBearingX_2 = value;
	}

	inline static int32_t get_offset_of_m_HorizontalBearingY_3() { return static_cast<int32_t>(offsetof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB, ___m_HorizontalBearingY_3)); }
	inline float get_m_HorizontalBearingY_3() const { return ___m_HorizontalBearingY_3; }
	inline float* get_address_of_m_HorizontalBearingY_3() { return &___m_HorizontalBearingY_3; }
	inline void set_m_HorizontalBearingY_3(float value)
	{
		___m_HorizontalBearingY_3 = value;
	}

	inline static int32_t get_offset_of_m_HorizontalAdvance_4() { return static_cast<int32_t>(offsetof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB, ___m_HorizontalAdvance_4)); }
	inline float get_m_HorizontalAdvance_4() const { return ___m_HorizontalAdvance_4; }
	inline float* get_address_of_m_HorizontalAdvance_4() { return &___m_HorizontalAdvance_4; }
	inline void set_m_HorizontalAdvance_4(float value)
	{
		___m_HorizontalAdvance_4 = value;
	}
};


// UnityEngine.TextCore.GlyphRect
struct  GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C 
{
public:
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Y
	int32_t ___m_Y_1;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Width
	int32_t ___m_Width_2;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Height
	int32_t ___m_Height_3;

public:
	inline static int32_t get_offset_of_m_X_0() { return static_cast<int32_t>(offsetof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C, ___m_X_0)); }
	inline int32_t get_m_X_0() const { return ___m_X_0; }
	inline int32_t* get_address_of_m_X_0() { return &___m_X_0; }
	inline void set_m_X_0(int32_t value)
	{
		___m_X_0 = value;
	}

	inline static int32_t get_offset_of_m_Y_1() { return static_cast<int32_t>(offsetof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C, ___m_Y_1)); }
	inline int32_t get_m_Y_1() const { return ___m_Y_1; }
	inline int32_t* get_address_of_m_Y_1() { return &___m_Y_1; }
	inline void set_m_Y_1(int32_t value)
	{
		___m_Y_1 = value;
	}

	inline static int32_t get_offset_of_m_Width_2() { return static_cast<int32_t>(offsetof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C, ___m_Width_2)); }
	inline int32_t get_m_Width_2() const { return ___m_Width_2; }
	inline int32_t* get_address_of_m_Width_2() { return &___m_Width_2; }
	inline void set_m_Width_2(int32_t value)
	{
		___m_Width_2 = value;
	}

	inline static int32_t get_offset_of_m_Height_3() { return static_cast<int32_t>(offsetof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C, ___m_Height_3)); }
	inline int32_t get_m_Height_3() const { return ___m_Height_3; }
	inline int32_t* get_address_of_m_Height_3() { return &___m_Height_3; }
	inline void set_m_Height_3(int32_t value)
	{
		___m_Height_3 = value;
	}
};

struct GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_StaticFields
{
public:
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::s_ZeroGlyphRect
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___s_ZeroGlyphRect_4;

public:
	inline static int32_t get_offset_of_s_ZeroGlyphRect_4() { return static_cast<int32_t>(offsetof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_StaticFields, ___s_ZeroGlyphRect_4)); }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  get_s_ZeroGlyphRect_4() const { return ___s_ZeroGlyphRect_4; }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * get_address_of_s_ZeroGlyphRect_4() { return &___s_ZeroGlyphRect_4; }
	inline void set_s_ZeroGlyphRect_4(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  value)
	{
		___s_ZeroGlyphRect_4 = value;
	}
};


// UnityEngine.TextCore.LowLevel.FontEngineUtilities
struct  FontEngineUtilities_tABC031FF1B1CCEB8547DB85E21174D2914DA7391 
{
public:
	union
	{
		struct
		{
		};
		uint8_t FontEngineUtilities_tABC031FF1B1CCEB8547DB85E21174D2914DA7391__padding[1];
	};

public:
};


// UnityEngine.TextCore.LowLevel.GlyphValueRecord
struct  GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D 
{
public:
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XPlacement
	float ___m_XPlacement_0;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YPlacement
	float ___m_YPlacement_1;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XAdvance
	float ___m_XAdvance_2;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YAdvance
	float ___m_YAdvance_3;

public:
	inline static int32_t get_offset_of_m_XPlacement_0() { return static_cast<int32_t>(offsetof(GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D, ___m_XPlacement_0)); }
	inline float get_m_XPlacement_0() const { return ___m_XPlacement_0; }
	inline float* get_address_of_m_XPlacement_0() { return &___m_XPlacement_0; }
	inline void set_m_XPlacement_0(float value)
	{
		___m_XPlacement_0 = value;
	}

	inline static int32_t get_offset_of_m_YPlacement_1() { return static_cast<int32_t>(offsetof(GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D, ___m_YPlacement_1)); }
	inline float get_m_YPlacement_1() const { return ___m_YPlacement_1; }
	inline float* get_address_of_m_YPlacement_1() { return &___m_YPlacement_1; }
	inline void set_m_YPlacement_1(float value)
	{
		___m_YPlacement_1 = value;
	}

	inline static int32_t get_offset_of_m_XAdvance_2() { return static_cast<int32_t>(offsetof(GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D, ___m_XAdvance_2)); }
	inline float get_m_XAdvance_2() const { return ___m_XAdvance_2; }
	inline float* get_address_of_m_XAdvance_2() { return &___m_XAdvance_2; }
	inline void set_m_XAdvance_2(float value)
	{
		___m_XAdvance_2 = value;
	}

	inline static int32_t get_offset_of_m_YAdvance_3() { return static_cast<int32_t>(offsetof(GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D, ___m_YAdvance_3)); }
	inline float get_m_YAdvance_3() const { return ___m_YAdvance_3; }
	inline float* get_address_of_m_YAdvance_3() { return &___m_YAdvance_3; }
	inline void set_m_YAdvance_3(float value)
	{
		___m_YAdvance_3 = value;
	}
};


// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.TextCore.Glyph
struct  Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4  : public RuntimeObject
{
public:
	// System.UInt32 UnityEngine.TextCore.Glyph::m_Index
	uint32_t ___m_Index_0;
	// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::m_Metrics
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___m_Metrics_1;
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::m_GlyphRect
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___m_GlyphRect_2;
	// System.Single UnityEngine.TextCore.Glyph::m_Scale
	float ___m_Scale_3;
	// System.Int32 UnityEngine.TextCore.Glyph::m_AtlasIndex
	int32_t ___m_AtlasIndex_4;

public:
	inline static int32_t get_offset_of_m_Index_0() { return static_cast<int32_t>(offsetof(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4, ___m_Index_0)); }
	inline uint32_t get_m_Index_0() const { return ___m_Index_0; }
	inline uint32_t* get_address_of_m_Index_0() { return &___m_Index_0; }
	inline void set_m_Index_0(uint32_t value)
	{
		___m_Index_0 = value;
	}

	inline static int32_t get_offset_of_m_Metrics_1() { return static_cast<int32_t>(offsetof(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4, ___m_Metrics_1)); }
	inline GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  get_m_Metrics_1() const { return ___m_Metrics_1; }
	inline GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * get_address_of_m_Metrics_1() { return &___m_Metrics_1; }
	inline void set_m_Metrics_1(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  value)
	{
		___m_Metrics_1 = value;
	}

	inline static int32_t get_offset_of_m_GlyphRect_2() { return static_cast<int32_t>(offsetof(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4, ___m_GlyphRect_2)); }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  get_m_GlyphRect_2() const { return ___m_GlyphRect_2; }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * get_address_of_m_GlyphRect_2() { return &___m_GlyphRect_2; }
	inline void set_m_GlyphRect_2(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  value)
	{
		___m_GlyphRect_2 = value;
	}

	inline static int32_t get_offset_of_m_Scale_3() { return static_cast<int32_t>(offsetof(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4, ___m_Scale_3)); }
	inline float get_m_Scale_3() const { return ___m_Scale_3; }
	inline float* get_address_of_m_Scale_3() { return &___m_Scale_3; }
	inline void set_m_Scale_3(float value)
	{
		___m_Scale_3 = value;
	}

	inline static int32_t get_offset_of_m_AtlasIndex_4() { return static_cast<int32_t>(offsetof(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4, ___m_AtlasIndex_4)); }
	inline int32_t get_m_AtlasIndex_4() const { return ___m_AtlasIndex_4; }
	inline int32_t* get_address_of_m_AtlasIndex_4() { return &___m_AtlasIndex_4; }
	inline void set_m_AtlasIndex_4(int32_t value)
	{
		___m_AtlasIndex_4 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_pinvoke
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___m_Metrics_1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_com
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___m_Metrics_1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
};

// UnityEngine.TextCore.LowLevel.FontEngineError
struct  FontEngineError_t64F8E9C372D8AC63E9BA857AC757719A321C357B 
{
public:
	// System.Int32 UnityEngine.TextCore.LowLevel.FontEngineError::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FontEngineError_t64F8E9C372D8AC63E9BA857AC757719A321C357B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord
struct  GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 
{
public:
	// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphIndex
	uint32_t ___m_GlyphIndex_0;
	// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphValueRecord
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  ___m_GlyphValueRecord_1;

public:
	inline static int32_t get_offset_of_m_GlyphIndex_0() { return static_cast<int32_t>(offsetof(GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00, ___m_GlyphIndex_0)); }
	inline uint32_t get_m_GlyphIndex_0() const { return ___m_GlyphIndex_0; }
	inline uint32_t* get_address_of_m_GlyphIndex_0() { return &___m_GlyphIndex_0; }
	inline void set_m_GlyphIndex_0(uint32_t value)
	{
		___m_GlyphIndex_0 = value;
	}

	inline static int32_t get_offset_of_m_GlyphValueRecord_1() { return static_cast<int32_t>(offsetof(GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00, ___m_GlyphValueRecord_1)); }
	inline GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  get_m_GlyphValueRecord_1() const { return ___m_GlyphValueRecord_1; }
	inline GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * get_address_of_m_GlyphValueRecord_1() { return &___m_GlyphValueRecord_1; }
	inline void set_m_GlyphValueRecord_1(GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  value)
	{
		___m_GlyphValueRecord_1 = value;
	}
};


// UnityEngine.TextCore.LowLevel.GlyphLoadFlags
struct  GlyphLoadFlags_t009F1B3663C1AC0CE62D615975C1F77A986C9F09 
{
public:
	// System.Int32 UnityEngine.TextCore.LowLevel.GlyphLoadFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(GlyphLoadFlags_t009F1B3663C1AC0CE62D615975C1F77A986C9F09, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct
struct  GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 
{
public:
	// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::index
	uint32_t ___index_0;
	// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::metrics
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___metrics_1;
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::glyphRect
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___glyphRect_2;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::scale
	float ___scale_3;
	// System.Int32 UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::atlasIndex
	int32_t ___atlasIndex_4;

public:
	inline static int32_t get_offset_of_index_0() { return static_cast<int32_t>(offsetof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448, ___index_0)); }
	inline uint32_t get_index_0() const { return ___index_0; }
	inline uint32_t* get_address_of_index_0() { return &___index_0; }
	inline void set_index_0(uint32_t value)
	{
		___index_0 = value;
	}

	inline static int32_t get_offset_of_metrics_1() { return static_cast<int32_t>(offsetof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448, ___metrics_1)); }
	inline GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  get_metrics_1() const { return ___metrics_1; }
	inline GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * get_address_of_metrics_1() { return &___metrics_1; }
	inline void set_metrics_1(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  value)
	{
		___metrics_1 = value;
	}

	inline static int32_t get_offset_of_glyphRect_2() { return static_cast<int32_t>(offsetof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448, ___glyphRect_2)); }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  get_glyphRect_2() const { return ___glyphRect_2; }
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * get_address_of_glyphRect_2() { return &___glyphRect_2; }
	inline void set_glyphRect_2(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  value)
	{
		___glyphRect_2 = value;
	}

	inline static int32_t get_offset_of_scale_3() { return static_cast<int32_t>(offsetof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448, ___scale_3)); }
	inline float get_scale_3() const { return ___scale_3; }
	inline float* get_address_of_scale_3() { return &___scale_3; }
	inline void set_scale_3(float value)
	{
		___scale_3 = value;
	}

	inline static int32_t get_offset_of_atlasIndex_4() { return static_cast<int32_t>(offsetof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448, ___atlasIndex_4)); }
	inline int32_t get_atlasIndex_4() const { return ___atlasIndex_4; }
	inline int32_t* get_address_of_atlasIndex_4() { return &___atlasIndex_4; }
	inline void set_atlasIndex_4(int32_t value)
	{
		___atlasIndex_4 = value;
	}
};


// UnityEngine.TextCore.LowLevel.GlyphPackingMode
struct  GlyphPackingMode_t61CDE7969B3E630F7BF8D982B58F0F35B367D9AE 
{
public:
	// System.Int32 UnityEngine.TextCore.LowLevel.GlyphPackingMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(GlyphPackingMode_t61CDE7969B3E630F7BF8D982B58F0F35B367D9AE, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.TextCore.LowLevel.GlyphRenderMode
struct  GlyphRenderMode_t73887B794BC6100E833D50FB9F5BF86B6D5D4A0D 
{
public:
	// System.Int32 UnityEngine.TextCore.LowLevel.GlyphRenderMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(GlyphRenderMode_t73887B794BC6100E833D50FB9F5BF86B6D5D4A0D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Font
struct  Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:
	// UnityEngine.Font_FontTextureRebuildCallback UnityEngine.Font::m_FontTextureRebuildCallback
	FontTextureRebuildCallback_tD700C63BB1A449E3A0464C81701E981677D3021C * ___m_FontTextureRebuildCallback_5;

public:
	inline static int32_t get_offset_of_m_FontTextureRebuildCallback_5() { return static_cast<int32_t>(offsetof(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26, ___m_FontTextureRebuildCallback_5)); }
	inline FontTextureRebuildCallback_tD700C63BB1A449E3A0464C81701E981677D3021C * get_m_FontTextureRebuildCallback_5() const { return ___m_FontTextureRebuildCallback_5; }
	inline FontTextureRebuildCallback_tD700C63BB1A449E3A0464C81701E981677D3021C ** get_address_of_m_FontTextureRebuildCallback_5() { return &___m_FontTextureRebuildCallback_5; }
	inline void set_m_FontTextureRebuildCallback_5(FontTextureRebuildCallback_tD700C63BB1A449E3A0464C81701E981677D3021C * value)
	{
		___m_FontTextureRebuildCallback_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FontTextureRebuildCallback_5), (void*)value);
	}
};

struct Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26_StaticFields
{
public:
	// System.Action`1<UnityEngine.Font> UnityEngine.Font::textureRebuilt
	Action_1_t795662E553415ECF2DD0F8EEB9BA170C3670F37C * ___textureRebuilt_4;

public:
	inline static int32_t get_offset_of_textureRebuilt_4() { return static_cast<int32_t>(offsetof(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26_StaticFields, ___textureRebuilt_4)); }
	inline Action_1_t795662E553415ECF2DD0F8EEB9BA170C3670F37C * get_textureRebuilt_4() const { return ___textureRebuilt_4; }
	inline Action_1_t795662E553415ECF2DD0F8EEB9BA170C3670F37C ** get_address_of_textureRebuilt_4() { return &___textureRebuilt_4; }
	inline void set_textureRebuilt_4(Action_1_t795662E553415ECF2DD0F8EEB9BA170C3670F37C * value)
	{
		___textureRebuilt_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___textureRebuilt_4), (void*)value);
	}
};


// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord
struct  GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C 
{
public:
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_FirstAdjustmentRecord
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  ___m_FirstAdjustmentRecord_0;
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_SecondAdjustmentRecord
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  ___m_SecondAdjustmentRecord_1;

public:
	inline static int32_t get_offset_of_m_FirstAdjustmentRecord_0() { return static_cast<int32_t>(offsetof(GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C, ___m_FirstAdjustmentRecord_0)); }
	inline GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  get_m_FirstAdjustmentRecord_0() const { return ___m_FirstAdjustmentRecord_0; }
	inline GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * get_address_of_m_FirstAdjustmentRecord_0() { return &___m_FirstAdjustmentRecord_0; }
	inline void set_m_FirstAdjustmentRecord_0(GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  value)
	{
		___m_FirstAdjustmentRecord_0 = value;
	}

	inline static int32_t get_offset_of_m_SecondAdjustmentRecord_1() { return static_cast<int32_t>(offsetof(GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C, ___m_SecondAdjustmentRecord_1)); }
	inline GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  get_m_SecondAdjustmentRecord_1() const { return ___m_SecondAdjustmentRecord_1; }
	inline GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * get_address_of_m_SecondAdjustmentRecord_1() { return &___m_SecondAdjustmentRecord_1; }
	inline void set_m_SecondAdjustmentRecord_1(GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  value)
	{
		___m_SecondAdjustmentRecord_1 = value;
	}
};


// UnityEngine.Texture
struct  Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4_StaticFields
{
public:
	// System.Int32 UnityEngine.Texture::GenerateAllMips
	int32_t ___GenerateAllMips_4;

public:
	inline static int32_t get_offset_of_GenerateAllMips_4() { return static_cast<int32_t>(offsetof(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4_StaticFields, ___GenerateAllMips_4)); }
	inline int32_t get_GenerateAllMips_4() const { return ___GenerateAllMips_4; }
	inline int32_t* get_address_of_GenerateAllMips_4() { return &___GenerateAllMips_4; }
	inline void set_GenerateAllMips_4(int32_t value)
	{
		___GenerateAllMips_4 = value;
	}
};


// UnityEngine.Texture2D
struct  Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C  : public Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.TextCore.GlyphRect[]
struct GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  m_Items[1];

public:
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[]
struct GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  m_Items[1];

public:
	inline GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Glyph[]
struct GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * m_Items[1];

public:
	inline Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.UInt32[]
struct UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint32_t m_Items[1];

public:
	inline uint32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint32_t value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[]
struct GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C  m_Items[1];

public:
	inline GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C  value)
	{
		m_Items[index] = value;
	}
};
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


// System.Int32 System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::get_Count()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_gshared_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::get_Item(System.Int32)
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_gshared_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_gshared (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::Add(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_gshared (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___item0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared_inline (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR RuntimeObject * List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared_inline (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.UInt32>::get_Count()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_gshared_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.UInt32>::get_Item(System.Int32)
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR uint32_t List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_gshared_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.UInt32,System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m7A72E1813C14D0E707F0A81C100E6C5B49213421_gshared (Dictionary_2_t9D3330644BF8CBACB84AB5EA2438CFB219E5D4D7 * __this, const RuntimeMethod* method);

// System.Void UnityEngine.TextCore.FaceInfo::set_familyName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_styleName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_pointSize(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_scale(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_lineHeight(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_ascentLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_capLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_meanLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_baseline(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_descentLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_superscriptOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_superscriptOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_superscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_superscriptSize(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_subscriptOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_subscriptSize(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_underlineOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineThickness()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_underlineThickness(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughThickness(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.FaceInfo::set_tabWidth(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method);
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.GlyphMetrics::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, float ___width0, float ___height1, float ___bearingX2, float ___bearingY3, float ___advance4, const RuntimeMethod* method);
// System.Int32 System.ValueType::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ValueType_GetHashCode_m48E9FA7FFC7C27D876E764A94E3CF2039ED6C9F9 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphMetrics::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method);
// System.Boolean System.ValueType::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ValueType_Equals_m5F6E6FDB8422FE9AFF6435C0C729FBE1032F4980 (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(UnityEngine.TextCore.GlyphMetrics)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___other0, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphRect::get_x()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphRect::get_y()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphRect::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphRect::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.GlyphRect::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, int32_t ___x0, int32_t ___y1, int32_t ___width2, int32_t ___height3, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.GlyphRect::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.GlyphRect::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.GlyphRect::Equals(UnityEngine.TextCore.GlyphRect)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___other0, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445 (const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013 (Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___font0, int32_t ___pointSize1, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * ___faceInfo0, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C (uint32_t ___unicode0, int32_t ___loadFlags1, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyphStruct2, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.Glyph::.ctor(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  ___glyphStruct0, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170 (uint32_t ___glyphIndex0, int32_t ___loadFlags1, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyphStruct2, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::.ctor(UnityEngine.TextCore.Glyph)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220 (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * __this, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * ___glyph0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::get_Count()
inline int32_t List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 *, const RuntimeMethod*))List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_gshared_inline)(__this, method);
}
// System.Int32 UnityEngine.Mathf::NextPowerOfTwo(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7 (int32_t ___value0, const RuntimeMethod* method);
// System.Int32 UnityEngine.Mathf::Max(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F (int32_t ___a0, int32_t ___b1, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::get_Item(System.Int32)
inline GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  (*) (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 *, int32_t, const RuntimeMethod*))List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_gshared_inline)(__this, ___index0, method);
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyph0, int32_t ___padding1, int32_t ___packingMode2, int32_t ___renderMode3, int32_t ___width4, int32_t ___height5, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects6, int32_t* ___freeGlyphRectCount7, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects8, int32_t* ___usedGlyphRectCount9, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.Glyph::set_glyphRect(UnityEngine.TextCore.GlyphRect)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_glyphRect_m5D45BF2EF4A7738AF7158D49DEDB5E09E034742C (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___value0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::Clear()
inline void List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780 (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 *, const RuntimeMethod*))List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>::Add(!0)
inline void List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___item0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 *, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C , const RuntimeMethod*))List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_gshared)(__this, ___item0, method);
}
// System.Int32 System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>::get_Count()
inline int32_t List_1_get_Count_m4A32B5B2CCE68FC874FEF42E9B23320FAF0828D3_inline (List_1_t8B3AA8D740B2E10383225037638055610A7BE123 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t8B3AA8D740B2E10383225037638055610A7BE123 *, const RuntimeMethod*))List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared_inline)(__this, method);
}
// !0 System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>::get_Item(System.Int32)
inline Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * List_1_get_Item_m1AA0C2D8B9692306C4D1AD0F721F4DAB85734BC5_inline (List_1_t8B3AA8D740B2E10383225037638055610A7BE123 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * (*) (List_1_t8B3AA8D740B2E10383225037638055610A7BE123 *, int32_t, const RuntimeMethod*))List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared_inline)(__this, ___index0, method);
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___glyphs0, int32_t ___glyphCount1, int32_t ___padding2, int32_t ___renderMode3, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture4, const RuntimeMethod* method);
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82 (uint32_t ___glyphIndex0, int32_t ___padding1, int32_t ___packingMode2, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects3, int32_t* ___freeGlyphRectCount4, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects5, int32_t* ___usedGlyphRectCount6, int32_t ___renderMode7, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture8, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyph9, const RuntimeMethod* method);
// System.Void UnityEngine.Profiling.Profiler::BeginSample(System.String)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Profiler_BeginSample_mDA159D5771838F40FC7C2829B2DC4329F8C9596B_inline (String_t* ___name0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.UInt32>::get_Count()
inline int32_t List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E *, const RuntimeMethod*))List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_gshared_inline)(__this, method);
}
// System.Void UnityEngine.Profiling.Profiler::EndSample()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Profiler_EndSample_m15350A0463FB3C5789504B4059B0EA68D5B70A21 (const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngineUtilities::MaxValue(System.Int32,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215 (int32_t ___a0, int32_t ___b1, int32_t ___c2, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.UInt32>::get_Item(System.Int32)
inline uint32_t List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  uint32_t (*) (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E *, int32_t, const RuntimeMethod*))List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_gshared_inline)(__this, ___index0, method);
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___glyphIndex0, int32_t ___padding1, int32_t ___packingMode2, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects3, int32_t* ___freeGlyphRectCount4, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects5, int32_t* ___usedGlyphRectCount6, int32_t ___renderMode7, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture8, GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___glyphs9, int32_t* ___glyphCount10, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable_Internal(System.UInt32[],UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8 (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___glyphIndexes0, GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* ___glyphPairAdjustmentRecords1, int32_t* ___adjustmentRecordCount2, const RuntimeMethod* method);
// System.Void System.Array::Clear(System.Array,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Array_Clear_m174F4957D6DEDB6359835123005304B14E79132E (RuntimeArray * ___array0, int32_t ___index1, int32_t ___length2, const RuntimeMethod* method);
// System.Void UnityEngine.TextCore.LowLevel.FontEngine::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontEngine__ctor_m90CBF12264B15BCA2368C372FC2062A06B0E788F (FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph>::.ctor()
inline void Dictionary_2__ctor_mD40472A556EEC9DFC4FC7FFB8413799EAAACB65E (Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B *, const RuntimeMethod*))Dictionary_2__ctor_m7A72E1813C14D0E707F0A81C100E6C5B49213421_gshared)(__this, method);
}
// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3 (GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * __this, const RuntimeMethod* method);
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC (GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * __this, const RuntimeMethod* method);
// System.UInt32 UnityEngine.TextCore.Glyph::get_index()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Glyph_get_index_mE8CFBF3B6E08A43EF11AA2E941F7FD9EDFF1C79F (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method);
// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  Glyph_get_metrics_m25A3C9DDEA15A3EC461A53F194F549699322A811 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method);
// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::get_glyphRect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  Glyph_get_glyphRect_mD937109DC8AE147EED30E0CEB667ACAAE281D4F0 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.Glyph::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Glyph_get_scale_mB6FDF083196D83B61233ECBF9407A708DE4F692E (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.TextCore.Glyph::get_atlasIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Glyph_get_atlasIndex_mF246F5C157408FCD5281DBFF08E21CBF28BB529A (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method);
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46 (GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * __this, const RuntimeMethod* method);
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66 (GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279 (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method);
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4 (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Profiling.Profiler::BeginSampleImpl(System.String,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Profiler_BeginSampleImpl_m831FE453CD200A1F5C3C49DB9E0D831C89B70751 (String_t* ___name0, Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___targetObject1, const RuntimeMethod* method);
// System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowArgumentOutOfRangeException_mBA2AF20A35144E0C43CD721A22EAC9FCA15D6550 (const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.TextCore.FaceInfo
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_pinvoke(const FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8& unmarshaled, FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_pinvoke& marshaled)
{
	marshaled.___m_FamilyName_0 = il2cpp_codegen_marshal_string(unmarshaled.get_m_FamilyName_0());
	marshaled.___m_StyleName_1 = il2cpp_codegen_marshal_string(unmarshaled.get_m_StyleName_1());
	marshaled.___m_PointSize_2 = unmarshaled.get_m_PointSize_2();
	marshaled.___m_Scale_3 = unmarshaled.get_m_Scale_3();
	marshaled.___m_LineHeight_4 = unmarshaled.get_m_LineHeight_4();
	marshaled.___m_AscentLine_5 = unmarshaled.get_m_AscentLine_5();
	marshaled.___m_CapLine_6 = unmarshaled.get_m_CapLine_6();
	marshaled.___m_MeanLine_7 = unmarshaled.get_m_MeanLine_7();
	marshaled.___m_Baseline_8 = unmarshaled.get_m_Baseline_8();
	marshaled.___m_DescentLine_9 = unmarshaled.get_m_DescentLine_9();
	marshaled.___m_SuperscriptOffset_10 = unmarshaled.get_m_SuperscriptOffset_10();
	marshaled.___m_SuperscriptSize_11 = unmarshaled.get_m_SuperscriptSize_11();
	marshaled.___m_SubscriptOffset_12 = unmarshaled.get_m_SubscriptOffset_12();
	marshaled.___m_SubscriptSize_13 = unmarshaled.get_m_SubscriptSize_13();
	marshaled.___m_UnderlineOffset_14 = unmarshaled.get_m_UnderlineOffset_14();
	marshaled.___m_UnderlineThickness_15 = unmarshaled.get_m_UnderlineThickness_15();
	marshaled.___m_StrikethroughOffset_16 = unmarshaled.get_m_StrikethroughOffset_16();
	marshaled.___m_StrikethroughThickness_17 = unmarshaled.get_m_StrikethroughThickness_17();
	marshaled.___m_TabWidth_18 = unmarshaled.get_m_TabWidth_18();
}
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_pinvoke_back(const FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_pinvoke& marshaled, FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8& unmarshaled)
{
	unmarshaled.set_m_FamilyName_0(il2cpp_codegen_marshal_string_result(marshaled.___m_FamilyName_0));
	unmarshaled.set_m_StyleName_1(il2cpp_codegen_marshal_string_result(marshaled.___m_StyleName_1));
	int32_t unmarshaled_m_PointSize_temp_2 = 0;
	unmarshaled_m_PointSize_temp_2 = marshaled.___m_PointSize_2;
	unmarshaled.set_m_PointSize_2(unmarshaled_m_PointSize_temp_2);
	float unmarshaled_m_Scale_temp_3 = 0.0f;
	unmarshaled_m_Scale_temp_3 = marshaled.___m_Scale_3;
	unmarshaled.set_m_Scale_3(unmarshaled_m_Scale_temp_3);
	float unmarshaled_m_LineHeight_temp_4 = 0.0f;
	unmarshaled_m_LineHeight_temp_4 = marshaled.___m_LineHeight_4;
	unmarshaled.set_m_LineHeight_4(unmarshaled_m_LineHeight_temp_4);
	float unmarshaled_m_AscentLine_temp_5 = 0.0f;
	unmarshaled_m_AscentLine_temp_5 = marshaled.___m_AscentLine_5;
	unmarshaled.set_m_AscentLine_5(unmarshaled_m_AscentLine_temp_5);
	float unmarshaled_m_CapLine_temp_6 = 0.0f;
	unmarshaled_m_CapLine_temp_6 = marshaled.___m_CapLine_6;
	unmarshaled.set_m_CapLine_6(unmarshaled_m_CapLine_temp_6);
	float unmarshaled_m_MeanLine_temp_7 = 0.0f;
	unmarshaled_m_MeanLine_temp_7 = marshaled.___m_MeanLine_7;
	unmarshaled.set_m_MeanLine_7(unmarshaled_m_MeanLine_temp_7);
	float unmarshaled_m_Baseline_temp_8 = 0.0f;
	unmarshaled_m_Baseline_temp_8 = marshaled.___m_Baseline_8;
	unmarshaled.set_m_Baseline_8(unmarshaled_m_Baseline_temp_8);
	float unmarshaled_m_DescentLine_temp_9 = 0.0f;
	unmarshaled_m_DescentLine_temp_9 = marshaled.___m_DescentLine_9;
	unmarshaled.set_m_DescentLine_9(unmarshaled_m_DescentLine_temp_9);
	float unmarshaled_m_SuperscriptOffset_temp_10 = 0.0f;
	unmarshaled_m_SuperscriptOffset_temp_10 = marshaled.___m_SuperscriptOffset_10;
	unmarshaled.set_m_SuperscriptOffset_10(unmarshaled_m_SuperscriptOffset_temp_10);
	float unmarshaled_m_SuperscriptSize_temp_11 = 0.0f;
	unmarshaled_m_SuperscriptSize_temp_11 = marshaled.___m_SuperscriptSize_11;
	unmarshaled.set_m_SuperscriptSize_11(unmarshaled_m_SuperscriptSize_temp_11);
	float unmarshaled_m_SubscriptOffset_temp_12 = 0.0f;
	unmarshaled_m_SubscriptOffset_temp_12 = marshaled.___m_SubscriptOffset_12;
	unmarshaled.set_m_SubscriptOffset_12(unmarshaled_m_SubscriptOffset_temp_12);
	float unmarshaled_m_SubscriptSize_temp_13 = 0.0f;
	unmarshaled_m_SubscriptSize_temp_13 = marshaled.___m_SubscriptSize_13;
	unmarshaled.set_m_SubscriptSize_13(unmarshaled_m_SubscriptSize_temp_13);
	float unmarshaled_m_UnderlineOffset_temp_14 = 0.0f;
	unmarshaled_m_UnderlineOffset_temp_14 = marshaled.___m_UnderlineOffset_14;
	unmarshaled.set_m_UnderlineOffset_14(unmarshaled_m_UnderlineOffset_temp_14);
	float unmarshaled_m_UnderlineThickness_temp_15 = 0.0f;
	unmarshaled_m_UnderlineThickness_temp_15 = marshaled.___m_UnderlineThickness_15;
	unmarshaled.set_m_UnderlineThickness_15(unmarshaled_m_UnderlineThickness_temp_15);
	float unmarshaled_m_StrikethroughOffset_temp_16 = 0.0f;
	unmarshaled_m_StrikethroughOffset_temp_16 = marshaled.___m_StrikethroughOffset_16;
	unmarshaled.set_m_StrikethroughOffset_16(unmarshaled_m_StrikethroughOffset_temp_16);
	float unmarshaled_m_StrikethroughThickness_temp_17 = 0.0f;
	unmarshaled_m_StrikethroughThickness_temp_17 = marshaled.___m_StrikethroughThickness_17;
	unmarshaled.set_m_StrikethroughThickness_17(unmarshaled_m_StrikethroughThickness_temp_17);
	float unmarshaled_m_TabWidth_temp_18 = 0.0f;
	unmarshaled_m_TabWidth_temp_18 = marshaled.___m_TabWidth_18;
	unmarshaled.set_m_TabWidth_18(unmarshaled_m_TabWidth_temp_18);
}
// Conversion method for clean up from marshalling of: UnityEngine.TextCore.FaceInfo
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_pinvoke_cleanup(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___m_FamilyName_0);
	marshaled.___m_FamilyName_0 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___m_StyleName_1);
	marshaled.___m_StyleName_1 = NULL;
}
// Conversion methods for marshalling of: UnityEngine.TextCore.FaceInfo
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_com(const FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8& unmarshaled, FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_com& marshaled)
{
	marshaled.___m_FamilyName_0 = il2cpp_codegen_marshal_bstring(unmarshaled.get_m_FamilyName_0());
	marshaled.___m_StyleName_1 = il2cpp_codegen_marshal_bstring(unmarshaled.get_m_StyleName_1());
	marshaled.___m_PointSize_2 = unmarshaled.get_m_PointSize_2();
	marshaled.___m_Scale_3 = unmarshaled.get_m_Scale_3();
	marshaled.___m_LineHeight_4 = unmarshaled.get_m_LineHeight_4();
	marshaled.___m_AscentLine_5 = unmarshaled.get_m_AscentLine_5();
	marshaled.___m_CapLine_6 = unmarshaled.get_m_CapLine_6();
	marshaled.___m_MeanLine_7 = unmarshaled.get_m_MeanLine_7();
	marshaled.___m_Baseline_8 = unmarshaled.get_m_Baseline_8();
	marshaled.___m_DescentLine_9 = unmarshaled.get_m_DescentLine_9();
	marshaled.___m_SuperscriptOffset_10 = unmarshaled.get_m_SuperscriptOffset_10();
	marshaled.___m_SuperscriptSize_11 = unmarshaled.get_m_SuperscriptSize_11();
	marshaled.___m_SubscriptOffset_12 = unmarshaled.get_m_SubscriptOffset_12();
	marshaled.___m_SubscriptSize_13 = unmarshaled.get_m_SubscriptSize_13();
	marshaled.___m_UnderlineOffset_14 = unmarshaled.get_m_UnderlineOffset_14();
	marshaled.___m_UnderlineThickness_15 = unmarshaled.get_m_UnderlineThickness_15();
	marshaled.___m_StrikethroughOffset_16 = unmarshaled.get_m_StrikethroughOffset_16();
	marshaled.___m_StrikethroughThickness_17 = unmarshaled.get_m_StrikethroughThickness_17();
	marshaled.___m_TabWidth_18 = unmarshaled.get_m_TabWidth_18();
}
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_com_back(const FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_com& marshaled, FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8& unmarshaled)
{
	unmarshaled.set_m_FamilyName_0(il2cpp_codegen_marshal_bstring_result(marshaled.___m_FamilyName_0));
	unmarshaled.set_m_StyleName_1(il2cpp_codegen_marshal_bstring_result(marshaled.___m_StyleName_1));
	int32_t unmarshaled_m_PointSize_temp_2 = 0;
	unmarshaled_m_PointSize_temp_2 = marshaled.___m_PointSize_2;
	unmarshaled.set_m_PointSize_2(unmarshaled_m_PointSize_temp_2);
	float unmarshaled_m_Scale_temp_3 = 0.0f;
	unmarshaled_m_Scale_temp_3 = marshaled.___m_Scale_3;
	unmarshaled.set_m_Scale_3(unmarshaled_m_Scale_temp_3);
	float unmarshaled_m_LineHeight_temp_4 = 0.0f;
	unmarshaled_m_LineHeight_temp_4 = marshaled.___m_LineHeight_4;
	unmarshaled.set_m_LineHeight_4(unmarshaled_m_LineHeight_temp_4);
	float unmarshaled_m_AscentLine_temp_5 = 0.0f;
	unmarshaled_m_AscentLine_temp_5 = marshaled.___m_AscentLine_5;
	unmarshaled.set_m_AscentLine_5(unmarshaled_m_AscentLine_temp_5);
	float unmarshaled_m_CapLine_temp_6 = 0.0f;
	unmarshaled_m_CapLine_temp_6 = marshaled.___m_CapLine_6;
	unmarshaled.set_m_CapLine_6(unmarshaled_m_CapLine_temp_6);
	float unmarshaled_m_MeanLine_temp_7 = 0.0f;
	unmarshaled_m_MeanLine_temp_7 = marshaled.___m_MeanLine_7;
	unmarshaled.set_m_MeanLine_7(unmarshaled_m_MeanLine_temp_7);
	float unmarshaled_m_Baseline_temp_8 = 0.0f;
	unmarshaled_m_Baseline_temp_8 = marshaled.___m_Baseline_8;
	unmarshaled.set_m_Baseline_8(unmarshaled_m_Baseline_temp_8);
	float unmarshaled_m_DescentLine_temp_9 = 0.0f;
	unmarshaled_m_DescentLine_temp_9 = marshaled.___m_DescentLine_9;
	unmarshaled.set_m_DescentLine_9(unmarshaled_m_DescentLine_temp_9);
	float unmarshaled_m_SuperscriptOffset_temp_10 = 0.0f;
	unmarshaled_m_SuperscriptOffset_temp_10 = marshaled.___m_SuperscriptOffset_10;
	unmarshaled.set_m_SuperscriptOffset_10(unmarshaled_m_SuperscriptOffset_temp_10);
	float unmarshaled_m_SuperscriptSize_temp_11 = 0.0f;
	unmarshaled_m_SuperscriptSize_temp_11 = marshaled.___m_SuperscriptSize_11;
	unmarshaled.set_m_SuperscriptSize_11(unmarshaled_m_SuperscriptSize_temp_11);
	float unmarshaled_m_SubscriptOffset_temp_12 = 0.0f;
	unmarshaled_m_SubscriptOffset_temp_12 = marshaled.___m_SubscriptOffset_12;
	unmarshaled.set_m_SubscriptOffset_12(unmarshaled_m_SubscriptOffset_temp_12);
	float unmarshaled_m_SubscriptSize_temp_13 = 0.0f;
	unmarshaled_m_SubscriptSize_temp_13 = marshaled.___m_SubscriptSize_13;
	unmarshaled.set_m_SubscriptSize_13(unmarshaled_m_SubscriptSize_temp_13);
	float unmarshaled_m_UnderlineOffset_temp_14 = 0.0f;
	unmarshaled_m_UnderlineOffset_temp_14 = marshaled.___m_UnderlineOffset_14;
	unmarshaled.set_m_UnderlineOffset_14(unmarshaled_m_UnderlineOffset_temp_14);
	float unmarshaled_m_UnderlineThickness_temp_15 = 0.0f;
	unmarshaled_m_UnderlineThickness_temp_15 = marshaled.___m_UnderlineThickness_15;
	unmarshaled.set_m_UnderlineThickness_15(unmarshaled_m_UnderlineThickness_temp_15);
	float unmarshaled_m_StrikethroughOffset_temp_16 = 0.0f;
	unmarshaled_m_StrikethroughOffset_temp_16 = marshaled.___m_StrikethroughOffset_16;
	unmarshaled.set_m_StrikethroughOffset_16(unmarshaled_m_StrikethroughOffset_temp_16);
	float unmarshaled_m_StrikethroughThickness_temp_17 = 0.0f;
	unmarshaled_m_StrikethroughThickness_temp_17 = marshaled.___m_StrikethroughThickness_17;
	unmarshaled.set_m_StrikethroughThickness_17(unmarshaled_m_StrikethroughThickness_temp_17);
	float unmarshaled_m_TabWidth_temp_18 = 0.0f;
	unmarshaled_m_TabWidth_temp_18 = marshaled.___m_TabWidth_18;
	unmarshaled.set_m_TabWidth_18(unmarshaled_m_TabWidth_temp_18);
}
// Conversion method for clean up from marshalling of: UnityEngine.TextCore.FaceInfo
IL2CPP_EXTERN_C void FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshal_com_cleanup(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___m_FamilyName_0);
	marshaled.___m_FamilyName_0 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___m_StyleName_1);
	marshaled.___m_StyleName_1 = NULL;
}
// System.Void UnityEngine.TextCore.FaceInfo::set_familyName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_m_FamilyName_0(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD_AdjustorThunk (RuntimeObject * __this, String_t* ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD(_thisAdjusted, ___value0, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_styleName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_m_StyleName_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689_AdjustorThunk (RuntimeObject * __this, String_t* ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689(_thisAdjusted, ___value0, method);
}
// System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_PointSize_2();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_pointSize(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_m_PointSize_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_Scale_3();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_scale(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_Scale_3(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_LineHeight_4();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_lineHeight(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_LineHeight_4(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_AscentLine_5();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_ascentLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_AscentLine_5(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_CapLine_6();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_capLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_CapLine_6(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3(_thisAdjusted, ___value0, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_meanLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_MeanLine_7(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_Baseline_8();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_baseline(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_Baseline_8(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_DescentLine_9();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_descentLine(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_DescentLine_9(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_superscriptOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_SuperscriptOffset_10();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_superscriptOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_SuperscriptOffset_10(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_superscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_SuperscriptSize_11();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_superscriptSize(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_SuperscriptSize_11(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_SubscriptOffset_12();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_subscriptOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_SubscriptOffset_12(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_SubscriptSize_13();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_subscriptSize(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_SubscriptSize_13(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_UnderlineOffset_14();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_underlineOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_UnderlineOffset_14(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineThickness()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_UnderlineThickness_15();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_underlineThickness(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_UnderlineThickness_15(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_StrikethroughOffset_16();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughOffset(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_StrikethroughOffset_16(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1(_thisAdjusted, ___value0, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughThickness(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_StrikethroughThickness_17(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_TabWidth_18();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	return FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.FaceInfo::set_tabWidth(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5 (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_TabWidth_18(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * _thisAdjusted = reinterpret_cast<FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *>(__this + _offset);
	FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.TextCore.Glyph
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_pinvoke(const Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4& unmarshaled, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_pinvoke& marshaled)
{
	marshaled.___m_Index_0 = unmarshaled.get_m_Index_0();
	marshaled.___m_Metrics_1 = unmarshaled.get_m_Metrics_1();
	marshaled.___m_GlyphRect_2 = unmarshaled.get_m_GlyphRect_2();
	marshaled.___m_Scale_3 = unmarshaled.get_m_Scale_3();
	marshaled.___m_AtlasIndex_4 = unmarshaled.get_m_AtlasIndex_4();
}
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_pinvoke_back(const Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_pinvoke& marshaled, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4& unmarshaled)
{
	uint32_t unmarshaled_m_Index_temp_0 = 0;
	unmarshaled_m_Index_temp_0 = marshaled.___m_Index_0;
	unmarshaled.set_m_Index_0(unmarshaled_m_Index_temp_0);
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  unmarshaled_m_Metrics_temp_1;
	memset((&unmarshaled_m_Metrics_temp_1), 0, sizeof(unmarshaled_m_Metrics_temp_1));
	unmarshaled_m_Metrics_temp_1 = marshaled.___m_Metrics_1;
	unmarshaled.set_m_Metrics_1(unmarshaled_m_Metrics_temp_1);
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  unmarshaled_m_GlyphRect_temp_2;
	memset((&unmarshaled_m_GlyphRect_temp_2), 0, sizeof(unmarshaled_m_GlyphRect_temp_2));
	unmarshaled_m_GlyphRect_temp_2 = marshaled.___m_GlyphRect_2;
	unmarshaled.set_m_GlyphRect_2(unmarshaled_m_GlyphRect_temp_2);
	float unmarshaled_m_Scale_temp_3 = 0.0f;
	unmarshaled_m_Scale_temp_3 = marshaled.___m_Scale_3;
	unmarshaled.set_m_Scale_3(unmarshaled_m_Scale_temp_3);
	int32_t unmarshaled_m_AtlasIndex_temp_4 = 0;
	unmarshaled_m_AtlasIndex_temp_4 = marshaled.___m_AtlasIndex_4;
	unmarshaled.set_m_AtlasIndex_4(unmarshaled_m_AtlasIndex_temp_4);
}
// Conversion method for clean up from marshalling of: UnityEngine.TextCore.Glyph
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_pinvoke_cleanup(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.TextCore.Glyph
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_com(const Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4& unmarshaled, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_com& marshaled)
{
	marshaled.___m_Index_0 = unmarshaled.get_m_Index_0();
	marshaled.___m_Metrics_1 = unmarshaled.get_m_Metrics_1();
	marshaled.___m_GlyphRect_2 = unmarshaled.get_m_GlyphRect_2();
	marshaled.___m_Scale_3 = unmarshaled.get_m_Scale_3();
	marshaled.___m_AtlasIndex_4 = unmarshaled.get_m_AtlasIndex_4();
}
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_com_back(const Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_com& marshaled, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4& unmarshaled)
{
	uint32_t unmarshaled_m_Index_temp_0 = 0;
	unmarshaled_m_Index_temp_0 = marshaled.___m_Index_0;
	unmarshaled.set_m_Index_0(unmarshaled_m_Index_temp_0);
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  unmarshaled_m_Metrics_temp_1;
	memset((&unmarshaled_m_Metrics_temp_1), 0, sizeof(unmarshaled_m_Metrics_temp_1));
	unmarshaled_m_Metrics_temp_1 = marshaled.___m_Metrics_1;
	unmarshaled.set_m_Metrics_1(unmarshaled_m_Metrics_temp_1);
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  unmarshaled_m_GlyphRect_temp_2;
	memset((&unmarshaled_m_GlyphRect_temp_2), 0, sizeof(unmarshaled_m_GlyphRect_temp_2));
	unmarshaled_m_GlyphRect_temp_2 = marshaled.___m_GlyphRect_2;
	unmarshaled.set_m_GlyphRect_2(unmarshaled_m_GlyphRect_temp_2);
	float unmarshaled_m_Scale_temp_3 = 0.0f;
	unmarshaled_m_Scale_temp_3 = marshaled.___m_Scale_3;
	unmarshaled.set_m_Scale_3(unmarshaled_m_Scale_temp_3);
	int32_t unmarshaled_m_AtlasIndex_temp_4 = 0;
	unmarshaled_m_AtlasIndex_temp_4 = marshaled.___m_AtlasIndex_4;
	unmarshaled.set_m_AtlasIndex_4(unmarshaled_m_AtlasIndex_temp_4);
}
// Conversion method for clean up from marshalling of: UnityEngine.TextCore.Glyph
IL2CPP_EXTERN_C void Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshal_com_cleanup(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_marshaled_com& marshaled)
{
}
// System.UInt32 UnityEngine.TextCore.Glyph::get_index()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Glyph_get_index_mE8CFBF3B6E08A43EF11AA2E941F7FD9EDFF1C79F (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	uint32_t V_0 = 0;
	{
		uint32_t L_0 = __this->get_m_Index_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		uint32_t L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.Glyph::set_index(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_index_m188CF50CD0658F2312AF3EA620A7BC8640AAFF1A (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		uint32_t L_0 = ___value0;
		__this->set_m_Index_0(L_0);
		return;
	}
}
// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  Glyph_get_metrics_m25A3C9DDEA15A3EC461A53F194F549699322A811 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_0 = __this->get_m_Metrics_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.Glyph::set_metrics(UnityEngine.TextCore.GlyphMetrics)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_metrics_m94E3778C5179B44C6141DFC75202C295ADF00DD9 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___value0, const RuntimeMethod* method)
{
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_0 = ___value0;
		__this->set_m_Metrics_1(L_0);
		return;
	}
}
// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::get_glyphRect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  Glyph_get_glyphRect_mD937109DC8AE147EED30E0CEB667ACAAE281D4F0 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = __this->get_m_GlyphRect_2();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.Glyph::set_glyphRect(UnityEngine.TextCore.GlyphRect)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_glyphRect_m5D45BF2EF4A7738AF7158D49DEDB5E09E034742C (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___value0, const RuntimeMethod* method)
{
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = ___value0;
		__this->set_m_GlyphRect_2(L_0);
		return;
	}
}
// System.Single UnityEngine.TextCore.Glyph::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Glyph_get_scale_mB6FDF083196D83B61233ECBF9407A708DE4F692E (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_Scale_3();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.Glyph::set_scale(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_scale_m649B0F686653E1B9F9EA247C8F9F975EADABCF6C (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		float L_0 = ___value0;
		__this->set_m_Scale_3(L_0);
		return;
	}
}
// System.Int32 UnityEngine.TextCore.Glyph::get_atlasIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Glyph_get_atlasIndex_mF246F5C157408FCD5281DBFF08E21CBF28BB529A (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_AtlasIndex_4();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.Glyph::set_atlasIndex(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph_set_atlasIndex_m29899906406A5F1F909359F9F8CB0ED15C64D5E8 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_m_AtlasIndex_4(L_0);
		return;
	}
}
// System.Void UnityEngine.TextCore.Glyph::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph__ctor_m21EF1BF22F642135C7C98A7F3E4A025F069A5BA9 (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		__this->set_m_Index_0(0);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * L_0 = __this->get_address_of_m_Metrics_1();
		il2cpp_codegen_initobj(L_0, sizeof(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB ));
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * L_1 = __this->get_address_of_m_GlyphRect_2();
		il2cpp_codegen_initobj(L_1, sizeof(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C ));
		__this->set_m_Scale_3((1.0f));
		__this->set_m_AtlasIndex_4(0);
		return;
	}
}
// System.Void UnityEngine.TextCore.Glyph::.ctor(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  ___glyphStruct0, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_0 = ___glyphStruct0;
		uint32_t L_1 = L_0.get_index_0();
		__this->set_m_Index_0(L_1);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_2 = ___glyphStruct0;
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_3 = L_2.get_metrics_1();
		__this->set_m_Metrics_1(L_3);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_4 = ___glyphStruct0;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_5 = L_4.get_glyphRect_2();
		__this->set_m_GlyphRect_2(L_5);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_6 = ___glyphStruct0;
		float L_7 = L_6.get_scale_3();
		__this->set_m_Scale_3(L_7);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_8 = ___glyphStruct0;
		int32_t L_9 = L_8.get_atlasIndex_4();
		__this->set_m_AtlasIndex_4(L_9);
		return;
	}
}
// System.Void UnityEngine.TextCore.Glyph::.ctor(System.UInt32,UnityEngine.TextCore.GlyphMetrics,UnityEngine.TextCore.GlyphRect,System.Single,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Glyph__ctor_m138B15C3C7EF727A502378428EE4262C57E7518E (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * __this, uint32_t ___index0, GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___metrics1, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___glyphRect2, float ___scale3, int32_t ___atlasIndex4, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		uint32_t L_0 = ___index0;
		__this->set_m_Index_0(L_0);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_1 = ___metrics1;
		__this->set_m_Metrics_1(L_1);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_2 = ___glyphRect2;
		__this->set_m_GlyphRect_2(L_2);
		float L_3 = ___scale3;
		__this->set_m_Scale_3(L_3);
		int32_t L_4 = ___atlasIndex4;
		__this->set_m_AtlasIndex_4(L_4);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_Width_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_Height_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_HorizontalBearingX_2();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_HorizontalBearingY_3();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_HorizontalAdvance_4();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0(_thisAdjusted, method);
}
// System.Void UnityEngine.TextCore.GlyphMetrics::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, float ___width0, float ___height1, float ___bearingX2, float ___bearingY3, float ___advance4, const RuntimeMethod* method)
{
	{
		float L_0 = ___width0;
		__this->set_m_Width_0(L_0);
		float L_1 = ___height1;
		__this->set_m_Height_1(L_1);
		float L_2 = ___bearingX2;
		__this->set_m_HorizontalBearingX_2(L_2);
		float L_3 = ___bearingY3;
		__this->set_m_HorizontalBearingY_3(L_3);
		float L_4 = ___advance4;
		__this->set_m_HorizontalAdvance_4(L_4);
		return;
	}
}
IL2CPP_EXTERN_C  void GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23_AdjustorThunk (RuntimeObject * __this, float ___width0, float ___height1, float ___bearingX2, float ___bearingY3, float ___advance4, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23(_thisAdjusted, ___width0, ___height1, ___bearingX2, ___bearingY3, ___advance4, method);
}
// System.Int32 UnityEngine.TextCore.GlyphMetrics::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_0 = (*(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *)__this);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB_il2cpp_TypeInfo_var, &L_1);
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		int32_t L_3 = ValueType_GetHashCode_m48E9FA7FFC7C27D876E764A94E3CF2039ED6C9F9((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		goto IL_0014;
	}

IL_0014:
	{
		int32_t L_4 = V_0;
		return L_4;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C(_thisAdjusted, method);
}
// System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3 (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_0 = (*(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *)__this);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB_il2cpp_TypeInfo_var, &L_1);
		RuntimeObject * L_3 = ___obj0;
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		bool L_4 = ValueType_Equals_m5F6E6FDB8422FE9AFF6435C0C729FBE1032F4980((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_0015;
	}

IL_0015:
	{
		bool L_5 = V_0;
		return L_5;
	}
}
IL2CPP_EXTERN_C  bool GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3(_thisAdjusted, ___obj0, method);
}
// System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(UnityEngine.TextCore.GlyphMetrics)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D (GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * __this, GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_0 = (*(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *)__this);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB_il2cpp_TypeInfo_var, &L_1);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_3 = ___other0;
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_4 = L_3;
		RuntimeObject * L_5 = Box(GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB_il2cpp_TypeInfo_var, &L_4);
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		bool L_6 = ValueType_Equals_m5F6E6FDB8422FE9AFF6435C0C729FBE1032F4980((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		goto IL_001a;
	}

IL_001a:
	{
		bool L_7 = V_0;
		return L_7;
	}
}
IL2CPP_EXTERN_C  bool GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D_AdjustorThunk (RuntimeObject * __this, GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  ___other0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB * _thisAdjusted = reinterpret_cast<GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB *>(__this + _offset);
	return GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D(_thisAdjusted, ___other0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 UnityEngine.TextCore.GlyphRect::get_x()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_X_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF(_thisAdjusted, method);
}
// System.Int32 UnityEngine.TextCore.GlyphRect::get_y()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_Y_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B(_thisAdjusted, method);
}
// System.Int32 UnityEngine.TextCore.GlyphRect::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_Width_2();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28(_thisAdjusted, method);
}
// System.Int32 UnityEngine.TextCore.GlyphRect::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_Height_3();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90(_thisAdjusted, method);
}
// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::get_zero()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  GlyphRect_get_zero_mA40D939BFBFB8D3A7301CA4A6D99A1DBDFC34736 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphRect_get_zero_mA40D939BFBFB8D3A7301CA4A6D99A1DBDFC34736_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		IL2CPP_RUNTIME_CLASS_INIT(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = ((GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_StaticFields*)il2cpp_codegen_static_fields_for(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var))->get_s_ZeroGlyphRect_4();
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.TextCore.GlyphRect::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, int32_t ___x0, int32_t ___y1, int32_t ___width2, int32_t ___height3, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___x0;
		__this->set_m_X_0(L_0);
		int32_t L_1 = ___y1;
		__this->set_m_Y_1(L_1);
		int32_t L_2 = ___width2;
		__this->set_m_Width_2(L_2);
		int32_t L_3 = ___height3;
		__this->set_m_Height_3(L_3);
		return;
	}
}
IL2CPP_EXTERN_C  void GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0_AdjustorThunk (RuntimeObject * __this, int32_t ___x0, int32_t ___y1, int32_t ___width2, int32_t ___height3, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0(_thisAdjusted, ___x0, ___y1, ___width2, ___height3, method);
}
// System.Int32 UnityEngine.TextCore.GlyphRect::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = (*(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *)__this);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var, &L_1);
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		int32_t L_3 = ValueType_GetHashCode_m48E9FA7FFC7C27D876E764A94E3CF2039ED6C9F9((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		goto IL_0014;
	}

IL_0014:
	{
		int32_t L_4 = V_0;
		return L_4;
	}
}
IL2CPP_EXTERN_C  int32_t GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2(_thisAdjusted, method);
}
// System.Boolean UnityEngine.TextCore.GlyphRect::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = (*(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *)__this);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var, &L_1);
		RuntimeObject * L_3 = ___obj0;
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		bool L_4 = ValueType_Equals_m5F6E6FDB8422FE9AFF6435C0C729FBE1032F4980((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_0015;
	}

IL_0015:
	{
		bool L_5 = V_0;
		return L_5;
	}
}
IL2CPP_EXTERN_C  bool GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114(_thisAdjusted, ___obj0, method);
}
// System.Boolean UnityEngine.TextCore.GlyphRect::Equals(UnityEngine.TextCore.GlyphRect)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371 (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0 = (*(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *)__this);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_1 = L_0;
		RuntimeObject * L_2 = Box(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var, &L_1);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_3 = ___other0;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_4 = L_3;
		RuntimeObject * L_5 = Box(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var, &L_4);
		NullCheck((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2);
		bool L_6 = ValueType_Equals_m5F6E6FDB8422FE9AFF6435C0C729FBE1032F4980((ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF *)L_2, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		goto IL_001a;
	}

IL_001a:
	{
		bool L_7 = V_0;
		return L_7;
	}
}
IL2CPP_EXTERN_C  bool GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371_AdjustorThunk (RuntimeObject * __this, GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  ___other0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C * _thisAdjusted = reinterpret_cast<GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C *>(__this + _offset);
	return GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371(_thisAdjusted, ___other0, method);
}
// System.Void UnityEngine.TextCore.GlyphRect::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphRect__cctor_m5AD2AC6BB42D6536F8F6E2F4369BA400354BFC35 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GlyphRect__cctor_m5AD2AC6BB42D6536F8F6E2F4369BA400354BFC35_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_0;
		memset((&L_0), 0, sizeof(L_0));
		GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0((&L_0), 0, 0, 0, 0, /*hidden argument*/NULL);
		((GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_StaticFields*)il2cpp_codegen_static_fields_for(GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C_il2cpp_TypeInfo_var))->set_s_ZeroGlyphRect_4(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.TextCore.LowLevel.FontEngine::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontEngine__ctor_m90CBF12264B15BCA2368C372FC2062A06B0E788F (FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
// UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_InitializeFontEngine_m1C7695D66160277DE576EB9D8BA749849BDC24B7 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_InitializeFontEngine_m1C7695D66160277DE576EB9D8BA749849BDC24B7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		int32_t L_0 = FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445(/*hidden argument*/NULL);
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445 (const RuntimeMethod* method)
{
	typedef int32_t (*FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445_ftn) ();
	static FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()");
	int32_t retVal = _il2cpp_icall_func();
	return retVal;
}
// UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace(UnityEngine.Font,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_LoadFontFace_mFEBC3184605C0BD37A83021F6B47E5C3FA3FAD3C (Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___font0, int32_t ___pointSize1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_LoadFontFace_mFEBC3184605C0BD37A83021F6B47E5C3FA3FAD3C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * L_0 = ___font0;
		int32_t L_1 = ___pointSize1;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		int32_t L_2 = FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013(L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		goto IL_000b;
	}

IL_000b:
	{
		int32_t L_3 = V_0;
		return L_3;
	}
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013 (Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___font0, int32_t ___pointSize1, const RuntimeMethod* method)
{
	typedef int32_t (*FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013_ftn) (Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 *, int32_t);
	static FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)");
	int32_t retVal = _il2cpp_icall_func(___font0, ___pointSize1);
	return retVal;
}
// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8  FontEngine_GetFaceInfo_mB4B6045A34FEBFE58EB401216E930F50364B0A41 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_GetFaceInfo_mB4B6045A34FEBFE58EB401216E930F50364B0A41_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8  V_0;
	memset((&V_0), 0, sizeof(V_0));
	FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 ));
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C((FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *)(&V_0), /*hidden argument*/NULL);
		FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8  L_0 = V_0;
		V_1 = L_0;
		goto IL_0015;
	}

IL_0015:
	{
		FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8  L_1 = V_1;
		return L_1;
	}
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 * ___faceInfo0, const RuntimeMethod* method)
{
	typedef int32_t (*FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C_ftn) (FaceInfo_t32155CB9E0D125155E829A3D23119FB323F382A8 *);
	static FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)");
	int32_t retVal = _il2cpp_icall_func(___faceInfo0);
	return retVal;
}
// System.UInt32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphIndex(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1 (uint32_t ___unicode0, const RuntimeMethod* method)
{
	typedef uint32_t (*FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1_ftn) (uint32_t);
	static FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphIndex(System.UInt32)");
	uint32_t retVal = _il2cpp_icall_func(___unicode0);
	return retVal;
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithUnicodeValue_mBC940303E740DC1897FCA6247D048266298BE00C (uint32_t ___unicode0, int32_t ___flags1, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** ___glyph2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_TryGetGlyphWithUnicodeValue_mBC940303E740DC1897FCA6247D048266298BE00C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  V_0;
	memset((&V_0), 0, sizeof(V_0));
	bool V_1 = false;
	bool V_2 = false;
	{
		il2cpp_codegen_initobj((&V_0), sizeof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 ));
		uint32_t L_0 = ___unicode0;
		int32_t L_1 = ___flags1;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		bool L_2 = FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C(L_0, L_1, (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *)(&V_0), /*hidden argument*/NULL);
		V_1 = L_2;
		bool L_3 = V_1;
		if (!L_3)
		{
			goto IL_0023;
		}
	}
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_4 = ___glyph2;
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_5 = V_0;
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_6 = (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)il2cpp_codegen_object_new(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_il2cpp_TypeInfo_var);
		Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF(L_6, L_5, /*hidden argument*/NULL);
		*((RuntimeObject **)L_4) = (RuntimeObject *)L_6;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_4, (void*)(RuntimeObject *)L_6);
		V_2 = (bool)1;
		goto IL_002a;
	}

IL_0023:
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_7 = ___glyph2;
		*((RuntimeObject **)L_7) = (RuntimeObject *)NULL;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_7, (void*)(RuntimeObject *)NULL);
		V_2 = (bool)0;
		goto IL_002a;
	}

IL_002a:
	{
		bool L_8 = V_2;
		return L_8;
	}
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C (uint32_t ___unicode0, int32_t ___loadFlags1, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyphStruct2, const RuntimeMethod* method)
{
	typedef bool (*FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C_ftn) (uint32_t, int32_t, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *);
	static FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)");
	bool retVal = _il2cpp_icall_func(___unicode0, ___loadFlags1, ___glyphStruct2);
	return retVal;
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithIndexValue_m75A9F7605232FAF4D9948E2E7BDFFB01A8FD5178 (uint32_t ___glyphIndex0, int32_t ___flags1, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** ___glyph2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_TryGetGlyphWithIndexValue_m75A9F7605232FAF4D9948E2E7BDFFB01A8FD5178_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  V_0;
	memset((&V_0), 0, sizeof(V_0));
	bool V_1 = false;
	bool V_2 = false;
	{
		il2cpp_codegen_initobj((&V_0), sizeof(GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 ));
		uint32_t L_0 = ___glyphIndex0;
		int32_t L_1 = ___flags1;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		bool L_2 = FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170(L_0, L_1, (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *)(&V_0), /*hidden argument*/NULL);
		V_1 = L_2;
		bool L_3 = V_1;
		if (!L_3)
		{
			goto IL_0023;
		}
	}
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_4 = ___glyph2;
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_5 = V_0;
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_6 = (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)il2cpp_codegen_object_new(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_il2cpp_TypeInfo_var);
		Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF(L_6, L_5, /*hidden argument*/NULL);
		*((RuntimeObject **)L_4) = (RuntimeObject *)L_6;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_4, (void*)(RuntimeObject *)L_6);
		V_2 = (bool)1;
		goto IL_002a;
	}

IL_0023:
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_7 = ___glyph2;
		*((RuntimeObject **)L_7) = (RuntimeObject *)NULL;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_7, (void*)(RuntimeObject *)NULL);
		V_2 = (bool)0;
		goto IL_002a;
	}

IL_002a:
	{
		bool L_8 = V_2;
		return L_8;
	}
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170 (uint32_t ___glyphIndex0, int32_t ___loadFlags1, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyphStruct2, const RuntimeMethod* method)
{
	typedef bool (*FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170_ftn) (uint32_t, int32_t, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *);
	static FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)");
	bool retVal = _il2cpp_icall_func(___glyphIndex0, ___loadFlags1, ___glyphStruct2);
	return retVal;
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas(UnityEngine.TextCore.Glyph,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryPackGlyphInAtlas_m0E9E8FBBC64AF69CB1DEB3C8A2EF862222C3B8EA (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * ___glyph0, int32_t ___padding1, int32_t ___packingMode2, int32_t ___renderMode3, int32_t ___width4, int32_t ___height5, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___freeGlyphRects6, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___usedGlyphRects7, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_TryPackGlyphInAtlas_m0E9E8FBBC64AF69CB1DEB3C8A2EF862222C3B8EA_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	bool V_5 = false;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	bool V_8 = false;
	bool V_9 = false;
	bool V_10 = false;
	bool V_11 = false;
	int32_t V_12 = 0;
	bool V_13 = false;
	bool V_14 = false;
	bool V_15 = false;
	bool V_16 = false;
	int32_t G_B3_0 = 0;
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_0 = ___glyph0;
		GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220((GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *)(&V_0), L_0, /*hidden argument*/NULL);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_1 = ___freeGlyphRects6;
		NullCheck(L_1);
		int32_t L_2 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_1, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_1 = L_2;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_3 = ___usedGlyphRects7;
		NullCheck(L_3);
		int32_t L_4 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_3, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_2 = L_4;
		int32_t L_5 = V_1;
		int32_t L_6 = V_2;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_5, (int32_t)L_6));
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_7 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		NullCheck(L_7);
		int32_t L_8 = V_3;
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_7)->max_length))))) < ((int32_t)L_8)))
		{
			goto IL_0033;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_9 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		NullCheck(L_9);
		int32_t L_10 = V_3;
		G_B3_0 = ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_9)->max_length))))) < ((int32_t)L_10))? 1 : 0);
		goto IL_0034;
	}

IL_0033:
	{
		G_B3_0 = 1;
	}

IL_0034:
	{
		V_5 = (bool)G_B3_0;
		bool L_11 = V_5;
		if (!L_11)
		{
			goto IL_005e;
		}
	}
	{
		int32_t L_12 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_13 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_12, (int32_t)1)), /*hidden argument*/NULL);
		V_6 = L_13;
		int32_t L_14 = V_6;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_15 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_14);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_FreeGlyphRects_5(L_15);
		int32_t L_16 = V_6;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_17 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_16);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_UsedGlyphRects_6(L_17);
	}

IL_005e:
	{
		int32_t L_18 = V_1;
		int32_t L_19 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_20 = Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F(L_18, L_19, /*hidden argument*/NULL);
		V_4 = L_20;
		V_7 = 0;
		goto IL_00b4;
	}

IL_006c:
	{
		int32_t L_21 = V_7;
		int32_t L_22 = V_1;
		V_8 = (bool)((((int32_t)L_21) < ((int32_t)L_22))? 1 : 0);
		bool L_23 = V_8;
		if (!L_23)
		{
			goto IL_008d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_24 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_25 = V_7;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_26 = ___freeGlyphRects6;
		int32_t L_27 = V_7;
		NullCheck(L_26);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_28 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_26, L_27, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_24);
		(L_24)->SetAt(static_cast<il2cpp_array_size_t>(L_25), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_28);
	}

IL_008d:
	{
		int32_t L_29 = V_7;
		int32_t L_30 = V_2;
		V_9 = (bool)((((int32_t)L_29) < ((int32_t)L_30))? 1 : 0);
		bool L_31 = V_9;
		if (!L_31)
		{
			goto IL_00ad;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_32 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_33 = V_7;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_34 = ___usedGlyphRects7;
		int32_t L_35 = V_7;
		NullCheck(L_34);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_36 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_34, L_35, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_32);
		(L_32)->SetAt(static_cast<il2cpp_array_size_t>(L_33), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_36);
	}

IL_00ad:
	{
		int32_t L_37 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add((int32_t)L_37, (int32_t)1));
	}

IL_00b4:
	{
		int32_t L_38 = V_7;
		int32_t L_39 = V_4;
		V_10 = (bool)((((int32_t)L_38) < ((int32_t)L_39))? 1 : 0);
		bool L_40 = V_10;
		if (L_40)
		{
			goto IL_006c;
		}
	}
	{
		int32_t L_41 = ___padding1;
		int32_t L_42 = ___packingMode2;
		int32_t L_43 = ___renderMode3;
		int32_t L_44 = ___width4;
		int32_t L_45 = ___height5;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_46 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_47 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		bool L_48 = FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B((GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *)(&V_0), L_41, L_42, L_43, L_44, L_45, L_46, (int32_t*)(&V_1), L_47, (int32_t*)(&V_2), /*hidden argument*/NULL);
		V_11 = L_48;
		bool L_49 = V_11;
		if (!L_49)
		{
			goto IL_0168;
		}
	}
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_50 = ___glyph0;
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_51 = V_0;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_52 = L_51.get_glyphRect_2();
		NullCheck(L_50);
		Glyph_set_glyphRect_m5D45BF2EF4A7738AF7158D49DEDB5E09E034742C(L_50, L_52, /*hidden argument*/NULL);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_53 = ___freeGlyphRects6;
		NullCheck(L_53);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_53, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_54 = ___usedGlyphRects7;
		NullCheck(L_54);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_54, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		int32_t L_55 = V_1;
		int32_t L_56 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_57 = Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F(L_55, L_56, /*hidden argument*/NULL);
		V_4 = L_57;
		V_12 = 0;
		goto IL_0157;
	}

IL_0111:
	{
		int32_t L_58 = V_12;
		int32_t L_59 = V_1;
		V_13 = (bool)((((int32_t)L_58) < ((int32_t)L_59))? 1 : 0);
		bool L_60 = V_13;
		if (!L_60)
		{
			goto IL_0131;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_61 = ___freeGlyphRects6;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_62 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_63 = V_12;
		NullCheck(L_62);
		int32_t L_64 = L_63;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_65 = (L_62)->GetAt(static_cast<il2cpp_array_size_t>(L_64));
		NullCheck(L_61);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_61, L_65, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_0131:
	{
		int32_t L_66 = V_12;
		int32_t L_67 = V_2;
		V_14 = (bool)((((int32_t)L_66) < ((int32_t)L_67))? 1 : 0);
		bool L_68 = V_14;
		if (!L_68)
		{
			goto IL_0150;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_69 = ___usedGlyphRects7;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_70 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_71 = V_12;
		NullCheck(L_70);
		int32_t L_72 = L_71;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_73 = (L_70)->GetAt(static_cast<il2cpp_array_size_t>(L_72));
		NullCheck(L_69);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_69, L_73, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_0150:
	{
		int32_t L_74 = V_12;
		V_12 = ((int32_t)il2cpp_codegen_add((int32_t)L_74, (int32_t)1));
	}

IL_0157:
	{
		int32_t L_75 = V_12;
		int32_t L_76 = V_4;
		V_15 = (bool)((((int32_t)L_75) < ((int32_t)L_76))? 1 : 0);
		bool L_77 = V_15;
		if (L_77)
		{
			goto IL_0111;
		}
	}
	{
		V_16 = (bool)1;
		goto IL_016d;
	}

IL_0168:
	{
		V_16 = (bool)0;
		goto IL_016d;
	}

IL_016d:
	{
		bool L_78 = V_16;
		return L_78;
	}
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyph0, int32_t ___padding1, int32_t ___packingMode2, int32_t ___renderMode3, int32_t ___width4, int32_t ___height5, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects6, int32_t* ___freeGlyphRectCount7, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects8, int32_t* ___usedGlyphRectCount9, const RuntimeMethod* method)
{
	typedef bool (*FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B_ftn) (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *, int32_t, int32_t, int32_t, int32_t, int32_t, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*);
	static FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&)");
	bool retVal = _il2cpp_icall_func(___glyph0, ___padding1, ___packingMode2, ___renderMode3, ___width4, ___height5, ___freeGlyphRects6, ___freeGlyphRectCount7, ___usedGlyphRects8, ___usedGlyphRectCount9);
	return retVal;
}
// UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture(System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_RenderGlyphsToTexture_m6A61FED7FC28A80B730C4B2C492A8E802DD2EB80 (List_1_t8B3AA8D740B2E10383225037638055610A7BE123 * ___glyphs0, int32_t ___padding1, int32_t ___renderMode2, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_RenderGlyphsToTexture_m6A61FED7FC28A80B730C4B2C492A8E802DD2EB80_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	bool V_2 = false;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	bool V_5 = false;
	int32_t V_6 = 0;
	{
		List_1_t8B3AA8D740B2E10383225037638055610A7BE123 * L_0 = ___glyphs0;
		NullCheck(L_0);
		int32_t L_1 = List_1_get_Count_m4A32B5B2CCE68FC874FEF42E9B23320FAF0828D3_inline(L_0, /*hidden argument*/List_1_get_Count_m4A32B5B2CCE68FC874FEF42E9B23320FAF0828D3_RuntimeMethod_var);
		V_0 = L_1;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_2 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_IN_3();
		NullCheck(L_2);
		int32_t L_3 = V_0;
		V_2 = (bool)((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_2)->max_length))))) < ((int32_t)L_3))? 1 : 0);
		bool L_4 = V_2;
		if (!L_4)
		{
			goto IL_002c;
		}
	}
	{
		int32_t L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_6 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_5, (int32_t)1)), /*hidden argument*/NULL);
		V_3 = L_6;
		int32_t L_7 = V_3;
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_8 = (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)SZArrayNew(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662_il2cpp_TypeInfo_var, (uint32_t)L_7);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphMarshallingStruct_IN_3(L_8);
	}

IL_002c:
	{
		V_4 = 0;
		goto IL_0050;
	}

IL_0031:
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_9 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_IN_3();
		int32_t L_10 = V_4;
		List_1_t8B3AA8D740B2E10383225037638055610A7BE123 * L_11 = ___glyphs0;
		int32_t L_12 = V_4;
		NullCheck(L_11);
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_13 = List_1_get_Item_m1AA0C2D8B9692306C4D1AD0F721F4DAB85734BC5_inline(L_11, L_12, /*hidden argument*/List_1_get_Item_m1AA0C2D8B9692306C4D1AD0F721F4DAB85734BC5_RuntimeMethod_var);
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_14;
		memset((&L_14), 0, sizeof(L_14));
		GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220((&L_14), L_13, /*hidden argument*/NULL);
		NullCheck(L_9);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(L_10), (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 )L_14);
		int32_t L_15 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_15, (int32_t)1));
	}

IL_0050:
	{
		int32_t L_16 = V_4;
		int32_t L_17 = V_0;
		V_5 = (bool)((((int32_t)L_16) < ((int32_t)L_17))? 1 : 0);
		bool L_18 = V_5;
		if (L_18)
		{
			goto IL_0031;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_19 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_IN_3();
		int32_t L_20 = V_0;
		int32_t L_21 = ___padding1;
		int32_t L_22 = ___renderMode2;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_23 = ___texture3;
		int32_t L_24 = FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D(L_19, L_20, L_21, L_22, L_23, /*hidden argument*/NULL);
		V_1 = L_24;
		int32_t L_25 = V_1;
		V_6 = L_25;
		goto IL_006f;
	}

IL_006f:
	{
		int32_t L_26 = V_6;
		return L_26;
	}
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___glyphs0, int32_t ___glyphCount1, int32_t ___padding2, int32_t ___renderMode3, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture4, const RuntimeMethod* method)
{
	typedef int32_t (*FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D_ftn) (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*, int32_t, int32_t, int32_t, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C *);
	static FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)");
	int32_t retVal = _il2cpp_icall_func(___glyphs0, ___glyphCount1, ___padding2, ___renderMode3, ___texture4);
	return retVal;
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphToTexture_mD70AEC0FDCEE818B4366C78FF662464F13112172 (uint32_t ___glyphIndex0, int32_t ___padding1, int32_t ___packingMode2, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___freeGlyphRects3, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___usedGlyphRects4, int32_t ___renderMode5, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture6, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** ___glyph7, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_TryAddGlyphToTexture_mD70AEC0FDCEE818B4366C78FF662464F13112172_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  V_4;
	memset((&V_4), 0, sizeof(V_4));
	bool V_5 = false;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	bool V_8 = false;
	bool V_9 = false;
	bool V_10 = false;
	bool V_11 = false;
	int32_t V_12 = 0;
	bool V_13 = false;
	bool V_14 = false;
	bool V_15 = false;
	bool V_16 = false;
	int32_t G_B3_0 = 0;
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_0 = ___freeGlyphRects3;
		NullCheck(L_0);
		int32_t L_1 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_0, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_0 = L_1;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_2 = ___usedGlyphRects4;
		NullCheck(L_2);
		int32_t L_3 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_2, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_1 = L_3;
		int32_t L_4 = V_0;
		int32_t L_5 = V_1;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)L_5));
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_6 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		NullCheck(L_6);
		int32_t L_7 = V_2;
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_6)->max_length))))) < ((int32_t)L_7)))
		{
			goto IL_002a;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_8 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		NullCheck(L_8);
		int32_t L_9 = V_2;
		G_B3_0 = ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_8)->max_length))))) < ((int32_t)L_9))? 1 : 0);
		goto IL_002b;
	}

IL_002a:
	{
		G_B3_0 = 1;
	}

IL_002b:
	{
		V_5 = (bool)G_B3_0;
		bool L_10 = V_5;
		if (!L_10)
		{
			goto IL_0055;
		}
	}
	{
		int32_t L_11 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_12 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_11, (int32_t)1)), /*hidden argument*/NULL);
		V_6 = L_12;
		int32_t L_13 = V_6;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_14 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_13);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_FreeGlyphRects_5(L_14);
		int32_t L_15 = V_6;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_16 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_15);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_UsedGlyphRects_6(L_16);
	}

IL_0055:
	{
		int32_t L_17 = V_0;
		int32_t L_18 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_19 = Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F(L_17, L_18, /*hidden argument*/NULL);
		V_3 = L_19;
		V_7 = 0;
		goto IL_00a9;
	}

IL_0062:
	{
		int32_t L_20 = V_7;
		int32_t L_21 = V_0;
		V_8 = (bool)((((int32_t)L_20) < ((int32_t)L_21))? 1 : 0);
		bool L_22 = V_8;
		if (!L_22)
		{
			goto IL_0082;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_23 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_24 = V_7;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_25 = ___freeGlyphRects3;
		int32_t L_26 = V_7;
		NullCheck(L_25);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_27 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_25, L_26, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_23);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(L_24), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_27);
	}

IL_0082:
	{
		int32_t L_28 = V_7;
		int32_t L_29 = V_1;
		V_9 = (bool)((((int32_t)L_28) < ((int32_t)L_29))? 1 : 0);
		bool L_30 = V_9;
		if (!L_30)
		{
			goto IL_00a2;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_31 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_32 = V_7;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_33 = ___usedGlyphRects4;
		int32_t L_34 = V_7;
		NullCheck(L_33);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_35 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_33, L_34, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_31);
		(L_31)->SetAt(static_cast<il2cpp_array_size_t>(L_32), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_35);
	}

IL_00a2:
	{
		int32_t L_36 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add((int32_t)L_36, (int32_t)1));
	}

IL_00a9:
	{
		int32_t L_37 = V_7;
		int32_t L_38 = V_3;
		V_10 = (bool)((((int32_t)L_37) < ((int32_t)L_38))? 1 : 0);
		bool L_39 = V_10;
		if (L_39)
		{
			goto IL_0062;
		}
	}
	{
		uint32_t L_40 = ___glyphIndex0;
		int32_t L_41 = ___padding1;
		int32_t L_42 = ___packingMode2;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_43 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_44 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_45 = ___renderMode5;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_46 = ___texture6;
		bool L_47 = FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82(L_40, L_41, L_42, L_43, (int32_t*)(&V_0), L_44, (int32_t*)(&V_1), L_45, L_46, (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *)(&V_4), /*hidden argument*/NULL);
		V_11 = L_47;
		bool L_48 = V_11;
		if (!L_48)
		{
			goto IL_0152;
		}
	}
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_49 = ___glyph7;
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_50 = V_4;
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_51 = (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)il2cpp_codegen_object_new(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_il2cpp_TypeInfo_var);
		Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF(L_51, L_50, /*hidden argument*/NULL);
		*((RuntimeObject **)L_49) = (RuntimeObject *)L_51;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_49, (void*)(RuntimeObject *)L_51);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_52 = ___freeGlyphRects3;
		NullCheck(L_52);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_52, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_53 = ___usedGlyphRects4;
		NullCheck(L_53);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_53, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		int32_t L_54 = V_0;
		int32_t L_55 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_56 = Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F(L_54, L_55, /*hidden argument*/NULL);
		V_3 = L_56;
		V_12 = 0;
		goto IL_0142;
	}

IL_00fd:
	{
		int32_t L_57 = V_12;
		int32_t L_58 = V_0;
		V_13 = (bool)((((int32_t)L_57) < ((int32_t)L_58))? 1 : 0);
		bool L_59 = V_13;
		if (!L_59)
		{
			goto IL_011c;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_60 = ___freeGlyphRects3;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_61 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_62 = V_12;
		NullCheck(L_61);
		int32_t L_63 = L_62;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_64 = (L_61)->GetAt(static_cast<il2cpp_array_size_t>(L_63));
		NullCheck(L_60);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_60, L_64, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_011c:
	{
		int32_t L_65 = V_12;
		int32_t L_66 = V_1;
		V_14 = (bool)((((int32_t)L_65) < ((int32_t)L_66))? 1 : 0);
		bool L_67 = V_14;
		if (!L_67)
		{
			goto IL_013b;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_68 = ___usedGlyphRects4;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_69 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_70 = V_12;
		NullCheck(L_69);
		int32_t L_71 = L_70;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_72 = (L_69)->GetAt(static_cast<il2cpp_array_size_t>(L_71));
		NullCheck(L_68);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_68, L_72, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_013b:
	{
		int32_t L_73 = V_12;
		V_12 = ((int32_t)il2cpp_codegen_add((int32_t)L_73, (int32_t)1));
	}

IL_0142:
	{
		int32_t L_74 = V_12;
		int32_t L_75 = V_3;
		V_15 = (bool)((((int32_t)L_74) < ((int32_t)L_75))? 1 : 0);
		bool L_76 = V_15;
		if (L_76)
		{
			goto IL_00fd;
		}
	}
	{
		V_16 = (bool)1;
		goto IL_015b;
	}

IL_0152:
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 ** L_77 = ___glyph7;
		*((RuntimeObject **)L_77) = (RuntimeObject *)NULL;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_77, (void*)(RuntimeObject *)NULL);
		V_16 = (bool)0;
		goto IL_015b;
	}

IL_015b:
	{
		bool L_78 = V_16;
		return L_78;
	}
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82 (uint32_t ___glyphIndex0, int32_t ___padding1, int32_t ___packingMode2, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects3, int32_t* ___freeGlyphRectCount4, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects5, int32_t* ___usedGlyphRectCount6, int32_t ___renderMode7, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture8, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * ___glyph9, const RuntimeMethod* method)
{
	typedef bool (*FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82_ftn) (uint32_t, int32_t, int32_t, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*, int32_t, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C *, GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *);
	static FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)");
	bool retVal = _il2cpp_icall_func(___glyphIndex0, ___padding1, ___packingMode2, ___freeGlyphRects3, ___freeGlyphRectCount4, ___usedGlyphRects5, ___usedGlyphRectCount6, ___renderMode7, ___texture8, ___glyph9);
	return retVal;
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture(System.Collections.Generic.List`1<System.UInt32>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph[]&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphsToTexture_mFC834881F6DB0867C01A9902A879C13ED66404A4 (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * ___glyphIndexes0, int32_t ___padding1, int32_t ___packingMode2, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___freeGlyphRects3, List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * ___usedGlyphRects4, int32_t ___renderMode5, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture6, GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** ___glyphs7, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_TryAddGlyphsToTexture_mFC834881F6DB0867C01A9902A879C13ED66404A4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	bool V_5 = false;
	bool V_6 = false;
	bool V_7 = false;
	bool V_8 = false;
	bool V_9 = false;
	int32_t V_10 = 0;
	bool V_11 = false;
	int32_t V_12 = 0;
	bool V_13 = false;
	int32_t V_14 = 0;
	int32_t V_15 = 0;
	bool V_16 = false;
	bool V_17 = false;
	bool V_18 = false;
	bool V_19 = false;
	bool V_20 = false;
	int32_t V_21 = 0;
	bool V_22 = false;
	bool V_23 = false;
	bool V_24 = false;
	bool V_25 = false;
	int32_t G_B3_0 = 0;
	int32_t G_B8_0 = 0;
	int32_t G_B16_0 = 0;
	int32_t G_B32_0 = 0;
	{
		Profiler_BeginSample_mDA159D5771838F40FC7C2829B2DC4329F8C9596B_inline(_stringLiteralD18BC4FA20EAFF07786EFFB312284C46A3CE5251, /*hidden argument*/NULL);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** L_0 = ___glyphs7;
		*((RuntimeObject **)L_0) = (RuntimeObject *)NULL;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_0, (void*)(RuntimeObject *)NULL);
		List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * L_1 = ___glyphIndexes0;
		if (!L_1)
		{
			goto IL_001e;
		}
	}
	{
		List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * L_2 = ___glyphIndexes0;
		NullCheck(L_2);
		int32_t L_3 = List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_inline(L_2, /*hidden argument*/List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_RuntimeMethod_var);
		G_B3_0 = ((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
		goto IL_001f;
	}

IL_001e:
	{
		G_B3_0 = 1;
	}

IL_001f:
	{
		V_6 = (bool)G_B3_0;
		bool L_4 = V_6;
		if (!L_4)
		{
			goto IL_0034;
		}
	}
	{
		Profiler_EndSample_m15350A0463FB3C5789504B4059B0EA68D5B70A21(/*hidden argument*/NULL);
		V_7 = (bool)0;
		goto IL_028a;
	}

IL_0034:
	{
		List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * L_5 = ___glyphIndexes0;
		NullCheck(L_5);
		int32_t L_6 = List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_inline(L_5, /*hidden argument*/List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_RuntimeMethod_var);
		V_0 = L_6;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_7 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphIndexes_MarshallingArray_2();
		if (!L_7)
		{
			goto IL_004e;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_8 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphIndexes_MarshallingArray_2();
		NullCheck(L_8);
		int32_t L_9 = V_0;
		G_B8_0 = ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_8)->max_length))))) < ((int32_t)L_9))? 1 : 0);
		goto IL_004f;
	}

IL_004e:
	{
		G_B8_0 = 1;
	}

IL_004f:
	{
		V_8 = (bool)G_B8_0;
		bool L_10 = V_8;
		if (!L_10)
		{
			goto IL_008a;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_11 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphIndexes_MarshallingArray_2();
		V_9 = (bool)((((RuntimeObject*)(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)L_11) == ((RuntimeObject*)(RuntimeObject *)NULL))? 1 : 0);
		bool L_12 = V_9;
		if (!L_12)
		{
			goto IL_0071;
		}
	}
	{
		int32_t L_13 = V_0;
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_14 = (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)SZArrayNew(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB_il2cpp_TypeInfo_var, (uint32_t)L_13);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphIndexes_MarshallingArray_2(L_14);
		goto IL_0089;
	}

IL_0071:
	{
		int32_t L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_16 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_15, (int32_t)1)), /*hidden argument*/NULL);
		V_10 = L_16;
		int32_t L_17 = V_10;
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_18 = (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)SZArrayNew(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB_il2cpp_TypeInfo_var, (uint32_t)L_17);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphIndexes_MarshallingArray_2(L_18);
	}

IL_0089:
	{
	}

IL_008a:
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_19 = ___freeGlyphRects3;
		NullCheck(L_19);
		int32_t L_20 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_19, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_1 = L_20;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_21 = ___usedGlyphRects4;
		NullCheck(L_21);
		int32_t L_22 = List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_inline(L_21, /*hidden argument*/List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_RuntimeMethod_var);
		V_2 = L_22;
		int32_t L_23 = V_1;
		int32_t L_24 = V_2;
		int32_t L_25 = V_0;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_23, (int32_t)L_24)), (int32_t)L_25));
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_26 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		NullCheck(L_26);
		int32_t L_27 = V_3;
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_26)->max_length))))) < ((int32_t)L_27)))
		{
			goto IL_00b5;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_28 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		NullCheck(L_28);
		int32_t L_29 = V_3;
		G_B16_0 = ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_28)->max_length))))) < ((int32_t)L_29))? 1 : 0);
		goto IL_00b6;
	}

IL_00b5:
	{
		G_B16_0 = 1;
	}

IL_00b6:
	{
		V_11 = (bool)G_B16_0;
		bool L_30 = V_11;
		if (!L_30)
		{
			goto IL_00e0;
		}
	}
	{
		int32_t L_31 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_32 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_31, (int32_t)1)), /*hidden argument*/NULL);
		V_12 = L_32;
		int32_t L_33 = V_12;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_34 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_33);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_FreeGlyphRects_5(L_34);
		int32_t L_35 = V_12;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_36 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)L_35);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_UsedGlyphRects_6(L_36);
	}

IL_00e0:
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_37 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_OUT_4();
		NullCheck(L_37);
		int32_t L_38 = V_0;
		V_13 = (bool)((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_37)->max_length))))) < ((int32_t)L_38))? 1 : 0);
		bool L_39 = V_13;
		if (!L_39)
		{
			goto IL_0108;
		}
	}
	{
		int32_t L_40 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_41 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_40, (int32_t)1)), /*hidden argument*/NULL);
		V_14 = L_41;
		int32_t L_42 = V_14;
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_43 = (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)SZArrayNew(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662_il2cpp_TypeInfo_var, (uint32_t)L_42);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphMarshallingStruct_OUT_4(L_43);
	}

IL_0108:
	{
		int32_t L_44 = V_1;
		int32_t L_45 = V_2;
		int32_t L_46 = V_0;
		int32_t L_47 = FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215(L_44, L_45, L_46, /*hidden argument*/NULL);
		V_4 = L_47;
		V_15 = 0;
		goto IL_0179;
	}

IL_0117:
	{
		int32_t L_48 = V_15;
		int32_t L_49 = V_0;
		V_16 = (bool)((((int32_t)L_48) < ((int32_t)L_49))? 1 : 0);
		bool L_50 = V_16;
		if (!L_50)
		{
			goto IL_0133;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_51 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphIndexes_MarshallingArray_2();
		int32_t L_52 = V_15;
		List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * L_53 = ___glyphIndexes0;
		int32_t L_54 = V_15;
		NullCheck(L_53);
		uint32_t L_55 = List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_inline(L_53, L_54, /*hidden argument*/List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_RuntimeMethod_var);
		NullCheck(L_51);
		(L_51)->SetAt(static_cast<il2cpp_array_size_t>(L_52), (uint32_t)L_55);
	}

IL_0133:
	{
		int32_t L_56 = V_15;
		int32_t L_57 = V_1;
		V_17 = (bool)((((int32_t)L_56) < ((int32_t)L_57))? 1 : 0);
		bool L_58 = V_17;
		if (!L_58)
		{
			goto IL_0152;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_59 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_60 = V_15;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_61 = ___freeGlyphRects3;
		int32_t L_62 = V_15;
		NullCheck(L_61);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_63 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_61, L_62, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_59);
		(L_59)->SetAt(static_cast<il2cpp_array_size_t>(L_60), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_63);
	}

IL_0152:
	{
		int32_t L_64 = V_15;
		int32_t L_65 = V_2;
		V_18 = (bool)((((int32_t)L_64) < ((int32_t)L_65))? 1 : 0);
		bool L_66 = V_18;
		if (!L_66)
		{
			goto IL_0172;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_67 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_68 = V_15;
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_69 = ___usedGlyphRects4;
		int32_t L_70 = V_15;
		NullCheck(L_69);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_71 = List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_inline(L_69, L_70, /*hidden argument*/List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_RuntimeMethod_var);
		NullCheck(L_67);
		(L_67)->SetAt(static_cast<il2cpp_array_size_t>(L_68), (GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C )L_71);
	}

IL_0172:
	{
		int32_t L_72 = V_15;
		V_15 = ((int32_t)il2cpp_codegen_add((int32_t)L_72, (int32_t)1));
	}

IL_0179:
	{
		int32_t L_73 = V_15;
		int32_t L_74 = V_4;
		V_19 = (bool)((((int32_t)L_73) < ((int32_t)L_74))? 1 : 0);
		bool L_75 = V_19;
		if (L_75)
		{
			goto IL_0117;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_76 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphIndexes_MarshallingArray_2();
		int32_t L_77 = ___padding1;
		int32_t L_78 = ___packingMode2;
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_79 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_80 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_81 = ___renderMode5;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_82 = ___texture6;
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_83 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_OUT_4();
		bool L_84 = FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB(L_76, L_77, L_78, L_79, (int32_t*)(&V_1), L_80, (int32_t*)(&V_2), L_81, L_82, L_83, (int32_t*)(&V_0), /*hidden argument*/NULL);
		V_5 = L_84;
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_85 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_Glyphs_1();
		if (!L_85)
		{
			goto IL_01c2;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_86 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_Glyphs_1();
		NullCheck(L_86);
		int32_t L_87 = V_0;
		G_B32_0 = ((((int32_t)((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_86)->max_length))))) > ((int32_t)L_87))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_01c3;
	}

IL_01c2:
	{
		G_B32_0 = 1;
	}

IL_01c3:
	{
		V_20 = (bool)G_B32_0;
		bool L_88 = V_20;
		if (!L_88)
		{
			goto IL_01db;
		}
	}
	{
		int32_t L_89 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		int32_t L_90 = Mathf_NextPowerOfTwo_m071D88C91A1CBECD47F18CA20D219C77879865E7(((int32_t)il2cpp_codegen_add((int32_t)L_89, (int32_t)1)), /*hidden argument*/NULL);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_91 = (GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F*)(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F*)SZArrayNew(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F_il2cpp_TypeInfo_var, (uint32_t)L_90);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_Glyphs_1(L_91);
	}

IL_01db:
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_92 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_Glyphs_1();
		int32_t L_93 = V_0;
		NullCheck(L_92);
		ArrayElementTypeCheck (L_92, NULL);
		(L_92)->SetAt(static_cast<il2cpp_array_size_t>(L_93), (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)NULL);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_94 = ___freeGlyphRects3;
		NullCheck(L_94);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_94, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_95 = ___usedGlyphRects4;
		NullCheck(L_95);
		List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780(L_95, /*hidden argument*/List_1_Clear_mEB5E44F925D8526A528E94FE1225FCDB2D595780_RuntimeMethod_var);
		int32_t L_96 = V_1;
		int32_t L_97 = V_2;
		int32_t L_98 = V_0;
		int32_t L_99 = FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215(L_96, L_97, L_98, /*hidden argument*/NULL);
		V_4 = L_99;
		V_21 = 0;
		goto IL_026a;
	}

IL_0201:
	{
		int32_t L_100 = V_21;
		int32_t L_101 = V_0;
		V_22 = (bool)((((int32_t)L_100) < ((int32_t)L_101))? 1 : 0);
		bool L_102 = V_22;
		if (!L_102)
		{
			goto IL_0226;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_103 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_Glyphs_1();
		int32_t L_104 = V_21;
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_105 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_GlyphMarshallingStruct_OUT_4();
		int32_t L_106 = V_21;
		NullCheck(L_105);
		int32_t L_107 = L_106;
		GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448  L_108 = (L_105)->GetAt(static_cast<il2cpp_array_size_t>(L_107));
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_109 = (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)il2cpp_codegen_object_new(Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4_il2cpp_TypeInfo_var);
		Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF(L_109, L_108, /*hidden argument*/NULL);
		NullCheck(L_103);
		ArrayElementTypeCheck (L_103, L_109);
		(L_103)->SetAt(static_cast<il2cpp_array_size_t>(L_104), (Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 *)L_109);
	}

IL_0226:
	{
		int32_t L_110 = V_21;
		int32_t L_111 = V_1;
		V_23 = (bool)((((int32_t)L_110) < ((int32_t)L_111))? 1 : 0);
		bool L_112 = V_23;
		if (!L_112)
		{
			goto IL_0244;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_113 = ___freeGlyphRects3;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_114 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_FreeGlyphRects_5();
		int32_t L_115 = V_21;
		NullCheck(L_114);
		int32_t L_116 = L_115;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_117 = (L_114)->GetAt(static_cast<il2cpp_array_size_t>(L_116));
		NullCheck(L_113);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_113, L_117, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_0244:
	{
		int32_t L_118 = V_21;
		int32_t L_119 = V_2;
		V_24 = (bool)((((int32_t)L_118) < ((int32_t)L_119))? 1 : 0);
		bool L_120 = V_24;
		if (!L_120)
		{
			goto IL_0263;
		}
	}
	{
		List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * L_121 = ___usedGlyphRects4;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_122 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_UsedGlyphRects_6();
		int32_t L_123 = V_21;
		NullCheck(L_122);
		int32_t L_124 = L_123;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_125 = (L_122)->GetAt(static_cast<il2cpp_array_size_t>(L_124));
		NullCheck(L_121);
		List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C(L_121, L_125, /*hidden argument*/List_1_Add_mAADCA2409517EC55213834CB16F9AFC64228518C_RuntimeMethod_var);
	}

IL_0263:
	{
		int32_t L_126 = V_21;
		V_21 = ((int32_t)il2cpp_codegen_add((int32_t)L_126, (int32_t)1));
	}

IL_026a:
	{
		int32_t L_127 = V_21;
		int32_t L_128 = V_4;
		V_25 = (bool)((((int32_t)L_127) < ((int32_t)L_128))? 1 : 0);
		bool L_129 = V_25;
		if (L_129)
		{
			goto IL_0201;
		}
	}
	{
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F** L_130 = ___glyphs7;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_131 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_Glyphs_1();
		*((RuntimeObject **)L_130) = (RuntimeObject *)L_131;
		Il2CppCodeGenWriteBarrier((void**)(RuntimeObject **)L_130, (void*)(RuntimeObject *)L_131);
		Profiler_EndSample_m15350A0463FB3C5789504B4059B0EA68D5B70A21(/*hidden argument*/NULL);
		bool L_132 = V_5;
		V_7 = L_132;
		goto IL_028a;
	}

IL_028a:
	{
		bool L_133 = V_7;
		return L_133;
	}
}
// System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___glyphIndex0, int32_t ___padding1, int32_t ___packingMode2, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___freeGlyphRects3, int32_t* ___freeGlyphRectCount4, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* ___usedGlyphRects5, int32_t* ___usedGlyphRectCount6, int32_t ___renderMode7, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture8, GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* ___glyphs9, int32_t* ___glyphCount10, const RuntimeMethod* method)
{
	typedef bool (*FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB_ftn) (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*, int32_t, int32_t, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*, GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*, int32_t*, int32_t, Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C *, GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*, int32_t*);
	static FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)");
	bool retVal = _il2cpp_icall_func(___glyphIndex0, ___padding1, ___packingMode2, ___freeGlyphRects3, ___freeGlyphRectCount4, ___usedGlyphRects5, ___usedGlyphRectCount6, ___renderMode7, ___texture8, ___glyphs9, ___glyphCount10);
	return retVal;
}
// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable(System.UInt32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* FontEngine_GetGlyphPairAdjustmentTable_m1FC9B74860076DCCECBCE77EEA38737FB32DF24B (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___glyphIndexes0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine_GetGlyphPairAdjustmentTable_m1FC9B74860076DCCECBCE77EEA38737FB32DF24B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	bool V_2 = false;
	bool V_3 = false;
	GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* V_4 = NULL;
	int32_t G_B3_0 = 0;
	{
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_0 = ___glyphIndexes0;
		NullCheck(L_0);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_1 = ___glyphIndexes0;
		NullCheck(L_1);
		V_0 = ((int32_t)il2cpp_codegen_multiply((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_0)->max_length)))), (int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_1)->max_length))))));
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_2 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		if (!L_2)
		{
			goto IL_001c;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_3 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		NullCheck(L_3);
		int32_t L_4 = V_0;
		G_B3_0 = ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_3)->max_length))))) < ((int32_t)L_4))? 1 : 0);
		goto IL_001d;
	}

IL_001c:
	{
		G_B3_0 = 1;
	}

IL_001d:
	{
		V_2 = (bool)G_B3_0;
		bool L_5 = V_2;
		if (!L_5)
		{
			goto IL_002e;
		}
	}
	{
		int32_t L_6 = V_0;
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_7 = (GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7*)(GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7*)SZArrayNew(GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7_il2cpp_TypeInfo_var, (uint32_t)L_6);
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_PairAdjustmentRecords_MarshallingArray_7(L_7);
	}

IL_002e:
	{
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_8 = ___glyphIndexes0;
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_9 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		int32_t L_10 = FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8(L_8, L_9, (int32_t*)(&V_1), /*hidden argument*/NULL);
		V_3 = (bool)((!(((uint32_t)L_10) <= ((uint32_t)0)))? 1 : 0);
		bool L_11 = V_3;
		if (!L_11)
		{
			goto IL_0048;
		}
	}
	{
		V_4 = (GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7*)NULL;
		goto IL_0066;
	}

IL_0048:
	{
		IL2CPP_RUNTIME_CLASS_INIT(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_12 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		int32_t L_13 = V_1;
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_14 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		NullCheck(L_14);
		int32_t L_15 = V_1;
		Array_Clear_m174F4957D6DEDB6359835123005304B14E79132E((RuntimeArray *)(RuntimeArray *)L_12, L_13, ((int32_t)il2cpp_codegen_subtract((int32_t)(((int32_t)((int32_t)(((RuntimeArray*)L_14)->max_length)))), (int32_t)L_15)), /*hidden argument*/NULL);
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_16 = ((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->get_s_PairAdjustmentRecords_MarshallingArray_7();
		V_4 = L_16;
		goto IL_0066;
	}

IL_0066:
	{
		GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* L_17 = V_4;
		return L_17;
	}
}
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable_Internal(System.UInt32[],UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[],System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8 (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* ___glyphIndexes0, GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7* ___glyphPairAdjustmentRecords1, int32_t* ___adjustmentRecordCount2, const RuntimeMethod* method)
{
	typedef int32_t (*FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8_ftn) (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*, GlyphPairAdjustmentRecordU5BU5D_tE4D7700D820175D7726010904F8477E90C1823E7*, int32_t*);
	static FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable_Internal(System.UInt32[],UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[],System.Int32&)");
	int32_t retVal = _il2cpp_icall_func(___glyphIndexes0, ___glyphPairAdjustmentRecords1, ___adjustmentRecordCount2);
	return retVal;
}
// System.Void UnityEngine.TextCore.LowLevel.FontEngine::ResetAtlasTexture(UnityEngine.Texture2D)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E (Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture0, const RuntimeMethod* method)
{
	typedef void (*FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E_ftn) (Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C *);
	static FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.TextCore.LowLevel.FontEngine::ResetAtlasTexture(UnityEngine.Texture2D)");
	_il2cpp_icall_func(___texture0);
}
// System.Void UnityEngine.TextCore.LowLevel.FontEngine::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontEngine__cctor_m17164EA5533727BA15D0E56719925E8AA986F7BC (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FontEngine__cctor_m17164EA5533727BA15D0E56719925E8AA986F7BC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC * L_0 = (FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC *)il2cpp_codegen_object_new(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var);
		FontEngine__ctor_m90CBF12264B15BCA2368C372FC2062A06B0E788F(L_0, /*hidden argument*/NULL);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_Instance_0(L_0);
		GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F* L_1 = (GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F*)(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F*)SZArrayNew(GlyphU5BU5D_t66134ED77A10B5F4419FAF39E4631074CB22E38F_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_Glyphs_1(L_1);
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_2 = (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)SZArrayNew(UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphIndexes_MarshallingArray_2(L_2);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_3 = (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)SZArrayNew(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphMarshallingStruct_IN_3(L_3);
		GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662* L_4 = (GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662*)SZArrayNew(GlyphMarshallingStructU5BU5D_tB5E281DB809E6848B7CC9F02763B5E5AAE5E5662_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphMarshallingStruct_OUT_4(L_4);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_5 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_FreeGlyphRects_5(L_5);
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_6 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)SZArrayNew(GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2_il2cpp_TypeInfo_var, (uint32_t)((int32_t)16));
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_UsedGlyphRects_6(L_6);
		Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B * L_7 = (Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B *)il2cpp_codegen_object_new(Dictionary_2_t572EE3ED0678E28D8D2E0199F7C33E24756FB72B_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_mD40472A556EEC9DFC4FC7FFB8413799EAAACB65E(L_7, /*hidden argument*/Dictionary_2__ctor_mD40472A556EEC9DFC4FC7FFB8413799EAAACB65E_RuntimeMethod_var);
		((FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_StaticFields*)il2cpp_codegen_static_fields_for(FontEngine_t9316586F7FD894C97716C9C48AF485A137284FBC_il2cpp_TypeInfo_var))->set_s_GlyphLookupDictionary_8(L_7);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 UnityEngine.TextCore.LowLevel.FontEngineUtilities::MaxValue(System.Int32,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215 (int32_t ___a0, int32_t ___b1, int32_t ___c2, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	int32_t G_B4_0 = 0;
	int32_t G_B8_0 = 0;
	{
		int32_t L_0 = ___a0;
		int32_t L_1 = ___b1;
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_000f;
		}
	}
	{
		int32_t L_2 = ___a0;
		int32_t L_3 = ___c2;
		if ((((int32_t)L_2) < ((int32_t)L_3)))
		{
			goto IL_000c;
		}
	}
	{
		int32_t L_4 = ___a0;
		G_B4_0 = L_4;
		goto IL_000d;
	}

IL_000c:
	{
		int32_t L_5 = ___c2;
		G_B4_0 = L_5;
	}

IL_000d:
	{
		G_B8_0 = G_B4_0;
		goto IL_0017;
	}

IL_000f:
	{
		int32_t L_6 = ___b1;
		int32_t L_7 = ___c2;
		if ((((int32_t)L_6) < ((int32_t)L_7)))
		{
			goto IL_0016;
		}
	}
	{
		int32_t L_8 = ___b1;
		G_B8_0 = L_8;
		goto IL_0017;
	}

IL_0016:
	{
		int32_t L_9 = ___c2;
		G_B8_0 = L_9;
	}

IL_0017:
	{
		V_0 = G_B8_0;
		goto IL_001a;
	}

IL_001a:
	{
		int32_t L_10 = V_0;
		return L_10;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3 (GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * __this, const RuntimeMethod* method)
{
	uint32_t V_0 = 0;
	{
		uint32_t L_0 = __this->get_m_GlyphIndex_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		uint32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  uint32_t GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * _thisAdjusted = reinterpret_cast<GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 *>(__this + _offset);
	return GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3(_thisAdjusted, method);
}
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC (GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * __this, const RuntimeMethod* method)
{
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  L_0 = __this->get_m_GlyphValueRecord_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D  GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 * _thisAdjusted = reinterpret_cast<GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00 *>(__this + _offset);
	return GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::.ctor(UnityEngine.TextCore.Glyph)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220 (GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * __this, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * ___glyph0, const RuntimeMethod* method)
{
	{
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_0 = ___glyph0;
		NullCheck(L_0);
		uint32_t L_1 = Glyph_get_index_mE8CFBF3B6E08A43EF11AA2E941F7FD9EDFF1C79F(L_0, /*hidden argument*/NULL);
		__this->set_index_0(L_1);
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_2 = ___glyph0;
		NullCheck(L_2);
		GlyphMetrics_t1CEF63AFDC4C55F3A8AF76BF32542B638C5608CB  L_3 = Glyph_get_metrics_m25A3C9DDEA15A3EC461A53F194F549699322A811(L_2, /*hidden argument*/NULL);
		__this->set_metrics_1(L_3);
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_4 = ___glyph0;
		NullCheck(L_4);
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_5 = Glyph_get_glyphRect_mD937109DC8AE147EED30E0CEB667ACAAE281D4F0(L_4, /*hidden argument*/NULL);
		__this->set_glyphRect_2(L_5);
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_6 = ___glyph0;
		NullCheck(L_6);
		float L_7 = Glyph_get_scale_mB6FDF083196D83B61233ECBF9407A708DE4F692E(L_6, /*hidden argument*/NULL);
		__this->set_scale_3(L_7);
		Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * L_8 = ___glyph0;
		NullCheck(L_8);
		int32_t L_9 = Glyph_get_atlasIndex_mF246F5C157408FCD5281DBFF08E21CBF28BB529A(L_8, /*hidden argument*/NULL);
		__this->set_atlasIndex_4(L_9);
		return;
	}
}
IL2CPP_EXTERN_C  void GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220_AdjustorThunk (RuntimeObject * __this, Glyph_t64B599C17F15D84707C46FE272E98B347E1283B4 * ___glyph0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 * _thisAdjusted = reinterpret_cast<GlyphMarshallingStruct_t4A13978D8A28D0D54B36F37557770DCD83219448 *>(__this + _offset);
	GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220(_thisAdjusted, ___glyph0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46 (GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * __this, const RuntimeMethod* method)
{
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  L_0 = __this->get_m_FirstAdjustmentRecord_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * _thisAdjusted = reinterpret_cast<GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C *>(__this + _offset);
	return GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46(_thisAdjusted, method);
}
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66 (GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * __this, const RuntimeMethod* method)
{
	GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  L_0 = __this->get_m_SecondAdjustmentRecord_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  GlyphAdjustmentRecord_t771BE41EF0B790AF1E65928F401E3AB0EE548D00  GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C * _thisAdjusted = reinterpret_cast<GlyphPairAdjustmentRecord_t4D86058777EDA2219FB8211B4C63EDD2B090239C *>(__this + _offset);
	return GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_XPlacement_0();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * _thisAdjusted = reinterpret_cast<GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D *>(__this + _offset);
	return GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_YPlacement_1();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * _thisAdjusted = reinterpret_cast<GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D *>(__this + _offset);
	return GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279 (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_XAdvance_2();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * _thisAdjusted = reinterpret_cast<GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D *>(__this + _offset);
	return GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279(_thisAdjusted, method);
}
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4 (GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_m_YAdvance_3();
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		float L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  float GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D * _thisAdjusted = reinterpret_cast<GlyphValueRecord_tC8C22AFC124DD2B4F0E9383A9C14AA8661359A5D *>(__this + _offset);
	return GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Profiler_BeginSample_mDA159D5771838F40FC7C2829B2DC4329F8C9596B_inline (String_t* ___name0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___name0;
		Profiler_BeginSampleImpl_m831FE453CD200A1F5C3C49DB9E0D831C89B70751(L_0, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_mECB6CD4548659C6AD4FE965FB3BA19CA3A80846F_gshared_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__size_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  List_1_get_Item_m6E99EC5DE0684C11227B9944968241CD1FCB9BE3_gshared_inline (List_1_tD87292C3DA9A1BCF7BE7A6A63897ABF69A015D65 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___index0;
		int32_t L_1 = (int32_t)__this->get__size_2();
		if ((!(((uint32_t)L_0) >= ((uint32_t)L_1))))
		{
			goto IL_000e;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_mBA2AF20A35144E0C43CD721A22EAC9FCA15D6550(/*hidden argument*/NULL);
	}

IL_000e:
	{
		GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2* L_2 = (GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)__this->get__items_1();
		int32_t L_3 = ___index0;
		GlyphRect_t398045C795E0E1264236DFAA5712796CC23C3E7C  L_4 = IL2CPP_ARRAY_UNSAFE_LOAD((GlyphRectU5BU5D_t0C8059848359C24B032007E1B643D747C2BB2FB2*)L_2, (int32_t)L_3);
		return L_4;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared_inline (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__size_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR RuntimeObject * List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared_inline (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, int32_t ___index0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___index0;
		int32_t L_1 = (int32_t)__this->get__size_2();
		if ((!(((uint32_t)L_0) >= ((uint32_t)L_1))))
		{
			goto IL_000e;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_mBA2AF20A35144E0C43CD721A22EAC9FCA15D6550(/*hidden argument*/NULL);
	}

IL_000e:
	{
		ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_2 = (ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)__this->get__items_1();
		int32_t L_3 = ___index0;
		RuntimeObject * L_4 = IL2CPP_ARRAY_UNSAFE_LOAD((ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)L_2, (int32_t)L_3);
		return L_4;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m3E3E6FA980D3D675E1A5DF9D9C95657717425563_gshared_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__size_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR uint32_t List_1_get_Item_m88EE8C94499F26CC0CD73495FE013C1C903DB702_gshared_inline (List_1_t49B315A213A231954A3718D77EE3A2AFF443C38E * __this, int32_t ___index0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___index0;
		int32_t L_1 = (int32_t)__this->get__size_2();
		if ((!(((uint32_t)L_0) >= ((uint32_t)L_1))))
		{
			goto IL_000e;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_mBA2AF20A35144E0C43CD721A22EAC9FCA15D6550(/*hidden argument*/NULL);
	}

IL_000e:
	{
		UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB* L_2 = (UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)__this->get__items_1();
		int32_t L_3 = ___index0;
		uint32_t L_4 = IL2CPP_ARRAY_UNSAFE_LOAD((UInt32U5BU5D_t9AA834AF2940E75BBF8E3F08FF0D20D266DB71CB*)L_2, (int32_t)L_3);
		return L_4;
	}
}
