﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String SR::GetString(System.String,System.Object[])
extern void SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39 ();
// 0x00000002 System.String SR::GetString(System.Globalization.CultureInfo,System.String,System.Object[])
extern void SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2 ();
// 0x00000003 System.String SR::GetString(System.String)
extern void SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7 ();
// 0x00000004 System.String SR::Format(System.String,System.Object)
extern void SR_Format_m0F2CEC6937029AEC3360EE21DB1D6329D5BE8906 ();
// 0x00000005 System.String SR::Format(System.String,System.Object,System.Object)
extern void SR_Format_mCE758E323017FDB5E39921BE8757AC78665C7504 ();
// 0x00000006 System.Void System.SecurityUtils::DemandReflectionAccess(System.Type)
extern void SecurityUtils_DemandReflectionAccess_mC21CA419C4B77BBDE16AAF5C33DCBF86E3CCA5F0 ();
// 0x00000007 System.Boolean System.SecurityUtils::HasReflectionPermission(System.Type)
extern void SecurityUtils_HasReflectionPermission_mE162700DD39C0E439075D744EA4DD3C768AA5D96 ();
// 0x00000008 System.Object System.SecurityUtils::SecureCreateInstance(System.Type)
extern void SecurityUtils_SecureCreateInstance_m00B165286E54C3393CFFE82948E078F96018750A ();
// 0x00000009 System.Object System.SecurityUtils::SecureCreateInstance(System.Type,System.Object[],System.Boolean)
extern void SecurityUtils_SecureCreateInstance_m75CC5B0308F53B01ADC1B5EEBF831C49A53808F4 ();
// 0x0000000A System.Object System.SecurityUtils::SecureConstructorInvoke(System.Type,System.Type[],System.Object[],System.Boolean)
extern void SecurityUtils_SecureConstructorInvoke_m7DA77EA06BECD2F9B36481C8CAD9429674166D27 ();
// 0x0000000B System.Object System.SecurityUtils::SecureConstructorInvoke(System.Type,System.Type[],System.Object[],System.Boolean,System.Reflection.BindingFlags)
extern void SecurityUtils_SecureConstructorInvoke_mE027B99C9C5C9A325AFC67CAC4B4106DBE855585 ();
// 0x0000000C System.Void System.InvariantComparer::.ctor()
extern void InvariantComparer__ctor_m803F2DC4D029AE0DA9B3C0A581E9B49B044DF51A ();
// 0x0000000D System.Int32 System.InvariantComparer::Compare(System.Object,System.Object)
extern void InvariantComparer_Compare_m974E695ADB170A8E1F6D63CB96FA0A0073B026AF ();
// 0x0000000E System.Void System.InvariantComparer::.cctor()
extern void InvariantComparer__cctor_m25FDC0EE3C4E0B5FE5E20F0C743C92CC22DE5B9B ();
// 0x0000000F System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C ();
// 0x00000010 System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Char,System.Boolean&,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9 ();
// 0x00000011 System.Boolean System.IriHelper::CheckIsReserved(System.Char,System.UriComponents)
extern void IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C ();
// 0x00000012 System.String System.IriHelper::EscapeUnescapeIri(System.Char*,System.Int32,System.Int32,System.UriComponents)
extern void IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239 ();
// 0x00000013 System.Boolean System.Uri::get_IsImplicitFile()
extern void Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D ();
// 0x00000014 System.Boolean System.Uri::get_IsUncOrDosPath()
extern void Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E ();
// 0x00000015 System.Boolean System.Uri::get_IsDosPath()
extern void Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08 ();
// 0x00000016 System.Boolean System.Uri::get_IsUncPath()
extern void Uri_get_IsUncPath_mD5EE84D5105BFB7D64E5C26B9549A67B720A7AE8 ();
// 0x00000017 System.Uri_Flags System.Uri::get_HostType()
extern void Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90 ();
// 0x00000018 System.UriParser System.Uri::get_Syntax()
extern void Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78 ();
// 0x00000019 System.Boolean System.Uri::get_IsNotAbsoluteUri()
extern void Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919 ();
// 0x0000001A System.Boolean System.Uri::IriParsingStatic(System.UriParser)
extern void Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5 ();
// 0x0000001B System.Boolean System.Uri::get_AllowIdn()
extern void Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941 ();
// 0x0000001C System.Boolean System.Uri::AllowIdnStatic(System.UriParser,System.Uri_Flags)
extern void Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5 ();
// 0x0000001D System.Boolean System.Uri::IsIntranet(System.String)
extern void Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1 ();
// 0x0000001E System.Boolean System.Uri::get_UserDrivenParsing()
extern void Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39 ();
// 0x0000001F System.Void System.Uri::SetUserDrivenParsing()
extern void Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B ();
// 0x00000020 System.UInt16 System.Uri::get_SecuredPathIndex()
extern void Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA ();
// 0x00000021 System.Boolean System.Uri::NotAny(System.Uri_Flags)
extern void Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D ();
// 0x00000022 System.Boolean System.Uri::InFact(System.Uri_Flags)
extern void Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7 ();
// 0x00000023 System.Boolean System.Uri::StaticNotAny(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A ();
// 0x00000024 System.Boolean System.Uri::StaticInFact(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8 ();
// 0x00000025 System.Uri_UriInfo System.Uri::EnsureUriInfo()
extern void Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7 ();
// 0x00000026 System.Void System.Uri::EnsureParseRemaining()
extern void Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B ();
// 0x00000027 System.Void System.Uri::EnsureHostString(System.Boolean)
extern void Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720 ();
// 0x00000028 System.Void System.Uri::.ctor(System.String)
extern void Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2 ();
// 0x00000029 System.Void System.Uri::.ctor(System.String,System.UriKind)
extern void Uri__ctor_mA02DB222F4F35380DE2700D84F58EB42497FDDE4 ();
// 0x0000002A System.Void System.Uri::.ctor(System.Uri,System.String)
extern void Uri__ctor_m41A759BF295FB902084DD289849793E01A65A14E ();
// 0x0000002B System.Void System.Uri::CreateUri(System.Uri,System.String,System.Boolean)
extern void Uri_CreateUri_m0A20410F2B8286AE6EDCD8B5AB3E104FA095808A ();
// 0x0000002C System.Void System.Uri::.ctor(System.Uri,System.Uri)
extern void Uri__ctor_m42192656437FBEF1EEA8724D3EF2BB67DA0ED6BF ();
// 0x0000002D System.ParsingError System.Uri::GetCombinedString(System.Uri,System.String,System.Boolean,System.String&)
extern void Uri_GetCombinedString_m7B95A90BC09E899CF41B0047E0B681FA7CEB8668 ();
// 0x0000002E System.UriFormatException System.Uri::GetException(System.ParsingError)
extern void Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164 ();
// 0x0000002F System.Void System.Uri::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF ();
// 0x00000030 System.Void System.Uri::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C ();
// 0x00000031 System.Void System.Uri::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68 ();
// 0x00000032 System.String System.Uri::get_AbsolutePath()
extern void Uri_get_AbsolutePath_mA9A825E2BBD0A43AD76EB9A9765E29E45FE32F31 ();
// 0x00000033 System.String System.Uri::get_PrivateAbsolutePath()
extern void Uri_get_PrivateAbsolutePath_mC1CDB66963BF6D6AEDE0713D3CF0CE0647A6A532 ();
// 0x00000034 System.String System.Uri::get_AbsoluteUri()
extern void Uri_get_AbsoluteUri_m4326730E572E7E3874021E802813EB6F49F7F99E ();
// 0x00000035 System.Boolean System.Uri::get_IsFile()
extern void Uri_get_IsFile_m06AB5A15E2A34BBC5177C6E902C5C9D7E766A213 ();
// 0x00000036 System.Boolean System.Uri::get_IsLoopback()
extern void Uri_get_IsLoopback_mCD7E1228C8296730CBD31C713B0A81B660D99BC4 ();
// 0x00000037 System.String System.Uri::get_PathAndQuery()
extern void Uri_get_PathAndQuery_mF079BA04B7A397B2729E5B5DEE72B3654A44E384 ();
// 0x00000038 System.Boolean System.Uri::get_IsUnc()
extern void Uri_get_IsUnc_m70B47E68BDAE06A7E5362DCE5AAD97C12119AB99 ();
// 0x00000039 System.Boolean System.Uri::StaticIsFile(System.UriParser)
extern void Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3 ();
// 0x0000003A System.Object System.Uri::get_InitializeLock()
extern void Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE ();
// 0x0000003B System.Void System.Uri::InitializeUriConfig()
extern void Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2 ();
// 0x0000003C System.Int32 System.Uri::get_Port()
extern void Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C ();
// 0x0000003D System.String System.Uri::get_Fragment()
extern void Uri_get_Fragment_m111666DD668AC59B9F3C3D3CEEEC7F70F6904D41 ();
// 0x0000003E System.String System.Uri::get_Scheme()
extern void Uri_get_Scheme_m14A8F0018D8AACADBEF39600A59944F33EE39187 ();
// 0x0000003F System.Boolean System.Uri::get_OriginalStringSwitched()
extern void Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D ();
// 0x00000040 System.String System.Uri::get_OriginalString()
extern void Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F ();
// 0x00000041 System.String System.Uri::get_DnsSafeHost()
extern void Uri_get_DnsSafeHost_mC2D93669288A9C05CC13EE5754CEBF2D74D04704 ();
// 0x00000042 System.Boolean System.Uri::get_IsAbsoluteUri()
extern void Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722 ();
// 0x00000043 System.Boolean System.Uri::get_UserEscaped()
extern void Uri_get_UserEscaped_m8F29E9A593E84E66DD4AC06CBD5880B93A5F0307 ();
// 0x00000044 System.Boolean System.Uri::IsGenDelim(System.Char)
extern void Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3 ();
// 0x00000045 System.Boolean System.Uri::IsHexDigit(System.Char)
extern void Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836 ();
// 0x00000046 System.Int32 System.Uri::FromHex(System.Char)
extern void Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B ();
// 0x00000047 System.Int32 System.Uri::GetHashCode()
extern void Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515 ();
// 0x00000048 System.String System.Uri::ToString()
extern void Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2 ();
// 0x00000049 System.Boolean System.Uri::op_Equality(System.Uri,System.Uri)
extern void Uri_op_Equality_mFED3D4AFAB090B76D2088C485507F8F702ADA18F ();
// 0x0000004A System.Boolean System.Uri::op_Inequality(System.Uri,System.Uri)
extern void Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B ();
// 0x0000004B System.Boolean System.Uri::Equals(System.Object)
extern void Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629 ();
// 0x0000004C System.ParsingError System.Uri::ParseScheme(System.String,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884 ();
// 0x0000004D System.UriFormatException System.Uri::ParseMinimal()
extern void Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF ();
// 0x0000004E System.ParsingError System.Uri::PrivateParseMinimal()
extern void Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0 ();
// 0x0000004F System.Void System.Uri::PrivateParseMinimalIri(System.String,System.UInt16)
extern void Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0 ();
// 0x00000050 System.Void System.Uri::CreateUriInfo(System.Uri_Flags)
extern void Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF ();
// 0x00000051 System.Void System.Uri::CreateHostString()
extern void Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54 ();
// 0x00000052 System.String System.Uri::CreateHostStringHelper(System.String,System.UInt16,System.UInt16,System.Uri_Flags&,System.String&)
extern void Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD ();
// 0x00000053 System.Void System.Uri::GetHostViaCustomSyntax()
extern void Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3 ();
// 0x00000054 System.String System.Uri::GetParts(System.UriComponents,System.UriFormat)
extern void Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F ();
// 0x00000055 System.String System.Uri::GetEscapedParts(System.UriComponents)
extern void Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4 ();
// 0x00000056 System.String System.Uri::GetUnescapedParts(System.UriComponents,System.UriFormat)
extern void Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3 ();
// 0x00000057 System.String System.Uri::ReCreateParts(System.UriComponents,System.UInt16,System.UriFormat)
extern void Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7 ();
// 0x00000058 System.String System.Uri::GetUriPartsFromUserString(System.UriComponents)
extern void Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6 ();
// 0x00000059 System.Void System.Uri::ParseRemaining()
extern void Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774 ();
// 0x0000005A System.UInt16 System.Uri::ParseSchemeCheckImplicitFile(System.Char*,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243 ();
// 0x0000005B System.Boolean System.Uri::CheckKnownSchemes(System.Int64*,System.UInt16,System.UriParser&)
extern void Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D ();
// 0x0000005C System.ParsingError System.Uri::CheckSchemeSyntax(System.Char*,System.UInt16,System.UriParser&)
extern void Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F ();
// 0x0000005D System.UInt16 System.Uri::CheckAuthorityHelper(System.Char*,System.UInt16,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser,System.String&)
extern void Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387 ();
// 0x0000005E System.Void System.Uri::CheckAuthorityHelperHandleDnsIri(System.Char*,System.UInt16,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.String,System.Uri_Flags&,System.Boolean&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28 ();
// 0x0000005F System.Void System.Uri::CheckAuthorityHelperHandleAnyHostIri(System.Char*,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.Uri_Flags&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8 ();
// 0x00000060 System.Void System.Uri::FindEndOfComponent(System.String,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B ();
// 0x00000061 System.Void System.Uri::FindEndOfComponent(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF ();
// 0x00000062 System.Uri_Check System.Uri::CheckCanonical(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6 ();
// 0x00000063 System.Char[] System.Uri::GetCanonicalPath(System.Char[],System.Int32&,System.UriFormat)
extern void Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2 ();
// 0x00000064 System.Void System.Uri::UnescapeOnly(System.Char*,System.Int32,System.Int32&,System.Char,System.Char,System.Char)
extern void Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21 ();
// 0x00000065 System.Char[] System.Uri::Compress(System.Char[],System.UInt16,System.Int32&,System.UriParser)
extern void Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF ();
// 0x00000066 System.Int32 System.Uri::CalculateCaseInsensitiveHashCode(System.String)
extern void Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4 ();
// 0x00000067 System.String System.Uri::CombineUri(System.Uri,System.String,System.UriFormat)
extern void Uri_CombineUri_m77B7B8B856CF8100E51250247930963E7C544F91 ();
// 0x00000068 System.Boolean System.Uri::IsLWS(System.Char)
extern void Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6 ();
// 0x00000069 System.Boolean System.Uri::IsAsciiLetter(System.Char)
extern void Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373 ();
// 0x0000006A System.Boolean System.Uri::IsAsciiLetterOrDigit(System.Char)
extern void Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661 ();
// 0x0000006B System.Boolean System.Uri::IsBidiControlCharacter(System.Char)
extern void Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D ();
// 0x0000006C System.String System.Uri::StripBidiControlCharacter(System.Char*,System.Int32,System.Int32)
extern void Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F ();
// 0x0000006D System.Void System.Uri::CreateThis(System.String,System.Boolean,System.UriKind)
extern void Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864 ();
// 0x0000006E System.Void System.Uri::InitializeUri(System.ParsingError,System.UriKind,System.UriFormatException&)
extern void Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE ();
// 0x0000006F System.Boolean System.Uri::CheckForConfigLoad(System.String)
extern void Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F ();
// 0x00000070 System.Boolean System.Uri::CheckForUnicode(System.String)
extern void Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD ();
// 0x00000071 System.Boolean System.Uri::CheckForEscapedUnreserved(System.String)
extern void Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A ();
// 0x00000072 System.Boolean System.Uri::TryCreate(System.String,System.UriKind,System.Uri&)
extern void Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB ();
// 0x00000073 System.String System.Uri::GetComponents(System.UriComponents,System.UriFormat)
extern void Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6 ();
// 0x00000074 System.String System.Uri::UnescapeDataString(System.String)
extern void Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D ();
// 0x00000075 System.String System.Uri::EscapeUnescapeIri(System.String,System.Int32,System.Int32,System.UriComponents)
extern void Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180 ();
// 0x00000076 System.Void System.Uri::.ctor(System.Uri_Flags,System.UriParser,System.String)
extern void Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD ();
// 0x00000077 System.Uri System.Uri::CreateHelper(System.String,System.Boolean,System.UriKind,System.UriFormatException&)
extern void Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0 ();
// 0x00000078 System.Uri System.Uri::ResolveHelper(System.Uri,System.Uri,System.String&,System.Boolean&,System.UriFormatException&)
extern void Uri_ResolveHelper_mEDF1549C3E9AC1CF6177DCF93B17D574411916BC ();
// 0x00000079 System.String System.Uri::GetRelativeSerializationString(System.UriFormat)
extern void Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58 ();
// 0x0000007A System.String System.Uri::GetComponentsHelper(System.UriComponents,System.UriFormat)
extern void Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3 ();
// 0x0000007B System.Void System.Uri::CreateThisFromUri(System.Uri)
extern void Uri_CreateThisFromUri_m9A4AE7CD70F7EDE9154634057EBE600E74A5D544 ();
// 0x0000007C System.Void System.Uri::.cctor()
extern void Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2 ();
// 0x0000007D System.Void System.Uri_UriInfo::.ctor()
extern void UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98 ();
// 0x0000007E System.Void System.Uri_MoreInfo::.ctor()
extern void MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C ();
// 0x0000007F System.Void System.UriFormatException::.ctor()
extern void UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424 ();
// 0x00000080 System.Void System.UriFormatException::.ctor(System.String)
extern void UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D ();
// 0x00000081 System.Void System.UriFormatException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5 ();
// 0x00000082 System.Void System.UriFormatException::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC ();
// 0x00000083 System.Char[] System.UriHelper::EscapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Boolean,System.Char,System.Char,System.Char)
extern void UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B ();
// 0x00000084 System.Char[] System.UriHelper::EnsureDestinationSize(System.Char*,System.Char[],System.Int32,System.Int16,System.Int16,System.Int32&,System.Int32)
extern void UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217 ();
// 0x00000085 System.Char[] System.UriHelper::UnescapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF ();
// 0x00000086 System.Char[] System.UriHelper::UnescapeString(System.Char*,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89 ();
// 0x00000087 System.Void System.UriHelper::MatchUTF8Sequence(System.Char*,System.Char[],System.Int32&,System.Char[],System.Int32,System.Byte[],System.Int32,System.Boolean,System.Boolean)
extern void UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F ();
// 0x00000088 System.Void System.UriHelper::EscapeAsciiChar(System.Char,System.Char[],System.Int32&)
extern void UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902 ();
// 0x00000089 System.Char System.UriHelper::EscapedAscii(System.Char,System.Char)
extern void UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78 ();
// 0x0000008A System.Boolean System.UriHelper::IsNotSafeForUnescape(System.Char)
extern void UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D ();
// 0x0000008B System.Boolean System.UriHelper::IsReservedUnreservedOrHash(System.Char)
extern void UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059 ();
// 0x0000008C System.Boolean System.UriHelper::IsUnreserved(System.Char)
extern void UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48 ();
// 0x0000008D System.Boolean System.UriHelper::Is3986Unreserved(System.Char)
extern void UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A ();
// 0x0000008E System.Void System.UriHelper::.cctor()
extern void UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27 ();
// 0x0000008F System.String System.UriParser::get_SchemeName()
extern void UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1 ();
// 0x00000090 System.Int32 System.UriParser::get_DefaultPort()
extern void UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D ();
// 0x00000091 System.UriParser System.UriParser::OnNewUri()
extern void UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897 ();
// 0x00000092 System.Void System.UriParser::InitializeAndValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0 ();
// 0x00000093 System.String System.UriParser::Resolve(System.Uri,System.Uri,System.UriFormatException&)
extern void UriParser_Resolve_mF21D3AA42AB1EC2B173617D76E4041EB3481D979 ();
// 0x00000094 System.String System.UriParser::GetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181 ();
// 0x00000095 System.Boolean System.UriParser::get_ShouldUseLegacyV2Quirks()
extern void UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD ();
// 0x00000096 System.Void System.UriParser::.cctor()
extern void UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2 ();
// 0x00000097 System.UriSyntaxFlags System.UriParser::get_Flags()
extern void UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039 ();
// 0x00000098 System.Boolean System.UriParser::NotAny(System.UriSyntaxFlags)
extern void UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3 ();
// 0x00000099 System.Boolean System.UriParser::InFact(System.UriSyntaxFlags)
extern void UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3 ();
// 0x0000009A System.Boolean System.UriParser::IsAllSet(System.UriSyntaxFlags)
extern void UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E ();
// 0x0000009B System.Boolean System.UriParser::IsFullMatch(System.UriSyntaxFlags,System.UriSyntaxFlags)
extern void UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E ();
// 0x0000009C System.Void System.UriParser::.ctor(System.UriSyntaxFlags)
extern void UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D ();
// 0x0000009D System.UriParser System.UriParser::FindOrFetchAsUnknownV1Syntax(System.String)
extern void UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD ();
// 0x0000009E System.Boolean System.UriParser::get_IsSimple()
extern void UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C ();
// 0x0000009F System.UriParser System.UriParser::InternalOnNewUri()
extern void UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA ();
// 0x000000A0 System.Void System.UriParser::InternalValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2 ();
// 0x000000A1 System.String System.UriParser::InternalResolve(System.Uri,System.Uri,System.UriFormatException&)
extern void UriParser_InternalResolve_m2A027789CB5105E32B09810E81810E8E35DD1F26 ();
// 0x000000A2 System.String System.UriParser::InternalGetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674 ();
// 0x000000A3 System.Void System.UriParser_BuiltInUriParser::.ctor(System.String,System.Int32,System.UriSyntaxFlags)
extern void BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C ();
// 0x000000A4 System.String System.DomainNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4 ();
// 0x000000A5 System.Boolean System.DomainNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461 ();
// 0x000000A6 System.Boolean System.DomainNameHelper::IsValidByIri(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF ();
// 0x000000A7 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F ();
// 0x000000A8 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.String&)
extern void DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57 ();
// 0x000000A9 System.Boolean System.DomainNameHelper::IsIdnAce(System.String,System.Int32)
extern void DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445 ();
// 0x000000AA System.Boolean System.DomainNameHelper::IsIdnAce(System.Char*,System.Int32)
extern void DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8 ();
// 0x000000AB System.String System.DomainNameHelper::UnicodeEquivalent(System.String,System.Char*,System.Int32,System.Int32)
extern void DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3 ();
// 0x000000AC System.String System.DomainNameHelper::UnicodeEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F ();
// 0x000000AD System.Boolean System.DomainNameHelper::IsASCIILetterOrDigit(System.Char,System.Boolean&)
extern void DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01 ();
// 0x000000AE System.Boolean System.DomainNameHelper::IsValidDomainLabelCharacter(System.Char,System.Boolean&)
extern void DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1 ();
// 0x000000AF System.String System.IPv4AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813 ();
// 0x000000B0 System.Int32 System.IPv4AddressHelper::ParseHostNumber(System.String,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14 ();
// 0x000000B1 System.Boolean System.IPv4AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843 ();
// 0x000000B2 System.Boolean System.IPv4AddressHelper::IsValidCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120 ();
// 0x000000B3 System.Int64 System.IPv4AddressHelper::ParseNonCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E ();
// 0x000000B4 System.Boolean System.IPv4AddressHelper::Parse(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF ();
// 0x000000B5 System.Boolean System.IPv4AddressHelper::ParseCanonical(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33 ();
// 0x000000B6 System.String System.IPv6AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Boolean&,System.String&)
extern void IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14 ();
// 0x000000B7 System.String System.IPv6AddressHelper::CreateCanonicalName(System.UInt16*)
extern void IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A ();
// 0x000000B8 System.Collections.Generic.KeyValuePair`2<System.Int32,System.Int32> System.IPv6AddressHelper::FindCompressionRange(System.UInt16*)
extern void IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD ();
// 0x000000B9 System.Boolean System.IPv6AddressHelper::ShouldHaveIpv4Embedded(System.UInt16*)
extern void IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE ();
// 0x000000BA System.Boolean System.IPv6AddressHelper::InternalIsValid(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A ();
// 0x000000BB System.Boolean System.IPv6AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&)
extern void IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289 ();
// 0x000000BC System.Boolean System.IPv6AddressHelper::Parse(System.String,System.UInt16*,System.Int32,System.String&)
extern void IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB ();
// 0x000000BD System.String System.UncNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E ();
// 0x000000BE System.Boolean System.UncNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean)
extern void UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6 ();
// 0x000000BF System.Void System.IOAsyncCallback::.ctor(System.Object,System.IntPtr)
extern void IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985 ();
// 0x000000C0 System.Void System.IOAsyncCallback::Invoke(System.IOAsyncResult)
extern void IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B ();
// 0x000000C1 System.IAsyncResult System.IOAsyncCallback::BeginInvoke(System.IOAsyncResult,System.AsyncCallback,System.Object)
extern void IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C ();
// 0x000000C2 System.Void System.IOAsyncCallback::EndInvoke(System.IAsyncResult)
extern void IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727 ();
// 0x000000C3 System.Void System.UriTypeConverter::.ctor()
extern void UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64 ();
// 0x000000C4 System.Boolean System.UriTypeConverter::CanConvert(System.Type)
extern void UriTypeConverter_CanConvert_m0F0FB34A1DC16C677BF8F4ED0E720144C17C4795 ();
// 0x000000C5 System.Boolean System.UriTypeConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void UriTypeConverter_CanConvertFrom_m1D18F7B5924B6B682AB1CC90FB814DC3331DFF47 ();
// 0x000000C6 System.Boolean System.UriTypeConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void UriTypeConverter_CanConvertTo_mC19530C1DD75AC92C20697EFDD0A0E2DB568E099 ();
// 0x000000C7 System.Object System.UriTypeConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void UriTypeConverter_ConvertFrom_m2FE8479F26F35A578983E194038CF186D6CD2F85 ();
// 0x000000C8 System.Object System.UriTypeConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void UriTypeConverter_ConvertTo_m2059A4086714BACA32E7618BD97713CCD5DCFEF4 ();
// 0x000000C9 System.Void System.Text.RegularExpressions.Regex::.ctor()
extern void Regex__ctor_mFDE4B6A423C15AA60BF9FEC7D4D7DFD4657D7C6E ();
// 0x000000CA System.Void System.Text.RegularExpressions.Regex::.ctor(System.String)
extern void Regex__ctor_m2769A5BA7B7A835514F6C0E4D30FAD467C6B1B0C ();
// 0x000000CB System.Void System.Text.RegularExpressions.Regex::.ctor(System.String,System.Text.RegularExpressions.RegexOptions)
extern void Regex__ctor_mEF4515C4C44DF8BE410F388C82CC679D743FB5CD ();
// 0x000000CC System.Void System.Text.RegularExpressions.Regex::.ctor(System.String,System.Text.RegularExpressions.RegexOptions,System.TimeSpan,System.Boolean)
extern void Regex__ctor_m87918FB2A856E264A492D2A2B4B412BE4E2370BB ();
// 0x000000CD System.Void System.Text.RegularExpressions.Regex::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Regex__ctor_mF11825F6E24D7D780BD34C74C96392DEC3602A5D ();
// 0x000000CE System.Void System.Text.RegularExpressions.Regex::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m95B0E2523A72DF6AC56DEA7CDA286F771E06B0FD ();
// 0x000000CF System.Void System.Text.RegularExpressions.Regex::ValidateMatchTimeout(System.TimeSpan)
extern void Regex_ValidateMatchTimeout_m71FE7188780DEAD57093B7345CCC50D0159218BE ();
// 0x000000D0 System.TimeSpan System.Text.RegularExpressions.Regex::InitDefaultMatchTimeout()
extern void Regex_InitDefaultMatchTimeout_mC91736B02BD12B92CBD93C329E7A8233CD0B9DA4 ();
// 0x000000D1 System.String System.Text.RegularExpressions.Regex::Unescape(System.String)
extern void Regex_Unescape_mDA4631C73336E4191E48CD512049D4B2E831306D ();
// 0x000000D2 System.Text.RegularExpressions.RegexOptions System.Text.RegularExpressions.Regex::get_Options()
extern void Regex_get_Options_m823A30690EEA63798DB8497F3E9CF062412B8653 ();
// 0x000000D3 System.TimeSpan System.Text.RegularExpressions.Regex::get_MatchTimeout()
extern void Regex_get_MatchTimeout_mD484D1CF0B6BF8516A08991D1387761CAE2340D6 ();
// 0x000000D4 System.Boolean System.Text.RegularExpressions.Regex::get_RightToLeft()
extern void Regex_get_RightToLeft_m546BF531C94563A11427CD24367525462CDB4509 ();
// 0x000000D5 System.String System.Text.RegularExpressions.Regex::ToString()
extern void Regex_ToString_mF967EF5E8BD74C3692379B8436AB8D3C5963FA75 ();
// 0x000000D6 System.Boolean System.Text.RegularExpressions.Regex::IsMatch(System.String,System.String)
extern void Regex_IsMatch_m3C44A8D92E43EA8CC8D623ECC394B27F09E2D5DA ();
// 0x000000D7 System.Boolean System.Text.RegularExpressions.Regex::IsMatch(System.String,System.String,System.Text.RegularExpressions.RegexOptions,System.TimeSpan)
extern void Regex_IsMatch_m90348BB44AD120A322F411001522DB0758A6678B ();
// 0x000000D8 System.Boolean System.Text.RegularExpressions.Regex::IsMatch(System.String)
extern void Regex_IsMatch_m79684C4D2CE6C5495BCCE9A32AC029E1E5950B7C ();
// 0x000000D9 System.Boolean System.Text.RegularExpressions.Regex::IsMatch(System.String,System.Int32)
extern void Regex_IsMatch_m2FB867817B341A5FA3E64A41F31820C9658F22A5 ();
// 0x000000DA System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Match(System.String)
extern void Regex_Match_mC2C718B93803F6633A708E430F8698E70354B77C ();
// 0x000000DB System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Match(System.String,System.Int32)
extern void Regex_Match_mA36A33D32F895CE84957DC7DA82E2CD45EF19EEA ();
// 0x000000DC System.Void System.Text.RegularExpressions.Regex::InitializeReferences()
extern void Regex_InitializeReferences_m2CD000C1AFAA8B214F32D989C7D116B684A31840 ();
// 0x000000DD System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Run(System.Boolean,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void Regex_Run_m74FB5EF178DF43F88B9058B94939F557479B93FC ();
// 0x000000DE System.Text.RegularExpressions.CachedCodeEntry System.Text.RegularExpressions.Regex::LookupCachedAndUpdate(System.String)
extern void Regex_LookupCachedAndUpdate_m88CA03797C5ED796BD5E1319DF6B1B6B6FCE6C0D ();
// 0x000000DF System.Text.RegularExpressions.CachedCodeEntry System.Text.RegularExpressions.Regex::CacheCode(System.String)
extern void Regex_CacheCode_m68F93FF3B918776D190D4DB807A3323691C77F0A ();
// 0x000000E0 System.Boolean System.Text.RegularExpressions.Regex::UseOptionR()
extern void Regex_UseOptionR_m84945EDBEDCD61DBCEB691C929CA28F4B0AF4B49 ();
// 0x000000E1 System.Boolean System.Text.RegularExpressions.Regex::UseOptionInvariant()
extern void Regex_UseOptionInvariant_m0CA185DBDB15932BB8A8B4F53EB8ACECEC006566 ();
// 0x000000E2 System.Void System.Text.RegularExpressions.Regex::.cctor()
extern void Regex__cctor_m86CE9B8D0FF5F2B54D4FF27D2213A1E6917477DF ();
// 0x000000E3 System.Void System.Text.RegularExpressions.CachedCodeEntry::.ctor(System.String,System.Collections.Hashtable,System.String[],System.Text.RegularExpressions.RegexCode,System.Collections.Hashtable,System.Int32,System.Text.RegularExpressions.ExclusiveReference,System.Text.RegularExpressions.SharedReference)
extern void CachedCodeEntry__ctor_m78BCA6060E7D83B172F998AF60D17FB41BE703B8 ();
// 0x000000E4 System.Object System.Text.RegularExpressions.ExclusiveReference::Get()
extern void ExclusiveReference_Get_mE79B077388AFBD19A4524E630701783E7DCE61E4 ();
// 0x000000E5 System.Void System.Text.RegularExpressions.ExclusiveReference::Release(System.Object)
extern void ExclusiveReference_Release_m9A1577138872106EA54A04EA4AB77F710CEDE336 ();
// 0x000000E6 System.Void System.Text.RegularExpressions.ExclusiveReference::.ctor()
extern void ExclusiveReference__ctor_m0427943C75CBB283EF26034339E3D412A080B5D7 ();
// 0x000000E7 System.Void System.Text.RegularExpressions.SharedReference::.ctor()
extern void SharedReference__ctor_m48E749BC646BEC89282B8F336325D42DE48CFC81 ();
// 0x000000E8 System.Void System.Text.RegularExpressions.RegexBoyerMoore::.ctor(System.String,System.Boolean,System.Boolean,System.Globalization.CultureInfo)
extern void RegexBoyerMoore__ctor_m39674FB18BB75DD891AAE3781FDA0CCDDEBC2F8C ();
// 0x000000E9 System.Boolean System.Text.RegularExpressions.RegexBoyerMoore::MatchPattern(System.String,System.Int32)
extern void RegexBoyerMoore_MatchPattern_m41D57E11972B2142649662886DA145AFE396F602 ();
// 0x000000EA System.Boolean System.Text.RegularExpressions.RegexBoyerMoore::IsMatch(System.String,System.Int32,System.Int32,System.Int32)
extern void RegexBoyerMoore_IsMatch_m820D06ED51C062451AFAF22682D2EB06C8DFABD9 ();
// 0x000000EB System.Int32 System.Text.RegularExpressions.RegexBoyerMoore::Scan(System.String,System.Int32,System.Int32,System.Int32)
extern void RegexBoyerMoore_Scan_m204A42056131A694B6D31FC69563355788CABD67 ();
// 0x000000EC System.String System.Text.RegularExpressions.RegexBoyerMoore::ToString()
extern void RegexBoyerMoore_ToString_mB0A62E68E8A3CAC5CE3AC45E1C54FA72DFB626F6 ();
// 0x000000ED System.Void System.Text.RegularExpressions.Capture::.ctor(System.String,System.Int32,System.Int32)
extern void Capture__ctor_m6CC8A5385C7BD6B8AE63F9812293EC3252A65B3B ();
// 0x000000EE System.String System.Text.RegularExpressions.Capture::get_Value()
extern void Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C ();
// 0x000000EF System.String System.Text.RegularExpressions.Capture::ToString()
extern void Capture_ToString_mD49A28CAD5727E8F629643EDE0C6BAB476BA639E ();
// 0x000000F0 System.Void System.Text.RegularExpressions.Capture::.ctor()
extern void Capture__ctor_m3ED807279C93FFCE8BE4EAF447DA01E62EF93D7B ();
// 0x000000F1 System.Void System.Text.RegularExpressions.RegexCharClass::.cctor()
extern void RegexCharClass__cctor_m5170E52D9864BA712125FB33F309FE9E37869EA8 ();
// 0x000000F2 System.Void System.Text.RegularExpressions.RegexCharClass::.ctor()
extern void RegexCharClass__ctor_mAA44510F3E5001A8612355B4FFB718D9DDC74264 ();
// 0x000000F3 System.Void System.Text.RegularExpressions.RegexCharClass::.ctor(System.Boolean,System.Collections.Generic.List`1<System.Text.RegularExpressions.RegexCharClass_SingleRange>,System.Text.StringBuilder,System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass__ctor_mB05A6CC8015C5D545C639682454A524DE7E2EA97 ();
// 0x000000F4 System.Boolean System.Text.RegularExpressions.RegexCharClass::get_CanMerge()
extern void RegexCharClass_get_CanMerge_mC27A4CF83CFBEF3741A3DB4F99ABA6DE76B57837 ();
// 0x000000F5 System.Void System.Text.RegularExpressions.RegexCharClass::set_Negate(System.Boolean)
extern void RegexCharClass_set_Negate_mEB8659D83748A4DF28CDDFC3AC573A6504385E09 ();
// 0x000000F6 System.Void System.Text.RegularExpressions.RegexCharClass::AddChar(System.Char)
extern void RegexCharClass_AddChar_m4C4BFD42572978A9F98ADE75BE3811593957A9E3 ();
// 0x000000F7 System.Void System.Text.RegularExpressions.RegexCharClass::AddCharClass(System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass_AddCharClass_m0E5DD1105844AFB7CE45B5C801304B5C803FB5CA ();
// 0x000000F8 System.Void System.Text.RegularExpressions.RegexCharClass::AddSet(System.String)
extern void RegexCharClass_AddSet_mFFDE070E770BE967173D630AD50010C3397F7B97 ();
// 0x000000F9 System.Void System.Text.RegularExpressions.RegexCharClass::AddSubtraction(System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass_AddSubtraction_m17E538235B02A1435BD43D4FE4501DA67AA35145 ();
// 0x000000FA System.Void System.Text.RegularExpressions.RegexCharClass::AddRange(System.Char,System.Char)
extern void RegexCharClass_AddRange_mCFE9B670B3EBB13A5CDB694B1D1D6B1C0249D110 ();
// 0x000000FB System.Void System.Text.RegularExpressions.RegexCharClass::AddCategoryFromName(System.String,System.Boolean,System.Boolean,System.String)
extern void RegexCharClass_AddCategoryFromName_m9AD2D607E1E34A52CBC26FC38D468905C43A9202 ();
// 0x000000FC System.Void System.Text.RegularExpressions.RegexCharClass::AddCategory(System.String)
extern void RegexCharClass_AddCategory_m6A4625370DA8927DF5342275CB1F6155FC2BA255 ();
// 0x000000FD System.Void System.Text.RegularExpressions.RegexCharClass::AddLowercase(System.Globalization.CultureInfo)
extern void RegexCharClass_AddLowercase_m01C1B11EB0B82E065276C7ECF60725886F59A07A ();
// 0x000000FE System.Void System.Text.RegularExpressions.RegexCharClass::AddLowercaseRange(System.Char,System.Char,System.Globalization.CultureInfo)
extern void RegexCharClass_AddLowercaseRange_mCDDE9661C9C300DFEB51A8FE36E2F790E3E75D75 ();
// 0x000000FF System.Void System.Text.RegularExpressions.RegexCharClass::AddWord(System.Boolean,System.Boolean)
extern void RegexCharClass_AddWord_m1D2553B878162B32B0548536AE4C3EE673041CA0 ();
// 0x00000100 System.Void System.Text.RegularExpressions.RegexCharClass::AddSpace(System.Boolean,System.Boolean)
extern void RegexCharClass_AddSpace_mC6557749D96EBD114BCB133D14887A29304196D8 ();
// 0x00000101 System.Void System.Text.RegularExpressions.RegexCharClass::AddDigit(System.Boolean,System.Boolean,System.String)
extern void RegexCharClass_AddDigit_mC4DE43D884E575729BB2E575DA5552989368F6B3 ();
// 0x00000102 System.Char System.Text.RegularExpressions.RegexCharClass::SingletonChar(System.String)
extern void RegexCharClass_SingletonChar_m01C15732FAD399460FF5BB449B8177A77CAB1DB9 ();
// 0x00000103 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsMergeable(System.String)
extern void RegexCharClass_IsMergeable_mB9A0CD8306728BAFA5460C7FD748A2A7AD4BA448 ();
// 0x00000104 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsEmpty(System.String)
extern void RegexCharClass_IsEmpty_mAD6C63FE25C4CF3E52A20185418925D12C4C07CF ();
// 0x00000105 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSingleton(System.String)
extern void RegexCharClass_IsSingleton_m89D3E8460B0E7020DB0ABA607AC2F76FB9A34F1A ();
// 0x00000106 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSingletonInverse(System.String)
extern void RegexCharClass_IsSingletonInverse_m3E75D541C85AD842B9EB80705D6869EDB3F6928D ();
// 0x00000107 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSubtraction(System.String)
extern void RegexCharClass_IsSubtraction_m3C9EF97AFE7E4BCC24A2DF10834BF62279D7EE26 ();
// 0x00000108 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsNegated(System.String)
extern void RegexCharClass_IsNegated_m9CEDECE7EDA98ACD502E75783CA631A719DBC675 ();
// 0x00000109 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsECMAWordChar(System.Char)
extern void RegexCharClass_IsECMAWordChar_m6E7FC296DB816D89E3D6CF8672DCE6DFC519D741 ();
// 0x0000010A System.Boolean System.Text.RegularExpressions.RegexCharClass::IsWordChar(System.Char)
extern void RegexCharClass_IsWordChar_m2DF03D32DAB403138E397CB05F45D37BD50EB18C ();
// 0x0000010B System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClass(System.Char,System.String)
extern void RegexCharClass_CharInClass_m194AAA57BBBD30E78E70255D6F53FAFDB785EC0E ();
// 0x0000010C System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClassRecursive(System.Char,System.String,System.Int32)
extern void RegexCharClass_CharInClassRecursive_m5560DBADE1463FDEC38643C72CDF2FD5B3F69A5F ();
// 0x0000010D System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClassInternal(System.Char,System.String,System.Int32,System.Int32,System.Int32)
extern void RegexCharClass_CharInClassInternal_m5D1634F64092E4BD9EB6427447F952983211A760 ();
// 0x0000010E System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInCategory(System.Char,System.String,System.Int32,System.Int32,System.Int32)
extern void RegexCharClass_CharInCategory_mCDE20DF783F8D4E4403EC7F00F9C12E34D86C2DD ();
// 0x0000010F System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInCategoryGroup(System.Char,System.Globalization.UnicodeCategory,System.String,System.Int32&)
extern void RegexCharClass_CharInCategoryGroup_m28E498004F5EA6445C83F1B8EB4A776C210D30C5 ();
// 0x00000110 System.String System.Text.RegularExpressions.RegexCharClass::NegateCategory(System.String)
extern void RegexCharClass_NegateCategory_mF2E03FFFE79E427F39D9368013A334F5BD118E13 ();
// 0x00000111 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexCharClass::Parse(System.String)
extern void RegexCharClass_Parse_mBC3780FFF0DDFB62CA2085746618E6C256E8D86C ();
// 0x00000112 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexCharClass::ParseRecursive(System.String,System.Int32)
extern void RegexCharClass_ParseRecursive_mF7E7DD4EB594C9C30A60E72CD3CFD4EC1D822CF5 ();
// 0x00000113 System.Int32 System.Text.RegularExpressions.RegexCharClass::RangeCount()
extern void RegexCharClass_RangeCount_mEACBB4BD08CE18A9C4F0C433A7D6C5726F563E2E ();
// 0x00000114 System.String System.Text.RegularExpressions.RegexCharClass::ToStringClass()
extern void RegexCharClass_ToStringClass_m7A760D96732A03D46C4060064B3FC58349D2B4D5 ();
// 0x00000115 System.Text.RegularExpressions.RegexCharClass_SingleRange System.Text.RegularExpressions.RegexCharClass::GetRangeAt(System.Int32)
extern void RegexCharClass_GetRangeAt_mE563FF8072DD9B4E1179F55416CCD7FC4EB2C4FC ();
// 0x00000116 System.Void System.Text.RegularExpressions.RegexCharClass::Canonicalize()
extern void RegexCharClass_Canonicalize_m44EEFB16DB02E73C1E7280D15DAE98E50F4D6FA4 ();
// 0x00000117 System.String System.Text.RegularExpressions.RegexCharClass::SetFromProperty(System.String,System.Boolean,System.String)
extern void RegexCharClass_SetFromProperty_mA33170AF599765B5FDE8611BED646A850FB2330E ();
// 0x00000118 System.Void System.Text.RegularExpressions.RegexCharClass_LowerCaseMapping::.ctor(System.Char,System.Char,System.Int32,System.Int32)
extern void LowerCaseMapping__ctor_m881B66875631FF0DD253696FE56313A9E3F24187_AdjustorThunk ();
// 0x00000119 System.Int32 System.Text.RegularExpressions.RegexCharClass_SingleRangeComparer::Compare(System.Text.RegularExpressions.RegexCharClass_SingleRange,System.Text.RegularExpressions.RegexCharClass_SingleRange)
extern void SingleRangeComparer_Compare_mF2CAD555BAC4D9CBF6A8F90D829CB528BD7BCCC9 ();
// 0x0000011A System.Void System.Text.RegularExpressions.RegexCharClass_SingleRangeComparer::.ctor()
extern void SingleRangeComparer__ctor_m9E44BF07F0F0C9E565E0BA050C1A26F496226BAD ();
// 0x0000011B System.Void System.Text.RegularExpressions.RegexCharClass_SingleRange::.ctor(System.Char,System.Char)
extern void SingleRange__ctor_m4674722AFC97A111D2466AE2050C2E4E6E57303E ();
// 0x0000011C System.Void System.Text.RegularExpressions.RegexCode::.ctor(System.Int32[],System.Collections.Generic.List`1<System.String>,System.Int32,System.Collections.Hashtable,System.Int32,System.Text.RegularExpressions.RegexBoyerMoore,System.Text.RegularExpressions.RegexPrefix,System.Int32,System.Boolean)
extern void RegexCode__ctor_mBCB059D3E98AEA211794E89DDF99193231F298CA ();
// 0x0000011D System.Boolean System.Text.RegularExpressions.RegexCode::OpcodeBacktracks(System.Int32)
extern void RegexCode_OpcodeBacktracks_mDA23B91B55FE4991B168BF8E18F6DDDC7667B882 ();
// 0x0000011E System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexFCD::FirstChars(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_FirstChars_mC60DC5CA9A078998CB55594436AB9CBFD86478FB ();
// 0x0000011F System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexFCD::Prefix(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_Prefix_m50B30C508C6745832FD3A76B2169462455C1A28E ();
// 0x00000120 System.Int32 System.Text.RegularExpressions.RegexFCD::Anchors(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_Anchors_m562FA644F10503074714E0F58A2A00F9F727D75E ();
// 0x00000121 System.Int32 System.Text.RegularExpressions.RegexFCD::AnchorFromType(System.Int32)
extern void RegexFCD_AnchorFromType_m4B458E2C589633A43F9324C14F9192EF68F80A14 ();
// 0x00000122 System.Void System.Text.RegularExpressions.RegexFCD::.ctor()
extern void RegexFCD__ctor_mFC6A3309CAFA8C3C2B94094AD443738823388A3B ();
// 0x00000123 System.Void System.Text.RegularExpressions.RegexFCD::PushInt(System.Int32)
extern void RegexFCD_PushInt_m63817D3969DF7BD31B7C93D43EE45C4AF539868F ();
// 0x00000124 System.Boolean System.Text.RegularExpressions.RegexFCD::IntIsEmpty()
extern void RegexFCD_IntIsEmpty_mE825A8A0DF9D5BA6618357ABBA93421D4099AAEB ();
// 0x00000125 System.Int32 System.Text.RegularExpressions.RegexFCD::PopInt()
extern void RegexFCD_PopInt_m1E4B64F2F6DDBCB7495E673540CF25FDD4D01B7E ();
// 0x00000126 System.Void System.Text.RegularExpressions.RegexFCD::PushFC(System.Text.RegularExpressions.RegexFC)
extern void RegexFCD_PushFC_mBE154E351E7C49FFFC26E603B4672136D91479C7 ();
// 0x00000127 System.Boolean System.Text.RegularExpressions.RegexFCD::FCIsEmpty()
extern void RegexFCD_FCIsEmpty_m57FDE5D4E352620B7773AD54B286531CA21FCDAD ();
// 0x00000128 System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::PopFC()
extern void RegexFCD_PopFC_m987A35E9ADF69335799EDEEB12C2CD3A3F40FB6E ();
// 0x00000129 System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::TopFC()
extern void RegexFCD_TopFC_m26ED21621830CF30FDA46AE8D7F3AC9F50DE416F ();
// 0x0000012A System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::RegexFCFromRegexTree(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_RegexFCFromRegexTree_mA85E74765529D05113116C73EC397E832D81D0BC ();
// 0x0000012B System.Void System.Text.RegularExpressions.RegexFCD::SkipChild()
extern void RegexFCD_SkipChild_m661F5D339305B97A37D855240A0B9AF500FE03F6 ();
// 0x0000012C System.Void System.Text.RegularExpressions.RegexFCD::CalculateFC(System.Int32,System.Text.RegularExpressions.RegexNode,System.Int32)
extern void RegexFCD_CalculateFC_m2267FAA6BCA80275E21DC9A0BAF90BBC85204BD8 ();
// 0x0000012D System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.Boolean)
extern void RegexFC__ctor_m354E8197215F3EE9097B69E783B744365A38EF20 ();
// 0x0000012E System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.Char,System.Boolean,System.Boolean,System.Boolean)
extern void RegexFC__ctor_m023D08ED0365AE9AAC539333B4390A8052C59229 ();
// 0x0000012F System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.String,System.Boolean,System.Boolean)
extern void RegexFC__ctor_mDCBBCCC1BB476741943D7F9AD88731B1DCA0C1B5 ();
// 0x00000130 System.Boolean System.Text.RegularExpressions.RegexFC::AddFC(System.Text.RegularExpressions.RegexFC,System.Boolean)
extern void RegexFC_AddFC_m5B05CD1D7700817843366EC1DF728977EDD4D11E ();
// 0x00000131 System.String System.Text.RegularExpressions.RegexFC::GetFirstChars(System.Globalization.CultureInfo)
extern void RegexFC_GetFirstChars_m7252E826F9A5BC1842A5A255BAC5A36EE8DADAF5 ();
// 0x00000132 System.Boolean System.Text.RegularExpressions.RegexFC::IsCaseInsensitive()
extern void RegexFC_IsCaseInsensitive_mD87B0C49AAEBB61215F09A9C5ABF8CCB8B5AB64E ();
// 0x00000133 System.Void System.Text.RegularExpressions.RegexPrefix::.ctor(System.String,System.Boolean)
extern void RegexPrefix__ctor_m93489A4FF55425A15BF5390E77EE0B84F6F9364C ();
// 0x00000134 System.String System.Text.RegularExpressions.RegexPrefix::get_Prefix()
extern void RegexPrefix_get_Prefix_m7137EC6CA5B857F49946E2EAEA19784040D430CF ();
// 0x00000135 System.Boolean System.Text.RegularExpressions.RegexPrefix::get_CaseInsensitive()
extern void RegexPrefix_get_CaseInsensitive_m76E04480FA9FFAE4C5031CA12F4AE9A2576212C0 ();
// 0x00000136 System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexPrefix::get_Empty()
extern void RegexPrefix_get_Empty_mAD10DECDBC7C51F9ACF5C02E3191874252DF9B8B ();
// 0x00000137 System.Void System.Text.RegularExpressions.RegexPrefix::.cctor()
extern void RegexPrefix__cctor_mCDCE7EDB98AFB119EE0281D37F7BC019AD28773D ();
// 0x00000138 System.Void System.Text.RegularExpressions.Group::.ctor(System.String,System.Int32[],System.Int32,System.String)
extern void Group__ctor_mECF4574592517D363C35ADC07F9D6F7E7DE6B4F6 ();
// 0x00000139 System.Boolean System.Text.RegularExpressions.Group::get_Success()
extern void Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521 ();
// 0x0000013A System.Void System.Text.RegularExpressions.Group::.cctor()
extern void Group__cctor_m213E26F039439904671CFD5DAF5D85B47D5CBE68 ();
// 0x0000013B System.Void System.Text.RegularExpressions.Group::.ctor()
extern void Group__ctor_mDCB3D51B8A672B342F452177D42D6D3F2F9BA91A ();
// 0x0000013C System.Void System.Text.RegularExpressions.RegexInterpreter::.ctor(System.Text.RegularExpressions.RegexCode,System.Globalization.CultureInfo)
extern void RegexInterpreter__ctor_m7B9BA594CF5F338B2E257EDADC2481826BF4C6BB ();
// 0x0000013D System.Void System.Text.RegularExpressions.RegexInterpreter::InitTrackCount()
extern void RegexInterpreter_InitTrackCount_mD93771C3D75617898528698E29AD09B7EA5EE24B ();
// 0x0000013E System.Void System.Text.RegularExpressions.RegexInterpreter::Advance()
extern void RegexInterpreter_Advance_mCD1A51680CD0318DDF6D104DE8C722FCCC468CCA ();
// 0x0000013F System.Void System.Text.RegularExpressions.RegexInterpreter::Advance(System.Int32)
extern void RegexInterpreter_Advance_m779870D7E1FA3580492E2E8B75E2805613525AF7 ();
// 0x00000140 System.Void System.Text.RegularExpressions.RegexInterpreter::Goto(System.Int32)
extern void RegexInterpreter_Goto_m438DE9CE790DF0757383C91126DEA68C6B0DADFE ();
// 0x00000141 System.Void System.Text.RegularExpressions.RegexInterpreter::Textto(System.Int32)
extern void RegexInterpreter_Textto_m6CE60A7C8FA9F9CEECD26BD6025F055EB64887AA ();
// 0x00000142 System.Void System.Text.RegularExpressions.RegexInterpreter::Trackto(System.Int32)
extern void RegexInterpreter_Trackto_m0C7B05A7385BE3F9BB096FE28DC22942A9F96783 ();
// 0x00000143 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Textstart()
extern void RegexInterpreter_Textstart_mE71CFC006954F38B9EB6CD85BCC0867E63BF0894 ();
// 0x00000144 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Textpos()
extern void RegexInterpreter_Textpos_mC66F0DE729E76EDA0BEEA7B1ABEE369BA6C81D5B ();
// 0x00000145 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Trackpos()
extern void RegexInterpreter_Trackpos_m472ADA4F5E1D07E71896E42714DFB723CB016842 ();
// 0x00000146 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush()
extern void RegexInterpreter_TrackPush_m5A8B9F863211AAEC7E5FAD14ECDDAFDE3059210D ();
// 0x00000147 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32)
extern void RegexInterpreter_TrackPush_mB2AF47E651D2A3853A719EFB908C30D27EC2FF5F ();
// 0x00000148 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush_m3EA36B28D636D1C617F85CEA57650344B562A38F ();
// 0x00000149 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32,System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush_mBCAADB1DF177D91DC9AA4518DCDB3AAF7D6C0E15 ();
// 0x0000014A System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush2(System.Int32)
extern void RegexInterpreter_TrackPush2_m4EBCF8B183717311AEE3FAA6AD6FAF1F08B14F77 ();
// 0x0000014B System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush2(System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush2_mD591F73FDDF69084636E0834BCCD530B057898FF ();
// 0x0000014C System.Void System.Text.RegularExpressions.RegexInterpreter::Backtrack()
extern void RegexInterpreter_Backtrack_m46612DE84F898D1656DE30F3BA86E93209E279E1 ();
// 0x0000014D System.Void System.Text.RegularExpressions.RegexInterpreter::SetOperator(System.Int32)
extern void RegexInterpreter_SetOperator_m5B633C33EE4CD85364E7C60003ACE8EA93FDAC91 ();
// 0x0000014E System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPop()
extern void RegexInterpreter_TrackPop_m84B55BE8F346693942045E937174EC8C1AE91F08 ();
// 0x0000014F System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPop(System.Int32)
extern void RegexInterpreter_TrackPop_m73AB2E002DB92E231B62510861277320F76BEEED ();
// 0x00000150 System.Int32 System.Text.RegularExpressions.RegexInterpreter::TrackPeek()
extern void RegexInterpreter_TrackPeek_m4EF7918CC0F10FFF7E73C1C9D13E74D1D8D13318 ();
// 0x00000151 System.Int32 System.Text.RegularExpressions.RegexInterpreter::TrackPeek(System.Int32)
extern void RegexInterpreter_TrackPeek_mEECF3E94E7823A68474C691F695D71087729553C ();
// 0x00000152 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPush(System.Int32)
extern void RegexInterpreter_StackPush_mC28C3F8B3C811C4DCA6CD312F7F487206C871E55 ();
// 0x00000153 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPush(System.Int32,System.Int32)
extern void RegexInterpreter_StackPush_m911FF20379BF912884E7F98BB59CFB6C51AA1861 ();
// 0x00000154 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPop()
extern void RegexInterpreter_StackPop_mD057CA7B190ED8FBD33C6CE48E1F28E4B09FC4F2 ();
// 0x00000155 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPop(System.Int32)
extern void RegexInterpreter_StackPop_m90FC35FD76D9B63851ECFD641DAA08B1B58C7B91 ();
// 0x00000156 System.Int32 System.Text.RegularExpressions.RegexInterpreter::StackPeek()
extern void RegexInterpreter_StackPeek_m08C28311048F6B075379EE46B924FC211BA48EC6 ();
// 0x00000157 System.Int32 System.Text.RegularExpressions.RegexInterpreter::StackPeek(System.Int32)
extern void RegexInterpreter_StackPeek_m308DE22A8E1AF524319E7F1D5A94DBFEC37700ED ();
// 0x00000158 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Operator()
extern void RegexInterpreter_Operator_m4DE2EAA1744D15294F2767D5217F753FE74FAC0B ();
// 0x00000159 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Operand(System.Int32)
extern void RegexInterpreter_Operand_m1ACB9C398C9C7ADF8DA58824877B99F08F181526 ();
// 0x0000015A System.Int32 System.Text.RegularExpressions.RegexInterpreter::Leftchars()
extern void RegexInterpreter_Leftchars_m3A200CD41FFE8C89CCB85B3CC7A367E32C5988D1 ();
// 0x0000015B System.Int32 System.Text.RegularExpressions.RegexInterpreter::Rightchars()
extern void RegexInterpreter_Rightchars_m3DB37A53D6C3DC3311C9EA020690CC0824959D30 ();
// 0x0000015C System.Int32 System.Text.RegularExpressions.RegexInterpreter::Bump()
extern void RegexInterpreter_Bump_mC33CB8A0CC0DF1C69F11115BD225D2D8B63F8753 ();
// 0x0000015D System.Int32 System.Text.RegularExpressions.RegexInterpreter::Forwardchars()
extern void RegexInterpreter_Forwardchars_mE5E437E285604CDC60551C112F7B2CEF7297F4ED ();
// 0x0000015E System.Char System.Text.RegularExpressions.RegexInterpreter::Forwardcharnext()
extern void RegexInterpreter_Forwardcharnext_mD2C6694CC31BC75D3E20C511D1004D28AAE1390F ();
// 0x0000015F System.Boolean System.Text.RegularExpressions.RegexInterpreter::Stringmatch(System.String)
extern void RegexInterpreter_Stringmatch_m543BC6834400A925D2603AE6FBB47944694AFDF1 ();
// 0x00000160 System.Boolean System.Text.RegularExpressions.RegexInterpreter::Refmatch(System.Int32,System.Int32)
extern void RegexInterpreter_Refmatch_m52369ADBF64E25A9EEEBE216939454EBB8D8E138 ();
// 0x00000161 System.Void System.Text.RegularExpressions.RegexInterpreter::Backwardnext()
extern void RegexInterpreter_Backwardnext_mD10CE2A9E229D0655EF01565DB39C902654D00CD ();
// 0x00000162 System.Char System.Text.RegularExpressions.RegexInterpreter::CharAt(System.Int32)
extern void RegexInterpreter_CharAt_mAE2AF6D293F53C2D8961C2D0C145BC3ADF6EC105 ();
// 0x00000163 System.Boolean System.Text.RegularExpressions.RegexInterpreter::FindFirstChar()
extern void RegexInterpreter_FindFirstChar_m95CDB0ECB99F7850479D951A5F32BB6B19B91F44 ();
// 0x00000164 System.Void System.Text.RegularExpressions.RegexInterpreter::Go()
extern void RegexInterpreter_Go_mBE9DEAECBD68F60DDFE2BB5A8C24CF92A1FB503A ();
// 0x00000165 System.Text.RegularExpressions.Match System.Text.RegularExpressions.Match::get_Empty()
extern void Match_get_Empty_m5D3AE3D0580F06ED901EE69FCCED6AF44715528F ();
// 0x00000166 System.Void System.Text.RegularExpressions.Match::.ctor(System.Text.RegularExpressions.Regex,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void Match__ctor_m08A8262ACD89C9E47AA7168D0F2CC6E3338855D7 ();
// 0x00000167 System.Void System.Text.RegularExpressions.Match::Reset(System.Text.RegularExpressions.Regex,System.String,System.Int32,System.Int32,System.Int32)
extern void Match_Reset_m9EDCC3689E8A5A57A644946AEC3E41C1901C7DAF ();
// 0x00000168 System.Void System.Text.RegularExpressions.Match::AddMatch(System.Int32,System.Int32,System.Int32)
extern void Match_AddMatch_m3C9178A7D6F8175A7628E4BE579FD209B7C7650A ();
// 0x00000169 System.Void System.Text.RegularExpressions.Match::BalanceMatch(System.Int32)
extern void Match_BalanceMatch_mCC0EC358E4C33191B896226512FE8F086EFEA4CF ();
// 0x0000016A System.Void System.Text.RegularExpressions.Match::RemoveMatch(System.Int32)
extern void Match_RemoveMatch_m6268C01D537F0BACB7DD707E11FA873C3E1918C7 ();
// 0x0000016B System.Boolean System.Text.RegularExpressions.Match::IsMatched(System.Int32)
extern void Match_IsMatched_m7686CA418F588EC198A82DE287326C46F4CBDD5F ();
// 0x0000016C System.Int32 System.Text.RegularExpressions.Match::MatchIndex(System.Int32)
extern void Match_MatchIndex_mA39CA9F84C3872675CB9C76EC342EFB30A2B5DA0 ();
// 0x0000016D System.Int32 System.Text.RegularExpressions.Match::MatchLength(System.Int32)
extern void Match_MatchLength_m25492EACF56E8211FEEC4856F93D7A19D30A984F ();
// 0x0000016E System.Void System.Text.RegularExpressions.Match::Tidy(System.Int32)
extern void Match_Tidy_m88B2494631267F8CF7E90F3305F713550ED39CE8 ();
// 0x0000016F System.Void System.Text.RegularExpressions.Match::.cctor()
extern void Match__cctor_m9158A9D469720E89CD9004B65F55EEEF5E330C0E ();
// 0x00000170 System.Void System.Text.RegularExpressions.Match::.ctor()
extern void Match__ctor_m38BC8AD7EEFA99C6FC25587D6FE56450FA849E0C ();
// 0x00000171 System.Void System.Text.RegularExpressions.MatchSparse::.ctor(System.Text.RegularExpressions.Regex,System.Collections.Hashtable,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void MatchSparse__ctor_mEA523FCAF96D8A81401D3ED010CACE4463CCE811 ();
// 0x00000172 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor(System.String,System.String,System.TimeSpan)
extern void RegexMatchTimeoutException__ctor_mCCDB413A8F68D924B276B8FED2744E81BE4C89AF ();
// 0x00000173 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor()
extern void RegexMatchTimeoutException__ctor_m4EFD030442FEEC81E59AB8CDF35D603A5D551058 ();
// 0x00000174 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void RegexMatchTimeoutException__ctor_m554FE8CFA7F42483517F11948A61E4D3C9F44D07 ();
// 0x00000175 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void RegexMatchTimeoutException_System_Runtime_Serialization_ISerializable_GetObjectData_m78FACBA38C002E195A507A32CDAB768D8DBC93E7 ();
// 0x00000176 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::Init()
extern void RegexMatchTimeoutException_Init_m09AF601CC7369F2D7E1300B166517FE7D20EB6F1 ();
// 0x00000177 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::Init(System.String,System.String,System.TimeSpan)
extern void RegexMatchTimeoutException_Init_m0F165C7170A46724458C06DA5EC05536D8CB95B7 ();
// 0x00000178 System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions)
extern void RegexNode__ctor_m29676E9646F598C827F25E906EEB6EA14A6FD5DB ();
// 0x00000179 System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Char)
extern void RegexNode__ctor_m92FB70D6C28D7E021A2A1ACBAD583461AB014F11 ();
// 0x0000017A System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.String)
extern void RegexNode__ctor_m89ACB97FB7FE8B38C0D69F0F2445A7916BC67D85 ();
// 0x0000017B System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Int32)
extern void RegexNode__ctor_mAE76BA90AA85F205CB0CC6799F06D1AD85A49F64 ();
// 0x0000017C System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Int32,System.Int32)
extern void RegexNode__ctor_m0EFEB707603B3C667626117E09A7EED58BBEC6D4 ();
// 0x0000017D System.Boolean System.Text.RegularExpressions.RegexNode::UseOptionR()
extern void RegexNode_UseOptionR_mB931929BBD1D89F8B263AA846C1665775096713E ();
// 0x0000017E System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReverseLeft()
extern void RegexNode_ReverseLeft_m994638E4886D007B9B29BC23EA3C8D76A92099FD ();
// 0x0000017F System.Void System.Text.RegularExpressions.RegexNode::MakeRep(System.Int32,System.Int32,System.Int32)
extern void RegexNode_MakeRep_mC310B028FBE3BD5EB80F83E4E05B891ADEE45C22 ();
// 0x00000180 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::Reduce()
extern void RegexNode_Reduce_mE9E22C30C296E328ABC7EDC9C52F18059FAE27C1 ();
// 0x00000181 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::StripEnation(System.Int32)
extern void RegexNode_StripEnation_mE19E0A57BCE0D0BF47F51A5103C08FCC7BB9E24F ();
// 0x00000182 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceGroup()
extern void RegexNode_ReduceGroup_m069FA93D4F88006F18473E647069B349683B9204 ();
// 0x00000183 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceRep()
extern void RegexNode_ReduceRep_m726F03D9E2420F276A37777942B66D15CA73F77E ();
// 0x00000184 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceSet()
extern void RegexNode_ReduceSet_m912F4A0DFF694EB14DE520599369A811C2E9D10D ();
// 0x00000185 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceAlternation()
extern void RegexNode_ReduceAlternation_m60EECC172A975620A5118D14D6ECF8B846ECED9F ();
// 0x00000186 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceConcatenation()
extern void RegexNode_ReduceConcatenation_m4BE1B6DBBC0F4BAB9A3873414B5EE77D825AD53B ();
// 0x00000187 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::MakeQuantifier(System.Boolean,System.Int32,System.Int32)
extern void RegexNode_MakeQuantifier_m1332537AA6BCCCD68A3E59EA7994CCFE69A19444 ();
// 0x00000188 System.Void System.Text.RegularExpressions.RegexNode::AddChild(System.Text.RegularExpressions.RegexNode)
extern void RegexNode_AddChild_m734A86A25E6074316FAC566F7D127253F7B71703 ();
// 0x00000189 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::Child(System.Int32)
extern void RegexNode_Child_m5AA4FFDDCCFA22FE70BA0F236F19A963AEF72079 ();
// 0x0000018A System.Int32 System.Text.RegularExpressions.RegexNode::ChildCount()
extern void RegexNode_ChildCount_m23B6965575DB0DBC1D90212820DEA144FCB06996 ();
// 0x0000018B System.Int32 System.Text.RegularExpressions.RegexNode::Type()
extern void RegexNode_Type_mFA1C2F11F3487BB1BCBA7F58FFB7975EC18E9CD4 ();
// 0x0000018C System.Text.RegularExpressions.RegexTree System.Text.RegularExpressions.RegexParser::Parse(System.String,System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_Parse_mD206BB554B6087ED35C5F744D72A93A07721D789 ();
// 0x0000018D System.String System.Text.RegularExpressions.RegexParser::Unescape(System.String)
extern void RegexParser_Unescape_m3BC9183007057FF7601C5E617F8238A07C0ED433 ();
// 0x0000018E System.Void System.Text.RegularExpressions.RegexParser::.ctor(System.Globalization.CultureInfo)
extern void RegexParser__ctor_mC69D13B4FC323EE77392251139C5F2C456171310 ();
// 0x0000018F System.Void System.Text.RegularExpressions.RegexParser::SetPattern(System.String)
extern void RegexParser_SetPattern_m4B385D83A9680A1B2707EBCA8659B6E12EDD5E46 ();
// 0x00000190 System.Void System.Text.RegularExpressions.RegexParser::Reset(System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_Reset_mEC49D1DCEBC555768D2FB90DA42374F1C547E328 ();
// 0x00000191 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanRegex()
extern void RegexParser_ScanRegex_m62049A6C66D6D8CDD795B9C740283D1EC85126DB ();
// 0x00000192 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexParser::ScanCharClass(System.Boolean)
extern void RegexParser_ScanCharClass_mF775DA8BFD214C64BC3D91E07436543717976DC4 ();
// 0x00000193 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexParser::ScanCharClass(System.Boolean,System.Boolean)
extern void RegexParser_ScanCharClass_mFE669B1C9CB6652157D9E8DAEE5B924C581AE81F ();
// 0x00000194 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanGroupOpen()
extern void RegexParser_ScanGroupOpen_mA4918ACA08C7E4C945197BBE4EF734AF5B35096C ();
// 0x00000195 System.Void System.Text.RegularExpressions.RegexParser::ScanBlank()
extern void RegexParser_ScanBlank_m99BA3097E182DE425BE0137BAFDD0218F0DF360D ();
// 0x00000196 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanBackslash()
extern void RegexParser_ScanBackslash_m45E9E0ABDB7DF70F58850B48905DE9DE026EA64C ();
// 0x00000197 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanBasicBackslash()
extern void RegexParser_ScanBasicBackslash_m5F438E56ACBE272622D39D4208B2D5ED536DD7B8 ();
// 0x00000198 System.String System.Text.RegularExpressions.RegexParser::ScanCapname()
extern void RegexParser_ScanCapname_m1D4DB4E5DA312CBCA841391F729CC626DC657D85 ();
// 0x00000199 System.Char System.Text.RegularExpressions.RegexParser::ScanOctal()
extern void RegexParser_ScanOctal_mCF3925D06CBBA1DD0CB60199F59991D099430C3A ();
// 0x0000019A System.Int32 System.Text.RegularExpressions.RegexParser::ScanDecimal()
extern void RegexParser_ScanDecimal_mE966D2C7F357215A52F88120F40A37707C1AB33A ();
// 0x0000019B System.Char System.Text.RegularExpressions.RegexParser::ScanHex(System.Int32)
extern void RegexParser_ScanHex_m296FC19218F8186D2C1B630DF9F138CFB195625E ();
// 0x0000019C System.Int32 System.Text.RegularExpressions.RegexParser::HexDigit(System.Char)
extern void RegexParser_HexDigit_m4BAEE94B2077B96A4B1D56C459EFB2B1938E1174 ();
// 0x0000019D System.Char System.Text.RegularExpressions.RegexParser::ScanControl()
extern void RegexParser_ScanControl_m244F59DA2B0711D154B7D68CCB5765390C65B5B8 ();
// 0x0000019E System.Boolean System.Text.RegularExpressions.RegexParser::IsOnlyTopOption(System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_IsOnlyTopOption_m66FE256A81BBD173C96B90EE9EBE9721F9ED16A1 ();
// 0x0000019F System.Void System.Text.RegularExpressions.RegexParser::ScanOptions()
extern void RegexParser_ScanOptions_m5CD283C15179190846762B90F78F0A87E7495537 ();
// 0x000001A0 System.Char System.Text.RegularExpressions.RegexParser::ScanCharEscape()
extern void RegexParser_ScanCharEscape_mF8821EE73F3F8A5D4267642F6E4F0A666FA5E7A6 ();
// 0x000001A1 System.String System.Text.RegularExpressions.RegexParser::ParseProperty()
extern void RegexParser_ParseProperty_m69C638E755F0A5C1A2BC8E08827E6124889C2CEF ();
// 0x000001A2 System.Int32 System.Text.RegularExpressions.RegexParser::TypeFromCode(System.Char)
extern void RegexParser_TypeFromCode_m0969E0D233AC767039B0A333901F47A22BABE0E8 ();
// 0x000001A3 System.Text.RegularExpressions.RegexOptions System.Text.RegularExpressions.RegexParser::OptionFromCode(System.Char)
extern void RegexParser_OptionFromCode_m6BCD10574DF5E08599B5F7FC8E947E3DC69EE151 ();
// 0x000001A4 System.Void System.Text.RegularExpressions.RegexParser::CountCaptures()
extern void RegexParser_CountCaptures_m5255DE4B24B8D9BA7B2A2A7A1FD79A67B36F4634 ();
// 0x000001A5 System.Void System.Text.RegularExpressions.RegexParser::NoteCaptureSlot(System.Int32,System.Int32)
extern void RegexParser_NoteCaptureSlot_m8B2D20B819C86E427837C879CCA72B9BCD1C4AA8 ();
// 0x000001A6 System.Void System.Text.RegularExpressions.RegexParser::NoteCaptureName(System.String,System.Int32)
extern void RegexParser_NoteCaptureName_m96A5301077C4C6554E993A2266EA40B690F455C4 ();
// 0x000001A7 System.Void System.Text.RegularExpressions.RegexParser::AssignNameSlots()
extern void RegexParser_AssignNameSlots_m168605CD3A6D6AAA52AFFDB13BE3D5DFAC3FE94B ();
// 0x000001A8 System.Int32 System.Text.RegularExpressions.RegexParser::CaptureSlotFromName(System.String)
extern void RegexParser_CaptureSlotFromName_mE3FD1D57EB29D4C7A0E4029E4D4785297798EE43 ();
// 0x000001A9 System.Boolean System.Text.RegularExpressions.RegexParser::IsCaptureSlot(System.Int32)
extern void RegexParser_IsCaptureSlot_m80540BE449D9B98B2B159CD5169F7AA6DB63CB80 ();
// 0x000001AA System.Boolean System.Text.RegularExpressions.RegexParser::IsCaptureName(System.String)
extern void RegexParser_IsCaptureName_mBFB85B16ED80CA59452491B4C3278C77ADCA1FDF ();
// 0x000001AB System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionN()
extern void RegexParser_UseOptionN_mE9C62585222B2D99D295708E4486C952973F35D5 ();
// 0x000001AC System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionI()
extern void RegexParser_UseOptionI_mFA3B59BD8A6F61626E20F8FE909A23289E694263 ();
// 0x000001AD System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionM()
extern void RegexParser_UseOptionM_mDE945B2DE782D12A5013D408F4FFBCABEC48C63D ();
// 0x000001AE System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionS()
extern void RegexParser_UseOptionS_mE96EEA754E1EEEF658AAF73885D048342D1D200E ();
// 0x000001AF System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionX()
extern void RegexParser_UseOptionX_mD63DEED6741AEA0B3F6CC4239712A4B2EF690810 ();
// 0x000001B0 System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionE()
extern void RegexParser_UseOptionE_mC171EEF863E091591BAD771F16B72D742F044096 ();
// 0x000001B1 System.Boolean System.Text.RegularExpressions.RegexParser::IsSpecial(System.Char)
extern void RegexParser_IsSpecial_mFF68456E944ACAF048B4F96F5758FFDD1D5E7DCD ();
// 0x000001B2 System.Boolean System.Text.RegularExpressions.RegexParser::IsStopperX(System.Char)
extern void RegexParser_IsStopperX_m0BCF2DB4B0E1324C9109C8BFD486FC5DBA8DC646 ();
// 0x000001B3 System.Boolean System.Text.RegularExpressions.RegexParser::IsQuantifier(System.Char)
extern void RegexParser_IsQuantifier_mE0620E30A63AD0C0DB9550A52A4A7D0BB4BC3A31 ();
// 0x000001B4 System.Boolean System.Text.RegularExpressions.RegexParser::IsTrueQuantifier()
extern void RegexParser_IsTrueQuantifier_m4AA95A9CE7CD78600E8D525ECA5A095984FBC63F ();
// 0x000001B5 System.Boolean System.Text.RegularExpressions.RegexParser::IsSpace(System.Char)
extern void RegexParser_IsSpace_m1E41FA7DD1FB93BF9220530CA91B35EF08879F30 ();
// 0x000001B6 System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate(System.Int32,System.Int32,System.Boolean)
extern void RegexParser_AddConcatenate_m3743C87DFCD1784A949BFDCE9443845CCD630A5D ();
// 0x000001B7 System.Void System.Text.RegularExpressions.RegexParser::PushGroup()
extern void RegexParser_PushGroup_m6F4246ECA3A6F29DA096C3B41D97652427E3175E ();
// 0x000001B8 System.Void System.Text.RegularExpressions.RegexParser::PopGroup()
extern void RegexParser_PopGroup_m43AB1FB84E11D8DFF6C5D38B9CAD324E5425DD74 ();
// 0x000001B9 System.Boolean System.Text.RegularExpressions.RegexParser::EmptyStack()
extern void RegexParser_EmptyStack_mB65B33DCF98A5967407B7C6A07F8799681202BE5 ();
// 0x000001BA System.Void System.Text.RegularExpressions.RegexParser::StartGroup(System.Text.RegularExpressions.RegexNode)
extern void RegexParser_StartGroup_m36A6C0ED245D844CD2E630160994C3F2D7CCA994 ();
// 0x000001BB System.Void System.Text.RegularExpressions.RegexParser::AddAlternate()
extern void RegexParser_AddAlternate_mDBDEEF8180738DE0D31CC05B0E223EFF0D66939B ();
// 0x000001BC System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate()
extern void RegexParser_AddConcatenate_mF80F14978ED6626A8F8E5F37AEB3B946A01192C1 ();
// 0x000001BD System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate(System.Boolean,System.Int32,System.Int32)
extern void RegexParser_AddConcatenate_m81CC39ED404E571347F0E97650F3BEB14639B1B0 ();
// 0x000001BE System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::Unit()
extern void RegexParser_Unit_mEAEEAC39DBE372DC762644F49E6E163CA37EA34E ();
// 0x000001BF System.Void System.Text.RegularExpressions.RegexParser::AddUnitOne(System.Char)
extern void RegexParser_AddUnitOne_m72DFA82092408E9C63544126093D98390E0C2145 ();
// 0x000001C0 System.Void System.Text.RegularExpressions.RegexParser::AddUnitNotone(System.Char)
extern void RegexParser_AddUnitNotone_mAA142A94BB7B6A358BA36A3920DB139382889749 ();
// 0x000001C1 System.Void System.Text.RegularExpressions.RegexParser::AddUnitSet(System.String)
extern void RegexParser_AddUnitSet_m024168548909EA2DF649E6194D60135312ADF5B3 ();
// 0x000001C2 System.Void System.Text.RegularExpressions.RegexParser::AddUnitNode(System.Text.RegularExpressions.RegexNode)
extern void RegexParser_AddUnitNode_m6EE11A898128A169E41A5C7B38B1F3DD314FB304 ();
// 0x000001C3 System.Void System.Text.RegularExpressions.RegexParser::AddUnitType(System.Int32)
extern void RegexParser_AddUnitType_m1ECB4025CA3B580F051CF6891D9C96922CA2FA7A ();
// 0x000001C4 System.Void System.Text.RegularExpressions.RegexParser::AddGroup()
extern void RegexParser_AddGroup_m54BBB919E4D4AD05EFECBC3ECBE46FC4A90569EA ();
// 0x000001C5 System.Void System.Text.RegularExpressions.RegexParser::PushOptions()
extern void RegexParser_PushOptions_m2034533961B704CBFA0F97BD4A54CB7269F0D88A ();
// 0x000001C6 System.Void System.Text.RegularExpressions.RegexParser::PopOptions()
extern void RegexParser_PopOptions_mA18691037302741375A44BD8BDC9387DFB07B676 ();
// 0x000001C7 System.Boolean System.Text.RegularExpressions.RegexParser::EmptyOptionsStack()
extern void RegexParser_EmptyOptionsStack_m5FCB7AF81ACB5C91A73231C9F0AA0DFB32067A45 ();
// 0x000001C8 System.Void System.Text.RegularExpressions.RegexParser::PopKeepOptions()
extern void RegexParser_PopKeepOptions_m8ACBCD324BAF7269F90AEB3CF901B666524658FA ();
// 0x000001C9 System.ArgumentException System.Text.RegularExpressions.RegexParser::MakeException(System.String)
extern void RegexParser_MakeException_m6D521D75808E2CD4255A68DC3456EAF2A88F2874 ();
// 0x000001CA System.Int32 System.Text.RegularExpressions.RegexParser::Textpos()
extern void RegexParser_Textpos_m36658DED82367E05DF4333E68A666FEEBC3DAC07 ();
// 0x000001CB System.Void System.Text.RegularExpressions.RegexParser::Textto(System.Int32)
extern void RegexParser_Textto_m5C8BAB13E35429238EA9A5F13D5A5A580D0DD3AC ();
// 0x000001CC System.Char System.Text.RegularExpressions.RegexParser::MoveRightGetChar()
extern void RegexParser_MoveRightGetChar_m3CF088DE129BADB346CCEEF1D547E2D260BC894A ();
// 0x000001CD System.Void System.Text.RegularExpressions.RegexParser::MoveRight()
extern void RegexParser_MoveRight_m6F0A1C10AE9EA183F04A9E06B62B2B53648688AC ();
// 0x000001CE System.Void System.Text.RegularExpressions.RegexParser::MoveRight(System.Int32)
extern void RegexParser_MoveRight_m7D1D27C901CAB81BCF60803E22FBDF2DEEC6CC51 ();
// 0x000001CF System.Void System.Text.RegularExpressions.RegexParser::MoveLeft()
extern void RegexParser_MoveLeft_m1BC035A4EA49F4168093B2AB0EEAB2653CB04033 ();
// 0x000001D0 System.Char System.Text.RegularExpressions.RegexParser::CharAt(System.Int32)
extern void RegexParser_CharAt_m08DBAE0DFD788548F74E061031B7221154F96A77 ();
// 0x000001D1 System.Char System.Text.RegularExpressions.RegexParser::RightChar()
extern void RegexParser_RightChar_m9E231199A8E5EA994AA1746FC5E977AF3823FDEB ();
// 0x000001D2 System.Char System.Text.RegularExpressions.RegexParser::RightChar(System.Int32)
extern void RegexParser_RightChar_m246E9E1F8D0A4A8E485C23E233CD3915C23739D8 ();
// 0x000001D3 System.Int32 System.Text.RegularExpressions.RegexParser::CharsRight()
extern void RegexParser_CharsRight_m318662CFE3223C3FA5E921D376409B4E1B28F9B4 ();
// 0x000001D4 System.Void System.Text.RegularExpressions.RegexParser::.cctor()
extern void RegexParser__cctor_mF468AF3C5916BA72C579CBD41A73D2DAD004F0EE ();
// 0x000001D5 System.Void System.Text.RegularExpressions.RegexRunner::.ctor()
extern void RegexRunner__ctor_mC04D94995556E71E813F8420C8A4EC0B66404550 ();
// 0x000001D6 System.Text.RegularExpressions.Match System.Text.RegularExpressions.RegexRunner::Scan(System.Text.RegularExpressions.Regex,System.String,System.Int32,System.Int32,System.Int32,System.Int32,System.Boolean,System.TimeSpan)
extern void RegexRunner_Scan_m1C3B1B034601773D510A4D2DEC337635A540BE31 ();
// 0x000001D7 System.Void System.Text.RegularExpressions.RegexRunner::StartTimeoutWatch()
extern void RegexRunner_StartTimeoutWatch_m257FBE0C72761082A11D275954C6A1343EB13301 ();
// 0x000001D8 System.Void System.Text.RegularExpressions.RegexRunner::CheckTimeout()
extern void RegexRunner_CheckTimeout_m52486A9CE7B6EA4C83BB60FB200196AF0EE5687B ();
// 0x000001D9 System.Void System.Text.RegularExpressions.RegexRunner::DoCheckTimeout()
extern void RegexRunner_DoCheckTimeout_mCDAA40848A2F8AAD70928FFD8A6C08FF2D9E72A3 ();
// 0x000001DA System.Void System.Text.RegularExpressions.RegexRunner::Go()
// 0x000001DB System.Boolean System.Text.RegularExpressions.RegexRunner::FindFirstChar()
// 0x000001DC System.Void System.Text.RegularExpressions.RegexRunner::InitTrackCount()
// 0x000001DD System.Void System.Text.RegularExpressions.RegexRunner::InitMatch()
extern void RegexRunner_InitMatch_mF9CD772D4A8E12F89B4785324CD6939ABAE89AD4 ();
// 0x000001DE System.Text.RegularExpressions.Match System.Text.RegularExpressions.RegexRunner::TidyMatch(System.Boolean)
extern void RegexRunner_TidyMatch_m61A8AE20E505F2055B276EB020EB0B804ED2D924 ();
// 0x000001DF System.Void System.Text.RegularExpressions.RegexRunner::EnsureStorage()
extern void RegexRunner_EnsureStorage_m6BC13F773B014E2875CCD9A83E4093A77AA1053C ();
// 0x000001E0 System.Boolean System.Text.RegularExpressions.RegexRunner::IsBoundary(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_IsBoundary_m6C846E11790EC61A9E75A24230E1477913DB3441 ();
// 0x000001E1 System.Boolean System.Text.RegularExpressions.RegexRunner::IsECMABoundary(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_IsECMABoundary_m35C5F5DDC7C2F0E57EBA2E9D9892A88EDAEE4B97 ();
// 0x000001E2 System.Void System.Text.RegularExpressions.RegexRunner::DoubleTrack()
extern void RegexRunner_DoubleTrack_m057C14C51F137222469C6526406B0E1069747618 ();
// 0x000001E3 System.Void System.Text.RegularExpressions.RegexRunner::DoubleStack()
extern void RegexRunner_DoubleStack_m8969F05F9E086EAA194DCBD2F137778239918925 ();
// 0x000001E4 System.Void System.Text.RegularExpressions.RegexRunner::DoubleCrawl()
extern void RegexRunner_DoubleCrawl_mF0425849E5E3C2BA5E9009CED7DE245C8CA0F7CC ();
// 0x000001E5 System.Void System.Text.RegularExpressions.RegexRunner::Crawl(System.Int32)
extern void RegexRunner_Crawl_m655A5D262056F7E13F0645CE5611AE65E83D97DB ();
// 0x000001E6 System.Int32 System.Text.RegularExpressions.RegexRunner::Popcrawl()
extern void RegexRunner_Popcrawl_mD8C76E2C584E6908F4BB11E055B97581F0CF7268 ();
// 0x000001E7 System.Int32 System.Text.RegularExpressions.RegexRunner::Crawlpos()
extern void RegexRunner_Crawlpos_m26A92CA69EF0C65BC7389834A12AD331538D064D ();
// 0x000001E8 System.Void System.Text.RegularExpressions.RegexRunner::Capture(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_Capture_mE34CB0D3351BCC69F6FDE6CDEA763B93C5E92642 ();
// 0x000001E9 System.Void System.Text.RegularExpressions.RegexRunner::TransferCapture(System.Int32,System.Int32,System.Int32,System.Int32)
extern void RegexRunner_TransferCapture_m4F01B5A96647BC3FD338ACF6D509741D80FEC837 ();
// 0x000001EA System.Void System.Text.RegularExpressions.RegexRunner::Uncapture()
extern void RegexRunner_Uncapture_mA7163C77BE1683E508821AB251F33FB7520CE3F8 ();
// 0x000001EB System.Boolean System.Text.RegularExpressions.RegexRunner::IsMatched(System.Int32)
extern void RegexRunner_IsMatched_mD7F580AA0533D5C4BC41D18824FA74BE16EAE7A3 ();
// 0x000001EC System.Int32 System.Text.RegularExpressions.RegexRunner::MatchIndex(System.Int32)
extern void RegexRunner_MatchIndex_mA8EEC418C65572A82720F5D16BAC99224CF0251A ();
// 0x000001ED System.Int32 System.Text.RegularExpressions.RegexRunner::MatchLength(System.Int32)
extern void RegexRunner_MatchLength_m06FA694D5EFE42F89C25C8599BBE86C7726DB2C6 ();
// 0x000001EE System.Text.RegularExpressions.RegexRunner System.Text.RegularExpressions.RegexRunnerFactory::CreateInstance()
// 0x000001EF System.Void System.Text.RegularExpressions.RegexTree::.ctor(System.Text.RegularExpressions.RegexNode,System.Collections.Hashtable,System.Int32[],System.Int32,System.Collections.Hashtable,System.String[],System.Text.RegularExpressions.RegexOptions)
extern void RegexTree__ctor_m5B10D5149928B35CE397472028EE327669C211DA ();
// 0x000001F0 System.Text.RegularExpressions.RegexCode System.Text.RegularExpressions.RegexWriter::Write(System.Text.RegularExpressions.RegexTree)
extern void RegexWriter_Write_m57CF8209EF566CD40F9146C74DF889C8AA06E061 ();
// 0x000001F1 System.Void System.Text.RegularExpressions.RegexWriter::.ctor()
extern void RegexWriter__ctor_m63A858FAE36A8640812DFF917751C1E215A2AE82 ();
// 0x000001F2 System.Void System.Text.RegularExpressions.RegexWriter::PushInt(System.Int32)
extern void RegexWriter_PushInt_mFBC85956A26FEBC66244C8DFC881106D85DD2C1D ();
// 0x000001F3 System.Boolean System.Text.RegularExpressions.RegexWriter::EmptyStack()
extern void RegexWriter_EmptyStack_mB0C109FA21F5CFD16A34438BA1CC1CE8BED91E7C ();
// 0x000001F4 System.Int32 System.Text.RegularExpressions.RegexWriter::PopInt()
extern void RegexWriter_PopInt_m8885F9428571674EC224D6BBC93570B1B4671713 ();
// 0x000001F5 System.Int32 System.Text.RegularExpressions.RegexWriter::CurPos()
extern void RegexWriter_CurPos_mEA105879492A4B415FA8AC25B29AA49153F83C18 ();
// 0x000001F6 System.Void System.Text.RegularExpressions.RegexWriter::PatchJump(System.Int32,System.Int32)
extern void RegexWriter_PatchJump_m6C0A440142E7AC772AD4AF7DF5D8291B6CA6D7D2 ();
// 0x000001F7 System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32)
extern void RegexWriter_Emit_mDC0B76CE49A6DE83DD2D169236BCD516AE9263EF ();
// 0x000001F8 System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32,System.Int32)
extern void RegexWriter_Emit_m6B0ACB44155A07161060838F483D555E7EF6ACED ();
// 0x000001F9 System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32,System.Int32,System.Int32)
extern void RegexWriter_Emit_m7C1D08F071C805F13DBF7684AEC3F2F7E748C497 ();
// 0x000001FA System.Int32 System.Text.RegularExpressions.RegexWriter::StringCode(System.String)
extern void RegexWriter_StringCode_m6AA17FFEBDD5E155004F05A78CF13B0D8E901158 ();
// 0x000001FB System.ArgumentException System.Text.RegularExpressions.RegexWriter::MakeException(System.String)
extern void RegexWriter_MakeException_m443C4CFA99AE06710D1E1BFA3D6EB9737AE70F17 ();
// 0x000001FC System.Int32 System.Text.RegularExpressions.RegexWriter::MapCapnum(System.Int32)
extern void RegexWriter_MapCapnum_m6AFE8BED80960BAA522EAA873D535C9D5AD4B811 ();
// 0x000001FD System.Text.RegularExpressions.RegexCode System.Text.RegularExpressions.RegexWriter::RegexCodeFromRegexTree(System.Text.RegularExpressions.RegexTree)
extern void RegexWriter_RegexCodeFromRegexTree_mAC489A29C00688CA929661BC394F1C4CF997CFC5 ();
// 0x000001FE System.Void System.Text.RegularExpressions.RegexWriter::EmitFragment(System.Int32,System.Text.RegularExpressions.RegexNode,System.Int32)
extern void RegexWriter_EmitFragment_mEFDD8EA3A65320222CF4EA8A52B33C687EE0C5AC ();
// 0x000001FF System.Void System.Diagnostics.BooleanSwitch::.ctor(System.String,System.String)
extern void BooleanSwitch__ctor_m6F066AB4D9A1AF132569B625CB857AE671F94C0B ();
// 0x00000200 System.Void System.Diagnostics.Switch::.ctor(System.String,System.String)
extern void Switch__ctor_mCEC1A7A86582AA8639404DCF7607B160A8B53A42 ();
// 0x00000201 System.Void System.Diagnostics.Switch::.ctor(System.String,System.String,System.String)
extern void Switch__ctor_mA94CBF64FF82CBF4819158911159130231ADE484 ();
// 0x00000202 System.Void System.Diagnostics.Switch::_pruneCachedSwitches()
extern void Switch__pruneCachedSwitches_m7500DBE46E6A2B4AA6BBE2978C90166B6EA35790 ();
// 0x00000203 System.Void System.Diagnostics.Switch::.cctor()
extern void Switch__cctor_mC01362AF23DB366F6103AC3762E913F3149B923C ();
// 0x00000204 System.Void System.Diagnostics.SwitchLevelAttribute::.ctor(System.Type)
extern void SwitchLevelAttribute__ctor_mD0C828AD634514271EDA0B06938D962B17EAFD52 ();
// 0x00000205 System.Void System.Diagnostics.SwitchLevelAttribute::set_SwitchLevelType(System.Type)
extern void SwitchLevelAttribute_set_SwitchLevelType_m88B4C116AB67D726698620238DFF195913299929 ();
// 0x00000206 System.Void System.Diagnostics.TraceSwitch::.ctor(System.String,System.String)
extern void TraceSwitch__ctor_mDBA48A8FB03E3CED698799144535B99F84D81008 ();
// 0x00000207 System.Int64 System.Diagnostics.Stopwatch::GetTimestamp()
extern void Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA ();
// 0x00000208 System.Void System.Diagnostics.Stopwatch::.ctor()
extern void Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860 ();
// 0x00000209 System.TimeSpan System.Diagnostics.Stopwatch::get_Elapsed()
extern void Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB ();
// 0x0000020A System.Int64 System.Diagnostics.Stopwatch::get_ElapsedMilliseconds()
extern void Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177 ();
// 0x0000020B System.Int64 System.Diagnostics.Stopwatch::get_ElapsedTicks()
extern void Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901 ();
// 0x0000020C System.Void System.Diagnostics.Stopwatch::Start()
extern void Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A ();
// 0x0000020D System.Void System.Diagnostics.Stopwatch::.cctor()
extern void Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064 ();
// 0x0000020E System.Object System.ComponentModel.ArrayConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void ArrayConverter_ConvertTo_mAEA49FE8501D2CA2989D859B2721CECCD5D0291B ();
// 0x0000020F System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ArrayConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void ArrayConverter_GetProperties_m6EA225499F1C9E760F12E922862ADBAACE8A7764 ();
// 0x00000210 System.Boolean System.ComponentModel.ArrayConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void ArrayConverter_GetPropertiesSupported_m0E3C2E559400F3DC3D63F9A4701F3FA60AEA5E6E ();
// 0x00000211 System.Void System.ComponentModel.ArrayConverter::.ctor()
extern void ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7 ();
// 0x00000212 System.Void System.ComponentModel.ArrayConverter_ArrayPropertyDescriptor::.ctor(System.Type,System.Type,System.Int32)
extern void ArrayPropertyDescriptor__ctor_m7C51D4632C85E9663A9C39AC44E6E2CAA55F9269 ();
// 0x00000213 System.Void System.ComponentModel.ArraySubsetEnumerator::.ctor(System.Array,System.Int32)
extern void ArraySubsetEnumerator__ctor_m39C3859EB2625F6E584E35FDB1950B5E8407761C ();
// 0x00000214 System.Boolean System.ComponentModel.ArraySubsetEnumerator::MoveNext()
extern void ArraySubsetEnumerator_MoveNext_mDA14E48B8A7B78616EEF81E31CE8E9A258C1A905 ();
// 0x00000215 System.Void System.ComponentModel.ArraySubsetEnumerator::Reset()
extern void ArraySubsetEnumerator_Reset_mC82A8E1D642B024903CA780F6034797EB423BEB4 ();
// 0x00000216 System.Object System.ComponentModel.ArraySubsetEnumerator::get_Current()
extern void ArraySubsetEnumerator_get_Current_m09128B3111243A65657005FFCBB036CD3EF1C0FC ();
// 0x00000217 System.Void System.ComponentModel.AttributeCollection::.ctor(System.Attribute[])
extern void AttributeCollection__ctor_m1EBB330147608510FB1B60549BA95812EA2A1190 ();
// 0x00000218 System.Attribute[] System.ComponentModel.AttributeCollection::get_Attributes()
extern void AttributeCollection_get_Attributes_m1EFD91DE73B1AB6FDB061108CA8FEF54F2FB5BF0 ();
// 0x00000219 System.Int32 System.ComponentModel.AttributeCollection::get_Count()
extern void AttributeCollection_get_Count_m18B4E5D1755D27754C9B3C7C89B4BD91B1458EC4 ();
// 0x0000021A System.Attribute System.ComponentModel.AttributeCollection::get_Item(System.Type)
extern void AttributeCollection_get_Item_m2124C159EC9B2357A091B520AEEE0901A1F0D686 ();
// 0x0000021B System.Boolean System.ComponentModel.AttributeCollection::Contains(System.Attribute)
extern void AttributeCollection_Contains_m44FEEEE6F4C20AAF6207A09BE38A10EEF6EDE6EF ();
// 0x0000021C System.Attribute System.ComponentModel.AttributeCollection::GetDefaultAttribute(System.Type)
extern void AttributeCollection_GetDefaultAttribute_mE4E776D746426F6C8E4FB92754FBA9067F0D7A3F ();
// 0x0000021D System.Collections.IEnumerator System.ComponentModel.AttributeCollection::GetEnumerator()
extern void AttributeCollection_GetEnumerator_m0A6B7803DAA1D559DF91BB18D0230F449A036DCB ();
// 0x0000021E System.Int32 System.ComponentModel.AttributeCollection::System.Collections.ICollection.get_Count()
extern void AttributeCollection_System_Collections_ICollection_get_Count_mE6419B4E22BAC7B304BFC745319C683C889CC7F7 ();
// 0x0000021F System.Object System.ComponentModel.AttributeCollection::System.Collections.ICollection.get_SyncRoot()
extern void AttributeCollection_System_Collections_ICollection_get_SyncRoot_mA3D7D19888BBE89E51D4BD84EE6AAA9237504E74 ();
// 0x00000220 System.Void System.ComponentModel.AttributeCollection::CopyTo(System.Array,System.Int32)
extern void AttributeCollection_CopyTo_mAE40D3E0FE070974B37F9BA5F4600E622E6F621F ();
// 0x00000221 System.Collections.IEnumerator System.ComponentModel.AttributeCollection::System.Collections.IEnumerable.GetEnumerator()
extern void AttributeCollection_System_Collections_IEnumerable_GetEnumerator_m582487AE671B368FDDF140B132FA868EC14349FD ();
// 0x00000222 System.Void System.ComponentModel.AttributeCollection::.cctor()
extern void AttributeCollection__cctor_m53AA3C8B32DE173EF653258A5BA9BCA1E5C5FCA9 ();
// 0x00000223 System.String System.ComponentModel.AttributeProviderAttribute::get_TypeName()
extern void AttributeProviderAttribute_get_TypeName_m83FA0949577D518981558E3A01BA14647565A0DC ();
// 0x00000224 System.String System.ComponentModel.AttributeProviderAttribute::get_PropertyName()
extern void AttributeProviderAttribute_get_PropertyName_mC7A169CDA2E8BE87946A71872C41F0C768D1C80B ();
// 0x00000225 System.Boolean System.ComponentModel.BooleanConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void BooleanConverter_CanConvertFrom_mD2CCC35D0029B29ED16C531E4389EE94F04AB955 ();
// 0x00000226 System.Object System.ComponentModel.BooleanConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void BooleanConverter_ConvertFrom_mAE7E5524CBFA2C3C060A5D7006E1F41BC8AD8426 ();
// 0x00000227 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.BooleanConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void BooleanConverter_GetStandardValues_mF92B51FE0ED7E1F8D89B691824CF7AAEC799DDFD ();
// 0x00000228 System.Boolean System.ComponentModel.BooleanConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void BooleanConverter_GetStandardValuesExclusive_m96A3138B9528AB4BAC2CAEA77493BD3A87C6E075 ();
// 0x00000229 System.Boolean System.ComponentModel.BooleanConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void BooleanConverter_GetStandardValuesSupported_m0F180543294A0E3C0F33460F95C1A839372A2C9F ();
// 0x0000022A System.Void System.ComponentModel.BooleanConverter::.ctor()
extern void BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4 ();
// 0x0000022B System.Void System.ComponentModel.BrowsableAttribute::.ctor(System.Boolean)
extern void BrowsableAttribute__ctor_m74B2B058CBFEE54B61640489C57D22055C7B482C ();
// 0x0000022C System.Boolean System.ComponentModel.BrowsableAttribute::get_Browsable()
extern void BrowsableAttribute_get_Browsable_m84931BFF3F51CB9F14D7B1D7548B796FE2DBB8D2 ();
// 0x0000022D System.Boolean System.ComponentModel.BrowsableAttribute::Equals(System.Object)
extern void BrowsableAttribute_Equals_mE405587EE66B0D70C2D59B27C01C65C96C391FBF ();
// 0x0000022E System.Int32 System.ComponentModel.BrowsableAttribute::GetHashCode()
extern void BrowsableAttribute_GetHashCode_mB190CC4AC3C2A7F8351335208D308E11C12A342D ();
// 0x0000022F System.Boolean System.ComponentModel.BrowsableAttribute::IsDefaultAttribute()
extern void BrowsableAttribute_IsDefaultAttribute_m71A749AC32DD9BCF4555DB7DE953E11C8A11651C ();
// 0x00000230 System.Void System.ComponentModel.BrowsableAttribute::.cctor()
extern void BrowsableAttribute__cctor_mE60A9058276719078B402CD5CA7E2D2FD831FE93 ();
// 0x00000231 System.Type System.ComponentModel.ByteConverter::get_TargetType()
extern void ByteConverter_get_TargetType_m21CE42EF4CCA5DB8100AC9DECF783C8A005B8B26 ();
// 0x00000232 System.Object System.ComponentModel.ByteConverter::FromString(System.String,System.Int32)
extern void ByteConverter_FromString_m0CAA015CF3C267450EF9F6EAD7D1AADF18B783C1 ();
// 0x00000233 System.Object System.ComponentModel.ByteConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void ByteConverter_FromString_m382279DD8FDF6650EDFC5977445BD2737200BC87 ();
// 0x00000234 System.Object System.ComponentModel.ByteConverter::FromString(System.String,System.Globalization.CultureInfo)
extern void ByteConverter_FromString_m7A932F208E2E545D5F04E9A884468EA5A2DEA54F ();
// 0x00000235 System.String System.ComponentModel.ByteConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void ByteConverter_ToString_m605162970D456ECCCD143AE873B1A66B7B8A5372 ();
// 0x00000236 System.Void System.ComponentModel.ByteConverter::.ctor()
extern void ByteConverter__ctor_mAA3E9232945941ADBB7CCC1E7B0DCC5F8FDBF766 ();
// 0x00000237 System.Boolean System.ComponentModel.CharConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void CharConverter_CanConvertFrom_mACC1C53BA7A3678023FA71E57FF9537B9135329F ();
// 0x00000238 System.Object System.ComponentModel.CharConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void CharConverter_ConvertTo_m0AE58CD85062AD115A508B40DFA8C03C2B4F5E30 ();
// 0x00000239 System.Object System.ComponentModel.CharConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void CharConverter_ConvertFrom_mEF1930149E499F9B6BB23BA076B05D409147D8ED ();
// 0x0000023A System.Void System.ComponentModel.CharConverter::.ctor()
extern void CharConverter__ctor_m42C950C40D8A37114897889BE6FAAE8EDEE428E5 ();
// 0x0000023B System.Object System.ComponentModel.CollectionConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void CollectionConverter_ConvertTo_m75D7A858FB6E5B535386F5DB31CE3B6C8B153837 ();
// 0x0000023C System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.CollectionConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void CollectionConverter_GetProperties_m157B337350174872C0A16671185BE3343FBA08D5 ();
// 0x0000023D System.Boolean System.ComponentModel.CollectionConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void CollectionConverter_GetPropertiesSupported_mD6B7423E7544EE67C784C160905E681816E8C7A5 ();
// 0x0000023E System.Void System.ComponentModel.CollectionConverter::.ctor()
extern void CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7 ();
// 0x0000023F System.ComponentModel.IComponent System.ComponentModel.ComponentCollection::get_Item(System.String)
extern void ComponentCollection_get_Item_mE2B50B2203E85B0FFD12BA25AB74284D0E1BF85E ();
// 0x00000240 System.Void System.ComponentModel.ComponentConverter::.ctor(System.Type)
extern void ComponentConverter__ctor_m49FB91A291AFCD94E41DD41B9B16A938A5FA5273 ();
// 0x00000241 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ComponentConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void ComponentConverter_GetProperties_m8C283D3EE69E185BD68E4A3570229F4B597C62F1 ();
// 0x00000242 System.Boolean System.ComponentModel.ComponentConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void ComponentConverter_GetPropertiesSupported_m1329740DF56E38B1C12C0394C25150078D31B7B6 ();
// 0x00000243 System.String System.ComponentModel.CultureInfoConverter::get_DefaultCultureString()
extern void CultureInfoConverter_get_DefaultCultureString_m202C68B34215169C103318A3A1620995A186EB61 ();
// 0x00000244 System.String System.ComponentModel.CultureInfoConverter::GetCultureName(System.Globalization.CultureInfo)
extern void CultureInfoConverter_GetCultureName_mA1618DE646813A98D2FDA246EDFE83D8015085E9 ();
// 0x00000245 System.Boolean System.ComponentModel.CultureInfoConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void CultureInfoConverter_CanConvertFrom_m85B0075150593AEA00319D8DABEC28929EC4C706 ();
// 0x00000246 System.Boolean System.ComponentModel.CultureInfoConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void CultureInfoConverter_CanConvertTo_m0AAD1DACA5AA6A17F6EA0246D8B787D2240BFEC2 ();
// 0x00000247 System.Object System.ComponentModel.CultureInfoConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void CultureInfoConverter_ConvertFrom_m49DB6CACA3C6739CD8C2ECA4CF1459D4420D609C ();
// 0x00000248 System.Object System.ComponentModel.CultureInfoConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void CultureInfoConverter_ConvertTo_m2283E0757C117D8E1A62DF66D50C182FEFCF0A2E ();
// 0x00000249 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.CultureInfoConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void CultureInfoConverter_GetStandardValues_m9F08100099391767017F8BC0506F955DEC48F1D6 ();
// 0x0000024A System.Boolean System.ComponentModel.CultureInfoConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void CultureInfoConverter_GetStandardValuesExclusive_m2EA028A53B09A143A8D1C66E16DD38A4F94D9888 ();
// 0x0000024B System.Boolean System.ComponentModel.CultureInfoConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void CultureInfoConverter_GetStandardValuesSupported_m0D68B3C3A848E81B3D868C323A20ADBFB7EB33AC ();
// 0x0000024C System.Void System.ComponentModel.CultureInfoConverter::.ctor()
extern void CultureInfoConverter__ctor_m7638B1C404D5C207B2FE06E6F53638A978CCC375 ();
// 0x0000024D System.Void System.ComponentModel.CultureInfoConverter_CultureComparer::.ctor(System.ComponentModel.CultureInfoConverter)
extern void CultureComparer__ctor_m24BDA06BAEE28F088B3B43FBC1F028F68E9E5B83 ();
// 0x0000024E System.Int32 System.ComponentModel.CultureInfoConverter_CultureComparer::Compare(System.Object,System.Object)
extern void CultureComparer_Compare_m74AD5F7935B54AB74291A38893B50E0CC609DA29 ();
// 0x0000024F System.String System.ComponentModel.CultureInfoConverter_CultureInfoMapper::GetCultureInfoName(System.String)
extern void CultureInfoMapper_GetCultureInfoName_m794274715866D2D8F320CBD3A051B55B24824720 ();
// 0x00000250 System.Void System.ComponentModel.CultureInfoConverter_CultureInfoMapper::InitializeCultureInfoMap()
extern void CultureInfoMapper_InitializeCultureInfoMap_m1FF56C2C0CF698132D8D96126D41A92340C4F040 ();
// 0x00000251 System.Void System.ComponentModel.CustomTypeDescriptor::.ctor()
extern void CustomTypeDescriptor__ctor_mD442A0BE59DB1D9EF0AC695FC857C18570B2AAD2 ();
// 0x00000252 System.ComponentModel.AttributeCollection System.ComponentModel.CustomTypeDescriptor::GetAttributes()
extern void CustomTypeDescriptor_GetAttributes_mA2DFA9E08F4CBE42FF54C0EA9313ACACF22AF1E9 ();
// 0x00000253 System.ComponentModel.TypeConverter System.ComponentModel.CustomTypeDescriptor::GetConverter()
extern void CustomTypeDescriptor_GetConverter_m326AC0250B0AECC9EE172FF9A6A112098EC7EB6C ();
// 0x00000254 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.CustomTypeDescriptor::GetProperties()
extern void CustomTypeDescriptor_GetProperties_m75853C1C9E6D90013A8AAEC85E5B2C68BFC42D57 ();
// 0x00000255 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.CustomTypeDescriptor::GetProperties(System.Attribute[])
extern void CustomTypeDescriptor_GetProperties_m9335548766C00E208B215333BF609541C4D88253 ();
// 0x00000256 System.Boolean System.ComponentModel.DateTimeConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void DateTimeConverter_CanConvertFrom_m47FF2772D08D0692FD2DDF4436584F38422F5FA1 ();
// 0x00000257 System.Boolean System.ComponentModel.DateTimeConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void DateTimeConverter_CanConvertTo_mB2896928A5346D92A19E3E59A409760F203C111A ();
// 0x00000258 System.Object System.ComponentModel.DateTimeConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void DateTimeConverter_ConvertFrom_m5F118F03495AD23C3694DD1F984B982A1B0F8D33 ();
// 0x00000259 System.Object System.ComponentModel.DateTimeConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void DateTimeConverter_ConvertTo_m9C4EFE6069A6BBEB95347CD4ABAE8EA9103CC516 ();
// 0x0000025A System.Void System.ComponentModel.DateTimeConverter::.ctor()
extern void DateTimeConverter__ctor_m1B60FCB4F2053392F67CF6B8398AB82291CC2FD2 ();
// 0x0000025B System.Boolean System.ComponentModel.DecimalConverter::get_AllowHex()
extern void DecimalConverter_get_AllowHex_mFB916A7101AA8F202F2EE1952E47B98D8D8D9AD7 ();
// 0x0000025C System.Type System.ComponentModel.DecimalConverter::get_TargetType()
extern void DecimalConverter_get_TargetType_m9D7F2BB39848B5F8A436A900487B55F6FCA94F20 ();
// 0x0000025D System.Boolean System.ComponentModel.DecimalConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void DecimalConverter_CanConvertTo_m055F9F0239B7D7970F61F3D5B14B3C1991E82C49 ();
// 0x0000025E System.Object System.ComponentModel.DecimalConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void DecimalConverter_ConvertTo_m5B21E6AB73251329BE83E9A25C4E2DECD2AE82C2 ();
// 0x0000025F System.Object System.ComponentModel.DecimalConverter::FromString(System.String,System.Int32)
extern void DecimalConverter_FromString_m00911E3824B71042A46E46CF5F0270D5EBBE77AA ();
// 0x00000260 System.Object System.ComponentModel.DecimalConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void DecimalConverter_FromString_m3FF2CFCCA66D2D6EBEC5E10A48A9F450C7F37949 ();
// 0x00000261 System.Object System.ComponentModel.DecimalConverter::FromString(System.String,System.Globalization.CultureInfo)
extern void DecimalConverter_FromString_m7C29C3AB8AB31C0DF043B36C1D32578C5DC09D78 ();
// 0x00000262 System.String System.ComponentModel.DecimalConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void DecimalConverter_ToString_m9E32217983BD348797296512695A5341C30697AD ();
// 0x00000263 System.Void System.ComponentModel.DecimalConverter::.ctor()
extern void DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7 ();
// 0x00000264 System.Object System.ComponentModel.DefaultValueAttribute::get_Value()
extern void DefaultValueAttribute_get_Value_m4C07236B56BD114C38BA7DA8C94605A174EEC005 ();
// 0x00000265 System.Void System.ComponentModel.DelegatingTypeDescriptionProvider::.ctor(System.Type)
extern void DelegatingTypeDescriptionProvider__ctor_mCA7A19A0B8F2306A3FCBE5541B92E0F1D1376B01 ();
// 0x00000266 System.ComponentModel.TypeDescriptionProvider System.ComponentModel.DelegatingTypeDescriptionProvider::get_Provider()
extern void DelegatingTypeDescriptionProvider_get_Provider_mA048A519047ACF1FB8AB8604AC985038883688E7 ();
// 0x00000267 System.Collections.IDictionary System.ComponentModel.DelegatingTypeDescriptionProvider::GetCache(System.Object)
extern void DelegatingTypeDescriptionProvider_GetCache_mB2D34194960FB5604FCCA8DEB3F563BD0E73321C ();
// 0x00000268 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.DelegatingTypeDescriptionProvider::GetExtendedTypeDescriptor(System.Object)
extern void DelegatingTypeDescriptionProvider_GetExtendedTypeDescriptor_m253D9E8BB497010592F6EDA8D601DEDF11191CD2 ();
// 0x00000269 System.ComponentModel.IExtenderProvider[] System.ComponentModel.DelegatingTypeDescriptionProvider::GetExtenderProviders(System.Object)
extern void DelegatingTypeDescriptionProvider_GetExtenderProviders_m6A6C2B71F960A4A5A8FA32B49DACD4872928D553 ();
// 0x0000026A System.Type System.ComponentModel.DelegatingTypeDescriptionProvider::GetReflectionType(System.Type,System.Object)
extern void DelegatingTypeDescriptionProvider_GetReflectionType_mAE5CE00625A29447106956644B1E52E7E7588E79 ();
// 0x0000026B System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.DelegatingTypeDescriptionProvider::GetTypeDescriptor(System.Type,System.Object)
extern void DelegatingTypeDescriptionProvider_GetTypeDescriptor_mFD091994993864869A433CD2507DE15B70D2A7E6 ();
// 0x0000026C System.Void System.ComponentModel.DescriptionAttribute::.ctor()
extern void DescriptionAttribute__ctor_m4813112E0C52509AA577C0A9A27A8C1D596CFF4E ();
// 0x0000026D System.Void System.ComponentModel.DescriptionAttribute::.ctor(System.String)
extern void DescriptionAttribute__ctor_m5964EBBE5F72FC3B765F2657E0C7A6A9EF1DF2C5 ();
// 0x0000026E System.String System.ComponentModel.DescriptionAttribute::get_Description()
extern void DescriptionAttribute_get_Description_m86EA9FDCEF55F6643C195B45A9BA6A58E30875B3 ();
// 0x0000026F System.String System.ComponentModel.DescriptionAttribute::get_DescriptionValue()
extern void DescriptionAttribute_get_DescriptionValue_mD892D328BECCFE526144A4B778DCC2B4BC8D45CD ();
// 0x00000270 System.Boolean System.ComponentModel.DescriptionAttribute::Equals(System.Object)
extern void DescriptionAttribute_Equals_mD0C91C3BDA1081BC9ECD15B9D8770EC9B8CCCB51 ();
// 0x00000271 System.Int32 System.ComponentModel.DescriptionAttribute::GetHashCode()
extern void DescriptionAttribute_GetHashCode_m936BEDB9238E6BF727014567451AD7DAC9F2B163 ();
// 0x00000272 System.Boolean System.ComponentModel.DescriptionAttribute::IsDefaultAttribute()
extern void DescriptionAttribute_IsDefaultAttribute_m027507DDAF18946B4CB2FA3015FE73EBAC53D62D ();
// 0x00000273 System.Void System.ComponentModel.DescriptionAttribute::.cctor()
extern void DescriptionAttribute__cctor_m70E48D1F612C3405E8C981060431512C0374C438 ();
// 0x00000274 System.Void System.ComponentModel.DesignOnlyAttribute::.ctor(System.Boolean)
extern void DesignOnlyAttribute__ctor_mEBDD48E0B85C8D87398601C52C8FFFD17CB39415 ();
// 0x00000275 System.Boolean System.ComponentModel.DesignOnlyAttribute::get_IsDesignOnly()
extern void DesignOnlyAttribute_get_IsDesignOnly_m68CBE6C4AD7154EE82ECD431849BA377756874CF ();
// 0x00000276 System.Boolean System.ComponentModel.DesignOnlyAttribute::IsDefaultAttribute()
extern void DesignOnlyAttribute_IsDefaultAttribute_m6D873950CDF25510F438ED647346317CA7A647FF ();
// 0x00000277 System.Boolean System.ComponentModel.DesignOnlyAttribute::Equals(System.Object)
extern void DesignOnlyAttribute_Equals_m076651DB673496528EE4BE929689DE99BEAB8B13 ();
// 0x00000278 System.Int32 System.ComponentModel.DesignOnlyAttribute::GetHashCode()
extern void DesignOnlyAttribute_GetHashCode_mADCBF4B2BF7067D02A09CF088C8D69F468C483AF ();
// 0x00000279 System.Void System.ComponentModel.DesignOnlyAttribute::.cctor()
extern void DesignOnlyAttribute__cctor_mB4872B8DD73AE15130706DEC6C80D66903C6D2C6 ();
// 0x0000027A System.Void System.ComponentModel.DesignerAttribute::.ctor(System.String,System.Type)
extern void DesignerAttribute__ctor_m80FC02525242A357EB829F1FF6E323C243571DF5 ();
// 0x0000027B System.Object System.ComponentModel.DesignerAttribute::get_TypeId()
extern void DesignerAttribute_get_TypeId_m5FEB8253BDB826CF1B19CD7CEAE5622ADBFA6A63 ();
// 0x0000027C System.Boolean System.ComponentModel.DesignerAttribute::Equals(System.Object)
extern void DesignerAttribute_Equals_m8F8B48C9F60766DE6DEB22CB0ED72F2B16C8C659 ();
// 0x0000027D System.Int32 System.ComponentModel.DesignerAttribute::GetHashCode()
extern void DesignerAttribute_GetHashCode_m756E31506E31D909272E5289ADC2DCB0DA675437 ();
// 0x0000027E System.Void System.ComponentModel.DisplayNameAttribute::.ctor()
extern void DisplayNameAttribute__ctor_mCA2BCC655453F00B75B3E6E072777304FA3599A9 ();
// 0x0000027F System.Void System.ComponentModel.DisplayNameAttribute::.ctor(System.String)
extern void DisplayNameAttribute__ctor_m3D4B66E435734FFA29B405B346956880AD44AF5B ();
// 0x00000280 System.String System.ComponentModel.DisplayNameAttribute::get_DisplayName()
extern void DisplayNameAttribute_get_DisplayName_mC1FE61B42690D98511D52340E04E6C54D1F4D494 ();
// 0x00000281 System.String System.ComponentModel.DisplayNameAttribute::get_DisplayNameValue()
extern void DisplayNameAttribute_get_DisplayNameValue_m6A75B8CBDD8F55609180D19E79E74BF7656F9163 ();
// 0x00000282 System.Boolean System.ComponentModel.DisplayNameAttribute::Equals(System.Object)
extern void DisplayNameAttribute_Equals_m7893F7A4E50D758CC46D15D3C7FE754471FA51AE ();
// 0x00000283 System.Int32 System.ComponentModel.DisplayNameAttribute::GetHashCode()
extern void DisplayNameAttribute_GetHashCode_m1369380C57DDC20FEBAFC4562305B7BAF52A1F64 ();
// 0x00000284 System.Boolean System.ComponentModel.DisplayNameAttribute::IsDefaultAttribute()
extern void DisplayNameAttribute_IsDefaultAttribute_m9835E20454EBC53D6F16D5B74B356EDA465D6FE2 ();
// 0x00000285 System.Void System.ComponentModel.DisplayNameAttribute::.cctor()
extern void DisplayNameAttribute__cctor_m42C8D9A551BF01816245A28D6291C7F17E29910F ();
// 0x00000286 System.Boolean System.ComponentModel.DoubleConverter::get_AllowHex()
extern void DoubleConverter_get_AllowHex_mDB902FA678E2823F8775CF2410F8BCFD45135A9A ();
// 0x00000287 System.Type System.ComponentModel.DoubleConverter::get_TargetType()
extern void DoubleConverter_get_TargetType_mE2AA85910CF4D5EE2857F5472FAD6F60E96FDA6E ();
// 0x00000288 System.Object System.ComponentModel.DoubleConverter::FromString(System.String,System.Int32)
extern void DoubleConverter_FromString_mDCD894BDC0A4DFB12E269CE8FF72B377691E4095 ();
// 0x00000289 System.Object System.ComponentModel.DoubleConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void DoubleConverter_FromString_m0FA24E767CC4FFA9CFD7B7CE0D382A0CA8903980 ();
// 0x0000028A System.Object System.ComponentModel.DoubleConverter::FromString(System.String,System.Globalization.CultureInfo)
extern void DoubleConverter_FromString_mFC898691E3FC0C34E4BAB3643645E081F4FF3347 ();
// 0x0000028B System.String System.ComponentModel.DoubleConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void DoubleConverter_ToString_m9C99B65F40B918222ED348FA19F750EC02DCD72B ();
// 0x0000028C System.Void System.ComponentModel.DoubleConverter::.ctor()
extern void DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB ();
// 0x0000028D System.Void System.ComponentModel.EditorBrowsableAttribute::.ctor(System.ComponentModel.EditorBrowsableState)
extern void EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E ();
// 0x0000028E System.Boolean System.ComponentModel.EditorBrowsableAttribute::Equals(System.Object)
extern void EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA ();
// 0x0000028F System.Int32 System.ComponentModel.EditorBrowsableAttribute::GetHashCode()
extern void EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6 ();
// 0x00000290 System.Void System.ComponentModel.EnumConverter::.ctor(System.Type)
extern void EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774 ();
// 0x00000291 System.Type System.ComponentModel.EnumConverter::get_EnumType()
extern void EnumConverter_get_EnumType_mE363752176E628FE1D15517BCE6F7FC98DEE6F68 ();
// 0x00000292 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.EnumConverter::get_Values()
extern void EnumConverter_get_Values_m83899F439FCAF72024528B8F04C9B7B1CC81C8FB ();
// 0x00000293 System.Void System.ComponentModel.EnumConverter::set_Values(System.ComponentModel.TypeConverter_StandardValuesCollection)
extern void EnumConverter_set_Values_m3769DFEE063A44FC1CBE85754639A0717F3BCFC1 ();
// 0x00000294 System.Boolean System.ComponentModel.EnumConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void EnumConverter_CanConvertFrom_m283E54FE7BFCFC3CF022827F20678CE40698BAE2 ();
// 0x00000295 System.Boolean System.ComponentModel.EnumConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void EnumConverter_CanConvertTo_m0BDD50EB0F3A7B3364DDD86650151F95C4D4965B ();
// 0x00000296 System.Collections.IComparer System.ComponentModel.EnumConverter::get_Comparer()
extern void EnumConverter_get_Comparer_mBD0584D1B45E8ACFFF5E0FEE31F0983033B1EA2A ();
// 0x00000297 System.Object System.ComponentModel.EnumConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void EnumConverter_ConvertFrom_m06D2FC9021EB3AF4BF131CE8E7268CC41A8994CF ();
// 0x00000298 System.Object System.ComponentModel.EnumConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void EnumConverter_ConvertTo_mBDC59D2EE871592603097C069D557F4D9A79ABFB ();
// 0x00000299 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.EnumConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void EnumConverter_GetStandardValues_m30FF1BC7361719D9A5EE7205F4F63B5CB1E95E15 ();
// 0x0000029A System.Boolean System.ComponentModel.EnumConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void EnumConverter_GetStandardValuesExclusive_m62880BF09B41A7CE88E01AA29C4CFE44A736A178 ();
// 0x0000029B System.Boolean System.ComponentModel.EnumConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void EnumConverter_GetStandardValuesSupported_mAC1496A78AEAD3844C796F9641AD2BC10CD6E1C2 ();
// 0x0000029C System.Boolean System.ComponentModel.EnumConverter::IsValid(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void EnumConverter_IsValid_m5D3AB88EAC5C70586DC64D867F99139FB82FFD87 ();
// 0x0000029D System.Void System.ComponentModel.EventDescriptorCollection::.ctor(System.ComponentModel.EventDescriptor[])
extern void EventDescriptorCollection__ctor_m39980AB8EA7F2F7B480F18E4EC36796C1A259CD7 ();
// 0x0000029E System.Void System.ComponentModel.EventDescriptorCollection::.ctor(System.ComponentModel.EventDescriptor[],System.Boolean)
extern void EventDescriptorCollection__ctor_mDC62048A9CCD9F4E5C2CE7BBEB7C995A60ACB0D5 ();
// 0x0000029F System.Int32 System.ComponentModel.EventDescriptorCollection::get_Count()
extern void EventDescriptorCollection_get_Count_mCAA673C0D2447E4823B34AE97D61BBC999A3E6BC ();
// 0x000002A0 System.ComponentModel.EventDescriptor System.ComponentModel.EventDescriptorCollection::get_Item(System.Int32)
extern void EventDescriptorCollection_get_Item_m861DB4DC0B594DC2BCB973266F49F77DB790689E ();
// 0x000002A1 System.Int32 System.ComponentModel.EventDescriptorCollection::Add(System.ComponentModel.EventDescriptor)
extern void EventDescriptorCollection_Add_mC05DAE99E5D1B041F5755F71E6A2E114640F9779 ();
// 0x000002A2 System.Void System.ComponentModel.EventDescriptorCollection::Clear()
extern void EventDescriptorCollection_Clear_m72C4D0C9B92F9055A62EE6D86D9F3E86264405B5 ();
// 0x000002A3 System.Boolean System.ComponentModel.EventDescriptorCollection::Contains(System.ComponentModel.EventDescriptor)
extern void EventDescriptorCollection_Contains_mD58C927756864E91133BD59356756E96253D4416 ();
// 0x000002A4 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void EventDescriptorCollection_System_Collections_ICollection_CopyTo_mB67B73650B5657F8405395D0BD6521ED8A3AF0D6 ();
// 0x000002A5 System.Void System.ComponentModel.EventDescriptorCollection::EnsureEventsOwned()
extern void EventDescriptorCollection_EnsureEventsOwned_mF1722C2F3574DFE39C8509B62BA0013A68A1C8FB ();
// 0x000002A6 System.Void System.ComponentModel.EventDescriptorCollection::EnsureSize(System.Int32)
extern void EventDescriptorCollection_EnsureSize_m025A1E96DE65403C6BB70BB95F9098E6572EF191 ();
// 0x000002A7 System.Int32 System.ComponentModel.EventDescriptorCollection::IndexOf(System.ComponentModel.EventDescriptor)
extern void EventDescriptorCollection_IndexOf_m2F0D99D9E5885CC7DB6133839635E9C806F6A385 ();
// 0x000002A8 System.Void System.ComponentModel.EventDescriptorCollection::Insert(System.Int32,System.ComponentModel.EventDescriptor)
extern void EventDescriptorCollection_Insert_mB3259BB95ADAA9B11B8A2171F5FAD03C52C40557 ();
// 0x000002A9 System.Void System.ComponentModel.EventDescriptorCollection::Remove(System.ComponentModel.EventDescriptor)
extern void EventDescriptorCollection_Remove_m9F6BF67636B9406EEFB0E3589F4EB3BAF625447E ();
// 0x000002AA System.Void System.ComponentModel.EventDescriptorCollection::RemoveAt(System.Int32)
extern void EventDescriptorCollection_RemoveAt_m3124EA86A586B8FE157E6D6F594E3DCA0752D6D1 ();
// 0x000002AB System.Collections.IEnumerator System.ComponentModel.EventDescriptorCollection::GetEnumerator()
extern void EventDescriptorCollection_GetEnumerator_mEC07212EAD84EF5CD1DB03CFF3773669A030342F ();
// 0x000002AC System.Void System.ComponentModel.EventDescriptorCollection::InternalSort(System.String[])
extern void EventDescriptorCollection_InternalSort_mFC9324E5B172C969B8930B47ABE42FF8C2FEEC72 ();
// 0x000002AD System.Void System.ComponentModel.EventDescriptorCollection::InternalSort(System.Collections.IComparer)
extern void EventDescriptorCollection_InternalSort_mAF3920AA7607A00C1B327539E007F9BBCD2FF13F ();
// 0x000002AE System.Int32 System.ComponentModel.EventDescriptorCollection::System.Collections.ICollection.get_Count()
extern void EventDescriptorCollection_System_Collections_ICollection_get_Count_m360696919250EEB37806F7B331BC2D5127021716 ();
// 0x000002AF System.Object System.ComponentModel.EventDescriptorCollection::System.Collections.ICollection.get_SyncRoot()
extern void EventDescriptorCollection_System_Collections_ICollection_get_SyncRoot_mBDACC0F4D991CDC34E1447AA9D5BE06B6A0E44F2 ();
// 0x000002B0 System.Collections.IEnumerator System.ComponentModel.EventDescriptorCollection::System.Collections.IEnumerable.GetEnumerator()
extern void EventDescriptorCollection_System_Collections_IEnumerable_GetEnumerator_m175494690E3ECAC20382096A8D43493C6DF3245A ();
// 0x000002B1 System.Object System.ComponentModel.EventDescriptorCollection::System.Collections.IList.get_Item(System.Int32)
extern void EventDescriptorCollection_System_Collections_IList_get_Item_mF9F2044326BAD3E203EE9C4B71998C6139671E7C ();
// 0x000002B2 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.IList.set_Item(System.Int32,System.Object)
extern void EventDescriptorCollection_System_Collections_IList_set_Item_m12BD29BF86D1A0AC1255C811F7E9BE0D56DD48DD ();
// 0x000002B3 System.Int32 System.ComponentModel.EventDescriptorCollection::System.Collections.IList.Add(System.Object)
extern void EventDescriptorCollection_System_Collections_IList_Add_mA285053C7C5617586A25D1B3FD1DA834A484F9B9 ();
// 0x000002B4 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.IList.Clear()
extern void EventDescriptorCollection_System_Collections_IList_Clear_m690719A2AC9F81A4B9D94878CA2A991F07F2538C ();
// 0x000002B5 System.Boolean System.ComponentModel.EventDescriptorCollection::System.Collections.IList.Contains(System.Object)
extern void EventDescriptorCollection_System_Collections_IList_Contains_mF75078ECF8D88E161AA11A9AAE71543ECB3CEC26 ();
// 0x000002B6 System.Int32 System.ComponentModel.EventDescriptorCollection::System.Collections.IList.IndexOf(System.Object)
extern void EventDescriptorCollection_System_Collections_IList_IndexOf_m48410473C90632946175F748D09BFAA506D0578E ();
// 0x000002B7 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.IList.Insert(System.Int32,System.Object)
extern void EventDescriptorCollection_System_Collections_IList_Insert_m0538802AE7EB66BDF621A96C23637A50738FD995 ();
// 0x000002B8 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.IList.Remove(System.Object)
extern void EventDescriptorCollection_System_Collections_IList_Remove_m7416A79A4EA58351DBF9B8111C69A6CA8DD1DB05 ();
// 0x000002B9 System.Void System.ComponentModel.EventDescriptorCollection::System.Collections.IList.RemoveAt(System.Int32)
extern void EventDescriptorCollection_System_Collections_IList_RemoveAt_m9DCA747BC2AC75F2920EC289C66FCE2099622329 ();
// 0x000002BA System.Boolean System.ComponentModel.EventDescriptorCollection::System.Collections.IList.get_IsReadOnly()
extern void EventDescriptorCollection_System_Collections_IList_get_IsReadOnly_m1D57F4D7C77E62F7E06273DEC783685E107D0DB5 ();
// 0x000002BB System.Boolean System.ComponentModel.EventDescriptorCollection::System.Collections.IList.get_IsFixedSize()
extern void EventDescriptorCollection_System_Collections_IList_get_IsFixedSize_m00833DCAD0FB8406395CDA1CA0E6C4DDBF958100 ();
// 0x000002BC System.Void System.ComponentModel.EventDescriptorCollection::.cctor()
extern void EventDescriptorCollection__cctor_m027E184FD1333633CEFBEE18BA140A89E8DEEFB1 ();
// 0x000002BD System.Void System.ComponentModel.ExpandableObjectConverter::.ctor()
extern void ExpandableObjectConverter__ctor_mDFE2C6DF3E42BFEDD938757267F2A6E40B8FEB66 ();
// 0x000002BE System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ExpandableObjectConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void ExpandableObjectConverter_GetProperties_m674DA113DAF377614A8EB8BB5BE199BEF53B37C2 ();
// 0x000002BF System.Boolean System.ComponentModel.ExpandableObjectConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void ExpandableObjectConverter_GetPropertiesSupported_m6908E999010CD552559E3143245E02D69BBB4B73 ();
// 0x000002C0 System.Void System.ComponentModel.ExtendedPropertyDescriptor::.ctor(System.ComponentModel.ReflectPropertyDescriptor,System.Type,System.ComponentModel.IExtenderProvider,System.Attribute[])
extern void ExtendedPropertyDescriptor__ctor_mC8CA04D11B52520D581769FB316244C9EA5F7420 ();
// 0x000002C1 System.Type System.ComponentModel.ExtendedPropertyDescriptor::get_ComponentType()
extern void ExtendedPropertyDescriptor_get_ComponentType_m6DBE270D501CFAB038FF8C12EF71A93F3C3025D7 ();
// 0x000002C2 System.Boolean System.ComponentModel.ExtendedPropertyDescriptor::get_IsReadOnly()
extern void ExtendedPropertyDescriptor_get_IsReadOnly_m2F1AB64D3CB1ED3E62800A2F52CC94645382B42A ();
// 0x000002C3 System.Type System.ComponentModel.ExtendedPropertyDescriptor::get_PropertyType()
extern void ExtendedPropertyDescriptor_get_PropertyType_m4F634F2E318150F948FA3D4572F7626C7E8968E2 ();
// 0x000002C4 System.String System.ComponentModel.ExtendedPropertyDescriptor::get_DisplayName()
extern void ExtendedPropertyDescriptor_get_DisplayName_mC5690961D9E460239779D421E4C5636958426E84 ();
// 0x000002C5 System.ComponentModel.ExtenderProvidedPropertyAttribute System.ComponentModel.ExtenderProvidedPropertyAttribute::Create(System.ComponentModel.PropertyDescriptor,System.Type,System.ComponentModel.IExtenderProvider)
extern void ExtenderProvidedPropertyAttribute_Create_mB53BAA317F0E146F21F4508E51921C05459A756B ();
// 0x000002C6 System.Void System.ComponentModel.ExtenderProvidedPropertyAttribute::.ctor()
extern void ExtenderProvidedPropertyAttribute__ctor_mED416479A8167DB724212857B8421BB4079D9F14 ();
// 0x000002C7 System.ComponentModel.IExtenderProvider System.ComponentModel.ExtenderProvidedPropertyAttribute::get_Provider()
extern void ExtenderProvidedPropertyAttribute_get_Provider_m54BFFEFF3AF82BD3F36AC3A1D473FAC53CF368C6 ();
// 0x000002C8 System.Type System.ComponentModel.ExtenderProvidedPropertyAttribute::get_ReceiverType()
extern void ExtenderProvidedPropertyAttribute_get_ReceiverType_mE35ED6058DEBE1160D17BF385E2C46E161085E33 ();
// 0x000002C9 System.Boolean System.ComponentModel.ExtenderProvidedPropertyAttribute::Equals(System.Object)
extern void ExtenderProvidedPropertyAttribute_Equals_m7FAB4FA6A11AAA6451F18CB7B06D001FD257EAAC ();
// 0x000002CA System.Int32 System.ComponentModel.ExtenderProvidedPropertyAttribute::GetHashCode()
extern void ExtenderProvidedPropertyAttribute_GetHashCode_m6D03B17855FE555DA2E3F54F11C164BBD3150FB4 ();
// 0x000002CB System.Boolean System.ComponentModel.ExtenderProvidedPropertyAttribute::IsDefaultAttribute()
extern void ExtenderProvidedPropertyAttribute_IsDefaultAttribute_m2BEF7A86CD44FC50CE84586895CE253453A18573 ();
// 0x000002CC System.ComponentModel.ISite System.ComponentModel.IComponent::get_Site()
// 0x000002CD System.ComponentModel.ComponentCollection System.ComponentModel.IContainer::get_Components()
// 0x000002CE System.ComponentModel.AttributeCollection System.ComponentModel.ICustomTypeDescriptor::GetAttributes()
// 0x000002CF System.ComponentModel.TypeConverter System.ComponentModel.ICustomTypeDescriptor::GetConverter()
// 0x000002D0 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ICustomTypeDescriptor::GetProperties()
// 0x000002D1 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ICustomTypeDescriptor::GetProperties(System.Attribute[])
// 0x000002D2 System.Boolean System.ComponentModel.IExtenderProvider::CanExtend(System.Object)
// 0x000002D3 System.ComponentModel.IContainer System.ComponentModel.ISite::get_Container()
// 0x000002D4 System.String System.ComponentModel.ISite::get_Name()
// 0x000002D5 System.ComponentModel.IContainer System.ComponentModel.ITypeDescriptorContext::get_Container()
// 0x000002D6 System.Type System.ComponentModel.Int16Converter::get_TargetType()
extern void Int16Converter_get_TargetType_m03C28B87C29C22B04B4D41C0F654612CADBBD144 ();
// 0x000002D7 System.Object System.ComponentModel.Int16Converter::FromString(System.String,System.Int32)
extern void Int16Converter_FromString_m5037FE57C286C9CAC9CDE3116D0F426EF88993FC ();
// 0x000002D8 System.Object System.ComponentModel.Int16Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void Int16Converter_FromString_m1D6EED88E7A619CF41C3F822EF148DC647521367 ();
// 0x000002D9 System.Object System.ComponentModel.Int16Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void Int16Converter_FromString_m68A48D7A88B2206AD366C3CD5824C90CB483A01B ();
// 0x000002DA System.String System.ComponentModel.Int16Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void Int16Converter_ToString_m04E267BEB959CCCD5FF76F5221B4A82D3B90DE23 ();
// 0x000002DB System.Void System.ComponentModel.Int16Converter::.ctor()
extern void Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D ();
// 0x000002DC System.Type System.ComponentModel.Int32Converter::get_TargetType()
extern void Int32Converter_get_TargetType_mADD76E2E99D4B78ECB684AE296C6AD5E45840433 ();
// 0x000002DD System.Object System.ComponentModel.Int32Converter::FromString(System.String,System.Int32)
extern void Int32Converter_FromString_m522F024625D49139F89AC5DE44EA3DCFDD490B55 ();
// 0x000002DE System.Object System.ComponentModel.Int32Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void Int32Converter_FromString_m99A5C50498D91308BEA81C8E9E134608DD525799 ();
// 0x000002DF System.Object System.ComponentModel.Int32Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void Int32Converter_FromString_m84E1A77746AAC084FF5A93E167D6ED83A772C704 ();
// 0x000002E0 System.String System.ComponentModel.Int32Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void Int32Converter_ToString_m30AAD6DCBB228CBD58299310D39D80A44AEB7C6A ();
// 0x000002E1 System.Void System.ComponentModel.Int32Converter::.ctor()
extern void Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9 ();
// 0x000002E2 System.Type System.ComponentModel.Int64Converter::get_TargetType()
extern void Int64Converter_get_TargetType_mA6FF642BF7B48C93043B520B6F56598262324155 ();
// 0x000002E3 System.Object System.ComponentModel.Int64Converter::FromString(System.String,System.Int32)
extern void Int64Converter_FromString_m40D208F2EDE6FFDFF6A897EDE71636290F759A61 ();
// 0x000002E4 System.Object System.ComponentModel.Int64Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void Int64Converter_FromString_m9537EF10EF270D889756264177A7AD71BAC3342C ();
// 0x000002E5 System.Object System.ComponentModel.Int64Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void Int64Converter_FromString_m4B006B13E6B60FB3471055D2AACA19A20BC6C73A ();
// 0x000002E6 System.String System.ComponentModel.Int64Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void Int64Converter_ToString_m914E4B677BB3D12FEFF432696606554C7276093C ();
// 0x000002E7 System.Void System.ComponentModel.Int64Converter::.ctor()
extern void Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74 ();
// 0x000002E8 System.Void System.ComponentModel.MemberDescriptor::.ctor(System.String,System.Attribute[])
extern void MemberDescriptor__ctor_m7DA97C2FCA1C99D7D7B31A89A908219E4A48DE7B ();
// 0x000002E9 System.Void System.ComponentModel.MemberDescriptor::.ctor(System.ComponentModel.MemberDescriptor,System.Attribute[])
extern void MemberDescriptor__ctor_mDDA60D0BB2448D6607AB2F2C353A8C30CFABE0A3 ();
// 0x000002EA System.Attribute[] System.ComponentModel.MemberDescriptor::get_AttributeArray()
extern void MemberDescriptor_get_AttributeArray_mDB41975C313AF40B0FA82B33F0AD504E92F3FDE8 ();
// 0x000002EB System.Void System.ComponentModel.MemberDescriptor::set_AttributeArray(System.Attribute[])
extern void MemberDescriptor_set_AttributeArray_m26BD377D06AA20A1A9A2DB982904B10CBF6D81F7 ();
// 0x000002EC System.ComponentModel.AttributeCollection System.ComponentModel.MemberDescriptor::get_Attributes()
extern void MemberDescriptor_get_Attributes_m4D430272C6E7D07FD2DD901B6FC26E3886217153 ();
// 0x000002ED System.String System.ComponentModel.MemberDescriptor::get_Name()
extern void MemberDescriptor_get_Name_mFADCC43480F88C3749FA2B82EAECA54F79D848BB ();
// 0x000002EE System.Int32 System.ComponentModel.MemberDescriptor::get_NameHashCode()
extern void MemberDescriptor_get_NameHashCode_mA91F4591F9D76BDCB3A43FFA2EF534DAB62CDB6A ();
// 0x000002EF System.String System.ComponentModel.MemberDescriptor::get_DisplayName()
extern void MemberDescriptor_get_DisplayName_m985D97ED7EAEC1A7DA3524E50FB0CF9B3704B746 ();
// 0x000002F0 System.Void System.ComponentModel.MemberDescriptor::CheckAttributesValid()
extern void MemberDescriptor_CheckAttributesValid_mEAFC02C4EAED626FCDC291F1512DD0E602E232BE ();
// 0x000002F1 System.ComponentModel.AttributeCollection System.ComponentModel.MemberDescriptor::CreateAttributeCollection()
extern void MemberDescriptor_CreateAttributeCollection_m579C3F75B24CD1373AE01189CD3CB9CBC6C49E66 ();
// 0x000002F2 System.Boolean System.ComponentModel.MemberDescriptor::Equals(System.Object)
extern void MemberDescriptor_Equals_m66818127B5F93EE67144CB305127BA3377601E54 ();
// 0x000002F3 System.Void System.ComponentModel.MemberDescriptor::FillAttributes(System.Collections.IList)
extern void MemberDescriptor_FillAttributes_mA33C5FFD1DE2BA560E335B6549E60A229B9F773B ();
// 0x000002F4 System.Void System.ComponentModel.MemberDescriptor::FilterAttributesIfNeeded()
extern void MemberDescriptor_FilterAttributesIfNeeded_mDEFEACE930F7537A7DF7A530198F04C73301D591 ();
// 0x000002F5 System.Reflection.MethodInfo System.ComponentModel.MemberDescriptor::FindMethod(System.Type,System.String,System.Type[],System.Type)
extern void MemberDescriptor_FindMethod_m4B26329E481C2681B235A311E2E7D022DC891773 ();
// 0x000002F6 System.Reflection.MethodInfo System.ComponentModel.MemberDescriptor::FindMethod(System.Type,System.String,System.Type[],System.Type,System.Boolean)
extern void MemberDescriptor_FindMethod_m55C2AA54F198A970DAD868DE103F41602CC4ABEF ();
// 0x000002F7 System.Int32 System.ComponentModel.MemberDescriptor::GetHashCode()
extern void MemberDescriptor_GetHashCode_m7E6C8BE058C4A813FE927FC0FC2D97981A3B1CE2 ();
// 0x000002F8 System.ComponentModel.ISite System.ComponentModel.MemberDescriptor::GetSite(System.Object)
extern void MemberDescriptor_GetSite_mCB20B3C6E8E9E4018655CB861FBC408F4468FFD6 ();
// 0x000002F9 System.Void System.ComponentModel.NullableConverter::.ctor(System.Type)
extern void NullableConverter__ctor_m508F1DA74FE1B37ECA5BBA5B0E3A623480E4C564 ();
// 0x000002FA System.Boolean System.ComponentModel.NullableConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void NullableConverter_CanConvertFrom_m248A954CEE87B4098FADA66CF035910E75C22DB9 ();
// 0x000002FB System.Object System.ComponentModel.NullableConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void NullableConverter_ConvertFrom_mB26A50D9B33247B7B6F52BF3C2091DB587296A29 ();
// 0x000002FC System.Boolean System.ComponentModel.NullableConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void NullableConverter_CanConvertTo_m971F73488C57414C8463065CB0CB0285D642519A ();
// 0x000002FD System.Object System.ComponentModel.NullableConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void NullableConverter_ConvertTo_mFE5CF810C6BE39B1A39E51B28875E8FDF0DAE363 ();
// 0x000002FE System.Object System.ComponentModel.NullableConverter::CreateInstance(System.ComponentModel.ITypeDescriptorContext,System.Collections.IDictionary)
extern void NullableConverter_CreateInstance_mC3E844589AD43223F7185523DD99CAAB580BBC52 ();
// 0x000002FF System.Boolean System.ComponentModel.NullableConverter::GetCreateInstanceSupported(System.ComponentModel.ITypeDescriptorContext)
extern void NullableConverter_GetCreateInstanceSupported_m26E7E2DDF37037BB6371AA566CA27104185B16EF ();
// 0x00000300 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.NullableConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void NullableConverter_GetProperties_m6FDB181A72AC16A73DA6DCFB78E86C7665D73A5C ();
// 0x00000301 System.Boolean System.ComponentModel.NullableConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void NullableConverter_GetPropertiesSupported_mA4CDDD3DA6F77162E6BA4B1654C9C8FC1E45F68D ();
// 0x00000302 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.NullableConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void NullableConverter_GetStandardValues_mE04D07ED245061BA6DF9A639DBB37B2ABBDA0E99 ();
// 0x00000303 System.Boolean System.ComponentModel.NullableConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void NullableConverter_GetStandardValuesExclusive_mE2DDC86AB100AFD0F01D9E798148B95F9F1DCB78 ();
// 0x00000304 System.Boolean System.ComponentModel.NullableConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void NullableConverter_GetStandardValuesSupported_m45F8361AB3BA832C14A71D2FE12B6A11707AC9EA ();
// 0x00000305 System.Boolean System.ComponentModel.NullableConverter::IsValid(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void NullableConverter_IsValid_mB0A466B916926A2B3442A69F7C8C86AB148C01C8 ();
// 0x00000306 System.Type System.ComponentModel.NullableConverter::get_NullableType()
extern void NullableConverter_get_NullableType_m3DD5EAE964748743F8CC684C72EC663C75491826 ();
// 0x00000307 System.Type System.ComponentModel.NullableConverter::get_UnderlyingType()
extern void NullableConverter_get_UnderlyingType_mF4A327831A2B20FE4FD3B734570509B6B5C327AF ();
// 0x00000308 System.ComponentModel.TypeConverter System.ComponentModel.NullableConverter::get_UnderlyingTypeConverter()
extern void NullableConverter_get_UnderlyingTypeConverter_m71AA3BCCFFC7B4D61971C691312DF0767350758D ();
// 0x00000309 System.Void System.ComponentModel.PropertyChangedEventArgs::.ctor(System.String)
extern void PropertyChangedEventArgs__ctor_mBC582C76F42CDEE455B350302FFDF687D135A9E2 ();
// 0x0000030A System.Void System.ComponentModel.PropertyChangedEventHandler::.ctor(System.Object,System.IntPtr)
extern void PropertyChangedEventHandler__ctor_mC6EC20F2995A9376A72EB51981850A9E5C8450E7 ();
// 0x0000030B System.Void System.ComponentModel.PropertyChangedEventHandler::Invoke(System.Object,System.ComponentModel.PropertyChangedEventArgs)
extern void PropertyChangedEventHandler_Invoke_m7DB0AABF07302887DD3FEE589E1F585B4C768F57 ();
// 0x0000030C System.IAsyncResult System.ComponentModel.PropertyChangedEventHandler::BeginInvoke(System.Object,System.ComponentModel.PropertyChangedEventArgs,System.AsyncCallback,System.Object)
extern void PropertyChangedEventHandler_BeginInvoke_m77D416AC801FF29FBF4D294574231171FE2E551D ();
// 0x0000030D System.Void System.ComponentModel.PropertyChangedEventHandler::EndInvoke(System.IAsyncResult)
extern void PropertyChangedEventHandler_EndInvoke_m3539B5822D063A13DF8EBCA57CA475A7B5BE32FE ();
// 0x0000030E System.Void System.ComponentModel.PropertyDescriptor::.ctor(System.String,System.Attribute[])
extern void PropertyDescriptor__ctor_m8CEC4DAE5266714927949F60E4F8A7F31141BC22 ();
// 0x0000030F System.Void System.ComponentModel.PropertyDescriptor::.ctor(System.ComponentModel.MemberDescriptor,System.Attribute[])
extern void PropertyDescriptor__ctor_m8C1C276319F5C29A452F48C89B595334AB7E65B0 ();
// 0x00000310 System.Type System.ComponentModel.PropertyDescriptor::get_ComponentType()
// 0x00000311 System.Boolean System.ComponentModel.PropertyDescriptor::get_IsReadOnly()
// 0x00000312 System.Type System.ComponentModel.PropertyDescriptor::get_PropertyType()
// 0x00000313 System.Boolean System.ComponentModel.PropertyDescriptor::Equals(System.Object)
extern void PropertyDescriptor_Equals_m080009C26475A3CBEE1291AC5F1BDFBF4EDA6597 ();
// 0x00000314 System.Void System.ComponentModel.PropertyDescriptor::FillAttributes(System.Collections.IList)
extern void PropertyDescriptor_FillAttributes_mA3E3A90097B815BD8F7A185036485FF86A03256F ();
// 0x00000315 System.Int32 System.ComponentModel.PropertyDescriptor::GetHashCode()
extern void PropertyDescriptor_GetHashCode_mF36CC7A4B3F53BE7EE8DB89B7E4B2E4C3F7A3075 ();
// 0x00000316 System.Void System.ComponentModel.PropertyDescriptorCollection::.ctor(System.ComponentModel.PropertyDescriptor[])
extern void PropertyDescriptorCollection__ctor_m132BE5B53DC73850841F2AB9A6633F4626C538BC ();
// 0x00000317 System.Void System.ComponentModel.PropertyDescriptorCollection::.ctor(System.ComponentModel.PropertyDescriptor[],System.Boolean)
extern void PropertyDescriptorCollection__ctor_m7DDFDE6996940ED1E0BF5073548E5C5B058D6D6D ();
// 0x00000318 System.Void System.ComponentModel.PropertyDescriptorCollection::.ctor(System.ComponentModel.PropertyDescriptor[],System.Int32,System.String[],System.Collections.IComparer)
extern void PropertyDescriptorCollection__ctor_m0BD142D7B2CAD889393CC69ADA2233984768DABB ();
// 0x00000319 System.Int32 System.ComponentModel.PropertyDescriptorCollection::get_Count()
extern void PropertyDescriptorCollection_get_Count_mAA1EA8D4BE590EE7F7E469876FB503F2A0F0E4B0 ();
// 0x0000031A System.ComponentModel.PropertyDescriptor System.ComponentModel.PropertyDescriptorCollection::get_Item(System.Int32)
extern void PropertyDescriptorCollection_get_Item_mD0F537639842BDFC56F142C00A4041CF598D26C2 ();
// 0x0000031B System.ComponentModel.PropertyDescriptor System.ComponentModel.PropertyDescriptorCollection::get_Item(System.String)
extern void PropertyDescriptorCollection_get_Item_m2FEEB6EF3922067EC403A4261D4FB6E77843F628 ();
// 0x0000031C System.Int32 System.ComponentModel.PropertyDescriptorCollection::Add(System.ComponentModel.PropertyDescriptor)
extern void PropertyDescriptorCollection_Add_m4EC994159DE3EC1B05CCD9186099D7935FF3ED33 ();
// 0x0000031D System.Void System.ComponentModel.PropertyDescriptorCollection::Clear()
extern void PropertyDescriptorCollection_Clear_mAD94D5BF4918591FEE475B3FC15A64729F89A3DE ();
// 0x0000031E System.Boolean System.ComponentModel.PropertyDescriptorCollection::Contains(System.ComponentModel.PropertyDescriptor)
extern void PropertyDescriptorCollection_Contains_m8262E7DEBA9D0C9496CE3DDA85BC1F1995F18DBA ();
// 0x0000031F System.Void System.ComponentModel.PropertyDescriptorCollection::CopyTo(System.Array,System.Int32)
extern void PropertyDescriptorCollection_CopyTo_m7F65E93884A12E569B035774440FA977CB9D3A30 ();
// 0x00000320 System.Void System.ComponentModel.PropertyDescriptorCollection::EnsurePropsOwned()
extern void PropertyDescriptorCollection_EnsurePropsOwned_mA7CDF7318480D4512B76733D3E1DF9EAE6C378A1 ();
// 0x00000321 System.Void System.ComponentModel.PropertyDescriptorCollection::EnsureSize(System.Int32)
extern void PropertyDescriptorCollection_EnsureSize_mCCF9502C5BE2212F88FDC6507E598175CF1298BA ();
// 0x00000322 System.ComponentModel.PropertyDescriptor System.ComponentModel.PropertyDescriptorCollection::Find(System.String,System.Boolean)
extern void PropertyDescriptorCollection_Find_m5B0293378066DA6E64B89658470B49EC2767E3B8 ();
// 0x00000323 System.Int32 System.ComponentModel.PropertyDescriptorCollection::IndexOf(System.ComponentModel.PropertyDescriptor)
extern void PropertyDescriptorCollection_IndexOf_mFBCAE0B916F2BF733D494020EBA7EFEEEFC20A45 ();
// 0x00000324 System.Void System.ComponentModel.PropertyDescriptorCollection::Insert(System.Int32,System.ComponentModel.PropertyDescriptor)
extern void PropertyDescriptorCollection_Insert_m22DC9C6797AE20CFE2815DCB8C5A98A9A363BDCD ();
// 0x00000325 System.Void System.ComponentModel.PropertyDescriptorCollection::Remove(System.ComponentModel.PropertyDescriptor)
extern void PropertyDescriptorCollection_Remove_mCFFC999272C8C7B4C325B6D32A9DA2FC6DABC997 ();
// 0x00000326 System.Void System.ComponentModel.PropertyDescriptorCollection::RemoveAt(System.Int32)
extern void PropertyDescriptorCollection_RemoveAt_m988ED89DD8C6F2D254BD664991461869786977F0 ();
// 0x00000327 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.PropertyDescriptorCollection::Sort(System.String[])
extern void PropertyDescriptorCollection_Sort_mCA6419FA5C73054D08EC62386E64C864D26C392A ();
// 0x00000328 System.Void System.ComponentModel.PropertyDescriptorCollection::InternalSort(System.String[])
extern void PropertyDescriptorCollection_InternalSort_m5BEF1BE7A393A601E9E404644C037EB7552362C6 ();
// 0x00000329 System.Void System.ComponentModel.PropertyDescriptorCollection::InternalSort(System.Collections.IComparer)
extern void PropertyDescriptorCollection_InternalSort_m05765A385A5F324219F60E3880193230BCCE8863 ();
// 0x0000032A System.Collections.IEnumerator System.ComponentModel.PropertyDescriptorCollection::GetEnumerator()
extern void PropertyDescriptorCollection_GetEnumerator_mFAB322230D6F91D8B5076910CF9D6107DBC768BD ();
// 0x0000032B System.Int32 System.ComponentModel.PropertyDescriptorCollection::System.Collections.ICollection.get_Count()
extern void PropertyDescriptorCollection_System_Collections_ICollection_get_Count_m4A8DC9D8BD368E2998FB84F1E764B746AB406C2D ();
// 0x0000032C System.Object System.ComponentModel.PropertyDescriptorCollection::System.Collections.ICollection.get_SyncRoot()
extern void PropertyDescriptorCollection_System_Collections_ICollection_get_SyncRoot_m0100C4A2C9B18F6E1A201E29C6F12D1F265DCA4A ();
// 0x0000032D System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.Add(System.Object,System.Object)
extern void PropertyDescriptorCollection_System_Collections_IDictionary_Add_m76AF67DE822D94A046E14382F1841C835EADA094 ();
// 0x0000032E System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.Clear()
extern void PropertyDescriptorCollection_System_Collections_IDictionary_Clear_mCD2DED6F88201D0839F266BA27ADA4C9CDAD8E7C ();
// 0x0000032F System.Boolean System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.Contains(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IDictionary_Contains_m2BF92AB5B0E6DE71F06C21D6A79F40EEB66DE53A ();
// 0x00000330 System.Collections.IDictionaryEnumerator System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.GetEnumerator()
extern void PropertyDescriptorCollection_System_Collections_IDictionary_GetEnumerator_m8BAA6008671D58327735A8CAF9F5916EAFA4B2F2 ();
// 0x00000331 System.Boolean System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.get_IsReadOnly()
extern void PropertyDescriptorCollection_System_Collections_IDictionary_get_IsReadOnly_mCA0E47965BC12EE580E220E38B71BB97CC2807C9 ();
// 0x00000332 System.Object System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.get_Item(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IDictionary_get_Item_m55B7B06FCFD64E0549A25F402E880015FA39237D ();
// 0x00000333 System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.set_Item(System.Object,System.Object)
extern void PropertyDescriptorCollection_System_Collections_IDictionary_set_Item_m45799DA37784A9840E8BCA5FA746535CDD86D696 ();
// 0x00000334 System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IDictionary.Remove(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IDictionary_Remove_mEE3E78216CC8C1192BEF19A0610D5345808B1D76 ();
// 0x00000335 System.Collections.IEnumerator System.ComponentModel.PropertyDescriptorCollection::System.Collections.IEnumerable.GetEnumerator()
extern void PropertyDescriptorCollection_System_Collections_IEnumerable_GetEnumerator_m98DD98C01E84C0A8729E0C7EEDC9265A4911FB61 ();
// 0x00000336 System.Int32 System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.Add(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_Add_m7805DEADF351C068D3397DB5C6D84C639452B874 ();
// 0x00000337 System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.Clear()
extern void PropertyDescriptorCollection_System_Collections_IList_Clear_mB8004EB4547BD17A52732BB53EE9D54FAB27C638 ();
// 0x00000338 System.Boolean System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.Contains(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_Contains_m480A973ED000ECA6482E3BE2970009A09ED545FA ();
// 0x00000339 System.Int32 System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.IndexOf(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_IndexOf_m5784A077E0E4C9936D1DD476E58374AD27063CF7 ();
// 0x0000033A System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.Insert(System.Int32,System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_Insert_m8B356017EBDC3A70B466B4787016840F89074F0D ();
// 0x0000033B System.Boolean System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.get_IsReadOnly()
extern void PropertyDescriptorCollection_System_Collections_IList_get_IsReadOnly_mC37BCD9B3BE2F5B9773062BF82C3AA5D6645F227 ();
// 0x0000033C System.Boolean System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.get_IsFixedSize()
extern void PropertyDescriptorCollection_System_Collections_IList_get_IsFixedSize_m56B5321D84E8B06C5A557009E62A7335A4EFA018 ();
// 0x0000033D System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.Remove(System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_Remove_m23C0000AD3979585B0659FEBCDE0B3EFF1207FEC ();
// 0x0000033E System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.RemoveAt(System.Int32)
extern void PropertyDescriptorCollection_System_Collections_IList_RemoveAt_m9FD20F8FDF9167173D07E0FE7C22E0D3A85B781D ();
// 0x0000033F System.Object System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.get_Item(System.Int32)
extern void PropertyDescriptorCollection_System_Collections_IList_get_Item_m444F1383137CD08C6AE33B93743C22970975B68B ();
// 0x00000340 System.Void System.ComponentModel.PropertyDescriptorCollection::System.Collections.IList.set_Item(System.Int32,System.Object)
extern void PropertyDescriptorCollection_System_Collections_IList_set_Item_mC9C9476E42ADB9166CFD8FC7C7AA379EBB8F8E4B ();
// 0x00000341 System.Void System.ComponentModel.PropertyDescriptorCollection::.cctor()
extern void PropertyDescriptorCollection__cctor_m5DE8BDE158CD72E98E2ADD9DB3151F931CC9FB0F ();
// 0x00000342 System.Void System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::.ctor(System.ComponentModel.PropertyDescriptorCollection)
extern void PropertyDescriptorEnumerator__ctor_mD766982CCA3E90487BD77781B1EA0C29F9477B7D ();
// 0x00000343 System.Object System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::get_Current()
extern void PropertyDescriptorEnumerator_get_Current_m010FD0E05A0FA950A30C202CF643D7B3934557D8 ();
// 0x00000344 System.Collections.DictionaryEntry System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::get_Entry()
extern void PropertyDescriptorEnumerator_get_Entry_m8BDC6BA3A4A5620F2EA393763B6BF271FD58AB60 ();
// 0x00000345 System.Object System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::get_Key()
extern void PropertyDescriptorEnumerator_get_Key_m229FC1FF77DE80A679B1FE548094C02AF396A9B0 ();
// 0x00000346 System.Object System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::get_Value()
extern void PropertyDescriptorEnumerator_get_Value_mADCA4A1AE3EB26072C808EACB670596099943359 ();
// 0x00000347 System.Boolean System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::MoveNext()
extern void PropertyDescriptorEnumerator_MoveNext_m6AB35EFF1B4CC455D419DF2C4F55DFCFFE420E1B ();
// 0x00000348 System.Void System.ComponentModel.PropertyDescriptorCollection_PropertyDescriptorEnumerator::Reset()
extern void PropertyDescriptorEnumerator_Reset_m4FFA35A10951E339F0A75683E0151217D120329D ();
// 0x00000349 System.String System.ComponentModel.ProvidePropertyAttribute::get_PropertyName()
extern void ProvidePropertyAttribute_get_PropertyName_mCFB6B8ECE17E7FFD9FA7D5EE4FB0FACEDE552AEC ();
// 0x0000034A System.String System.ComponentModel.ProvidePropertyAttribute::get_ReceiverTypeName()
extern void ProvidePropertyAttribute_get_ReceiverTypeName_m66AECE2E8CB9069B1A1EC02C17BE84B4D176BB82 ();
// 0x0000034B System.Void System.ComponentModel.ReadOnlyAttribute::.ctor(System.Boolean)
extern void ReadOnlyAttribute__ctor_m57EACC99156B2E048A2BA49ACF9F58FBF6537752 ();
// 0x0000034C System.Boolean System.ComponentModel.ReadOnlyAttribute::get_IsReadOnly()
extern void ReadOnlyAttribute_get_IsReadOnly_m0626C74195DDB464E767AFE4CB8C205C267C8866 ();
// 0x0000034D System.Boolean System.ComponentModel.ReadOnlyAttribute::Equals(System.Object)
extern void ReadOnlyAttribute_Equals_m26B602C82A7F89B540D34BCC23DBAFEF44AA8F4F ();
// 0x0000034E System.Int32 System.ComponentModel.ReadOnlyAttribute::GetHashCode()
extern void ReadOnlyAttribute_GetHashCode_m697ACF28ADDA00FCE0470F0014FB341AB141796E ();
// 0x0000034F System.Boolean System.ComponentModel.ReadOnlyAttribute::IsDefaultAttribute()
extern void ReadOnlyAttribute_IsDefaultAttribute_mFE2BD94B822BE83971CA81A4A364ED0265E7B294 ();
// 0x00000350 System.Void System.ComponentModel.ReadOnlyAttribute::.cctor()
extern void ReadOnlyAttribute__cctor_m82F2AA3C79CBEBF7C845B6EF35A5774A25CB33C4 ();
// 0x00000351 System.Void System.ComponentModel.ReferenceConverter::.ctor(System.Type)
extern void ReferenceConverter__ctor_m2FB1721E7BE48D8857E0BF4690A1FB82C9EC1DC7 ();
// 0x00000352 System.Boolean System.ComponentModel.ReferenceConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void ReferenceConverter_CanConvertFrom_m5B23C497B2BFB682E5733F35369FB714098EA731 ();
// 0x00000353 System.Object System.ComponentModel.ReferenceConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void ReferenceConverter_ConvertFrom_m9D3A8DC96E994551E61A2432EDE3978A61370650 ();
// 0x00000354 System.Object System.ComponentModel.ReferenceConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void ReferenceConverter_ConvertTo_m82E3032D3598D3E709C5475209ADFE427FD7EDFE ();
// 0x00000355 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.ReferenceConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void ReferenceConverter_GetStandardValues_mF0F5434970C6CA3D182842120296A2FCC3928BE2 ();
// 0x00000356 System.Boolean System.ComponentModel.ReferenceConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void ReferenceConverter_GetStandardValuesExclusive_m4CCC72D62B9A051A01F70D48219920A639481B28 ();
// 0x00000357 System.Boolean System.ComponentModel.ReferenceConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void ReferenceConverter_GetStandardValuesSupported_mE721CE30F2B1CC5C3BE0A46B349D6C96F0932405 ();
// 0x00000358 System.Boolean System.ComponentModel.ReferenceConverter::IsValueAllowed(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void ReferenceConverter_IsValueAllowed_m1CFB041C5BF5BE8FA167627CCC406C607498C069 ();
// 0x00000359 System.Void System.ComponentModel.ReferenceConverter::.cctor()
extern void ReferenceConverter__cctor_m6B8D4BF669E7923D139320E54DF971BF30D4825C ();
// 0x0000035A System.Void System.ComponentModel.ReferenceConverter_ReferenceComparer::.ctor(System.ComponentModel.ReferenceConverter)
extern void ReferenceComparer__ctor_m7547D75DBAFDA96F03302A6FE4E5AE47153AE77E ();
// 0x0000035B System.Int32 System.ComponentModel.ReferenceConverter_ReferenceComparer::Compare(System.Object,System.Object)
extern void ReferenceComparer_Compare_m0B320ABB7F1A30AD4FB195849020B843764BE1D0 ();
// 0x0000035C System.Void System.ComponentModel.ReflectPropertyDescriptor::.ctor(System.Type,System.String,System.Type,System.Attribute[])
extern void ReflectPropertyDescriptor__ctor_mB5E1EB28647D1B39D7EEC2A60C41BD3F2B5EBB4E ();
// 0x0000035D System.Void System.ComponentModel.ReflectPropertyDescriptor::.ctor(System.Type,System.String,System.Type,System.Reflection.PropertyInfo,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Attribute[])
extern void ReflectPropertyDescriptor__ctor_m81658E6FF4EDE19BDC21661F2AD7F1D428DE2D90 ();
// 0x0000035E System.Void System.ComponentModel.ReflectPropertyDescriptor::.ctor(System.Type,System.String,System.Type,System.Type,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Attribute[])
extern void ReflectPropertyDescriptor__ctor_mED173B591B660C3642C4F39591EF6A2CBBA13C5F ();
// 0x0000035F System.Type System.ComponentModel.ReflectPropertyDescriptor::get_ComponentType()
extern void ReflectPropertyDescriptor_get_ComponentType_mBDBB35C343705F6E0BCF6E29CA74EE9AD7192C5E ();
// 0x00000360 System.Boolean System.ComponentModel.ReflectPropertyDescriptor::get_IsExtender()
extern void ReflectPropertyDescriptor_get_IsExtender_mFFEE1C5A723D8A0BBBAC2AFE3DA9B77D7821727A ();
// 0x00000361 System.Boolean System.ComponentModel.ReflectPropertyDescriptor::get_IsReadOnly()
extern void ReflectPropertyDescriptor_get_IsReadOnly_m5E22D2D628A2EE4DA486A40ED815A72C1574D641 ();
// 0x00000362 System.Type System.ComponentModel.ReflectPropertyDescriptor::get_PropertyType()
extern void ReflectPropertyDescriptor_get_PropertyType_m42BC13BCBD5DD4FADEF53D5BA86EB8BD8C1153F1 ();
// 0x00000363 System.Reflection.MethodInfo System.ComponentModel.ReflectPropertyDescriptor::get_SetMethodValue()
extern void ReflectPropertyDescriptor_get_SetMethodValue_m9C7CB91D0400A7450E620516B1A30B2FD37791A5 ();
// 0x00000364 System.Type System.ComponentModel.ReflectPropertyDescriptor::ExtenderGetReceiverType()
extern void ReflectPropertyDescriptor_ExtenderGetReceiverType_mEACD75A498F4FEA40302981092B93DBBC95EB1FA ();
// 0x00000365 System.Type System.ComponentModel.ReflectPropertyDescriptor::ExtenderGetType(System.ComponentModel.IExtenderProvider)
extern void ReflectPropertyDescriptor_ExtenderGetType_mD6042994CD9EFFCDE3177C09E58823CADA0CFBD7 ();
// 0x00000366 System.Void System.ComponentModel.ReflectPropertyDescriptor::FillAttributes(System.Collections.IList)
extern void ReflectPropertyDescriptor_FillAttributes_m6D3D9FF9C54562771EAFA7176184DF610B99B6EC ();
// 0x00000367 System.Void System.ComponentModel.ReflectPropertyDescriptor::.cctor()
extern void ReflectPropertyDescriptor__cctor_m63AF69EC4D3FA3894DDDFC6704D71401FE8DF9F3 ();
// 0x00000368 System.Void System.ComponentModel.ReflectTypeDescriptionProvider::.ctor()
extern void ReflectTypeDescriptionProvider__ctor_mE3E181FF24A78513F9E285D485FA292B11708B17 ();
// 0x00000369 System.Collections.Hashtable System.ComponentModel.ReflectTypeDescriptionProvider::get_IntrinsicTypeConverters()
extern void ReflectTypeDescriptionProvider_get_IntrinsicTypeConverters_m9CC87D07619955CD00731AD91FC7F8323C18AF4F ();
// 0x0000036A System.Object System.ComponentModel.ReflectTypeDescriptionProvider::CreateInstance(System.Type,System.Type)
extern void ReflectTypeDescriptionProvider_CreateInstance_m1A50E07E2455EA23FDE96B06EFD81DCA451025D4 ();
// 0x0000036B System.ComponentModel.AttributeCollection System.ComponentModel.ReflectTypeDescriptionProvider::GetAttributes(System.Type)
extern void ReflectTypeDescriptionProvider_GetAttributes_mD827142E84D2111FBD6F88118D1DD0BCF898700C ();
// 0x0000036C System.Collections.IDictionary System.ComponentModel.ReflectTypeDescriptionProvider::GetCache(System.Object)
extern void ReflectTypeDescriptionProvider_GetCache_m90103F5B0B173BA5AA6F8B773FA02EE66FA58D7F ();
// 0x0000036D System.ComponentModel.TypeConverter System.ComponentModel.ReflectTypeDescriptionProvider::GetConverter(System.Type,System.Object)
extern void ReflectTypeDescriptionProvider_GetConverter_mB8782B30A3D40FBDB37A4FD68A635149B0154880 ();
// 0x0000036E System.ComponentModel.AttributeCollection System.ComponentModel.ReflectTypeDescriptionProvider::GetExtendedAttributes(System.Object)
extern void ReflectTypeDescriptionProvider_GetExtendedAttributes_m27849C4290581FFD9B350AD671E5DE9764531E46 ();
// 0x0000036F System.ComponentModel.TypeConverter System.ComponentModel.ReflectTypeDescriptionProvider::GetExtendedConverter(System.Object)
extern void ReflectTypeDescriptionProvider_GetExtendedConverter_m54A3FED3A123C2C0375E2FBCA5C4B29C6220BA2D ();
// 0x00000370 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ReflectTypeDescriptionProvider::GetExtendedProperties(System.Object)
extern void ReflectTypeDescriptionProvider_GetExtendedProperties_mFFA65F71DEFE3C3EBEBF8EE010EA69F524AE3D1A ();
// 0x00000371 System.ComponentModel.IExtenderProvider[] System.ComponentModel.ReflectTypeDescriptionProvider::GetExtenderProviders(System.Object)
extern void ReflectTypeDescriptionProvider_GetExtenderProviders_mF9938FD27716A116007EF4F9E60B2E4E318D62F6 ();
// 0x00000372 System.ComponentModel.IExtenderProvider[] System.ComponentModel.ReflectTypeDescriptionProvider::GetExtenders(System.Collections.ICollection,System.Object,System.Collections.IDictionary)
extern void ReflectTypeDescriptionProvider_GetExtenders_m37F9CE244018FF66E847402A2E3F3A0F805D4843 ();
// 0x00000373 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.ReflectTypeDescriptionProvider::GetExtendedTypeDescriptor(System.Object)
extern void ReflectTypeDescriptionProvider_GetExtendedTypeDescriptor_mE33F57B6C037B34BACC549681047C513D9C6934F ();
// 0x00000374 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ReflectTypeDescriptionProvider::GetProperties(System.Type)
extern void ReflectTypeDescriptionProvider_GetProperties_m198ED05393452A6A44A4F073C6B6EA08F4C62C09 ();
// 0x00000375 System.Type System.ComponentModel.ReflectTypeDescriptionProvider::GetReflectionType(System.Type,System.Object)
extern void ReflectTypeDescriptionProvider_GetReflectionType_mF229DC91D51765143C01388F689FAA98EB4EC658 ();
// 0x00000376 System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData System.ComponentModel.ReflectTypeDescriptionProvider::GetTypeData(System.Type,System.Boolean)
extern void ReflectTypeDescriptionProvider_GetTypeData_m297505206CB7033A420244CD3962881B3FAA55E4 ();
// 0x00000377 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.ReflectTypeDescriptionProvider::GetTypeDescriptor(System.Type,System.Object)
extern void ReflectTypeDescriptionProvider_GetTypeDescriptor_m99EE1E613367E54A6132ADD94E0D34772BBEB67C ();
// 0x00000378 System.Type System.ComponentModel.ReflectTypeDescriptionProvider::GetTypeFromName(System.String)
extern void ReflectTypeDescriptionProvider_GetTypeFromName_mAAEB4488DDC97DDC4780EC28C8CF4BD27BB9E9EC ();
// 0x00000379 System.Boolean System.ComponentModel.ReflectTypeDescriptionProvider::IsPopulated(System.Type)
extern void ReflectTypeDescriptionProvider_IsPopulated_mDA141741A260991A87C6B4C7EE84FAB26220A534 ();
// 0x0000037A System.Attribute[] System.ComponentModel.ReflectTypeDescriptionProvider::ReflectGetAttributes(System.Type)
extern void ReflectTypeDescriptionProvider_ReflectGetAttributes_m378C9A3D2CB09CE7EBA76BCF431A99F6C2EF67DD ();
// 0x0000037B System.Attribute[] System.ComponentModel.ReflectTypeDescriptionProvider::ReflectGetAttributes(System.Reflection.MemberInfo)
extern void ReflectTypeDescriptionProvider_ReflectGetAttributes_mA3DA28648085382DC968178CE6B9D5288DE17739 ();
// 0x0000037C System.ComponentModel.PropertyDescriptor[] System.ComponentModel.ReflectTypeDescriptionProvider::ReflectGetExtendedProperties(System.ComponentModel.IExtenderProvider)
extern void ReflectTypeDescriptionProvider_ReflectGetExtendedProperties_m8DF1B37E62CB64A4249355F85F421C57BA1A16F1 ();
// 0x0000037D System.ComponentModel.PropertyDescriptor[] System.ComponentModel.ReflectTypeDescriptionProvider::ReflectGetProperties(System.Type)
extern void ReflectTypeDescriptionProvider_ReflectGetProperties_m0F7F5B7591FEC0B4F26419E559C20E3134F522B6 ();
// 0x0000037E System.Void System.ComponentModel.ReflectTypeDescriptionProvider::Refresh(System.Type)
extern void ReflectTypeDescriptionProvider_Refresh_m6C8F1779B16BB22FAAABA8E16E5DB5AB1025DF89 ();
// 0x0000037F System.Object System.ComponentModel.ReflectTypeDescriptionProvider::SearchIntrinsicTable(System.Collections.Hashtable,System.Type)
extern void ReflectTypeDescriptionProvider_SearchIntrinsicTable_mD70A9E795A2A1411479E8BB0ACE34604726C9D82 ();
// 0x00000380 System.Void System.ComponentModel.ReflectTypeDescriptionProvider::.cctor()
extern void ReflectTypeDescriptionProvider__cctor_mB9C7F73E1722134C687B3BB8E0F484EF2F30FEA5 ();
// 0x00000381 System.Void System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::.ctor(System.Type)
extern void ReflectedTypeData__ctor_mA8A7CF229ABE16D20515D5A827382370C78151AA ();
// 0x00000382 System.Boolean System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::get_IsPopulated()
extern void ReflectedTypeData_get_IsPopulated_m0BE08AAC57F2AA79A21B33C3A4A3FC7EECE35549 ();
// 0x00000383 System.ComponentModel.AttributeCollection System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::GetAttributes()
extern void ReflectedTypeData_GetAttributes_m663A1FD9948A46D290B3D9E033F291B1E535452E ();
// 0x00000384 System.ComponentModel.TypeConverter System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::GetConverter(System.Object)
extern void ReflectedTypeData_GetConverter_mD37346D7D19C72DC50CBB82BF4F4F9DF5218D0B6 ();
// 0x00000385 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::GetProperties()
extern void ReflectedTypeData_GetProperties_mEDCD21FF9DB7D27C3EF7ACC291E12B348AEC7CF5 ();
// 0x00000386 System.Type System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::GetTypeFromName(System.String)
extern void ReflectedTypeData_GetTypeFromName_m9E59CF61CA7CAC4E47B9736F36891FCB2E325D27 ();
// 0x00000387 System.Void System.ComponentModel.ReflectTypeDescriptionProvider_ReflectedTypeData::Refresh()
extern void ReflectedTypeData_Refresh_mA966D08F6AC6693D49DCB60CE3BF23ADBF4DE7BA ();
// 0x00000388 System.Void System.ComponentModel.RefreshEventArgs::.ctor(System.Type)
extern void RefreshEventArgs__ctor_mEC162508026E43A0B4E193163E6ED7D6B682D342 ();
// 0x00000389 System.Void System.ComponentModel.RefreshEventHandler::.ctor(System.Object,System.IntPtr)
extern void RefreshEventHandler__ctor_m37CAC58BA1E426C888118B568F540D5FA6E4E9CC ();
// 0x0000038A System.Void System.ComponentModel.RefreshEventHandler::Invoke(System.ComponentModel.RefreshEventArgs)
extern void RefreshEventHandler_Invoke_mF3ADA58FAFE8E56B53F99B9717A4D3E252575FF5 ();
// 0x0000038B System.IAsyncResult System.ComponentModel.RefreshEventHandler::BeginInvoke(System.ComponentModel.RefreshEventArgs,System.AsyncCallback,System.Object)
extern void RefreshEventHandler_BeginInvoke_m21258C5F768FBD9949B49F95A574B80981515AFF ();
// 0x0000038C System.Void System.ComponentModel.RefreshEventHandler::EndInvoke(System.IAsyncResult)
extern void RefreshEventHandler_EndInvoke_mAF60D2A0CC7D45F8AFD1C1135EA3DF225545C030 ();
// 0x0000038D System.Type System.ComponentModel.SByteConverter::get_TargetType()
extern void SByteConverter_get_TargetType_m034BBA889EAAC775483117120F159E328D1260D6 ();
// 0x0000038E System.Object System.ComponentModel.SByteConverter::FromString(System.String,System.Int32)
extern void SByteConverter_FromString_m0AE243DE3D62BE5B4D6B5902412E59B6F2B4C6B4 ();
// 0x0000038F System.Object System.ComponentModel.SByteConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void SByteConverter_FromString_mE18AD8A52E1E48B186DE67EAE676B20B29C69DD3 ();
// 0x00000390 System.Object System.ComponentModel.SByteConverter::FromString(System.String,System.Globalization.CultureInfo)
extern void SByteConverter_FromString_m7B5EE08AE984C1211B9647C245A9DB220C867467 ();
// 0x00000391 System.String System.ComponentModel.SByteConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void SByteConverter_ToString_m7DFD79BF472530D27DE2EFA08023C39AEF3EE048 ();
// 0x00000392 System.Void System.ComponentModel.SByteConverter::.ctor()
extern void SByteConverter__ctor_mA13FB10F00F75128F2A56113A5AEDEA2EDFB0826 ();
// 0x00000393 System.Boolean System.ComponentModel.SingleConverter::get_AllowHex()
extern void SingleConverter_get_AllowHex_m9A8EC29BC10782CF9BC2E9C526B1F958876DDA43 ();
// 0x00000394 System.Type System.ComponentModel.SingleConverter::get_TargetType()
extern void SingleConverter_get_TargetType_mEE841A77D0642D07A7978A8A871FD73DD57EB7DF ();
// 0x00000395 System.Object System.ComponentModel.SingleConverter::FromString(System.String,System.Int32)
extern void SingleConverter_FromString_mAE00A2E4F24907D0666B2C4B62833289E96FDE8C ();
// 0x00000396 System.Object System.ComponentModel.SingleConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void SingleConverter_FromString_mAB67D8A4BDEAC852EA4060FCE6F69C40F48E13DB ();
// 0x00000397 System.Object System.ComponentModel.SingleConverter::FromString(System.String,System.Globalization.CultureInfo)
extern void SingleConverter_FromString_mCE7472435CF8E8DF01D4B286AFFF545393E10E28 ();
// 0x00000398 System.String System.ComponentModel.SingleConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void SingleConverter_ToString_m5002E1C3937CECC3094583349B9EF72474524583 ();
// 0x00000399 System.Void System.ComponentModel.SingleConverter::.ctor()
extern void SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8 ();
// 0x0000039A System.Boolean System.ComponentModel.StringConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void StringConverter_CanConvertFrom_m50224B731176E5B25E43B35F74C0D1EA0859EC81 ();
// 0x0000039B System.Object System.ComponentModel.StringConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void StringConverter_ConvertFrom_mC11C90F2FD2BD033AEA354185DC892D951FA5005 ();
// 0x0000039C System.Void System.ComponentModel.StringConverter::.ctor()
extern void StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2 ();
// 0x0000039D System.Boolean System.ComponentModel.TimeSpanConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void TimeSpanConverter_CanConvertFrom_m693C336C7A5435912FC4AC569E1EAD30BEB32FFF ();
// 0x0000039E System.Boolean System.ComponentModel.TimeSpanConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void TimeSpanConverter_CanConvertTo_m5AC96B662FA4EACCEADAC81931591E0B14711276 ();
// 0x0000039F System.Object System.ComponentModel.TimeSpanConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void TimeSpanConverter_ConvertFrom_m4244DF51D5A1AC286C35FCE04D82F5A9A2F33894 ();
// 0x000003A0 System.Object System.ComponentModel.TimeSpanConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void TimeSpanConverter_ConvertTo_m6A1E0C832909670E26B892813AD9E14F08EE316E ();
// 0x000003A1 System.Void System.ComponentModel.TimeSpanConverter::.ctor()
extern void TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B ();
// 0x000003A2 System.Boolean System.ComponentModel.TypeConverter::get_UseCompatibleTypeConversion()
extern void TypeConverter_get_UseCompatibleTypeConversion_m4E8A4FB4000523FF099E5B064BF58BA44664E8CF ();
// 0x000003A3 System.Boolean System.ComponentModel.TypeConverter::CanConvertFrom(System.Type)
extern void TypeConverter_CanConvertFrom_mB405721DE7D2532FA893C4F9242BD7675784DF3D ();
// 0x000003A4 System.Boolean System.ComponentModel.TypeConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void TypeConverter_CanConvertFrom_m8E1F9E41B7DEE6A032EAC70130ADC6356C3F227D ();
// 0x000003A5 System.Boolean System.ComponentModel.TypeConverter::CanConvertTo(System.Type)
extern void TypeConverter_CanConvertTo_mFD084EFAE4C064C6844E20E5A0C6719925A2D938 ();
// 0x000003A6 System.Boolean System.ComponentModel.TypeConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void TypeConverter_CanConvertTo_m1CD3397D9E5717DE72A13B28C0A75D997A9F337D ();
// 0x000003A7 System.Object System.ComponentModel.TypeConverter::ConvertFrom(System.Object)
extern void TypeConverter_ConvertFrom_m3E71724F5033CD589B5D01DDD14E357582BD2476 ();
// 0x000003A8 System.Object System.ComponentModel.TypeConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void TypeConverter_ConvertFrom_mD5AE49E422520F6E07B3C0D6202788E49B4698A3 ();
// 0x000003A9 System.Object System.ComponentModel.TypeConverter::ConvertFromInvariantString(System.String)
extern void TypeConverter_ConvertFromInvariantString_m9293C7DF0805F4C7EA4510B71724BDAC3BE80AB2 ();
// 0x000003AA System.Object System.ComponentModel.TypeConverter::ConvertFromInvariantString(System.ComponentModel.ITypeDescriptorContext,System.String)
extern void TypeConverter_ConvertFromInvariantString_m8CA941FF49C01AB09F89531ACB3FDF4F97C041E2 ();
// 0x000003AB System.Object System.ComponentModel.TypeConverter::ConvertFromString(System.String)
extern void TypeConverter_ConvertFromString_m79BBFB959114D5294C21BD6FD0C4C0F826869202 ();
// 0x000003AC System.Object System.ComponentModel.TypeConverter::ConvertFromString(System.ComponentModel.ITypeDescriptorContext,System.String)
extern void TypeConverter_ConvertFromString_m24C4F0F94A2F6758E32DC307B232B29E2F05049A ();
// 0x000003AD System.Object System.ComponentModel.TypeConverter::ConvertFromString(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.String)
extern void TypeConverter_ConvertFromString_m29A7CD7DC7BD65459316FA4D807A1D16362C524E ();
// 0x000003AE System.Object System.ComponentModel.TypeConverter::ConvertTo(System.Object,System.Type)
extern void TypeConverter_ConvertTo_m7A68C74ECC7FD5C58919C9AAD0FA4389D4E56149 ();
// 0x000003AF System.Object System.ComponentModel.TypeConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void TypeConverter_ConvertTo_mFC7AA7F0A382607E75CCE820A705B5965D099AAC ();
// 0x000003B0 System.String System.ComponentModel.TypeConverter::ConvertToInvariantString(System.Object)
extern void TypeConverter_ConvertToInvariantString_m761850CEC1FEE3C82ABE5F794DE84FFE29C852A2 ();
// 0x000003B1 System.String System.ComponentModel.TypeConverter::ConvertToInvariantString(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void TypeConverter_ConvertToInvariantString_m382F27F2262271AB0775D6FA6F413D24BEA28808 ();
// 0x000003B2 System.String System.ComponentModel.TypeConverter::ConvertToString(System.Object)
extern void TypeConverter_ConvertToString_m2CBE8E127541982F2FB74F81D59AA62D097FD623 ();
// 0x000003B3 System.String System.ComponentModel.TypeConverter::ConvertToString(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void TypeConverter_ConvertToString_m5F4325990F5C0E979B0C18408D276534CC2B5101 ();
// 0x000003B4 System.String System.ComponentModel.TypeConverter::ConvertToString(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void TypeConverter_ConvertToString_m2601B49A8D7AB780DBA7F2DD08A3790DF7987FB4 ();
// 0x000003B5 System.Object System.ComponentModel.TypeConverter::CreateInstance(System.Collections.IDictionary)
extern void TypeConverter_CreateInstance_m910234390A61C68C5AEB1F0376D922C880254734 ();
// 0x000003B6 System.Object System.ComponentModel.TypeConverter::CreateInstance(System.ComponentModel.ITypeDescriptorContext,System.Collections.IDictionary)
extern void TypeConverter_CreateInstance_mDC7CFC64F7538582820FE98B48B025956549FA6F ();
// 0x000003B7 System.Exception System.ComponentModel.TypeConverter::GetConvertFromException(System.Object)
extern void TypeConverter_GetConvertFromException_m10012C012ED008F8AC9DF76BBAD93E19DDA6EAC3 ();
// 0x000003B8 System.Exception System.ComponentModel.TypeConverter::GetConvertToException(System.Object,System.Type)
extern void TypeConverter_GetConvertToException_mD906D7D39A16CC8ACFC0179208CE2627B73D5C32 ();
// 0x000003B9 System.Boolean System.ComponentModel.TypeConverter::GetCreateInstanceSupported()
extern void TypeConverter_GetCreateInstanceSupported_mCFECC64262DC92B2474D88446010AF0421EE7E07 ();
// 0x000003BA System.Boolean System.ComponentModel.TypeConverter::GetCreateInstanceSupported(System.ComponentModel.ITypeDescriptorContext)
extern void TypeConverter_GetCreateInstanceSupported_mA94E6A163BDDEF26EF22676B270763C010FA2D1C ();
// 0x000003BB System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeConverter::GetProperties(System.Object)
extern void TypeConverter_GetProperties_m02BA46C92F9265712A6637DDA1E4A0DBCFC10FAA ();
// 0x000003BC System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void TypeConverter_GetProperties_m5C07AE2E3658FB12366BFAA4A6DA26C9AA26F631 ();
// 0x000003BD System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeConverter::GetProperties(System.ComponentModel.ITypeDescriptorContext,System.Object,System.Attribute[])
extern void TypeConverter_GetProperties_mE9B2F1B88BC6A544E6FB1B5369A9603D24871DA1 ();
// 0x000003BE System.Boolean System.ComponentModel.TypeConverter::GetPropertiesSupported()
extern void TypeConverter_GetPropertiesSupported_m51BD8041C9104A4B4102444C6E3E6A876544D5E3 ();
// 0x000003BF System.Boolean System.ComponentModel.TypeConverter::GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void TypeConverter_GetPropertiesSupported_m689053FED1C08F4E898BC80D3E802866A08CCE1D ();
// 0x000003C0 System.Collections.ICollection System.ComponentModel.TypeConverter::GetStandardValues()
extern void TypeConverter_GetStandardValues_m0E0160DE18F9601C528E8CC773C8AC3873796060 ();
// 0x000003C1 System.ComponentModel.TypeConverter_StandardValuesCollection System.ComponentModel.TypeConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void TypeConverter_GetStandardValues_m58938306CEF726F9537744C71AC943E399D5F927 ();
// 0x000003C2 System.Boolean System.ComponentModel.TypeConverter::GetStandardValuesExclusive()
extern void TypeConverter_GetStandardValuesExclusive_mC8BBDA525FD8038D81EC1F3C0CA18F69A4DD58DA ();
// 0x000003C3 System.Boolean System.ComponentModel.TypeConverter::GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext)
extern void TypeConverter_GetStandardValuesExclusive_m6B189B96FF37D21B43FD397661F5C9960D7204E4 ();
// 0x000003C4 System.Boolean System.ComponentModel.TypeConverter::GetStandardValuesSupported()
extern void TypeConverter_GetStandardValuesSupported_mBD5FFD9335978CCD8C3A26F80D70D6B192E9E1DB ();
// 0x000003C5 System.Boolean System.ComponentModel.TypeConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void TypeConverter_GetStandardValuesSupported_mE7E8F04BE48835C994C035A90CBBFD7681B0D198 ();
// 0x000003C6 System.Boolean System.ComponentModel.TypeConverter::IsValid(System.Object)
extern void TypeConverter_IsValid_m464CADACE18B5EDEB9202AB8DBA183D8FB3463C3 ();
// 0x000003C7 System.Boolean System.ComponentModel.TypeConverter::IsValid(System.ComponentModel.ITypeDescriptorContext,System.Object)
extern void TypeConverter_IsValid_m7F461605B50FF4BAED21EB5B59C65459CF5DC8F4 ();
// 0x000003C8 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeConverter::SortProperties(System.ComponentModel.PropertyDescriptorCollection,System.String[])
extern void TypeConverter_SortProperties_m5AD81E82E93298C5FEAF26AC70BEC8EBF9981DA3 ();
// 0x000003C9 System.Void System.ComponentModel.TypeConverter::.ctor()
extern void TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD ();
// 0x000003CA System.Void System.ComponentModel.TypeConverter::.cctor()
extern void TypeConverter__cctor_mC99D8D0F3AA6CCB3E21123CFA7BAB73800CC38DC ();
// 0x000003CB System.Void System.ComponentModel.TypeConverter_SimplePropertyDescriptor::.ctor(System.Type,System.String,System.Type,System.Attribute[])
extern void SimplePropertyDescriptor__ctor_m8F44C82E16B8574F418418F47D8E6A3A52D0978A ();
// 0x000003CC System.Type System.ComponentModel.TypeConverter_SimplePropertyDescriptor::get_ComponentType()
extern void SimplePropertyDescriptor_get_ComponentType_m39197EC5A3662AA3D3C3BA74A3F65512D445DEE4 ();
// 0x000003CD System.Boolean System.ComponentModel.TypeConverter_SimplePropertyDescriptor::get_IsReadOnly()
extern void SimplePropertyDescriptor_get_IsReadOnly_mD5DD3E9534AFE907A9D3A6E1E00ECF6B35FE2F3D ();
// 0x000003CE System.Type System.ComponentModel.TypeConverter_SimplePropertyDescriptor::get_PropertyType()
extern void SimplePropertyDescriptor_get_PropertyType_mF8DD1C406A8679B366D7BC5DF4B0C72CDFFC31FA ();
// 0x000003CF System.Void System.ComponentModel.TypeConverter_StandardValuesCollection::.ctor(System.Collections.ICollection)
extern void StandardValuesCollection__ctor_m75578979BC0D77C0D622E4C9D7C1CB1E047615C1 ();
// 0x000003D0 System.Int32 System.ComponentModel.TypeConverter_StandardValuesCollection::get_Count()
extern void StandardValuesCollection_get_Count_mD0531EA777492E88EBEA8C6B8E8A12C4AFE5103A ();
// 0x000003D1 System.Void System.ComponentModel.TypeConverter_StandardValuesCollection::CopyTo(System.Array,System.Int32)
extern void StandardValuesCollection_CopyTo_mA319F11A11360C258FCEEF3C9EFA53D504BD7C3E ();
// 0x000003D2 System.Collections.IEnumerator System.ComponentModel.TypeConverter_StandardValuesCollection::GetEnumerator()
extern void StandardValuesCollection_GetEnumerator_m40E0D69CDEDD7EDE2D9454C4A18AA4C91A96B95F ();
// 0x000003D3 System.Int32 System.ComponentModel.TypeConverter_StandardValuesCollection::System.Collections.ICollection.get_Count()
extern void StandardValuesCollection_System_Collections_ICollection_get_Count_m3B04852950AC738A4E8AF41974DA6AFB1CC2BAD6 ();
// 0x000003D4 System.Object System.ComponentModel.TypeConverter_StandardValuesCollection::System.Collections.ICollection.get_SyncRoot()
extern void StandardValuesCollection_System_Collections_ICollection_get_SyncRoot_mF42D50E0E5A77DD85C897C37352834E2D4023810 ();
// 0x000003D5 System.Void System.ComponentModel.TypeConverter_StandardValuesCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void StandardValuesCollection_System_Collections_ICollection_CopyTo_m27D62D0B27B9151F55B3F3069E72B1B8ABEC5447 ();
// 0x000003D6 System.Collections.IEnumerator System.ComponentModel.TypeConverter_StandardValuesCollection::System.Collections.IEnumerable.GetEnumerator()
extern void StandardValuesCollection_System_Collections_IEnumerable_GetEnumerator_m017DACA9E9C081C4964887FF9E1F7D8A36B7BD8F ();
// 0x000003D7 System.Void System.ComponentModel.TypeConverterAttribute::.ctor()
extern void TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5 ();
// 0x000003D8 System.Void System.ComponentModel.TypeConverterAttribute::.ctor(System.Type)
extern void TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C ();
// 0x000003D9 System.String System.ComponentModel.TypeConverterAttribute::get_ConverterTypeName()
extern void TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8 ();
// 0x000003DA System.Boolean System.ComponentModel.TypeConverterAttribute::Equals(System.Object)
extern void TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4 ();
// 0x000003DB System.Int32 System.ComponentModel.TypeConverterAttribute::GetHashCode()
extern void TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA ();
// 0x000003DC System.Void System.ComponentModel.TypeConverterAttribute::.cctor()
extern void TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A ();
// 0x000003DD System.Void System.ComponentModel.TypeDescriptionProvider::.ctor()
extern void TypeDescriptionProvider__ctor_m9A35B40DE4D4CCB86B72BD3BABF375982DB32912 ();
// 0x000003DE System.Collections.IDictionary System.ComponentModel.TypeDescriptionProvider::GetCache(System.Object)
extern void TypeDescriptionProvider_GetCache_m9D7FBAC80ED350BC4C50D5C58FDB8F5C6DCDC2E8 ();
// 0x000003DF System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptionProvider::GetExtendedTypeDescriptor(System.Object)
extern void TypeDescriptionProvider_GetExtendedTypeDescriptor_mA6C0C2BCF78F4018FA4C2278CBFD07E2E77E3347 ();
// 0x000003E0 System.ComponentModel.IExtenderProvider[] System.ComponentModel.TypeDescriptionProvider::GetExtenderProviders(System.Object)
extern void TypeDescriptionProvider_GetExtenderProviders_mF8C68F2BA1E5CDDFAD9618C257F2D743FD10FF39 ();
// 0x000003E1 System.Type System.ComponentModel.TypeDescriptionProvider::GetReflectionType(System.Type)
extern void TypeDescriptionProvider_GetReflectionType_m5A731257A8DCBE75C4FE588A1CC73EE2FFCA7E16 ();
// 0x000003E2 System.Type System.ComponentModel.TypeDescriptionProvider::GetReflectionType(System.Type,System.Object)
extern void TypeDescriptionProvider_GetReflectionType_mEDACDCA9A57ADF6F376DD6847315931630CE538D ();
// 0x000003E3 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptionProvider::GetTypeDescriptor(System.Type)
extern void TypeDescriptionProvider_GetTypeDescriptor_m8CC34F54B8A643F99C2F4E4C254D661D3DC212D2 ();
// 0x000003E4 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptionProvider::GetTypeDescriptor(System.Object)
extern void TypeDescriptionProvider_GetTypeDescriptor_m04847083CB9DB8E7BF69CFCD06283A8D817293A0 ();
// 0x000003E5 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptionProvider::GetTypeDescriptor(System.Type,System.Object)
extern void TypeDescriptionProvider_GetTypeDescriptor_mE0B51D84608BE9DAB9597220D009C8F03ED7EE39 ();
// 0x000003E6 System.Void System.ComponentModel.TypeDescriptionProvider_EmptyCustomTypeDescriptor::.ctor()
extern void EmptyCustomTypeDescriptor__ctor_m3AF937D2171D0224FC6501A9AFA23F89BAC5B1D0 ();
// 0x000003E7 System.Void System.ComponentModel.TypeDescriptionProviderAttribute::.ctor(System.String)
extern void TypeDescriptionProviderAttribute__ctor_m10489BA811D0D61760F9C90B2D72542A08A3F90A ();
// 0x000003E8 System.String System.ComponentModel.TypeDescriptionProviderAttribute::get_TypeName()
extern void TypeDescriptionProviderAttribute_get_TypeName_m6C47AACE737391F28BD1C0A762AABBECA8DB8F75 ();
// 0x000003E9 System.Type System.ComponentModel.TypeDescriptor::get_ComObjectType()
extern void TypeDescriptor_get_ComObjectType_mD9A4F9CDA5863A62DEE85F88DECB3FF37CE42A4F ();
// 0x000003EA System.Type System.ComponentModel.TypeDescriptor::get_InterfaceType()
extern void TypeDescriptor_get_InterfaceType_m0DB3316CB939FE67643C044BAF39EB4F69D758E6 ();
// 0x000003EB System.Int32 System.ComponentModel.TypeDescriptor::get_MetadataVersion()
extern void TypeDescriptor_get_MetadataVersion_m70C215D1B15DCBD67B58127EB0E6D7E6F5D020DC ();
// 0x000003EC System.Void System.ComponentModel.TypeDescriptor::AddProvider(System.ComponentModel.TypeDescriptionProvider,System.Type)
extern void TypeDescriptor_AddProvider_mD81A072B4AB0D7801F9297879CB43071C8740C9A ();
// 0x000003ED System.Void System.ComponentModel.TypeDescriptor::CheckDefaultProvider(System.Type)
extern void TypeDescriptor_CheckDefaultProvider_m992A2ED0D5F3621C00369DF8CF35D6AFB17D3ADC ();
// 0x000003EE System.Collections.ArrayList System.ComponentModel.TypeDescriptor::FilterMembers(System.Collections.IList,System.Attribute[])
extern void TypeDescriptor_FilterMembers_m6DE8E2489628CB06AFAE539F0202E73AEB645AA9 ();
// 0x000003EF System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor::GetAttributes(System.Type)
extern void TypeDescriptor_GetAttributes_m945F6ABA03A5014918ACA5F9B57F1F58B805EC0B ();
// 0x000003F0 System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor::GetAttributes(System.Object)
extern void TypeDescriptor_GetAttributes_m0325F763D0AA6354E3F7859E15FF7BE3A8D5F3D3 ();
// 0x000003F1 System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor::GetAttributes(System.Object,System.Boolean)
extern void TypeDescriptor_GetAttributes_mA96E001729AC6C2EF5ED8E0E5573BABF67501C44 ();
// 0x000003F2 System.Collections.IDictionary System.ComponentModel.TypeDescriptor::GetCache(System.Object)
extern void TypeDescriptor_GetCache_mC7540D2FBAB562E689ED1BC2399D3F3C31D97145 ();
// 0x000003F3 System.ComponentModel.TypeConverter System.ComponentModel.TypeDescriptor::GetConverter(System.Type)
extern void TypeDescriptor_GetConverter_m30E075F6ED53FD85B7C1F7F44E58BA20645A68BA ();
// 0x000003F4 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptor::GetDescriptor(System.Type,System.String)
extern void TypeDescriptor_GetDescriptor_m03B8BB2FE0F4EB472FC543B31A37D627CD02D5EB ();
// 0x000003F5 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptor::GetDescriptor(System.Object,System.Boolean)
extern void TypeDescriptor_GetDescriptor_m557DDD4B793F92E5D71B980E264ACCF1C6A2EFB1 ();
// 0x000003F6 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptor::GetExtendedDescriptor(System.Object)
extern void TypeDescriptor_GetExtendedDescriptor_mD3B3C0990D1E6DF8A99C269710B4FC77DAC1BCFE ();
// 0x000003F7 System.String System.ComponentModel.TypeDescriptor::GetExtenderCollisionSuffix(System.ComponentModel.MemberDescriptor)
extern void TypeDescriptor_GetExtenderCollisionSuffix_m686BE0F744E8E5511310EA611B39FF891AEDC784 ();
// 0x000003F8 System.Type System.ComponentModel.TypeDescriptor::GetNodeForBaseType(System.Type)
extern void TypeDescriptor_GetNodeForBaseType_mD4DC672E329294D1CC62ED255A60FEB216151414 ();
// 0x000003F9 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor::GetProperties(System.Object,System.Attribute[])
extern void TypeDescriptor_GetProperties_m05CFF294019C93C8ADC7433BB7D5D87F19DDE7FC ();
// 0x000003FA System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor::GetProperties(System.Object,System.Attribute[],System.Boolean)
extern void TypeDescriptor_GetProperties_mD2A9DF20F4E4373E7144791303ECB062973647FA ();
// 0x000003FB System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor::GetPropertiesImpl(System.Object,System.Attribute[],System.Boolean,System.Boolean)
extern void TypeDescriptor_GetPropertiesImpl_m0F204546AFC2CCED7979E08E0FF134D7084DC248 ();
// 0x000003FC System.ComponentModel.TypeDescriptionProvider System.ComponentModel.TypeDescriptor::GetProviderRecursive(System.Type)
extern void TypeDescriptor_GetProviderRecursive_mFA9FD212A625262784E9B1B05D3B82564B393877 ();
// 0x000003FD System.Type System.ComponentModel.TypeDescriptor::GetReflectionType(System.Type)
extern void TypeDescriptor_GetReflectionType_mB28D64FBA294D618334381A77DAE790811611C3D ();
// 0x000003FE System.ComponentModel.TypeDescriptor_TypeDescriptionNode System.ComponentModel.TypeDescriptor::NodeFor(System.Type)
extern void TypeDescriptor_NodeFor_m767FF87E78839CA052D9BA45FC6E18BD28F8E2E2 ();
// 0x000003FF System.ComponentModel.TypeDescriptor_TypeDescriptionNode System.ComponentModel.TypeDescriptor::NodeFor(System.Type,System.Boolean)
extern void TypeDescriptor_NodeFor_m47CC24E4CFA599136DD05F6DD9A72A4B309D0D90 ();
// 0x00000400 System.ComponentModel.TypeDescriptor_TypeDescriptionNode System.ComponentModel.TypeDescriptor::NodeFor(System.Object)
extern void TypeDescriptor_NodeFor_m5CD091DA5BF7D035FA36E6E397A96B2A9610E9D5 ();
// 0x00000401 System.ComponentModel.TypeDescriptor_TypeDescriptionNode System.ComponentModel.TypeDescriptor::NodeFor(System.Object,System.Boolean)
extern void TypeDescriptor_NodeFor_m90ADBC22F629303B34247E6000724298EDDF3E61 ();
// 0x00000402 System.Collections.ICollection System.ComponentModel.TypeDescriptor::PipelineAttributeFilter(System.Int32,System.Collections.ICollection,System.Attribute[],System.Object,System.Collections.IDictionary)
extern void TypeDescriptor_PipelineAttributeFilter_mDFD0C9F6114800954B3A9275EB4109520570307D ();
// 0x00000403 System.Collections.ICollection System.ComponentModel.TypeDescriptor::PipelineFilter(System.Int32,System.Collections.ICollection,System.Object,System.Collections.IDictionary)
extern void TypeDescriptor_PipelineFilter_m7522739B5B21B076A5722C659E9B17A404196487 ();
// 0x00000404 System.Collections.ICollection System.ComponentModel.TypeDescriptor::PipelineInitialize(System.Int32,System.Collections.ICollection,System.Collections.IDictionary)
extern void TypeDescriptor_PipelineInitialize_mE238329E4034835777FC35289A14EA9A1397CF66 ();
// 0x00000405 System.Collections.ICollection System.ComponentModel.TypeDescriptor::PipelineMerge(System.Int32,System.Collections.ICollection,System.Collections.ICollection,System.Object,System.Collections.IDictionary)
extern void TypeDescriptor_PipelineMerge_m12CD63D0457BCA451AF9635E4E754A1E27122E65 ();
// 0x00000406 System.Void System.ComponentModel.TypeDescriptor::RaiseRefresh(System.Type)
extern void TypeDescriptor_RaiseRefresh_m75708E2026685B087D03E5383F08E65F1608332C ();
// 0x00000407 System.Void System.ComponentModel.TypeDescriptor::Refresh(System.Type)
extern void TypeDescriptor_Refresh_m3EE0C2B17D9683C6C719C590D0D9744D16F58027 ();
// 0x00000408 System.Boolean System.ComponentModel.TypeDescriptor::ShouldHideMember(System.ComponentModel.MemberDescriptor,System.Attribute)
extern void TypeDescriptor_ShouldHideMember_m7530A7627AB76EB292A22E86DA7D4B1A8DFEAF01 ();
// 0x00000409 System.Void System.ComponentModel.TypeDescriptor::SortDescriptorArray(System.Collections.IList)
extern void TypeDescriptor_SortDescriptorArray_mF1BF8FDE18108198B6E5CF6B31909A7F544F649C ();
// 0x0000040A System.Void System.ComponentModel.TypeDescriptor::.cctor()
extern void TypeDescriptor__cctor_m93DDEDF2D6E089FEFA7A29B425C854E1E04E6145 ();
// 0x0000040B System.Void System.ComponentModel.TypeDescriptor_AttributeFilterCacheItem::.ctor(System.Attribute[],System.Collections.ICollection)
extern void AttributeFilterCacheItem__ctor_m8319ED63E0DDDB46F62ED8DBC04CCD530C477AAF ();
// 0x0000040C System.Boolean System.ComponentModel.TypeDescriptor_AttributeFilterCacheItem::IsValid(System.Attribute[])
extern void AttributeFilterCacheItem_IsValid_m0218A992CF2B98E84CD36A2C037F948A5DDB6BF9 ();
// 0x0000040D System.Void System.ComponentModel.TypeDescriptor_FilterCacheItem::.ctor(System.ComponentModel.Design.ITypeDescriptorFilterService,System.Collections.ICollection)
extern void FilterCacheItem__ctor_m9398DF7D02FBE4926AFB8D768F6F0936E0929181 ();
// 0x0000040E System.Boolean System.ComponentModel.TypeDescriptor_FilterCacheItem::IsValid(System.ComponentModel.Design.ITypeDescriptorFilterService)
extern void FilterCacheItem_IsValid_m91C02B95AF49F2BD09314CF2EB67F6090052B8B4 ();
// 0x0000040F System.Int32 System.ComponentModel.TypeDescriptor_MemberDescriptorComparer::Compare(System.Object,System.Object)
extern void MemberDescriptorComparer_Compare_m9C56C6E64A892DB13EEB4B1F551B6F161B4C237E ();
// 0x00000410 System.Void System.ComponentModel.TypeDescriptor_MemberDescriptorComparer::.ctor()
extern void MemberDescriptorComparer__ctor_mE0D379E9AA3712B69614E48771226910DE517618 ();
// 0x00000411 System.Void System.ComponentModel.TypeDescriptor_MemberDescriptorComparer::.cctor()
extern void MemberDescriptorComparer__cctor_m9E4FF9CCCC93BEE24671FD459069CB7793ED97C6 ();
// 0x00000412 System.Void System.ComponentModel.TypeDescriptor_MergedTypeDescriptor::.ctor(System.ComponentModel.ICustomTypeDescriptor,System.ComponentModel.ICustomTypeDescriptor)
extern void MergedTypeDescriptor__ctor_m07BED02593A42C075C4F95B23D208CF1222C12A0 ();
// 0x00000413 System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor_MergedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetAttributes()
extern void MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_m2DD60D9C133AE18F38D7A27189168A2FBF3729FD ();
// 0x00000414 System.ComponentModel.TypeConverter System.ComponentModel.TypeDescriptor_MergedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetConverter()
extern void MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mFC2AC7E8BEF7680E424A34D335EB4FCC9A6BACB6 ();
// 0x00000415 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_MergedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties()
extern void MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m5C461A51153A91C829F3F75CC2E2D7AD2933BC69 ();
// 0x00000416 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_MergedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties(System.Attribute[])
extern void MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m9C59F8E3A2F518EBBE770B6ABE66B82796B18F63 ();
// 0x00000417 System.Void System.ComponentModel.TypeDescriptor_TypeDescriptionNode::.ctor(System.ComponentModel.TypeDescriptionProvider)
extern void TypeDescriptionNode__ctor_m18D16A33443D7C6C32D09203AE94E5A5DA65BDFF ();
// 0x00000418 System.Collections.IDictionary System.ComponentModel.TypeDescriptor_TypeDescriptionNode::GetCache(System.Object)
extern void TypeDescriptionNode_GetCache_m275E9B8AA100455DA54B9CBD3581B9556C5DE825 ();
// 0x00000419 System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptor_TypeDescriptionNode::GetExtendedTypeDescriptor(System.Object)
extern void TypeDescriptionNode_GetExtendedTypeDescriptor_m014DF481F410A49BBB0B087DD65EA4DBD51E9AF2 ();
// 0x0000041A System.ComponentModel.IExtenderProvider[] System.ComponentModel.TypeDescriptor_TypeDescriptionNode::GetExtenderProviders(System.Object)
extern void TypeDescriptionNode_GetExtenderProviders_mA26764DE3C998BCD030B9E111462EB622BB127BE ();
// 0x0000041B System.Type System.ComponentModel.TypeDescriptor_TypeDescriptionNode::GetReflectionType(System.Type,System.Object)
extern void TypeDescriptionNode_GetReflectionType_m4C80319088CB3DFFEF76A5DB4C862FCDD98BDC92 ();
// 0x0000041C System.ComponentModel.ICustomTypeDescriptor System.ComponentModel.TypeDescriptor_TypeDescriptionNode::GetTypeDescriptor(System.Type,System.Object)
extern void TypeDescriptionNode_GetTypeDescriptor_m55BB50B1A0B0542BD4736FE3F7A14A7ABEC94903 ();
// 0x0000041D System.Void System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultExtendedTypeDescriptor::.ctor(System.ComponentModel.TypeDescriptor_TypeDescriptionNode,System.Object)
extern void DefaultExtendedTypeDescriptor__ctor_mD297D84C0AEF8C2AF0867391BD0FD037D8E6AB86_AdjustorThunk ();
// 0x0000041E System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultExtendedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetAttributes()
extern void DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_mF4C670B634C8C86057E939F3DD5EAA4173DAB1A8_AdjustorThunk ();
// 0x0000041F System.ComponentModel.TypeConverter System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultExtendedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetConverter()
extern void DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mE26BB774C31A0760EC238B30A3BDE0EE202EF1A6_AdjustorThunk ();
// 0x00000420 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultExtendedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties()
extern void DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_mCD9AF5CF5F30A8A6F9125272F6AB969039A96DA7_AdjustorThunk ();
// 0x00000421 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultExtendedTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties(System.Attribute[])
extern void DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m46AE37DFC7FBE5AE7641AD20F09C09109313E2AC_AdjustorThunk ();
// 0x00000422 System.Void System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultTypeDescriptor::.ctor(System.ComponentModel.TypeDescriptor_TypeDescriptionNode,System.Type,System.Object)
extern void DefaultTypeDescriptor__ctor_m8542D50B70E1A86255B2C64908C9397B971BBC90_AdjustorThunk ();
// 0x00000423 System.ComponentModel.AttributeCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetAttributes()
extern void DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_m6EEBB8DB4E72761D9CB03978D149295CFE2B39EC_AdjustorThunk ();
// 0x00000424 System.ComponentModel.TypeConverter System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetConverter()
extern void DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mA5D26F3E5D42548F740BD72B1AA9AE1CE89EC6E7_AdjustorThunk ();
// 0x00000425 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties()
extern void DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_mE25AA0FCA6D4DAD1D1C671F258B3C9B23A9D3354_AdjustorThunk ();
// 0x00000426 System.ComponentModel.PropertyDescriptorCollection System.ComponentModel.TypeDescriptor_TypeDescriptionNode_DefaultTypeDescriptor::System.ComponentModel.ICustomTypeDescriptor.GetProperties(System.Attribute[])
extern void DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m45476E33EA6039C732EF799D4E95FAE74AD67B36_AdjustorThunk ();
// 0x00000427 System.Type System.ComponentModel.UInt16Converter::get_TargetType()
extern void UInt16Converter_get_TargetType_m09485223873376B5306CC41EE00DE41C7C9A4D48 ();
// 0x00000428 System.Object System.ComponentModel.UInt16Converter::FromString(System.String,System.Int32)
extern void UInt16Converter_FromString_m6C68C86307AAFB890294E95FAFEEC5558F898B7B ();
// 0x00000429 System.Object System.ComponentModel.UInt16Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void UInt16Converter_FromString_m086976C0A5AE966B1BF493EF9215D7CD5FA1E248 ();
// 0x0000042A System.Object System.ComponentModel.UInt16Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void UInt16Converter_FromString_m33761AE9D171E9D4ADB9875D87F55FB078ACA9E9 ();
// 0x0000042B System.String System.ComponentModel.UInt16Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void UInt16Converter_ToString_m104A682B05A314790038B0F6C080A2242B813E62 ();
// 0x0000042C System.Void System.ComponentModel.UInt16Converter::.ctor()
extern void UInt16Converter__ctor_m64B8902701F454D776E92A8373B7D0C923F7507D ();
// 0x0000042D System.Type System.ComponentModel.UInt32Converter::get_TargetType()
extern void UInt32Converter_get_TargetType_mB0970D9A54AF4DBB22763BCF302C1BF96987514D ();
// 0x0000042E System.Object System.ComponentModel.UInt32Converter::FromString(System.String,System.Int32)
extern void UInt32Converter_FromString_mC2A923816231211450F8DE19A663F73CC32F9C23 ();
// 0x0000042F System.Object System.ComponentModel.UInt32Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void UInt32Converter_FromString_m3311119AE44125DA0CF3703D93966E7D3B9A66A7 ();
// 0x00000430 System.Object System.ComponentModel.UInt32Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void UInt32Converter_FromString_mC1772B9D65A03EF96521A527EFC9C1B55C353908 ();
// 0x00000431 System.String System.ComponentModel.UInt32Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void UInt32Converter_ToString_m19F6F8A0D732BA61405B020CF1D2A1EDF6847AA6 ();
// 0x00000432 System.Void System.ComponentModel.UInt32Converter::.ctor()
extern void UInt32Converter__ctor_mAC512A9B15152E36517BFB4434889F79E154C60E ();
// 0x00000433 System.Type System.ComponentModel.UInt64Converter::get_TargetType()
extern void UInt64Converter_get_TargetType_mFDC942E31D697EB81B1BC6F2DC0C1984E5B4CDF2 ();
// 0x00000434 System.Object System.ComponentModel.UInt64Converter::FromString(System.String,System.Int32)
extern void UInt64Converter_FromString_m0F4D6141688C8C778E7B5CF3F38F8F2FDC88308C ();
// 0x00000435 System.Object System.ComponentModel.UInt64Converter::FromString(System.String,System.Globalization.NumberFormatInfo)
extern void UInt64Converter_FromString_m335C75F6E6840F7BF678CB73845C905C1216671C ();
// 0x00000436 System.Object System.ComponentModel.UInt64Converter::FromString(System.String,System.Globalization.CultureInfo)
extern void UInt64Converter_FromString_m119E342F5A0A5553CB6A328DADFAFE509FCB72BC ();
// 0x00000437 System.String System.ComponentModel.UInt64Converter::ToString(System.Object,System.Globalization.NumberFormatInfo)
extern void UInt64Converter_ToString_mB2E701BBFDC1465555D4049C047FBEB8888E29D5 ();
// 0x00000438 System.Void System.ComponentModel.UInt64Converter::.ctor()
extern void UInt64Converter__ctor_m90B1A912D739A0CB3C30A5BC466DB7A235FB1275 ();
// 0x00000439 System.Void System.ComponentModel.Win32Exception::.ctor()
extern void Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759 ();
// 0x0000043A System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32)
extern void Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714 ();
// 0x0000043B System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32,System.String)
extern void Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6 ();
// 0x0000043C System.Void System.ComponentModel.Win32Exception::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB ();
// 0x0000043D System.Void System.ComponentModel.Win32Exception::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8 ();
// 0x0000043E System.String System.ComponentModel.Win32Exception::GetErrorMessage(System.Int32)
extern void Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D ();
// 0x0000043F System.Void System.ComponentModel.Win32Exception::InitializeErrorMessages()
extern void Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438 ();
// 0x00000440 System.Void System.ComponentModel.Win32Exception::.cctor()
extern void Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52 ();
// 0x00000441 System.Boolean System.ComponentModel.BaseNumberConverter::get_AllowHex()
extern void BaseNumberConverter_get_AllowHex_m994DD130AADA77ADA7E3AF7DF18674E617417CED ();
// 0x00000442 System.Type System.ComponentModel.BaseNumberConverter::get_TargetType()
// 0x00000443 System.Object System.ComponentModel.BaseNumberConverter::FromString(System.String,System.Int32)
// 0x00000444 System.Object System.ComponentModel.BaseNumberConverter::FromString(System.String,System.Globalization.NumberFormatInfo)
// 0x00000445 System.Object System.ComponentModel.BaseNumberConverter::FromString(System.String,System.Globalization.CultureInfo)
// 0x00000446 System.Exception System.ComponentModel.BaseNumberConverter::FromStringError(System.String,System.Exception)
extern void BaseNumberConverter_FromStringError_mF63BDCFB96540E83A867B6F206D2C453B9BB0A42 ();
// 0x00000447 System.String System.ComponentModel.BaseNumberConverter::ToString(System.Object,System.Globalization.NumberFormatInfo)
// 0x00000448 System.Boolean System.ComponentModel.BaseNumberConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void BaseNumberConverter_CanConvertFrom_mCAE77B4E99810F0C9B06FCB2F4F7036C733E3016 ();
// 0x00000449 System.Object System.ComponentModel.BaseNumberConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void BaseNumberConverter_ConvertFrom_mA629768C8117947BD168EACC84D02DBA1FCA51E6 ();
// 0x0000044A System.Object System.ComponentModel.BaseNumberConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void BaseNumberConverter_ConvertTo_m672375F1E58DB241E693E5F45A7FFD38C3070B6A ();
// 0x0000044B System.Boolean System.ComponentModel.BaseNumberConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void BaseNumberConverter_CanConvertTo_mBAA70FD6742A616F9E0F9E42908EF6C70C3214B7 ();
// 0x0000044C System.Void System.ComponentModel.BaseNumberConverter::.ctor()
extern void BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83 ();
// 0x0000044D System.Void System.ComponentModel.WeakHashtable::.ctor()
extern void WeakHashtable__ctor_mE6517A855F67EE9584AF60DB7BC3AF5B2D58C249 ();
// 0x0000044E System.Void System.ComponentModel.WeakHashtable::Clear()
extern void WeakHashtable_Clear_m0559384B1ED014495416A4CD76EE26A8CCBD9531 ();
// 0x0000044F System.Void System.ComponentModel.WeakHashtable::Remove(System.Object)
extern void WeakHashtable_Remove_m6780AE4C0C4B072B9857C7A11ABC6AAF4805F9D3 ();
// 0x00000450 System.Void System.ComponentModel.WeakHashtable::.cctor()
extern void WeakHashtable__cctor_m7EECB04C288887CC895D8ED91A837C7822A299CE ();
// 0x00000451 System.Boolean System.ComponentModel.WeakHashtable_WeakKeyComparer::System.Collections.IEqualityComparer.Equals(System.Object,System.Object)
extern void WeakKeyComparer_System_Collections_IEqualityComparer_Equals_mC3D733EAC828C7C1C1B8F0890B0CD86F67F3668C ();
// 0x00000452 System.Int32 System.ComponentModel.WeakHashtable_WeakKeyComparer::System.Collections.IEqualityComparer.GetHashCode(System.Object)
extern void WeakKeyComparer_System_Collections_IEqualityComparer_GetHashCode_m8A2DBF9E2E7D75717DF22C7CF88550E0502E2F98 ();
// 0x00000453 System.Void System.ComponentModel.WeakHashtable_WeakKeyComparer::.ctor()
extern void WeakKeyComparer__ctor_m084512BBA20EA3050E018C920AF05AA43F1EC704 ();
// 0x00000454 System.Object System.ComponentModel.Design.IDictionaryService::GetValue(System.Object)
// 0x00000455 System.Void System.ComponentModel.Design.IDictionaryService::SetValue(System.Object,System.Object)
// 0x00000456 System.ComponentModel.IExtenderProvider[] System.ComponentModel.Design.IExtenderListService::GetExtenderProviders()
// 0x00000457 System.Object System.ComponentModel.Design.IReferenceService::GetReference(System.String)
// 0x00000458 System.String System.ComponentModel.Design.IReferenceService::GetName(System.Object)
// 0x00000459 System.Object[] System.ComponentModel.Design.IReferenceService::GetReferences(System.Type)
// 0x0000045A System.Boolean System.ComponentModel.Design.ITypeDescriptorFilterService::FilterAttributes(System.ComponentModel.IComponent,System.Collections.IDictionary)
// 0x0000045B System.Boolean System.ComponentModel.Design.ITypeDescriptorFilterService::FilterEvents(System.ComponentModel.IComponent,System.Collections.IDictionary)
// 0x0000045C System.Boolean System.ComponentModel.Design.ITypeDescriptorFilterService::FilterProperties(System.ComponentModel.IComponent,System.Collections.IDictionary)
// 0x0000045D System.Void System.ComponentModel.Design.Serialization.InstanceDescriptor::.ctor(System.Reflection.MemberInfo,System.Collections.ICollection)
extern void InstanceDescriptor__ctor_m90DA8CABB01052EA5C5022E14FE50533254C71DD ();
// 0x0000045E System.Void System.ComponentModel.Design.Serialization.InstanceDescriptor::.ctor(System.Reflection.MemberInfo,System.Collections.ICollection,System.Boolean)
extern void InstanceDescriptor__ctor_m47D0A6167384EA496F0734E951DECD7EE576CAC4 ();
// 0x0000045F System.Object System.ComponentModel.Design.Serialization.InstanceDescriptor::Invoke()
extern void InstanceDescriptor_Invoke_mFA1E52E0F4971ABC4432D30F7CF80304272355C0 ();
// 0x00000460 System.Void System.ComponentModel.Design.Serialization.RootDesignerSerializerAttribute::.ctor(System.String,System.String,System.Boolean)
extern void RootDesignerSerializerAttribute__ctor_m0F3B236B6A2362EEF20773BC3205FE7DA72AD6AE ();
// 0x00000461 System.Object System.ComponentModel.Design.Serialization.RootDesignerSerializerAttribute::get_TypeId()
extern void RootDesignerSerializerAttribute_get_TypeId_mC34D430C36628B810BB11754EAD222F65805D2A7 ();
// 0x00000462 System.Void System.Security.Cryptography.Oid::.ctor(System.String)
extern void Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743 ();
// 0x00000463 System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.Security.Cryptography.OidGroup,System.Boolean)
extern void Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC ();
// 0x00000464 System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.String)
extern void Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985 ();
// 0x00000465 System.Void System.Security.Cryptography.Oid::.ctor(System.Security.Cryptography.Oid)
extern void Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079 ();
// 0x00000466 System.String System.Security.Cryptography.Oid::get_Value()
extern void Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05 ();
// 0x00000467 System.Void System.Security.Cryptography.Oid::set_Value(System.String)
extern void Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F ();
// 0x00000468 System.Void System.Security.Cryptography.OidCollection::.ctor()
extern void OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800 ();
// 0x00000469 System.Int32 System.Security.Cryptography.OidCollection::Add(System.Security.Cryptography.Oid)
extern void OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C ();
// 0x0000046A System.Security.Cryptography.Oid System.Security.Cryptography.OidCollection::get_Item(System.Int32)
extern void OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9 ();
// 0x0000046B System.Int32 System.Security.Cryptography.OidCollection::get_Count()
extern void OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2 ();
// 0x0000046C System.Collections.IEnumerator System.Security.Cryptography.OidCollection::System.Collections.IEnumerable.GetEnumerator()
extern void OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30 ();
// 0x0000046D System.Void System.Security.Cryptography.OidCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9 ();
// 0x0000046E System.Object System.Security.Cryptography.OidCollection::get_SyncRoot()
extern void OidCollection_get_SyncRoot_m6C13949F67338F684C29DD162C8228986DAB6850 ();
// 0x0000046F System.Void System.Security.Cryptography.OidEnumerator::.ctor(System.Security.Cryptography.OidCollection)
extern void OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797 ();
// 0x00000470 System.Object System.Security.Cryptography.OidEnumerator::System.Collections.IEnumerator.get_Current()
extern void OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53 ();
// 0x00000471 System.Boolean System.Security.Cryptography.OidEnumerator::MoveNext()
extern void OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D ();
// 0x00000472 System.Void System.Security.Cryptography.OidEnumerator::Reset()
extern void OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E ();
// 0x00000473 System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoNameFromKey(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698 ();
// 0x00000474 System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoKeyFromName(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB ();
// 0x00000475 System.Void System.Security.Cryptography.AsnEncodedData::.ctor()
extern void AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6 ();
// 0x00000476 System.Void System.Security.Cryptography.AsnEncodedData::set_Oid(System.Security.Cryptography.Oid)
extern void AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6 ();
// 0x00000477 System.Byte[] System.Security.Cryptography.AsnEncodedData::get_RawData()
extern void AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC ();
// 0x00000478 System.Void System.Security.Cryptography.AsnEncodedData::set_RawData(System.Byte[])
extern void AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC ();
// 0x00000479 System.Void System.Security.Cryptography.AsnEncodedData::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7 ();
// 0x0000047A System.String System.Security.Cryptography.AsnEncodedData::ToString(System.Boolean)
extern void AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7 ();
// 0x0000047B System.String System.Security.Cryptography.AsnEncodedData::Default(System.Boolean)
extern void AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07 ();
// 0x0000047C System.String System.Security.Cryptography.AsnEncodedData::BasicConstraintsExtension(System.Boolean)
extern void AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182 ();
// 0x0000047D System.String System.Security.Cryptography.AsnEncodedData::EnhancedKeyUsageExtension(System.Boolean)
extern void AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058 ();
// 0x0000047E System.String System.Security.Cryptography.AsnEncodedData::KeyUsageExtension(System.Boolean)
extern void AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590 ();
// 0x0000047F System.String System.Security.Cryptography.AsnEncodedData::SubjectKeyIdentifierExtension(System.Boolean)
extern void AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76 ();
// 0x00000480 System.String System.Security.Cryptography.AsnEncodedData::SubjectAltName(System.Boolean)
extern void AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49 ();
// 0x00000481 System.String System.Security.Cryptography.AsnEncodedData::NetscapeCertType(System.Boolean)
extern void AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4 ();
// 0x00000482 System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfo(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2 ();
// 0x00000483 System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfoWithFallback(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950 ();
// 0x00000484 System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedKeyValue()
extern void PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F ();
// 0x00000485 System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedParameters()
extern void PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F ();
// 0x00000486 System.Security.Cryptography.Oid System.Security.Cryptography.X509Certificates.PublicKey::get_Oid()
extern void PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE ();
// 0x00000487 System.Void System.Security.Cryptography.X509Certificates.PublicKey::.cctor()
extern void PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC ();
// 0x00000488 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor()
extern void X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C ();
// 0x00000489 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729 ();
// 0x0000048A System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Boolean,System.Boolean,System.Int32,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780 ();
// 0x0000048B System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_CertificateAuthority()
extern void X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F ();
// 0x0000048C System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_HasPathLengthConstraint()
extern void X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42 ();
// 0x0000048D System.Int32 System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_PathLengthConstraint()
extern void X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F ();
// 0x0000048E System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC ();
// 0x0000048F System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Decode(System.Byte[])
extern void X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81 ();
// 0x00000490 System.Byte[] System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Encode()
extern void X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF ();
// 0x00000491 System.String System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::ToString(System.Boolean)
extern void X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336 ();
// 0x00000492 System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2 ();
// 0x00000493 System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A ();
// 0x00000494 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::Decode(System.Byte[])
extern void X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D ();
// 0x00000495 System.String System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::ToString(System.Boolean)
extern void X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818 ();
// 0x00000496 System.Void System.Security.Cryptography.X509Certificates.X509Extension::.ctor()
extern void X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384 ();
// 0x00000497 System.Boolean System.Security.Cryptography.X509Certificates.X509Extension::get_Critical()
extern void X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2 ();
// 0x00000498 System.Void System.Security.Cryptography.X509Certificates.X509Extension::set_Critical(System.Boolean)
extern void X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4 ();
// 0x00000499 System.Void System.Security.Cryptography.X509Certificates.X509Extension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02 ();
// 0x0000049A System.String System.Security.Cryptography.X509Certificates.X509Extension::FormatUnkownData(System.Byte[])
extern void X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A ();
// 0x0000049B System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor()
extern void X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99 ();
// 0x0000049C System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018 ();
// 0x0000049D System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags,System.Boolean)
extern void X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426 ();
// 0x0000049E System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::get_KeyUsages()
extern void X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505 ();
// 0x0000049F System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F ();
// 0x000004A0 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::GetValidFlags(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)
extern void X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB ();
// 0x000004A1 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Decode(System.Byte[])
extern void X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2 ();
// 0x000004A2 System.Byte[] System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Encode()
extern void X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360 ();
// 0x000004A3 System.String System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::ToString(System.Boolean)
extern void X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC ();
// 0x000004A4 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor()
extern void X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29 ();
// 0x000004A5 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6 ();
// 0x000004A6 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Byte[],System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B ();
// 0x000004A7 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.String,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432 ();
// 0x000004A8 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3 ();
// 0x000004A9 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierHashAlgorithm,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1 ();
// 0x000004AA System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::get_SubjectKeyIdentifier()
extern void X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF ();
// 0x000004AB System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC ();
// 0x000004AC System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChar(System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC ();
// 0x000004AD System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChars(System.Char,System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38 ();
// 0x000004AE System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHex(System.String)
extern void X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B ();
// 0x000004AF System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Decode(System.Byte[])
extern void X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1 ();
// 0x000004B0 System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Encode()
extern void X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD ();
// 0x000004B1 System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::ToString(System.Boolean)
extern void X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA ();
// 0x000004B2 System.Void System.Net.EndPoint::.ctor()
extern void EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776 ();
// 0x000004B3 System.Void System.Net.IPAddress::.ctor(System.Int64)
extern void IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748 ();
// 0x000004B4 System.Void System.Net.IPAddress::.ctor(System.Byte[],System.Int64)
extern void IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84 ();
// 0x000004B5 System.Void System.Net.IPAddress::.ctor(System.Int32)
extern void IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D ();
// 0x000004B6 System.Int64 System.Net.IPAddress::get_ScopeId()
extern void IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9 ();
// 0x000004B7 System.String System.Net.IPAddress::ToString()
extern void IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF ();
// 0x000004B8 System.Boolean System.Net.IPAddress::Equals(System.Object,System.Boolean)
extern void IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6 ();
// 0x000004B9 System.Boolean System.Net.IPAddress::Equals(System.Object)
extern void IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678 ();
// 0x000004BA System.Int32 System.Net.IPAddress::GetHashCode()
extern void IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C ();
// 0x000004BB System.Void System.Net.IPAddress::.cctor()
extern void IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA ();
// 0x000004BC System.Void System.Net.IPv6AddressFormatter::.ctor(System.UInt16[],System.Int64)
extern void IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk ();
// 0x000004BD System.UInt16 System.Net.IPv6AddressFormatter::SwapUShort(System.UInt16)
extern void IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C ();
// 0x000004BE System.UInt32 System.Net.IPv6AddressFormatter::AsIPv4Int()
extern void IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk ();
// 0x000004BF System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Compatible()
extern void IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk ();
// 0x000004C0 System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Mapped()
extern void IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk ();
// 0x000004C1 System.String System.Net.IPv6AddressFormatter::ToString()
extern void IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk ();
// 0x000004C2 System.Int32 System.Net.Sockets.SocketException::WSAGetLastError_internal()
extern void SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3 ();
// 0x000004C3 System.Void System.Net.Sockets.SocketException::.ctor()
extern void SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA ();
// 0x000004C4 System.Void System.Net.Sockets.SocketException::.ctor(System.Net.Sockets.SocketError)
extern void SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A ();
// 0x000004C5 System.Void System.Net.Sockets.SocketException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071 ();
// 0x000004C6 System.String System.Net.Sockets.SocketException::get_Message()
extern void SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378 ();
// 0x000004C7 System.Boolean System.Collections.Specialized.BitVector32::get_Item(System.Int32)
extern void BitVector32_get_Item_m00C3142256C406B075C4E364C03AC3A89E37A0CB_AdjustorThunk ();
// 0x000004C8 System.Void System.Collections.Specialized.BitVector32::set_Item(System.Int32,System.Boolean)
extern void BitVector32_set_Item_mA42604EC8406BCA63DEB3434E3F9D8D16742400C_AdjustorThunk ();
// 0x000004C9 System.Int32 System.Collections.Specialized.BitVector32::CreateMask()
extern void BitVector32_CreateMask_mF40475E10251217A893C1C396B80B4690A6245B2 ();
// 0x000004CA System.Int32 System.Collections.Specialized.BitVector32::CreateMask(System.Int32)
extern void BitVector32_CreateMask_mFE756231DB1A3377702CD31ED57BF6CBCB0487CD ();
// 0x000004CB System.Boolean System.Collections.Specialized.BitVector32::Equals(System.Object)
extern void BitVector32_Equals_m658488AB2FE6B6D71F9574CD29A92FAB17026C5A_AdjustorThunk ();
// 0x000004CC System.Int32 System.Collections.Specialized.BitVector32::GetHashCode()
extern void BitVector32_GetHashCode_m27DDA82E5461278F9ED05C032F604107E67C71C1_AdjustorThunk ();
// 0x000004CD System.String System.Collections.Specialized.BitVector32::ToString(System.Collections.Specialized.BitVector32)
extern void BitVector32_ToString_m5580D76C2D5C86F0AEC8538762BCE520F3EDC731 ();
// 0x000004CE System.String System.Collections.Specialized.BitVector32::ToString()
extern void BitVector32_ToString_m637FCCA35840D4ABED687F1FCDAE50AB8BC7B6D0_AdjustorThunk ();
// 0x000004CF System.Void System.Collections.Specialized.HybridDictionary::.ctor()
extern void HybridDictionary__ctor_m18ABDB797A0591DF595BBDD2A03F1670DDD07AA7 ();
// 0x000004D0 System.Void System.Collections.Specialized.HybridDictionary::.ctor(System.Boolean)
extern void HybridDictionary__ctor_mBA75388EDF5456916408D7D3954B6873D50BA2F1 ();
// 0x000004D1 System.Object System.Collections.Specialized.HybridDictionary::get_Item(System.Object)
extern void HybridDictionary_get_Item_mE16332A6CE6880D436633519FAC3662ED4A89E11 ();
// 0x000004D2 System.Void System.Collections.Specialized.HybridDictionary::set_Item(System.Object,System.Object)
extern void HybridDictionary_set_Item_mFFC14A7F4B45807D97503616AF98160061F6B9D3 ();
// 0x000004D3 System.Collections.Specialized.ListDictionary System.Collections.Specialized.HybridDictionary::get_List()
extern void HybridDictionary_get_List_mA5314524D5C411AFB165F07D860010DC0E11D28E ();
// 0x000004D4 System.Void System.Collections.Specialized.HybridDictionary::ChangeOver()
extern void HybridDictionary_ChangeOver_m41ACD333E29ACCFF1C0CF45DF9E09E84EA28F173 ();
// 0x000004D5 System.Int32 System.Collections.Specialized.HybridDictionary::get_Count()
extern void HybridDictionary_get_Count_m170B942CEB7FA1B42BFFB246D72B583BD1397738 ();
// 0x000004D6 System.Boolean System.Collections.Specialized.HybridDictionary::get_IsReadOnly()
extern void HybridDictionary_get_IsReadOnly_mB58FCC395C6CC8A569B0277DE6D0B02550E786E1 ();
// 0x000004D7 System.Object System.Collections.Specialized.HybridDictionary::get_SyncRoot()
extern void HybridDictionary_get_SyncRoot_m3A81A716ADC2A40444AF517E38EA943FDC72AB97 ();
// 0x000004D8 System.Void System.Collections.Specialized.HybridDictionary::Add(System.Object,System.Object)
extern void HybridDictionary_Add_m8022C90B2CAE2484ED0D740734EA4E512D8B130D ();
// 0x000004D9 System.Void System.Collections.Specialized.HybridDictionary::Clear()
extern void HybridDictionary_Clear_m9C53B8C32A090321B9D928B0F2B8ACDE1BA8591E ();
// 0x000004DA System.Boolean System.Collections.Specialized.HybridDictionary::Contains(System.Object)
extern void HybridDictionary_Contains_mF8C826101599A5F6EDB300954BD90FDEC4BCA6D6 ();
// 0x000004DB System.Void System.Collections.Specialized.HybridDictionary::CopyTo(System.Array,System.Int32)
extern void HybridDictionary_CopyTo_m130965C0084284EE331912B40157958A1075E4A1 ();
// 0x000004DC System.Collections.IDictionaryEnumerator System.Collections.Specialized.HybridDictionary::GetEnumerator()
extern void HybridDictionary_GetEnumerator_m02B2FC70ED4C2E91818DC8EAA3F3602B0DE81437 ();
// 0x000004DD System.Collections.IEnumerator System.Collections.Specialized.HybridDictionary::System.Collections.IEnumerable.GetEnumerator()
extern void HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m4B6D49D2814E11C16C7005F84DFC58333BCBFAA0 ();
// 0x000004DE System.Void System.Collections.Specialized.HybridDictionary::Remove(System.Object)
extern void HybridDictionary_Remove_mF87829C60C964F938DE42D453582712B726A2CD7 ();
// 0x000004DF System.Void System.Collections.Specialized.ListDictionary::.ctor()
extern void ListDictionary__ctor_mEB7BEC57F72A27168FCCE46DAC90CD5B8B7088A5 ();
// 0x000004E0 System.Void System.Collections.Specialized.ListDictionary::.ctor(System.Collections.IComparer)
extern void ListDictionary__ctor_mD1A7D146747D4E3AD93C261C1783CE34B10E48EC ();
// 0x000004E1 System.Object System.Collections.Specialized.ListDictionary::get_Item(System.Object)
extern void ListDictionary_get_Item_m34D2DAE21AFFB6B1801EDE8A6998732CD9B45605 ();
// 0x000004E2 System.Void System.Collections.Specialized.ListDictionary::set_Item(System.Object,System.Object)
extern void ListDictionary_set_Item_m89155730D3E404A1270CBDE7BEEC99138FBC64A0 ();
// 0x000004E3 System.Int32 System.Collections.Specialized.ListDictionary::get_Count()
extern void ListDictionary_get_Count_m4CB9ACB21730241E566764AAB76B8B2A3D72418B ();
// 0x000004E4 System.Boolean System.Collections.Specialized.ListDictionary::get_IsReadOnly()
extern void ListDictionary_get_IsReadOnly_mD2FC02FAB99A9FA7FA8A69F5CAB8E5887AAEC0CE ();
// 0x000004E5 System.Object System.Collections.Specialized.ListDictionary::get_SyncRoot()
extern void ListDictionary_get_SyncRoot_m58A889327021D843C7EB9171BD6B0D1E482C8BD7 ();
// 0x000004E6 System.Void System.Collections.Specialized.ListDictionary::Add(System.Object,System.Object)
extern void ListDictionary_Add_m2204C61650D1B23A093627DF4D87009A7E3F9EDB ();
// 0x000004E7 System.Void System.Collections.Specialized.ListDictionary::Clear()
extern void ListDictionary_Clear_m9D51C37F441D6390E7FF8B633EFD144F4771DB1E ();
// 0x000004E8 System.Boolean System.Collections.Specialized.ListDictionary::Contains(System.Object)
extern void ListDictionary_Contains_mA832E669186A7B91FF5819A535F8D394C963C508 ();
// 0x000004E9 System.Void System.Collections.Specialized.ListDictionary::CopyTo(System.Array,System.Int32)
extern void ListDictionary_CopyTo_m9B1961C99A5B80996E42431630907C6BC02627A0 ();
// 0x000004EA System.Collections.IDictionaryEnumerator System.Collections.Specialized.ListDictionary::GetEnumerator()
extern void ListDictionary_GetEnumerator_m17E264D47385C88C7C366177CE8127CE933B0F9D ();
// 0x000004EB System.Collections.IEnumerator System.Collections.Specialized.ListDictionary::System.Collections.IEnumerable.GetEnumerator()
extern void ListDictionary_System_Collections_IEnumerable_GetEnumerator_mF0DF8988C2CA6D5D493A61C502F20DA7879FA8E3 ();
// 0x000004EC System.Void System.Collections.Specialized.ListDictionary::Remove(System.Object)
extern void ListDictionary_Remove_m8CDD8E6A5B18DAC6446C1D93BADEB0A804AC9C5E ();
// 0x000004ED System.Void System.Collections.Specialized.ListDictionary_NodeEnumerator::.ctor(System.Collections.Specialized.ListDictionary)
extern void NodeEnumerator__ctor_m61652E6AF76A5460A6F4EA14BF97B982B7BB0261 ();
// 0x000004EE System.Object System.Collections.Specialized.ListDictionary_NodeEnumerator::get_Current()
extern void NodeEnumerator_get_Current_m08DA3FD558CA771BD75B9C9A54FE681EDE668D25 ();
// 0x000004EF System.Collections.DictionaryEntry System.Collections.Specialized.ListDictionary_NodeEnumerator::get_Entry()
extern void NodeEnumerator_get_Entry_m5C0AAD879BADE3838D42B8525084C8C5DF96C56D ();
// 0x000004F0 System.Object System.Collections.Specialized.ListDictionary_NodeEnumerator::get_Key()
extern void NodeEnumerator_get_Key_m83C059C6F52DE85B2E1605051400F3751534F8FF ();
// 0x000004F1 System.Object System.Collections.Specialized.ListDictionary_NodeEnumerator::get_Value()
extern void NodeEnumerator_get_Value_m8532A492ECB3CE11B557109057E81DD2175070C7 ();
// 0x000004F2 System.Boolean System.Collections.Specialized.ListDictionary_NodeEnumerator::MoveNext()
extern void NodeEnumerator_MoveNext_m111785D3C26CEB364566F3E517B3EB7528940552 ();
// 0x000004F3 System.Void System.Collections.Specialized.ListDictionary_NodeEnumerator::Reset()
extern void NodeEnumerator_Reset_m66F3E60AB0A5AFCB3B3A8C37399B5357098BDD2E ();
// 0x000004F4 System.Void System.Collections.Specialized.ListDictionary_DictionaryNode::.ctor()
extern void DictionaryNode__ctor_m824EFE3D79F05D11FE0DE6FD5491D2FB1D382619 ();
// 0x000004F5 System.Void System.Collections.Specialized.OrderedDictionary::.ctor()
extern void OrderedDictionary__ctor_mABFCC28E59BA806C34604B33877C1CEAD0AA9CE9 ();
// 0x000004F6 System.Void System.Collections.Specialized.OrderedDictionary::.ctor(System.Int32)
extern void OrderedDictionary__ctor_m278F36318DAF73A39FB15CF0ED1439C36237C175 ();
// 0x000004F7 System.Void System.Collections.Specialized.OrderedDictionary::.ctor(System.Int32,System.Collections.IEqualityComparer)
extern void OrderedDictionary__ctor_mEE01676A6098C432B4981481099AE2C305E606F4 ();
// 0x000004F8 System.Void System.Collections.Specialized.OrderedDictionary::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void OrderedDictionary__ctor_mD73E278CB399AD723FEC465939C20D2AAE434B3E ();
// 0x000004F9 System.Int32 System.Collections.Specialized.OrderedDictionary::get_Count()
extern void OrderedDictionary_get_Count_m55F1F94E727BA49C8D94E7A7088D4C2E4B33605C ();
// 0x000004FA System.Boolean System.Collections.Specialized.OrderedDictionary::get_IsReadOnly()
extern void OrderedDictionary_get_IsReadOnly_mF9796A4518A4F291F1FF0BD4042F5077B75710A2 ();
// 0x000004FB System.Collections.ArrayList System.Collections.Specialized.OrderedDictionary::get_objectsArray()
extern void OrderedDictionary_get_objectsArray_m690618ABC6772FE7A565AC5BDF5EE2896EB83045 ();
// 0x000004FC System.Collections.Hashtable System.Collections.Specialized.OrderedDictionary::get_objectsTable()
extern void OrderedDictionary_get_objectsTable_m0D81CE869362587F2124DAB3CE393E902DBB9F80 ();
// 0x000004FD System.Object System.Collections.Specialized.OrderedDictionary::System.Collections.ICollection.get_SyncRoot()
extern void OrderedDictionary_System_Collections_ICollection_get_SyncRoot_mFCD92778BDB71764F12583F9F27054EF6957CE42 ();
// 0x000004FE System.Object System.Collections.Specialized.OrderedDictionary::get_Item(System.Object)
extern void OrderedDictionary_get_Item_m4BA1DD5702BF43A016E1785285DE53D4E9902E7B ();
// 0x000004FF System.Void System.Collections.Specialized.OrderedDictionary::set_Item(System.Object,System.Object)
extern void OrderedDictionary_set_Item_mA8C71C7FD9354ABDCB0DBFB1977459680BD748BB ();
// 0x00000500 System.Collections.ICollection System.Collections.Specialized.OrderedDictionary::get_Values()
extern void OrderedDictionary_get_Values_mF389293625F26A739573D543FB5E21FEC6BDAE13 ();
// 0x00000501 System.Void System.Collections.Specialized.OrderedDictionary::Add(System.Object,System.Object)
extern void OrderedDictionary_Add_mF2EC1AE8051D89FD384B7D8B25E03E8A1817BC19 ();
// 0x00000502 System.Void System.Collections.Specialized.OrderedDictionary::Clear()
extern void OrderedDictionary_Clear_mBC338E68811632FEA7E12E1C8CB896A9D17D9D74 ();
// 0x00000503 System.Boolean System.Collections.Specialized.OrderedDictionary::Contains(System.Object)
extern void OrderedDictionary_Contains_m957B6F29E97A93AB5A0AF9272ED0AB65E4401EF1 ();
// 0x00000504 System.Void System.Collections.Specialized.OrderedDictionary::CopyTo(System.Array,System.Int32)
extern void OrderedDictionary_CopyTo_m6D7C307CED28372BFE59C365B4392EBCDE64CFE2 ();
// 0x00000505 System.Int32 System.Collections.Specialized.OrderedDictionary::IndexOfKey(System.Object)
extern void OrderedDictionary_IndexOfKey_m9CC5C8BCA6AEAED5821C6A8235DB9C90140291D2 ();
// 0x00000506 System.Void System.Collections.Specialized.OrderedDictionary::OnDeserialization(System.Object)
extern void OrderedDictionary_OnDeserialization_mC430F0CA656131C627EE2F1920749DD36A745357 ();
// 0x00000507 System.Void System.Collections.Specialized.OrderedDictionary::Remove(System.Object)
extern void OrderedDictionary_Remove_m32466C87EC2ED256642300B29B89101DD5227AA0 ();
// 0x00000508 System.Collections.IDictionaryEnumerator System.Collections.Specialized.OrderedDictionary::GetEnumerator()
extern void OrderedDictionary_GetEnumerator_mDFBC515FDE9C8A8AE56064C0655C19C3D130EB26 ();
// 0x00000509 System.Collections.IEnumerator System.Collections.Specialized.OrderedDictionary::System.Collections.IEnumerable.GetEnumerator()
extern void OrderedDictionary_System_Collections_IEnumerable_GetEnumerator_m47B64CD9FF588025B1C067C150670B2EA363CB29 ();
// 0x0000050A System.Void System.Collections.Specialized.OrderedDictionary::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void OrderedDictionary_GetObjectData_m64EA42255566CF993C85C556897C5A73263AA5C6 ();
// 0x0000050B System.Void System.Collections.Specialized.OrderedDictionary::System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(System.Object)
extern void OrderedDictionary_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1B07A96F704FCEDF5A1163E40C894FC77FA6EDDB ();
// 0x0000050C System.Void System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::.ctor(System.Collections.ArrayList,System.Int32)
extern void OrderedDictionaryEnumerator__ctor_m0C688CE7F033E4A145EBC003E5FAC145EC117265 ();
// 0x0000050D System.Object System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::get_Current()
extern void OrderedDictionaryEnumerator_get_Current_m3D8DF89674C33D4DEA12463FEC53FCF1780ADE70 ();
// 0x0000050E System.Collections.DictionaryEntry System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::get_Entry()
extern void OrderedDictionaryEnumerator_get_Entry_m378B3659B18D635E114695226BDA8094AFC46E06 ();
// 0x0000050F System.Object System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::get_Key()
extern void OrderedDictionaryEnumerator_get_Key_m536FA8AF2BBBED8E47FBF8A3467596654984FF25 ();
// 0x00000510 System.Object System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::get_Value()
extern void OrderedDictionaryEnumerator_get_Value_m2199F649E120FDE587520D7DED478C7E0A764DDE ();
// 0x00000511 System.Boolean System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::MoveNext()
extern void OrderedDictionaryEnumerator_MoveNext_m93D8BD7C91EFCCBFDD85BED6FF9130E957652CD1 ();
// 0x00000512 System.Void System.Collections.Specialized.OrderedDictionary_OrderedDictionaryEnumerator::Reset()
extern void OrderedDictionaryEnumerator_Reset_m6FC4640DE96193B4BD596C9476DD56E034A9440B ();
// 0x00000513 System.Void System.Collections.Specialized.OrderedDictionary_OrderedDictionaryKeyValueCollection::.ctor(System.Collections.ArrayList,System.Boolean)
extern void OrderedDictionaryKeyValueCollection__ctor_mD7596CC3855A371FF8EB8C05B3E886EC52F081BC ();
// 0x00000514 System.Void System.Collections.Specialized.OrderedDictionary_OrderedDictionaryKeyValueCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void OrderedDictionaryKeyValueCollection_System_Collections_ICollection_CopyTo_mE81AE69E425015D650DB16850C8BA51D73E8320A ();
// 0x00000515 System.Int32 System.Collections.Specialized.OrderedDictionary_OrderedDictionaryKeyValueCollection::System.Collections.ICollection.get_Count()
extern void OrderedDictionaryKeyValueCollection_System_Collections_ICollection_get_Count_m247949B9D6061A309DACDD9CB1D8982C0AAE4E0C ();
// 0x00000516 System.Object System.Collections.Specialized.OrderedDictionary_OrderedDictionaryKeyValueCollection::System.Collections.ICollection.get_SyncRoot()
extern void OrderedDictionaryKeyValueCollection_System_Collections_ICollection_get_SyncRoot_m2415812982AE4651AE467053E83243522CE5F979 ();
// 0x00000517 System.Collections.IEnumerator System.Collections.Specialized.OrderedDictionary_OrderedDictionaryKeyValueCollection::System.Collections.IEnumerable.GetEnumerator()
extern void OrderedDictionaryKeyValueCollection_System_Collections_IEnumerable_GetEnumerator_m0A5A85B1101591DE72343805CD5F1DE725DC0D04 ();
// 0x00000518 System.Void System.Collections.Generic.LinkedList`1::.ctor()
// 0x00000519 System.Void System.Collections.Generic.LinkedList`1::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000051A System.Int32 System.Collections.Generic.LinkedList`1::get_Count()
// 0x0000051B System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::get_First()
// 0x0000051C System.Boolean System.Collections.Generic.LinkedList`1::System.Collections.Generic.ICollection<T>.get_IsReadOnly()
// 0x0000051D System.Void System.Collections.Generic.LinkedList`1::System.Collections.Generic.ICollection<T>.Add(T)
// 0x0000051E System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::AddFirst(T)
// 0x0000051F System.Void System.Collections.Generic.LinkedList`1::AddFirst(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000520 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::AddLast(T)
// 0x00000521 System.Void System.Collections.Generic.LinkedList`1::Clear()
// 0x00000522 System.Boolean System.Collections.Generic.LinkedList`1::Contains(T)
// 0x00000523 System.Void System.Collections.Generic.LinkedList`1::CopyTo(T[],System.Int32)
// 0x00000524 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::Find(T)
// 0x00000525 System.Collections.Generic.LinkedList`1_Enumerator<T> System.Collections.Generic.LinkedList`1::GetEnumerator()
// 0x00000526 System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.LinkedList`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x00000527 System.Boolean System.Collections.Generic.LinkedList`1::Remove(T)
// 0x00000528 System.Void System.Collections.Generic.LinkedList`1::Remove(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000529 System.Void System.Collections.Generic.LinkedList`1::RemoveLast()
// 0x0000052A System.Void System.Collections.Generic.LinkedList`1::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000052B System.Void System.Collections.Generic.LinkedList`1::OnDeserialization(System.Object)
// 0x0000052C System.Void System.Collections.Generic.LinkedList`1::InternalInsertNodeBefore(System.Collections.Generic.LinkedListNode`1<T>,System.Collections.Generic.LinkedListNode`1<T>)
// 0x0000052D System.Void System.Collections.Generic.LinkedList`1::InternalInsertNodeToEmptyList(System.Collections.Generic.LinkedListNode`1<T>)
// 0x0000052E System.Void System.Collections.Generic.LinkedList`1::InternalRemoveNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x0000052F System.Void System.Collections.Generic.LinkedList`1::ValidateNewNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000530 System.Void System.Collections.Generic.LinkedList`1::ValidateNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000531 System.Object System.Collections.Generic.LinkedList`1::System.Collections.ICollection.get_SyncRoot()
// 0x00000532 System.Void System.Collections.Generic.LinkedList`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x00000533 System.Collections.IEnumerator System.Collections.Generic.LinkedList`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000534 System.Void System.Collections.Generic.LinkedList`1_Enumerator::.ctor(System.Collections.Generic.LinkedList`1<T>)
// 0x00000535 System.Void System.Collections.Generic.LinkedList`1_Enumerator::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x00000536 T System.Collections.Generic.LinkedList`1_Enumerator::get_Current()
// 0x00000537 System.Object System.Collections.Generic.LinkedList`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x00000538 System.Boolean System.Collections.Generic.LinkedList`1_Enumerator::MoveNext()
// 0x00000539 System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x0000053A System.Void System.Collections.Generic.LinkedList`1_Enumerator::Dispose()
// 0x0000053B System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000053C System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(System.Object)
// 0x0000053D System.Void System.Collections.Generic.LinkedListNode`1::.ctor(System.Collections.Generic.LinkedList`1<T>,T)
// 0x0000053E System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedListNode`1::get_Next()
// 0x0000053F T System.Collections.Generic.LinkedListNode`1::get_Value()
// 0x00000540 System.Void System.Collections.Generic.LinkedListNode`1::Invalidate()
// 0x00000541 System.Void System.Collections.Generic.SortedList`2::.ctor()
// 0x00000542 System.Void System.Collections.Generic.SortedList`2::.ctor(System.Collections.Generic.IComparer`1<TKey>)
// 0x00000543 System.Void System.Collections.Generic.SortedList`2::Add(TKey,TValue)
// 0x00000544 System.Void System.Collections.Generic.SortedList`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(System.Collections.Generic.KeyValuePair`2<TKey,TValue>)
// 0x00000545 System.Boolean System.Collections.Generic.SortedList`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(System.Collections.Generic.KeyValuePair`2<TKey,TValue>)
// 0x00000546 System.Boolean System.Collections.Generic.SortedList`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(System.Collections.Generic.KeyValuePair`2<TKey,TValue>)
// 0x00000547 System.Void System.Collections.Generic.SortedList`2::set_Capacity(System.Int32)
// 0x00000548 System.Void System.Collections.Generic.SortedList`2::System.Collections.IDictionary.Add(System.Object,System.Object)
// 0x00000549 System.Int32 System.Collections.Generic.SortedList`2::get_Count()
// 0x0000054A System.Collections.Generic.IList`1<TValue> System.Collections.Generic.SortedList`2::get_Values()
// 0x0000054B System.Collections.Generic.SortedList`2_ValueList<TKey,TValue> System.Collections.Generic.SortedList`2::GetValueListHelper()
// 0x0000054C System.Boolean System.Collections.Generic.SortedList`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly()
// 0x0000054D System.Boolean System.Collections.Generic.SortedList`2::System.Collections.IDictionary.get_IsReadOnly()
// 0x0000054E System.Object System.Collections.Generic.SortedList`2::System.Collections.ICollection.get_SyncRoot()
// 0x0000054F System.Void System.Collections.Generic.SortedList`2::Clear()
// 0x00000550 System.Boolean System.Collections.Generic.SortedList`2::System.Collections.IDictionary.Contains(System.Object)
// 0x00000551 System.Boolean System.Collections.Generic.SortedList`2::ContainsKey(TKey)
// 0x00000552 System.Boolean System.Collections.Generic.SortedList`2::ContainsValue(TValue)
// 0x00000553 System.Void System.Collections.Generic.SortedList`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(System.Collections.Generic.KeyValuePair`2<TKey,TValue>[],System.Int32)
// 0x00000554 System.Void System.Collections.Generic.SortedList`2::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x00000555 System.Void System.Collections.Generic.SortedList`2::EnsureCapacity(System.Int32)
// 0x00000556 TValue System.Collections.Generic.SortedList`2::GetByIndex(System.Int32)
// 0x00000557 System.Collections.Generic.IEnumerator`1<System.Collections.Generic.KeyValuePair`2<TKey,TValue>> System.Collections.Generic.SortedList`2::System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator()
// 0x00000558 System.Collections.IDictionaryEnumerator System.Collections.Generic.SortedList`2::System.Collections.IDictionary.GetEnumerator()
// 0x00000559 System.Collections.IEnumerator System.Collections.Generic.SortedList`2::System.Collections.IEnumerable.GetEnumerator()
// 0x0000055A TValue System.Collections.Generic.SortedList`2::get_Item(TKey)
// 0x0000055B System.Void System.Collections.Generic.SortedList`2::set_Item(TKey,TValue)
// 0x0000055C System.Object System.Collections.Generic.SortedList`2::System.Collections.IDictionary.get_Item(System.Object)
// 0x0000055D System.Void System.Collections.Generic.SortedList`2::System.Collections.IDictionary.set_Item(System.Object,System.Object)
// 0x0000055E System.Int32 System.Collections.Generic.SortedList`2::IndexOfKey(TKey)
// 0x0000055F System.Int32 System.Collections.Generic.SortedList`2::IndexOfValue(TValue)
// 0x00000560 System.Void System.Collections.Generic.SortedList`2::Insert(System.Int32,TKey,TValue)
// 0x00000561 System.Boolean System.Collections.Generic.SortedList`2::TryGetValue(TKey,TValue&)
// 0x00000562 System.Void System.Collections.Generic.SortedList`2::RemoveAt(System.Int32)
// 0x00000563 System.Boolean System.Collections.Generic.SortedList`2::Remove(TKey)
// 0x00000564 System.Void System.Collections.Generic.SortedList`2::System.Collections.IDictionary.Remove(System.Object)
// 0x00000565 System.Boolean System.Collections.Generic.SortedList`2::IsCompatibleKey(System.Object)
// 0x00000566 System.Void System.Collections.Generic.SortedList`2_Enumerator::.ctor(System.Collections.Generic.SortedList`2<TKey,TValue>,System.Int32)
// 0x00000567 System.Void System.Collections.Generic.SortedList`2_Enumerator::Dispose()
// 0x00000568 System.Object System.Collections.Generic.SortedList`2_Enumerator::System.Collections.IDictionaryEnumerator.get_Key()
// 0x00000569 System.Boolean System.Collections.Generic.SortedList`2_Enumerator::MoveNext()
// 0x0000056A System.Collections.DictionaryEntry System.Collections.Generic.SortedList`2_Enumerator::System.Collections.IDictionaryEnumerator.get_Entry()
// 0x0000056B System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.SortedList`2_Enumerator::get_Current()
// 0x0000056C System.Object System.Collections.Generic.SortedList`2_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x0000056D System.Object System.Collections.Generic.SortedList`2_Enumerator::System.Collections.IDictionaryEnumerator.get_Value()
// 0x0000056E System.Void System.Collections.Generic.SortedList`2_Enumerator::System.Collections.IEnumerator.Reset()
// 0x0000056F System.Void System.Collections.Generic.SortedList`2_SortedListValueEnumerator::.ctor(System.Collections.Generic.SortedList`2<TKey,TValue>)
// 0x00000570 System.Void System.Collections.Generic.SortedList`2_SortedListValueEnumerator::Dispose()
// 0x00000571 System.Boolean System.Collections.Generic.SortedList`2_SortedListValueEnumerator::MoveNext()
// 0x00000572 TValue System.Collections.Generic.SortedList`2_SortedListValueEnumerator::get_Current()
// 0x00000573 System.Object System.Collections.Generic.SortedList`2_SortedListValueEnumerator::System.Collections.IEnumerator.get_Current()
// 0x00000574 System.Void System.Collections.Generic.SortedList`2_SortedListValueEnumerator::System.Collections.IEnumerator.Reset()
// 0x00000575 System.Void System.Collections.Generic.SortedList`2_ValueList::.ctor(System.Collections.Generic.SortedList`2<TKey,TValue>)
// 0x00000576 System.Int32 System.Collections.Generic.SortedList`2_ValueList::get_Count()
// 0x00000577 System.Boolean System.Collections.Generic.SortedList`2_ValueList::get_IsReadOnly()
// 0x00000578 System.Object System.Collections.Generic.SortedList`2_ValueList::System.Collections.ICollection.get_SyncRoot()
// 0x00000579 System.Void System.Collections.Generic.SortedList`2_ValueList::Add(TValue)
// 0x0000057A System.Void System.Collections.Generic.SortedList`2_ValueList::Clear()
// 0x0000057B System.Boolean System.Collections.Generic.SortedList`2_ValueList::Contains(TValue)
// 0x0000057C System.Void System.Collections.Generic.SortedList`2_ValueList::CopyTo(TValue[],System.Int32)
// 0x0000057D System.Void System.Collections.Generic.SortedList`2_ValueList::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x0000057E System.Void System.Collections.Generic.SortedList`2_ValueList::Insert(System.Int32,TValue)
// 0x0000057F TValue System.Collections.Generic.SortedList`2_ValueList::get_Item(System.Int32)
// 0x00000580 System.Void System.Collections.Generic.SortedList`2_ValueList::set_Item(System.Int32,TValue)
// 0x00000581 System.Collections.Generic.IEnumerator`1<TValue> System.Collections.Generic.SortedList`2_ValueList::GetEnumerator()
// 0x00000582 System.Collections.IEnumerator System.Collections.Generic.SortedList`2_ValueList::System.Collections.IEnumerable.GetEnumerator()
// 0x00000583 System.Int32 System.Collections.Generic.SortedList`2_ValueList::IndexOf(TValue)
// 0x00000584 System.Boolean System.Collections.Generic.SortedList`2_ValueList::Remove(TValue)
// 0x00000585 System.Void System.Collections.Generic.SortedList`2_ValueList::RemoveAt(System.Int32)
// 0x00000586 System.Void System.Collections.Generic.Stack`1::.ctor()
// 0x00000587 System.Int32 System.Collections.Generic.Stack`1::get_Count()
// 0x00000588 System.Object System.Collections.Generic.Stack`1::System.Collections.ICollection.get_SyncRoot()
// 0x00000589 System.Void System.Collections.Generic.Stack`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x0000058A System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.Stack`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x0000058B System.Collections.IEnumerator System.Collections.Generic.Stack`1::System.Collections.IEnumerable.GetEnumerator()
// 0x0000058C T System.Collections.Generic.Stack`1::Peek()
// 0x0000058D T System.Collections.Generic.Stack`1::Pop()
// 0x0000058E System.Void System.Collections.Generic.Stack`1::Push(T)
// 0x0000058F System.Void System.Collections.Generic.Stack`1::ThrowForEmptyStack()
// 0x00000590 System.Void System.Collections.Generic.Stack`1_Enumerator::.ctor(System.Collections.Generic.Stack`1<T>)
// 0x00000591 System.Void System.Collections.Generic.Stack`1_Enumerator::Dispose()
// 0x00000592 System.Boolean System.Collections.Generic.Stack`1_Enumerator::MoveNext()
// 0x00000593 T System.Collections.Generic.Stack`1_Enumerator::get_Current()
// 0x00000594 System.Void System.Collections.Generic.Stack`1_Enumerator::ThrowEnumerationNotStartedOrEnded()
// 0x00000595 System.Object System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x00000596 System.Void System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x00000597 System.UInt32 <PrivateImplementationDetails>::ComputeStringHash(System.String)
extern void U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874 ();
// 0x00000598 System.Void System.Net.Configuration.BypassElementCollection::.ctor()
extern void BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A ();
// 0x00000599 System.Void System.Net.Configuration.ConnectionManagementElementCollection::.ctor()
extern void ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B ();
// 0x0000059A System.Void System.Net.Configuration.ConnectionManagementSection::.ctor()
extern void ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4 ();
// 0x0000059B System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ConnectionManagementSection::get_Properties()
extern void ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19 ();
// 0x0000059C System.Void System.Net.Configuration.DefaultProxySection::.ctor()
extern void DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6 ();
// 0x0000059D System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.DefaultProxySection::get_Properties()
extern void DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555 ();
// 0x0000059E System.Void System.Net.Configuration.DefaultProxySection::Reset(System.Configuration.ConfigurationElement)
extern void DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276 ();
// 0x0000059F System.Void System.Net.Configuration.ProxyElement::.ctor()
extern void ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC ();
// 0x000005A0 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ProxyElement::get_Properties()
extern void ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377 ();
// 0x000005A1 System.Void System.Net.Configuration.HttpWebRequestElement::.ctor()
extern void HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233 ();
// 0x000005A2 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.HttpWebRequestElement::get_Properties()
extern void HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C ();
// 0x000005A3 System.Void System.Net.Configuration.Ipv6Element::.ctor()
extern void Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965 ();
// 0x000005A4 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.Ipv6Element::get_Properties()
extern void Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC ();
// 0x000005A5 System.Void System.Net.Configuration.NetSectionGroup::.ctor()
extern void NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269 ();
// 0x000005A6 System.Void System.Net.Configuration.SettingsSection::.ctor()
extern void SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005 ();
// 0x000005A7 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SettingsSection::get_Properties()
extern void SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254 ();
// 0x000005A8 System.Void System.Net.Configuration.PerformanceCountersElement::.ctor()
extern void PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083 ();
// 0x000005A9 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.PerformanceCountersElement::get_Properties()
extern void PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0 ();
// 0x000005AA System.Void System.Net.Configuration.ServicePointManagerElement::.ctor()
extern void ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7 ();
// 0x000005AB System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ServicePointManagerElement::get_Properties()
extern void ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677 ();
// 0x000005AC System.Void System.Net.Configuration.SocketElement::.ctor()
extern void SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3 ();
// 0x000005AD System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SocketElement::get_Properties()
extern void SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A ();
// 0x000005AE System.Void System.Net.Configuration.WebProxyScriptElement::.ctor()
extern void WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591 ();
// 0x000005AF System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebProxyScriptElement::get_Properties()
extern void WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26 ();
// 0x000005B0 System.Void System.Net.Configuration.WebRequestModulesSection::.ctor()
extern void WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02 ();
// 0x000005B1 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebRequestModulesSection::get_Properties()
extern void WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44 ();
// 0x000005B2 System.Void System.Net.Configuration.WebRequestModuleElementCollection::.ctor()
extern void WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961 ();
// 0x000005B3 System.Void System.Diagnostics.DiagnosticsConfigurationHandler::.ctor()
extern void DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0 ();
// 0x000005B4 System.Object System.Diagnostics.DiagnosticsConfigurationHandler::Create(System.Object,System.Object,System.Xml.XmlNode)
extern void DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96 ();
// 0x000005B5 System.Void Unity.ThrowStub::ThrowNotSupportedException()
extern void ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD ();
static Il2CppMethodPointer s_methodPointers[1461] = 
{
	SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39,
	SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2,
	SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7,
	SR_Format_m0F2CEC6937029AEC3360EE21DB1D6329D5BE8906,
	SR_Format_mCE758E323017FDB5E39921BE8757AC78665C7504,
	SecurityUtils_DemandReflectionAccess_mC21CA419C4B77BBDE16AAF5C33DCBF86E3CCA5F0,
	SecurityUtils_HasReflectionPermission_mE162700DD39C0E439075D744EA4DD3C768AA5D96,
	SecurityUtils_SecureCreateInstance_m00B165286E54C3393CFFE82948E078F96018750A,
	SecurityUtils_SecureCreateInstance_m75CC5B0308F53B01ADC1B5EEBF831C49A53808F4,
	SecurityUtils_SecureConstructorInvoke_m7DA77EA06BECD2F9B36481C8CAD9429674166D27,
	SecurityUtils_SecureConstructorInvoke_mE027B99C9C5C9A325AFC67CAC4B4106DBE855585,
	InvariantComparer__ctor_m803F2DC4D029AE0DA9B3C0A581E9B49B044DF51A,
	InvariantComparer_Compare_m974E695ADB170A8E1F6D63CB96FA0A0073B026AF,
	InvariantComparer__cctor_m25FDC0EE3C4E0B5FE5E20F0C743C92CC22DE5B9B,
	IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C,
	IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9,
	IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C,
	IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239,
	Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D,
	Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E,
	Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08,
	Uri_get_IsUncPath_mD5EE84D5105BFB7D64E5C26B9549A67B720A7AE8,
	Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90,
	Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78,
	Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919,
	Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5,
	Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941,
	Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5,
	Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1,
	Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39,
	Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B,
	Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA,
	Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D,
	Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7,
	Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A,
	Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8,
	Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7,
	Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B,
	Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720,
	Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2,
	Uri__ctor_mA02DB222F4F35380DE2700D84F58EB42497FDDE4,
	Uri__ctor_m41A759BF295FB902084DD289849793E01A65A14E,
	Uri_CreateUri_m0A20410F2B8286AE6EDCD8B5AB3E104FA095808A,
	Uri__ctor_m42192656437FBEF1EEA8724D3EF2BB67DA0ED6BF,
	Uri_GetCombinedString_m7B95A90BC09E899CF41B0047E0B681FA7CEB8668,
	Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164,
	Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF,
	Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C,
	Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68,
	Uri_get_AbsolutePath_mA9A825E2BBD0A43AD76EB9A9765E29E45FE32F31,
	Uri_get_PrivateAbsolutePath_mC1CDB66963BF6D6AEDE0713D3CF0CE0647A6A532,
	Uri_get_AbsoluteUri_m4326730E572E7E3874021E802813EB6F49F7F99E,
	Uri_get_IsFile_m06AB5A15E2A34BBC5177C6E902C5C9D7E766A213,
	Uri_get_IsLoopback_mCD7E1228C8296730CBD31C713B0A81B660D99BC4,
	Uri_get_PathAndQuery_mF079BA04B7A397B2729E5B5DEE72B3654A44E384,
	Uri_get_IsUnc_m70B47E68BDAE06A7E5362DCE5AAD97C12119AB99,
	Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3,
	Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE,
	Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2,
	Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C,
	Uri_get_Fragment_m111666DD668AC59B9F3C3D3CEEEC7F70F6904D41,
	Uri_get_Scheme_m14A8F0018D8AACADBEF39600A59944F33EE39187,
	Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D,
	Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F,
	Uri_get_DnsSafeHost_mC2D93669288A9C05CC13EE5754CEBF2D74D04704,
	Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722,
	Uri_get_UserEscaped_m8F29E9A593E84E66DD4AC06CBD5880B93A5F0307,
	Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3,
	Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836,
	Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B,
	Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515,
	Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2,
	Uri_op_Equality_mFED3D4AFAB090B76D2088C485507F8F702ADA18F,
	Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B,
	Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629,
	Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884,
	Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF,
	Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0,
	Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0,
	Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF,
	Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54,
	Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD,
	Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3,
	Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F,
	Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4,
	Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3,
	Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7,
	Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6,
	Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774,
	Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243,
	Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D,
	Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F,
	Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387,
	Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28,
	Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8,
	Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B,
	Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF,
	Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6,
	Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2,
	Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21,
	Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF,
	Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4,
	Uri_CombineUri_m77B7B8B856CF8100E51250247930963E7C544F91,
	Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6,
	Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373,
	Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661,
	Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D,
	Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F,
	Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864,
	Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE,
	Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F,
	Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD,
	Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A,
	Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB,
	Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6,
	Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D,
	Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180,
	Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD,
	Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0,
	Uri_ResolveHelper_mEDF1549C3E9AC1CF6177DCF93B17D574411916BC,
	Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58,
	Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3,
	Uri_CreateThisFromUri_m9A4AE7CD70F7EDE9154634057EBE600E74A5D544,
	Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2,
	UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98,
	MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C,
	UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424,
	UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D,
	UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5,
	UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC,
	UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B,
	UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217,
	UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF,
	UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89,
	UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F,
	UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902,
	UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78,
	UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D,
	UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059,
	UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48,
	UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A,
	UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27,
	UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1,
	UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D,
	UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897,
	UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0,
	UriParser_Resolve_mF21D3AA42AB1EC2B173617D76E4041EB3481D979,
	UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181,
	UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD,
	UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2,
	UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039,
	UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3,
	UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3,
	UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E,
	UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E,
	UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D,
	UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD,
	UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C,
	UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA,
	UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2,
	UriParser_InternalResolve_m2A027789CB5105E32B09810E81810E8E35DD1F26,
	UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674,
	BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C,
	DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4,
	DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461,
	DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF,
	DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F,
	DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57,
	DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445,
	DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8,
	DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3,
	DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F,
	DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01,
	DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1,
	IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813,
	IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14,
	IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843,
	IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120,
	IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E,
	IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF,
	IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33,
	IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14,
	IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A,
	IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD,
	IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE,
	IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A,
	IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289,
	IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB,
	UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E,
	UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6,
	IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985,
	IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B,
	IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C,
	IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727,
	UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64,
	UriTypeConverter_CanConvert_m0F0FB34A1DC16C677BF8F4ED0E720144C17C4795,
	UriTypeConverter_CanConvertFrom_m1D18F7B5924B6B682AB1CC90FB814DC3331DFF47,
	UriTypeConverter_CanConvertTo_mC19530C1DD75AC92C20697EFDD0A0E2DB568E099,
	UriTypeConverter_ConvertFrom_m2FE8479F26F35A578983E194038CF186D6CD2F85,
	UriTypeConverter_ConvertTo_m2059A4086714BACA32E7618BD97713CCD5DCFEF4,
	Regex__ctor_mFDE4B6A423C15AA60BF9FEC7D4D7DFD4657D7C6E,
	Regex__ctor_m2769A5BA7B7A835514F6C0E4D30FAD467C6B1B0C,
	Regex__ctor_mEF4515C4C44DF8BE410F388C82CC679D743FB5CD,
	Regex__ctor_m87918FB2A856E264A492D2A2B4B412BE4E2370BB,
	Regex__ctor_mF11825F6E24D7D780BD34C74C96392DEC3602A5D,
	Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m95B0E2523A72DF6AC56DEA7CDA286F771E06B0FD,
	Regex_ValidateMatchTimeout_m71FE7188780DEAD57093B7345CCC50D0159218BE,
	Regex_InitDefaultMatchTimeout_mC91736B02BD12B92CBD93C329E7A8233CD0B9DA4,
	Regex_Unescape_mDA4631C73336E4191E48CD512049D4B2E831306D,
	Regex_get_Options_m823A30690EEA63798DB8497F3E9CF062412B8653,
	Regex_get_MatchTimeout_mD484D1CF0B6BF8516A08991D1387761CAE2340D6,
	Regex_get_RightToLeft_m546BF531C94563A11427CD24367525462CDB4509,
	Regex_ToString_mF967EF5E8BD74C3692379B8436AB8D3C5963FA75,
	Regex_IsMatch_m3C44A8D92E43EA8CC8D623ECC394B27F09E2D5DA,
	Regex_IsMatch_m90348BB44AD120A322F411001522DB0758A6678B,
	Regex_IsMatch_m79684C4D2CE6C5495BCCE9A32AC029E1E5950B7C,
	Regex_IsMatch_m2FB867817B341A5FA3E64A41F31820C9658F22A5,
	Regex_Match_mC2C718B93803F6633A708E430F8698E70354B77C,
	Regex_Match_mA36A33D32F895CE84957DC7DA82E2CD45EF19EEA,
	Regex_InitializeReferences_m2CD000C1AFAA8B214F32D989C7D116B684A31840,
	Regex_Run_m74FB5EF178DF43F88B9058B94939F557479B93FC,
	Regex_LookupCachedAndUpdate_m88CA03797C5ED796BD5E1319DF6B1B6B6FCE6C0D,
	Regex_CacheCode_m68F93FF3B918776D190D4DB807A3323691C77F0A,
	Regex_UseOptionR_m84945EDBEDCD61DBCEB691C929CA28F4B0AF4B49,
	Regex_UseOptionInvariant_m0CA185DBDB15932BB8A8B4F53EB8ACECEC006566,
	Regex__cctor_m86CE9B8D0FF5F2B54D4FF27D2213A1E6917477DF,
	CachedCodeEntry__ctor_m78BCA6060E7D83B172F998AF60D17FB41BE703B8,
	ExclusiveReference_Get_mE79B077388AFBD19A4524E630701783E7DCE61E4,
	ExclusiveReference_Release_m9A1577138872106EA54A04EA4AB77F710CEDE336,
	ExclusiveReference__ctor_m0427943C75CBB283EF26034339E3D412A080B5D7,
	SharedReference__ctor_m48E749BC646BEC89282B8F336325D42DE48CFC81,
	RegexBoyerMoore__ctor_m39674FB18BB75DD891AAE3781FDA0CCDDEBC2F8C,
	RegexBoyerMoore_MatchPattern_m41D57E11972B2142649662886DA145AFE396F602,
	RegexBoyerMoore_IsMatch_m820D06ED51C062451AFAF22682D2EB06C8DFABD9,
	RegexBoyerMoore_Scan_m204A42056131A694B6D31FC69563355788CABD67,
	RegexBoyerMoore_ToString_mB0A62E68E8A3CAC5CE3AC45E1C54FA72DFB626F6,
	Capture__ctor_m6CC8A5385C7BD6B8AE63F9812293EC3252A65B3B,
	Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C,
	Capture_ToString_mD49A28CAD5727E8F629643EDE0C6BAB476BA639E,
	Capture__ctor_m3ED807279C93FFCE8BE4EAF447DA01E62EF93D7B,
	RegexCharClass__cctor_m5170E52D9864BA712125FB33F309FE9E37869EA8,
	RegexCharClass__ctor_mAA44510F3E5001A8612355B4FFB718D9DDC74264,
	RegexCharClass__ctor_mB05A6CC8015C5D545C639682454A524DE7E2EA97,
	RegexCharClass_get_CanMerge_mC27A4CF83CFBEF3741A3DB4F99ABA6DE76B57837,
	RegexCharClass_set_Negate_mEB8659D83748A4DF28CDDFC3AC573A6504385E09,
	RegexCharClass_AddChar_m4C4BFD42572978A9F98ADE75BE3811593957A9E3,
	RegexCharClass_AddCharClass_m0E5DD1105844AFB7CE45B5C801304B5C803FB5CA,
	RegexCharClass_AddSet_mFFDE070E770BE967173D630AD50010C3397F7B97,
	RegexCharClass_AddSubtraction_m17E538235B02A1435BD43D4FE4501DA67AA35145,
	RegexCharClass_AddRange_mCFE9B670B3EBB13A5CDB694B1D1D6B1C0249D110,
	RegexCharClass_AddCategoryFromName_m9AD2D607E1E34A52CBC26FC38D468905C43A9202,
	RegexCharClass_AddCategory_m6A4625370DA8927DF5342275CB1F6155FC2BA255,
	RegexCharClass_AddLowercase_m01C1B11EB0B82E065276C7ECF60725886F59A07A,
	RegexCharClass_AddLowercaseRange_mCDDE9661C9C300DFEB51A8FE36E2F790E3E75D75,
	RegexCharClass_AddWord_m1D2553B878162B32B0548536AE4C3EE673041CA0,
	RegexCharClass_AddSpace_mC6557749D96EBD114BCB133D14887A29304196D8,
	RegexCharClass_AddDigit_mC4DE43D884E575729BB2E575DA5552989368F6B3,
	RegexCharClass_SingletonChar_m01C15732FAD399460FF5BB449B8177A77CAB1DB9,
	RegexCharClass_IsMergeable_mB9A0CD8306728BAFA5460C7FD748A2A7AD4BA448,
	RegexCharClass_IsEmpty_mAD6C63FE25C4CF3E52A20185418925D12C4C07CF,
	RegexCharClass_IsSingleton_m89D3E8460B0E7020DB0ABA607AC2F76FB9A34F1A,
	RegexCharClass_IsSingletonInverse_m3E75D541C85AD842B9EB80705D6869EDB3F6928D,
	RegexCharClass_IsSubtraction_m3C9EF97AFE7E4BCC24A2DF10834BF62279D7EE26,
	RegexCharClass_IsNegated_m9CEDECE7EDA98ACD502E75783CA631A719DBC675,
	RegexCharClass_IsECMAWordChar_m6E7FC296DB816D89E3D6CF8672DCE6DFC519D741,
	RegexCharClass_IsWordChar_m2DF03D32DAB403138E397CB05F45D37BD50EB18C,
	RegexCharClass_CharInClass_m194AAA57BBBD30E78E70255D6F53FAFDB785EC0E,
	RegexCharClass_CharInClassRecursive_m5560DBADE1463FDEC38643C72CDF2FD5B3F69A5F,
	RegexCharClass_CharInClassInternal_m5D1634F64092E4BD9EB6427447F952983211A760,
	RegexCharClass_CharInCategory_mCDE20DF783F8D4E4403EC7F00F9C12E34D86C2DD,
	RegexCharClass_CharInCategoryGroup_m28E498004F5EA6445C83F1B8EB4A776C210D30C5,
	RegexCharClass_NegateCategory_mF2E03FFFE79E427F39D9368013A334F5BD118E13,
	RegexCharClass_Parse_mBC3780FFF0DDFB62CA2085746618E6C256E8D86C,
	RegexCharClass_ParseRecursive_mF7E7DD4EB594C9C30A60E72CD3CFD4EC1D822CF5,
	RegexCharClass_RangeCount_mEACBB4BD08CE18A9C4F0C433A7D6C5726F563E2E,
	RegexCharClass_ToStringClass_m7A760D96732A03D46C4060064B3FC58349D2B4D5,
	RegexCharClass_GetRangeAt_mE563FF8072DD9B4E1179F55416CCD7FC4EB2C4FC,
	RegexCharClass_Canonicalize_m44EEFB16DB02E73C1E7280D15DAE98E50F4D6FA4,
	RegexCharClass_SetFromProperty_mA33170AF599765B5FDE8611BED646A850FB2330E,
	LowerCaseMapping__ctor_m881B66875631FF0DD253696FE56313A9E3F24187_AdjustorThunk,
	SingleRangeComparer_Compare_mF2CAD555BAC4D9CBF6A8F90D829CB528BD7BCCC9,
	SingleRangeComparer__ctor_m9E44BF07F0F0C9E565E0BA050C1A26F496226BAD,
	SingleRange__ctor_m4674722AFC97A111D2466AE2050C2E4E6E57303E,
	RegexCode__ctor_mBCB059D3E98AEA211794E89DDF99193231F298CA,
	RegexCode_OpcodeBacktracks_mDA23B91B55FE4991B168BF8E18F6DDDC7667B882,
	RegexFCD_FirstChars_mC60DC5CA9A078998CB55594436AB9CBFD86478FB,
	RegexFCD_Prefix_m50B30C508C6745832FD3A76B2169462455C1A28E,
	RegexFCD_Anchors_m562FA644F10503074714E0F58A2A00F9F727D75E,
	RegexFCD_AnchorFromType_m4B458E2C589633A43F9324C14F9192EF68F80A14,
	RegexFCD__ctor_mFC6A3309CAFA8C3C2B94094AD443738823388A3B,
	RegexFCD_PushInt_m63817D3969DF7BD31B7C93D43EE45C4AF539868F,
	RegexFCD_IntIsEmpty_mE825A8A0DF9D5BA6618357ABBA93421D4099AAEB,
	RegexFCD_PopInt_m1E4B64F2F6DDBCB7495E673540CF25FDD4D01B7E,
	RegexFCD_PushFC_mBE154E351E7C49FFFC26E603B4672136D91479C7,
	RegexFCD_FCIsEmpty_m57FDE5D4E352620B7773AD54B286531CA21FCDAD,
	RegexFCD_PopFC_m987A35E9ADF69335799EDEEB12C2CD3A3F40FB6E,
	RegexFCD_TopFC_m26ED21621830CF30FDA46AE8D7F3AC9F50DE416F,
	RegexFCD_RegexFCFromRegexTree_mA85E74765529D05113116C73EC397E832D81D0BC,
	RegexFCD_SkipChild_m661F5D339305B97A37D855240A0B9AF500FE03F6,
	RegexFCD_CalculateFC_m2267FAA6BCA80275E21DC9A0BAF90BBC85204BD8,
	RegexFC__ctor_m354E8197215F3EE9097B69E783B744365A38EF20,
	RegexFC__ctor_m023D08ED0365AE9AAC539333B4390A8052C59229,
	RegexFC__ctor_mDCBBCCC1BB476741943D7F9AD88731B1DCA0C1B5,
	RegexFC_AddFC_m5B05CD1D7700817843366EC1DF728977EDD4D11E,
	RegexFC_GetFirstChars_m7252E826F9A5BC1842A5A255BAC5A36EE8DADAF5,
	RegexFC_IsCaseInsensitive_mD87B0C49AAEBB61215F09A9C5ABF8CCB8B5AB64E,
	RegexPrefix__ctor_m93489A4FF55425A15BF5390E77EE0B84F6F9364C,
	RegexPrefix_get_Prefix_m7137EC6CA5B857F49946E2EAEA19784040D430CF,
	RegexPrefix_get_CaseInsensitive_m76E04480FA9FFAE4C5031CA12F4AE9A2576212C0,
	RegexPrefix_get_Empty_mAD10DECDBC7C51F9ACF5C02E3191874252DF9B8B,
	RegexPrefix__cctor_mCDCE7EDB98AFB119EE0281D37F7BC019AD28773D,
	Group__ctor_mECF4574592517D363C35ADC07F9D6F7E7DE6B4F6,
	Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521,
	Group__cctor_m213E26F039439904671CFD5DAF5D85B47D5CBE68,
	Group__ctor_mDCB3D51B8A672B342F452177D42D6D3F2F9BA91A,
	RegexInterpreter__ctor_m7B9BA594CF5F338B2E257EDADC2481826BF4C6BB,
	RegexInterpreter_InitTrackCount_mD93771C3D75617898528698E29AD09B7EA5EE24B,
	RegexInterpreter_Advance_mCD1A51680CD0318DDF6D104DE8C722FCCC468CCA,
	RegexInterpreter_Advance_m779870D7E1FA3580492E2E8B75E2805613525AF7,
	RegexInterpreter_Goto_m438DE9CE790DF0757383C91126DEA68C6B0DADFE,
	RegexInterpreter_Textto_m6CE60A7C8FA9F9CEECD26BD6025F055EB64887AA,
	RegexInterpreter_Trackto_m0C7B05A7385BE3F9BB096FE28DC22942A9F96783,
	RegexInterpreter_Textstart_mE71CFC006954F38B9EB6CD85BCC0867E63BF0894,
	RegexInterpreter_Textpos_mC66F0DE729E76EDA0BEEA7B1ABEE369BA6C81D5B,
	RegexInterpreter_Trackpos_m472ADA4F5E1D07E71896E42714DFB723CB016842,
	RegexInterpreter_TrackPush_m5A8B9F863211AAEC7E5FAD14ECDDAFDE3059210D,
	RegexInterpreter_TrackPush_mB2AF47E651D2A3853A719EFB908C30D27EC2FF5F,
	RegexInterpreter_TrackPush_m3EA36B28D636D1C617F85CEA57650344B562A38F,
	RegexInterpreter_TrackPush_mBCAADB1DF177D91DC9AA4518DCDB3AAF7D6C0E15,
	RegexInterpreter_TrackPush2_m4EBCF8B183717311AEE3FAA6AD6FAF1F08B14F77,
	RegexInterpreter_TrackPush2_mD591F73FDDF69084636E0834BCCD530B057898FF,
	RegexInterpreter_Backtrack_m46612DE84F898D1656DE30F3BA86E93209E279E1,
	RegexInterpreter_SetOperator_m5B633C33EE4CD85364E7C60003ACE8EA93FDAC91,
	RegexInterpreter_TrackPop_m84B55BE8F346693942045E937174EC8C1AE91F08,
	RegexInterpreter_TrackPop_m73AB2E002DB92E231B62510861277320F76BEEED,
	RegexInterpreter_TrackPeek_m4EF7918CC0F10FFF7E73C1C9D13E74D1D8D13318,
	RegexInterpreter_TrackPeek_mEECF3E94E7823A68474C691F695D71087729553C,
	RegexInterpreter_StackPush_mC28C3F8B3C811C4DCA6CD312F7F487206C871E55,
	RegexInterpreter_StackPush_m911FF20379BF912884E7F98BB59CFB6C51AA1861,
	RegexInterpreter_StackPop_mD057CA7B190ED8FBD33C6CE48E1F28E4B09FC4F2,
	RegexInterpreter_StackPop_m90FC35FD76D9B63851ECFD641DAA08B1B58C7B91,
	RegexInterpreter_StackPeek_m08C28311048F6B075379EE46B924FC211BA48EC6,
	RegexInterpreter_StackPeek_m308DE22A8E1AF524319E7F1D5A94DBFEC37700ED,
	RegexInterpreter_Operator_m4DE2EAA1744D15294F2767D5217F753FE74FAC0B,
	RegexInterpreter_Operand_m1ACB9C398C9C7ADF8DA58824877B99F08F181526,
	RegexInterpreter_Leftchars_m3A200CD41FFE8C89CCB85B3CC7A367E32C5988D1,
	RegexInterpreter_Rightchars_m3DB37A53D6C3DC3311C9EA020690CC0824959D30,
	RegexInterpreter_Bump_mC33CB8A0CC0DF1C69F11115BD225D2D8B63F8753,
	RegexInterpreter_Forwardchars_mE5E437E285604CDC60551C112F7B2CEF7297F4ED,
	RegexInterpreter_Forwardcharnext_mD2C6694CC31BC75D3E20C511D1004D28AAE1390F,
	RegexInterpreter_Stringmatch_m543BC6834400A925D2603AE6FBB47944694AFDF1,
	RegexInterpreter_Refmatch_m52369ADBF64E25A9EEEBE216939454EBB8D8E138,
	RegexInterpreter_Backwardnext_mD10CE2A9E229D0655EF01565DB39C902654D00CD,
	RegexInterpreter_CharAt_mAE2AF6D293F53C2D8961C2D0C145BC3ADF6EC105,
	RegexInterpreter_FindFirstChar_m95CDB0ECB99F7850479D951A5F32BB6B19B91F44,
	RegexInterpreter_Go_mBE9DEAECBD68F60DDFE2BB5A8C24CF92A1FB503A,
	Match_get_Empty_m5D3AE3D0580F06ED901EE69FCCED6AF44715528F,
	Match__ctor_m08A8262ACD89C9E47AA7168D0F2CC6E3338855D7,
	Match_Reset_m9EDCC3689E8A5A57A644946AEC3E41C1901C7DAF,
	Match_AddMatch_m3C9178A7D6F8175A7628E4BE579FD209B7C7650A,
	Match_BalanceMatch_mCC0EC358E4C33191B896226512FE8F086EFEA4CF,
	Match_RemoveMatch_m6268C01D537F0BACB7DD707E11FA873C3E1918C7,
	Match_IsMatched_m7686CA418F588EC198A82DE287326C46F4CBDD5F,
	Match_MatchIndex_mA39CA9F84C3872675CB9C76EC342EFB30A2B5DA0,
	Match_MatchLength_m25492EACF56E8211FEEC4856F93D7A19D30A984F,
	Match_Tidy_m88B2494631267F8CF7E90F3305F713550ED39CE8,
	Match__cctor_m9158A9D469720E89CD9004B65F55EEEF5E330C0E,
	Match__ctor_m38BC8AD7EEFA99C6FC25587D6FE56450FA849E0C,
	MatchSparse__ctor_mEA523FCAF96D8A81401D3ED010CACE4463CCE811,
	RegexMatchTimeoutException__ctor_mCCDB413A8F68D924B276B8FED2744E81BE4C89AF,
	RegexMatchTimeoutException__ctor_m4EFD030442FEEC81E59AB8CDF35D603A5D551058,
	RegexMatchTimeoutException__ctor_m554FE8CFA7F42483517F11948A61E4D3C9F44D07,
	RegexMatchTimeoutException_System_Runtime_Serialization_ISerializable_GetObjectData_m78FACBA38C002E195A507A32CDAB768D8DBC93E7,
	RegexMatchTimeoutException_Init_m09AF601CC7369F2D7E1300B166517FE7D20EB6F1,
	RegexMatchTimeoutException_Init_m0F165C7170A46724458C06DA5EC05536D8CB95B7,
	RegexNode__ctor_m29676E9646F598C827F25E906EEB6EA14A6FD5DB,
	RegexNode__ctor_m92FB70D6C28D7E021A2A1ACBAD583461AB014F11,
	RegexNode__ctor_m89ACB97FB7FE8B38C0D69F0F2445A7916BC67D85,
	RegexNode__ctor_mAE76BA90AA85F205CB0CC6799F06D1AD85A49F64,
	RegexNode__ctor_m0EFEB707603B3C667626117E09A7EED58BBEC6D4,
	RegexNode_UseOptionR_mB931929BBD1D89F8B263AA846C1665775096713E,
	RegexNode_ReverseLeft_m994638E4886D007B9B29BC23EA3C8D76A92099FD,
	RegexNode_MakeRep_mC310B028FBE3BD5EB80F83E4E05B891ADEE45C22,
	RegexNode_Reduce_mE9E22C30C296E328ABC7EDC9C52F18059FAE27C1,
	RegexNode_StripEnation_mE19E0A57BCE0D0BF47F51A5103C08FCC7BB9E24F,
	RegexNode_ReduceGroup_m069FA93D4F88006F18473E647069B349683B9204,
	RegexNode_ReduceRep_m726F03D9E2420F276A37777942B66D15CA73F77E,
	RegexNode_ReduceSet_m912F4A0DFF694EB14DE520599369A811C2E9D10D,
	RegexNode_ReduceAlternation_m60EECC172A975620A5118D14D6ECF8B846ECED9F,
	RegexNode_ReduceConcatenation_m4BE1B6DBBC0F4BAB9A3873414B5EE77D825AD53B,
	RegexNode_MakeQuantifier_m1332537AA6BCCCD68A3E59EA7994CCFE69A19444,
	RegexNode_AddChild_m734A86A25E6074316FAC566F7D127253F7B71703,
	RegexNode_Child_m5AA4FFDDCCFA22FE70BA0F236F19A963AEF72079,
	RegexNode_ChildCount_m23B6965575DB0DBC1D90212820DEA144FCB06996,
	RegexNode_Type_mFA1C2F11F3487BB1BCBA7F58FFB7975EC18E9CD4,
	RegexParser_Parse_mD206BB554B6087ED35C5F744D72A93A07721D789,
	RegexParser_Unescape_m3BC9183007057FF7601C5E617F8238A07C0ED433,
	RegexParser__ctor_mC69D13B4FC323EE77392251139C5F2C456171310,
	RegexParser_SetPattern_m4B385D83A9680A1B2707EBCA8659B6E12EDD5E46,
	RegexParser_Reset_mEC49D1DCEBC555768D2FB90DA42374F1C547E328,
	RegexParser_ScanRegex_m62049A6C66D6D8CDD795B9C740283D1EC85126DB,
	RegexParser_ScanCharClass_mF775DA8BFD214C64BC3D91E07436543717976DC4,
	RegexParser_ScanCharClass_mFE669B1C9CB6652157D9E8DAEE5B924C581AE81F,
	RegexParser_ScanGroupOpen_mA4918ACA08C7E4C945197BBE4EF734AF5B35096C,
	RegexParser_ScanBlank_m99BA3097E182DE425BE0137BAFDD0218F0DF360D,
	RegexParser_ScanBackslash_m45E9E0ABDB7DF70F58850B48905DE9DE026EA64C,
	RegexParser_ScanBasicBackslash_m5F438E56ACBE272622D39D4208B2D5ED536DD7B8,
	RegexParser_ScanCapname_m1D4DB4E5DA312CBCA841391F729CC626DC657D85,
	RegexParser_ScanOctal_mCF3925D06CBBA1DD0CB60199F59991D099430C3A,
	RegexParser_ScanDecimal_mE966D2C7F357215A52F88120F40A37707C1AB33A,
	RegexParser_ScanHex_m296FC19218F8186D2C1B630DF9F138CFB195625E,
	RegexParser_HexDigit_m4BAEE94B2077B96A4B1D56C459EFB2B1938E1174,
	RegexParser_ScanControl_m244F59DA2B0711D154B7D68CCB5765390C65B5B8,
	RegexParser_IsOnlyTopOption_m66FE256A81BBD173C96B90EE9EBE9721F9ED16A1,
	RegexParser_ScanOptions_m5CD283C15179190846762B90F78F0A87E7495537,
	RegexParser_ScanCharEscape_mF8821EE73F3F8A5D4267642F6E4F0A666FA5E7A6,
	RegexParser_ParseProperty_m69C638E755F0A5C1A2BC8E08827E6124889C2CEF,
	RegexParser_TypeFromCode_m0969E0D233AC767039B0A333901F47A22BABE0E8,
	RegexParser_OptionFromCode_m6BCD10574DF5E08599B5F7FC8E947E3DC69EE151,
	RegexParser_CountCaptures_m5255DE4B24B8D9BA7B2A2A7A1FD79A67B36F4634,
	RegexParser_NoteCaptureSlot_m8B2D20B819C86E427837C879CCA72B9BCD1C4AA8,
	RegexParser_NoteCaptureName_m96A5301077C4C6554E993A2266EA40B690F455C4,
	RegexParser_AssignNameSlots_m168605CD3A6D6AAA52AFFDB13BE3D5DFAC3FE94B,
	RegexParser_CaptureSlotFromName_mE3FD1D57EB29D4C7A0E4029E4D4785297798EE43,
	RegexParser_IsCaptureSlot_m80540BE449D9B98B2B159CD5169F7AA6DB63CB80,
	RegexParser_IsCaptureName_mBFB85B16ED80CA59452491B4C3278C77ADCA1FDF,
	RegexParser_UseOptionN_mE9C62585222B2D99D295708E4486C952973F35D5,
	RegexParser_UseOptionI_mFA3B59BD8A6F61626E20F8FE909A23289E694263,
	RegexParser_UseOptionM_mDE945B2DE782D12A5013D408F4FFBCABEC48C63D,
	RegexParser_UseOptionS_mE96EEA754E1EEEF658AAF73885D048342D1D200E,
	RegexParser_UseOptionX_mD63DEED6741AEA0B3F6CC4239712A4B2EF690810,
	RegexParser_UseOptionE_mC171EEF863E091591BAD771F16B72D742F044096,
	RegexParser_IsSpecial_mFF68456E944ACAF048B4F96F5758FFDD1D5E7DCD,
	RegexParser_IsStopperX_m0BCF2DB4B0E1324C9109C8BFD486FC5DBA8DC646,
	RegexParser_IsQuantifier_mE0620E30A63AD0C0DB9550A52A4A7D0BB4BC3A31,
	RegexParser_IsTrueQuantifier_m4AA95A9CE7CD78600E8D525ECA5A095984FBC63F,
	RegexParser_IsSpace_m1E41FA7DD1FB93BF9220530CA91B35EF08879F30,
	RegexParser_AddConcatenate_m3743C87DFCD1784A949BFDCE9443845CCD630A5D,
	RegexParser_PushGroup_m6F4246ECA3A6F29DA096C3B41D97652427E3175E,
	RegexParser_PopGroup_m43AB1FB84E11D8DFF6C5D38B9CAD324E5425DD74,
	RegexParser_EmptyStack_mB65B33DCF98A5967407B7C6A07F8799681202BE5,
	RegexParser_StartGroup_m36A6C0ED245D844CD2E630160994C3F2D7CCA994,
	RegexParser_AddAlternate_mDBDEEF8180738DE0D31CC05B0E223EFF0D66939B,
	RegexParser_AddConcatenate_mF80F14978ED6626A8F8E5F37AEB3B946A01192C1,
	RegexParser_AddConcatenate_m81CC39ED404E571347F0E97650F3BEB14639B1B0,
	RegexParser_Unit_mEAEEAC39DBE372DC762644F49E6E163CA37EA34E,
	RegexParser_AddUnitOne_m72DFA82092408E9C63544126093D98390E0C2145,
	RegexParser_AddUnitNotone_mAA142A94BB7B6A358BA36A3920DB139382889749,
	RegexParser_AddUnitSet_m024168548909EA2DF649E6194D60135312ADF5B3,
	RegexParser_AddUnitNode_m6EE11A898128A169E41A5C7B38B1F3DD314FB304,
	RegexParser_AddUnitType_m1ECB4025CA3B580F051CF6891D9C96922CA2FA7A,
	RegexParser_AddGroup_m54BBB919E4D4AD05EFECBC3ECBE46FC4A90569EA,
	RegexParser_PushOptions_m2034533961B704CBFA0F97BD4A54CB7269F0D88A,
	RegexParser_PopOptions_mA18691037302741375A44BD8BDC9387DFB07B676,
	RegexParser_EmptyOptionsStack_m5FCB7AF81ACB5C91A73231C9F0AA0DFB32067A45,
	RegexParser_PopKeepOptions_m8ACBCD324BAF7269F90AEB3CF901B666524658FA,
	RegexParser_MakeException_m6D521D75808E2CD4255A68DC3456EAF2A88F2874,
	RegexParser_Textpos_m36658DED82367E05DF4333E68A666FEEBC3DAC07,
	RegexParser_Textto_m5C8BAB13E35429238EA9A5F13D5A5A580D0DD3AC,
	RegexParser_MoveRightGetChar_m3CF088DE129BADB346CCEEF1D547E2D260BC894A,
	RegexParser_MoveRight_m6F0A1C10AE9EA183F04A9E06B62B2B53648688AC,
	RegexParser_MoveRight_m7D1D27C901CAB81BCF60803E22FBDF2DEEC6CC51,
	RegexParser_MoveLeft_m1BC035A4EA49F4168093B2AB0EEAB2653CB04033,
	RegexParser_CharAt_m08DBAE0DFD788548F74E061031B7221154F96A77,
	RegexParser_RightChar_m9E231199A8E5EA994AA1746FC5E977AF3823FDEB,
	RegexParser_RightChar_m246E9E1F8D0A4A8E485C23E233CD3915C23739D8,
	RegexParser_CharsRight_m318662CFE3223C3FA5E921D376409B4E1B28F9B4,
	RegexParser__cctor_mF468AF3C5916BA72C579CBD41A73D2DAD004F0EE,
	RegexRunner__ctor_mC04D94995556E71E813F8420C8A4EC0B66404550,
	RegexRunner_Scan_m1C3B1B034601773D510A4D2DEC337635A540BE31,
	RegexRunner_StartTimeoutWatch_m257FBE0C72761082A11D275954C6A1343EB13301,
	RegexRunner_CheckTimeout_m52486A9CE7B6EA4C83BB60FB200196AF0EE5687B,
	RegexRunner_DoCheckTimeout_mCDAA40848A2F8AAD70928FFD8A6C08FF2D9E72A3,
	NULL,
	NULL,
	NULL,
	RegexRunner_InitMatch_mF9CD772D4A8E12F89B4785324CD6939ABAE89AD4,
	RegexRunner_TidyMatch_m61A8AE20E505F2055B276EB020EB0B804ED2D924,
	RegexRunner_EnsureStorage_m6BC13F773B014E2875CCD9A83E4093A77AA1053C,
	RegexRunner_IsBoundary_m6C846E11790EC61A9E75A24230E1477913DB3441,
	RegexRunner_IsECMABoundary_m35C5F5DDC7C2F0E57EBA2E9D9892A88EDAEE4B97,
	RegexRunner_DoubleTrack_m057C14C51F137222469C6526406B0E1069747618,
	RegexRunner_DoubleStack_m8969F05F9E086EAA194DCBD2F137778239918925,
	RegexRunner_DoubleCrawl_mF0425849E5E3C2BA5E9009CED7DE245C8CA0F7CC,
	RegexRunner_Crawl_m655A5D262056F7E13F0645CE5611AE65E83D97DB,
	RegexRunner_Popcrawl_mD8C76E2C584E6908F4BB11E055B97581F0CF7268,
	RegexRunner_Crawlpos_m26A92CA69EF0C65BC7389834A12AD331538D064D,
	RegexRunner_Capture_mE34CB0D3351BCC69F6FDE6CDEA763B93C5E92642,
	RegexRunner_TransferCapture_m4F01B5A96647BC3FD338ACF6D509741D80FEC837,
	RegexRunner_Uncapture_mA7163C77BE1683E508821AB251F33FB7520CE3F8,
	RegexRunner_IsMatched_mD7F580AA0533D5C4BC41D18824FA74BE16EAE7A3,
	RegexRunner_MatchIndex_mA8EEC418C65572A82720F5D16BAC99224CF0251A,
	RegexRunner_MatchLength_m06FA694D5EFE42F89C25C8599BBE86C7726DB2C6,
	NULL,
	RegexTree__ctor_m5B10D5149928B35CE397472028EE327669C211DA,
	RegexWriter_Write_m57CF8209EF566CD40F9146C74DF889C8AA06E061,
	RegexWriter__ctor_m63A858FAE36A8640812DFF917751C1E215A2AE82,
	RegexWriter_PushInt_mFBC85956A26FEBC66244C8DFC881106D85DD2C1D,
	RegexWriter_EmptyStack_mB0C109FA21F5CFD16A34438BA1CC1CE8BED91E7C,
	RegexWriter_PopInt_m8885F9428571674EC224D6BBC93570B1B4671713,
	RegexWriter_CurPos_mEA105879492A4B415FA8AC25B29AA49153F83C18,
	RegexWriter_PatchJump_m6C0A440142E7AC772AD4AF7DF5D8291B6CA6D7D2,
	RegexWriter_Emit_mDC0B76CE49A6DE83DD2D169236BCD516AE9263EF,
	RegexWriter_Emit_m6B0ACB44155A07161060838F483D555E7EF6ACED,
	RegexWriter_Emit_m7C1D08F071C805F13DBF7684AEC3F2F7E748C497,
	RegexWriter_StringCode_m6AA17FFEBDD5E155004F05A78CF13B0D8E901158,
	RegexWriter_MakeException_m443C4CFA99AE06710D1E1BFA3D6EB9737AE70F17,
	RegexWriter_MapCapnum_m6AFE8BED80960BAA522EAA873D535C9D5AD4B811,
	RegexWriter_RegexCodeFromRegexTree_mAC489A29C00688CA929661BC394F1C4CF997CFC5,
	RegexWriter_EmitFragment_mEFDD8EA3A65320222CF4EA8A52B33C687EE0C5AC,
	BooleanSwitch__ctor_m6F066AB4D9A1AF132569B625CB857AE671F94C0B,
	Switch__ctor_mCEC1A7A86582AA8639404DCF7607B160A8B53A42,
	Switch__ctor_mA94CBF64FF82CBF4819158911159130231ADE484,
	Switch__pruneCachedSwitches_m7500DBE46E6A2B4AA6BBE2978C90166B6EA35790,
	Switch__cctor_mC01362AF23DB366F6103AC3762E913F3149B923C,
	SwitchLevelAttribute__ctor_mD0C828AD634514271EDA0B06938D962B17EAFD52,
	SwitchLevelAttribute_set_SwitchLevelType_m88B4C116AB67D726698620238DFF195913299929,
	TraceSwitch__ctor_mDBA48A8FB03E3CED698799144535B99F84D81008,
	Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA,
	Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860,
	Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB,
	Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177,
	Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901,
	Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A,
	Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064,
	ArrayConverter_ConvertTo_mAEA49FE8501D2CA2989D859B2721CECCD5D0291B,
	ArrayConverter_GetProperties_m6EA225499F1C9E760F12E922862ADBAACE8A7764,
	ArrayConverter_GetPropertiesSupported_m0E3C2E559400F3DC3D63F9A4701F3FA60AEA5E6E,
	ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7,
	ArrayPropertyDescriptor__ctor_m7C51D4632C85E9663A9C39AC44E6E2CAA55F9269,
	ArraySubsetEnumerator__ctor_m39C3859EB2625F6E584E35FDB1950B5E8407761C,
	ArraySubsetEnumerator_MoveNext_mDA14E48B8A7B78616EEF81E31CE8E9A258C1A905,
	ArraySubsetEnumerator_Reset_mC82A8E1D642B024903CA780F6034797EB423BEB4,
	ArraySubsetEnumerator_get_Current_m09128B3111243A65657005FFCBB036CD3EF1C0FC,
	AttributeCollection__ctor_m1EBB330147608510FB1B60549BA95812EA2A1190,
	AttributeCollection_get_Attributes_m1EFD91DE73B1AB6FDB061108CA8FEF54F2FB5BF0,
	AttributeCollection_get_Count_m18B4E5D1755D27754C9B3C7C89B4BD91B1458EC4,
	AttributeCollection_get_Item_m2124C159EC9B2357A091B520AEEE0901A1F0D686,
	AttributeCollection_Contains_m44FEEEE6F4C20AAF6207A09BE38A10EEF6EDE6EF,
	AttributeCollection_GetDefaultAttribute_mE4E776D746426F6C8E4FB92754FBA9067F0D7A3F,
	AttributeCollection_GetEnumerator_m0A6B7803DAA1D559DF91BB18D0230F449A036DCB,
	AttributeCollection_System_Collections_ICollection_get_Count_mE6419B4E22BAC7B304BFC745319C683C889CC7F7,
	AttributeCollection_System_Collections_ICollection_get_SyncRoot_mA3D7D19888BBE89E51D4BD84EE6AAA9237504E74,
	AttributeCollection_CopyTo_mAE40D3E0FE070974B37F9BA5F4600E622E6F621F,
	AttributeCollection_System_Collections_IEnumerable_GetEnumerator_m582487AE671B368FDDF140B132FA868EC14349FD,
	AttributeCollection__cctor_m53AA3C8B32DE173EF653258A5BA9BCA1E5C5FCA9,
	AttributeProviderAttribute_get_TypeName_m83FA0949577D518981558E3A01BA14647565A0DC,
	AttributeProviderAttribute_get_PropertyName_mC7A169CDA2E8BE87946A71872C41F0C768D1C80B,
	BooleanConverter_CanConvertFrom_mD2CCC35D0029B29ED16C531E4389EE94F04AB955,
	BooleanConverter_ConvertFrom_mAE7E5524CBFA2C3C060A5D7006E1F41BC8AD8426,
	BooleanConverter_GetStandardValues_mF92B51FE0ED7E1F8D89B691824CF7AAEC799DDFD,
	BooleanConverter_GetStandardValuesExclusive_m96A3138B9528AB4BAC2CAEA77493BD3A87C6E075,
	BooleanConverter_GetStandardValuesSupported_m0F180543294A0E3C0F33460F95C1A839372A2C9F,
	BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4,
	BrowsableAttribute__ctor_m74B2B058CBFEE54B61640489C57D22055C7B482C,
	BrowsableAttribute_get_Browsable_m84931BFF3F51CB9F14D7B1D7548B796FE2DBB8D2,
	BrowsableAttribute_Equals_mE405587EE66B0D70C2D59B27C01C65C96C391FBF,
	BrowsableAttribute_GetHashCode_mB190CC4AC3C2A7F8351335208D308E11C12A342D,
	BrowsableAttribute_IsDefaultAttribute_m71A749AC32DD9BCF4555DB7DE953E11C8A11651C,
	BrowsableAttribute__cctor_mE60A9058276719078B402CD5CA7E2D2FD831FE93,
	ByteConverter_get_TargetType_m21CE42EF4CCA5DB8100AC9DECF783C8A005B8B26,
	ByteConverter_FromString_m0CAA015CF3C267450EF9F6EAD7D1AADF18B783C1,
	ByteConverter_FromString_m382279DD8FDF6650EDFC5977445BD2737200BC87,
	ByteConverter_FromString_m7A932F208E2E545D5F04E9A884468EA5A2DEA54F,
	ByteConverter_ToString_m605162970D456ECCCD143AE873B1A66B7B8A5372,
	ByteConverter__ctor_mAA3E9232945941ADBB7CCC1E7B0DCC5F8FDBF766,
	CharConverter_CanConvertFrom_mACC1C53BA7A3678023FA71E57FF9537B9135329F,
	CharConverter_ConvertTo_m0AE58CD85062AD115A508B40DFA8C03C2B4F5E30,
	CharConverter_ConvertFrom_mEF1930149E499F9B6BB23BA076B05D409147D8ED,
	CharConverter__ctor_m42C950C40D8A37114897889BE6FAAE8EDEE428E5,
	CollectionConverter_ConvertTo_m75D7A858FB6E5B535386F5DB31CE3B6C8B153837,
	CollectionConverter_GetProperties_m157B337350174872C0A16671185BE3343FBA08D5,
	CollectionConverter_GetPropertiesSupported_mD6B7423E7544EE67C784C160905E681816E8C7A5,
	CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7,
	ComponentCollection_get_Item_mE2B50B2203E85B0FFD12BA25AB74284D0E1BF85E,
	ComponentConverter__ctor_m49FB91A291AFCD94E41DD41B9B16A938A5FA5273,
	ComponentConverter_GetProperties_m8C283D3EE69E185BD68E4A3570229F4B597C62F1,
	ComponentConverter_GetPropertiesSupported_m1329740DF56E38B1C12C0394C25150078D31B7B6,
	CultureInfoConverter_get_DefaultCultureString_m202C68B34215169C103318A3A1620995A186EB61,
	CultureInfoConverter_GetCultureName_mA1618DE646813A98D2FDA246EDFE83D8015085E9,
	CultureInfoConverter_CanConvertFrom_m85B0075150593AEA00319D8DABEC28929EC4C706,
	CultureInfoConverter_CanConvertTo_m0AAD1DACA5AA6A17F6EA0246D8B787D2240BFEC2,
	CultureInfoConverter_ConvertFrom_m49DB6CACA3C6739CD8C2ECA4CF1459D4420D609C,
	CultureInfoConverter_ConvertTo_m2283E0757C117D8E1A62DF66D50C182FEFCF0A2E,
	CultureInfoConverter_GetStandardValues_m9F08100099391767017F8BC0506F955DEC48F1D6,
	CultureInfoConverter_GetStandardValuesExclusive_m2EA028A53B09A143A8D1C66E16DD38A4F94D9888,
	CultureInfoConverter_GetStandardValuesSupported_m0D68B3C3A848E81B3D868C323A20ADBFB7EB33AC,
	CultureInfoConverter__ctor_m7638B1C404D5C207B2FE06E6F53638A978CCC375,
	CultureComparer__ctor_m24BDA06BAEE28F088B3B43FBC1F028F68E9E5B83,
	CultureComparer_Compare_m74AD5F7935B54AB74291A38893B50E0CC609DA29,
	CultureInfoMapper_GetCultureInfoName_m794274715866D2D8F320CBD3A051B55B24824720,
	CultureInfoMapper_InitializeCultureInfoMap_m1FF56C2C0CF698132D8D96126D41A92340C4F040,
	CustomTypeDescriptor__ctor_mD442A0BE59DB1D9EF0AC695FC857C18570B2AAD2,
	CustomTypeDescriptor_GetAttributes_mA2DFA9E08F4CBE42FF54C0EA9313ACACF22AF1E9,
	CustomTypeDescriptor_GetConverter_m326AC0250B0AECC9EE172FF9A6A112098EC7EB6C,
	CustomTypeDescriptor_GetProperties_m75853C1C9E6D90013A8AAEC85E5B2C68BFC42D57,
	CustomTypeDescriptor_GetProperties_m9335548766C00E208B215333BF609541C4D88253,
	DateTimeConverter_CanConvertFrom_m47FF2772D08D0692FD2DDF4436584F38422F5FA1,
	DateTimeConverter_CanConvertTo_mB2896928A5346D92A19E3E59A409760F203C111A,
	DateTimeConverter_ConvertFrom_m5F118F03495AD23C3694DD1F984B982A1B0F8D33,
	DateTimeConverter_ConvertTo_m9C4EFE6069A6BBEB95347CD4ABAE8EA9103CC516,
	DateTimeConverter__ctor_m1B60FCB4F2053392F67CF6B8398AB82291CC2FD2,
	DecimalConverter_get_AllowHex_mFB916A7101AA8F202F2EE1952E47B98D8D8D9AD7,
	DecimalConverter_get_TargetType_m9D7F2BB39848B5F8A436A900487B55F6FCA94F20,
	DecimalConverter_CanConvertTo_m055F9F0239B7D7970F61F3D5B14B3C1991E82C49,
	DecimalConverter_ConvertTo_m5B21E6AB73251329BE83E9A25C4E2DECD2AE82C2,
	DecimalConverter_FromString_m00911E3824B71042A46E46CF5F0270D5EBBE77AA,
	DecimalConverter_FromString_m3FF2CFCCA66D2D6EBEC5E10A48A9F450C7F37949,
	DecimalConverter_FromString_m7C29C3AB8AB31C0DF043B36C1D32578C5DC09D78,
	DecimalConverter_ToString_m9E32217983BD348797296512695A5341C30697AD,
	DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7,
	DefaultValueAttribute_get_Value_m4C07236B56BD114C38BA7DA8C94605A174EEC005,
	DelegatingTypeDescriptionProvider__ctor_mCA7A19A0B8F2306A3FCBE5541B92E0F1D1376B01,
	DelegatingTypeDescriptionProvider_get_Provider_mA048A519047ACF1FB8AB8604AC985038883688E7,
	DelegatingTypeDescriptionProvider_GetCache_mB2D34194960FB5604FCCA8DEB3F563BD0E73321C,
	DelegatingTypeDescriptionProvider_GetExtendedTypeDescriptor_m253D9E8BB497010592F6EDA8D601DEDF11191CD2,
	DelegatingTypeDescriptionProvider_GetExtenderProviders_m6A6C2B71F960A4A5A8FA32B49DACD4872928D553,
	DelegatingTypeDescriptionProvider_GetReflectionType_mAE5CE00625A29447106956644B1E52E7E7588E79,
	DelegatingTypeDescriptionProvider_GetTypeDescriptor_mFD091994993864869A433CD2507DE15B70D2A7E6,
	DescriptionAttribute__ctor_m4813112E0C52509AA577C0A9A27A8C1D596CFF4E,
	DescriptionAttribute__ctor_m5964EBBE5F72FC3B765F2657E0C7A6A9EF1DF2C5,
	DescriptionAttribute_get_Description_m86EA9FDCEF55F6643C195B45A9BA6A58E30875B3,
	DescriptionAttribute_get_DescriptionValue_mD892D328BECCFE526144A4B778DCC2B4BC8D45CD,
	DescriptionAttribute_Equals_mD0C91C3BDA1081BC9ECD15B9D8770EC9B8CCCB51,
	DescriptionAttribute_GetHashCode_m936BEDB9238E6BF727014567451AD7DAC9F2B163,
	DescriptionAttribute_IsDefaultAttribute_m027507DDAF18946B4CB2FA3015FE73EBAC53D62D,
	DescriptionAttribute__cctor_m70E48D1F612C3405E8C981060431512C0374C438,
	DesignOnlyAttribute__ctor_mEBDD48E0B85C8D87398601C52C8FFFD17CB39415,
	DesignOnlyAttribute_get_IsDesignOnly_m68CBE6C4AD7154EE82ECD431849BA377756874CF,
	DesignOnlyAttribute_IsDefaultAttribute_m6D873950CDF25510F438ED647346317CA7A647FF,
	DesignOnlyAttribute_Equals_m076651DB673496528EE4BE929689DE99BEAB8B13,
	DesignOnlyAttribute_GetHashCode_mADCBF4B2BF7067D02A09CF088C8D69F468C483AF,
	DesignOnlyAttribute__cctor_mB4872B8DD73AE15130706DEC6C80D66903C6D2C6,
	DesignerAttribute__ctor_m80FC02525242A357EB829F1FF6E323C243571DF5,
	DesignerAttribute_get_TypeId_m5FEB8253BDB826CF1B19CD7CEAE5622ADBFA6A63,
	DesignerAttribute_Equals_m8F8B48C9F60766DE6DEB22CB0ED72F2B16C8C659,
	DesignerAttribute_GetHashCode_m756E31506E31D909272E5289ADC2DCB0DA675437,
	DisplayNameAttribute__ctor_mCA2BCC655453F00B75B3E6E072777304FA3599A9,
	DisplayNameAttribute__ctor_m3D4B66E435734FFA29B405B346956880AD44AF5B,
	DisplayNameAttribute_get_DisplayName_mC1FE61B42690D98511D52340E04E6C54D1F4D494,
	DisplayNameAttribute_get_DisplayNameValue_m6A75B8CBDD8F55609180D19E79E74BF7656F9163,
	DisplayNameAttribute_Equals_m7893F7A4E50D758CC46D15D3C7FE754471FA51AE,
	DisplayNameAttribute_GetHashCode_m1369380C57DDC20FEBAFC4562305B7BAF52A1F64,
	DisplayNameAttribute_IsDefaultAttribute_m9835E20454EBC53D6F16D5B74B356EDA465D6FE2,
	DisplayNameAttribute__cctor_m42C8D9A551BF01816245A28D6291C7F17E29910F,
	DoubleConverter_get_AllowHex_mDB902FA678E2823F8775CF2410F8BCFD45135A9A,
	DoubleConverter_get_TargetType_mE2AA85910CF4D5EE2857F5472FAD6F60E96FDA6E,
	DoubleConverter_FromString_mDCD894BDC0A4DFB12E269CE8FF72B377691E4095,
	DoubleConverter_FromString_m0FA24E767CC4FFA9CFD7B7CE0D382A0CA8903980,
	DoubleConverter_FromString_mFC898691E3FC0C34E4BAB3643645E081F4FF3347,
	DoubleConverter_ToString_m9C99B65F40B918222ED348FA19F750EC02DCD72B,
	DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB,
	EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E,
	EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA,
	EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6,
	EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774,
	EnumConverter_get_EnumType_mE363752176E628FE1D15517BCE6F7FC98DEE6F68,
	EnumConverter_get_Values_m83899F439FCAF72024528B8F04C9B7B1CC81C8FB,
	EnumConverter_set_Values_m3769DFEE063A44FC1CBE85754639A0717F3BCFC1,
	EnumConverter_CanConvertFrom_m283E54FE7BFCFC3CF022827F20678CE40698BAE2,
	EnumConverter_CanConvertTo_m0BDD50EB0F3A7B3364DDD86650151F95C4D4965B,
	EnumConverter_get_Comparer_mBD0584D1B45E8ACFFF5E0FEE31F0983033B1EA2A,
	EnumConverter_ConvertFrom_m06D2FC9021EB3AF4BF131CE8E7268CC41A8994CF,
	EnumConverter_ConvertTo_mBDC59D2EE871592603097C069D557F4D9A79ABFB,
	EnumConverter_GetStandardValues_m30FF1BC7361719D9A5EE7205F4F63B5CB1E95E15,
	EnumConverter_GetStandardValuesExclusive_m62880BF09B41A7CE88E01AA29C4CFE44A736A178,
	EnumConverter_GetStandardValuesSupported_mAC1496A78AEAD3844C796F9641AD2BC10CD6E1C2,
	EnumConverter_IsValid_m5D3AB88EAC5C70586DC64D867F99139FB82FFD87,
	EventDescriptorCollection__ctor_m39980AB8EA7F2F7B480F18E4EC36796C1A259CD7,
	EventDescriptorCollection__ctor_mDC62048A9CCD9F4E5C2CE7BBEB7C995A60ACB0D5,
	EventDescriptorCollection_get_Count_mCAA673C0D2447E4823B34AE97D61BBC999A3E6BC,
	EventDescriptorCollection_get_Item_m861DB4DC0B594DC2BCB973266F49F77DB790689E,
	EventDescriptorCollection_Add_mC05DAE99E5D1B041F5755F71E6A2E114640F9779,
	EventDescriptorCollection_Clear_m72C4D0C9B92F9055A62EE6D86D9F3E86264405B5,
	EventDescriptorCollection_Contains_mD58C927756864E91133BD59356756E96253D4416,
	EventDescriptorCollection_System_Collections_ICollection_CopyTo_mB67B73650B5657F8405395D0BD6521ED8A3AF0D6,
	EventDescriptorCollection_EnsureEventsOwned_mF1722C2F3574DFE39C8509B62BA0013A68A1C8FB,
	EventDescriptorCollection_EnsureSize_m025A1E96DE65403C6BB70BB95F9098E6572EF191,
	EventDescriptorCollection_IndexOf_m2F0D99D9E5885CC7DB6133839635E9C806F6A385,
	EventDescriptorCollection_Insert_mB3259BB95ADAA9B11B8A2171F5FAD03C52C40557,
	EventDescriptorCollection_Remove_m9F6BF67636B9406EEFB0E3589F4EB3BAF625447E,
	EventDescriptorCollection_RemoveAt_m3124EA86A586B8FE157E6D6F594E3DCA0752D6D1,
	EventDescriptorCollection_GetEnumerator_mEC07212EAD84EF5CD1DB03CFF3773669A030342F,
	EventDescriptorCollection_InternalSort_mFC9324E5B172C969B8930B47ABE42FF8C2FEEC72,
	EventDescriptorCollection_InternalSort_mAF3920AA7607A00C1B327539E007F9BBCD2FF13F,
	EventDescriptorCollection_System_Collections_ICollection_get_Count_m360696919250EEB37806F7B331BC2D5127021716,
	EventDescriptorCollection_System_Collections_ICollection_get_SyncRoot_mBDACC0F4D991CDC34E1447AA9D5BE06B6A0E44F2,
	EventDescriptorCollection_System_Collections_IEnumerable_GetEnumerator_m175494690E3ECAC20382096A8D43493C6DF3245A,
	EventDescriptorCollection_System_Collections_IList_get_Item_mF9F2044326BAD3E203EE9C4B71998C6139671E7C,
	EventDescriptorCollection_System_Collections_IList_set_Item_m12BD29BF86D1A0AC1255C811F7E9BE0D56DD48DD,
	EventDescriptorCollection_System_Collections_IList_Add_mA285053C7C5617586A25D1B3FD1DA834A484F9B9,
	EventDescriptorCollection_System_Collections_IList_Clear_m690719A2AC9F81A4B9D94878CA2A991F07F2538C,
	EventDescriptorCollection_System_Collections_IList_Contains_mF75078ECF8D88E161AA11A9AAE71543ECB3CEC26,
	EventDescriptorCollection_System_Collections_IList_IndexOf_m48410473C90632946175F748D09BFAA506D0578E,
	EventDescriptorCollection_System_Collections_IList_Insert_m0538802AE7EB66BDF621A96C23637A50738FD995,
	EventDescriptorCollection_System_Collections_IList_Remove_m7416A79A4EA58351DBF9B8111C69A6CA8DD1DB05,
	EventDescriptorCollection_System_Collections_IList_RemoveAt_m9DCA747BC2AC75F2920EC289C66FCE2099622329,
	EventDescriptorCollection_System_Collections_IList_get_IsReadOnly_m1D57F4D7C77E62F7E06273DEC783685E107D0DB5,
	EventDescriptorCollection_System_Collections_IList_get_IsFixedSize_m00833DCAD0FB8406395CDA1CA0E6C4DDBF958100,
	EventDescriptorCollection__cctor_m027E184FD1333633CEFBEE18BA140A89E8DEEFB1,
	ExpandableObjectConverter__ctor_mDFE2C6DF3E42BFEDD938757267F2A6E40B8FEB66,
	ExpandableObjectConverter_GetProperties_m674DA113DAF377614A8EB8BB5BE199BEF53B37C2,
	ExpandableObjectConverter_GetPropertiesSupported_m6908E999010CD552559E3143245E02D69BBB4B73,
	ExtendedPropertyDescriptor__ctor_mC8CA04D11B52520D581769FB316244C9EA5F7420,
	ExtendedPropertyDescriptor_get_ComponentType_m6DBE270D501CFAB038FF8C12EF71A93F3C3025D7,
	ExtendedPropertyDescriptor_get_IsReadOnly_m2F1AB64D3CB1ED3E62800A2F52CC94645382B42A,
	ExtendedPropertyDescriptor_get_PropertyType_m4F634F2E318150F948FA3D4572F7626C7E8968E2,
	ExtendedPropertyDescriptor_get_DisplayName_mC5690961D9E460239779D421E4C5636958426E84,
	ExtenderProvidedPropertyAttribute_Create_mB53BAA317F0E146F21F4508E51921C05459A756B,
	ExtenderProvidedPropertyAttribute__ctor_mED416479A8167DB724212857B8421BB4079D9F14,
	ExtenderProvidedPropertyAttribute_get_Provider_m54BFFEFF3AF82BD3F36AC3A1D473FAC53CF368C6,
	ExtenderProvidedPropertyAttribute_get_ReceiverType_mE35ED6058DEBE1160D17BF385E2C46E161085E33,
	ExtenderProvidedPropertyAttribute_Equals_m7FAB4FA6A11AAA6451F18CB7B06D001FD257EAAC,
	ExtenderProvidedPropertyAttribute_GetHashCode_m6D03B17855FE555DA2E3F54F11C164BBD3150FB4,
	ExtenderProvidedPropertyAttribute_IsDefaultAttribute_m2BEF7A86CD44FC50CE84586895CE253453A18573,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Int16Converter_get_TargetType_m03C28B87C29C22B04B4D41C0F654612CADBBD144,
	Int16Converter_FromString_m5037FE57C286C9CAC9CDE3116D0F426EF88993FC,
	Int16Converter_FromString_m1D6EED88E7A619CF41C3F822EF148DC647521367,
	Int16Converter_FromString_m68A48D7A88B2206AD366C3CD5824C90CB483A01B,
	Int16Converter_ToString_m04E267BEB959CCCD5FF76F5221B4A82D3B90DE23,
	Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D,
	Int32Converter_get_TargetType_mADD76E2E99D4B78ECB684AE296C6AD5E45840433,
	Int32Converter_FromString_m522F024625D49139F89AC5DE44EA3DCFDD490B55,
	Int32Converter_FromString_m99A5C50498D91308BEA81C8E9E134608DD525799,
	Int32Converter_FromString_m84E1A77746AAC084FF5A93E167D6ED83A772C704,
	Int32Converter_ToString_m30AAD6DCBB228CBD58299310D39D80A44AEB7C6A,
	Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9,
	Int64Converter_get_TargetType_mA6FF642BF7B48C93043B520B6F56598262324155,
	Int64Converter_FromString_m40D208F2EDE6FFDFF6A897EDE71636290F759A61,
	Int64Converter_FromString_m9537EF10EF270D889756264177A7AD71BAC3342C,
	Int64Converter_FromString_m4B006B13E6B60FB3471055D2AACA19A20BC6C73A,
	Int64Converter_ToString_m914E4B677BB3D12FEFF432696606554C7276093C,
	Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74,
	MemberDescriptor__ctor_m7DA97C2FCA1C99D7D7B31A89A908219E4A48DE7B,
	MemberDescriptor__ctor_mDDA60D0BB2448D6607AB2F2C353A8C30CFABE0A3,
	MemberDescriptor_get_AttributeArray_mDB41975C313AF40B0FA82B33F0AD504E92F3FDE8,
	MemberDescriptor_set_AttributeArray_m26BD377D06AA20A1A9A2DB982904B10CBF6D81F7,
	MemberDescriptor_get_Attributes_m4D430272C6E7D07FD2DD901B6FC26E3886217153,
	MemberDescriptor_get_Name_mFADCC43480F88C3749FA2B82EAECA54F79D848BB,
	MemberDescriptor_get_NameHashCode_mA91F4591F9D76BDCB3A43FFA2EF534DAB62CDB6A,
	MemberDescriptor_get_DisplayName_m985D97ED7EAEC1A7DA3524E50FB0CF9B3704B746,
	MemberDescriptor_CheckAttributesValid_mEAFC02C4EAED626FCDC291F1512DD0E602E232BE,
	MemberDescriptor_CreateAttributeCollection_m579C3F75B24CD1373AE01189CD3CB9CBC6C49E66,
	MemberDescriptor_Equals_m66818127B5F93EE67144CB305127BA3377601E54,
	MemberDescriptor_FillAttributes_mA33C5FFD1DE2BA560E335B6549E60A229B9F773B,
	MemberDescriptor_FilterAttributesIfNeeded_mDEFEACE930F7537A7DF7A530198F04C73301D591,
	MemberDescriptor_FindMethod_m4B26329E481C2681B235A311E2E7D022DC891773,
	MemberDescriptor_FindMethod_m55C2AA54F198A970DAD868DE103F41602CC4ABEF,
	MemberDescriptor_GetHashCode_m7E6C8BE058C4A813FE927FC0FC2D97981A3B1CE2,
	MemberDescriptor_GetSite_mCB20B3C6E8E9E4018655CB861FBC408F4468FFD6,
	NullableConverter__ctor_m508F1DA74FE1B37ECA5BBA5B0E3A623480E4C564,
	NullableConverter_CanConvertFrom_m248A954CEE87B4098FADA66CF035910E75C22DB9,
	NullableConverter_ConvertFrom_mB26A50D9B33247B7B6F52BF3C2091DB587296A29,
	NullableConverter_CanConvertTo_m971F73488C57414C8463065CB0CB0285D642519A,
	NullableConverter_ConvertTo_mFE5CF810C6BE39B1A39E51B28875E8FDF0DAE363,
	NullableConverter_CreateInstance_mC3E844589AD43223F7185523DD99CAAB580BBC52,
	NullableConverter_GetCreateInstanceSupported_m26E7E2DDF37037BB6371AA566CA27104185B16EF,
	NullableConverter_GetProperties_m6FDB181A72AC16A73DA6DCFB78E86C7665D73A5C,
	NullableConverter_GetPropertiesSupported_mA4CDDD3DA6F77162E6BA4B1654C9C8FC1E45F68D,
	NullableConverter_GetStandardValues_mE04D07ED245061BA6DF9A639DBB37B2ABBDA0E99,
	NullableConverter_GetStandardValuesExclusive_mE2DDC86AB100AFD0F01D9E798148B95F9F1DCB78,
	NullableConverter_GetStandardValuesSupported_m45F8361AB3BA832C14A71D2FE12B6A11707AC9EA,
	NullableConverter_IsValid_mB0A466B916926A2B3442A69F7C8C86AB148C01C8,
	NullableConverter_get_NullableType_m3DD5EAE964748743F8CC684C72EC663C75491826,
	NullableConverter_get_UnderlyingType_mF4A327831A2B20FE4FD3B734570509B6B5C327AF,
	NullableConverter_get_UnderlyingTypeConverter_m71AA3BCCFFC7B4D61971C691312DF0767350758D,
	PropertyChangedEventArgs__ctor_mBC582C76F42CDEE455B350302FFDF687D135A9E2,
	PropertyChangedEventHandler__ctor_mC6EC20F2995A9376A72EB51981850A9E5C8450E7,
	PropertyChangedEventHandler_Invoke_m7DB0AABF07302887DD3FEE589E1F585B4C768F57,
	PropertyChangedEventHandler_BeginInvoke_m77D416AC801FF29FBF4D294574231171FE2E551D,
	PropertyChangedEventHandler_EndInvoke_m3539B5822D063A13DF8EBCA57CA475A7B5BE32FE,
	PropertyDescriptor__ctor_m8CEC4DAE5266714927949F60E4F8A7F31141BC22,
	PropertyDescriptor__ctor_m8C1C276319F5C29A452F48C89B595334AB7E65B0,
	NULL,
	NULL,
	NULL,
	PropertyDescriptor_Equals_m080009C26475A3CBEE1291AC5F1BDFBF4EDA6597,
	PropertyDescriptor_FillAttributes_mA3E3A90097B815BD8F7A185036485FF86A03256F,
	PropertyDescriptor_GetHashCode_mF36CC7A4B3F53BE7EE8DB89B7E4B2E4C3F7A3075,
	PropertyDescriptorCollection__ctor_m132BE5B53DC73850841F2AB9A6633F4626C538BC,
	PropertyDescriptorCollection__ctor_m7DDFDE6996940ED1E0BF5073548E5C5B058D6D6D,
	PropertyDescriptorCollection__ctor_m0BD142D7B2CAD889393CC69ADA2233984768DABB,
	PropertyDescriptorCollection_get_Count_mAA1EA8D4BE590EE7F7E469876FB503F2A0F0E4B0,
	PropertyDescriptorCollection_get_Item_mD0F537639842BDFC56F142C00A4041CF598D26C2,
	PropertyDescriptorCollection_get_Item_m2FEEB6EF3922067EC403A4261D4FB6E77843F628,
	PropertyDescriptorCollection_Add_m4EC994159DE3EC1B05CCD9186099D7935FF3ED33,
	PropertyDescriptorCollection_Clear_mAD94D5BF4918591FEE475B3FC15A64729F89A3DE,
	PropertyDescriptorCollection_Contains_m8262E7DEBA9D0C9496CE3DDA85BC1F1995F18DBA,
	PropertyDescriptorCollection_CopyTo_m7F65E93884A12E569B035774440FA977CB9D3A30,
	PropertyDescriptorCollection_EnsurePropsOwned_mA7CDF7318480D4512B76733D3E1DF9EAE6C378A1,
	PropertyDescriptorCollection_EnsureSize_mCCF9502C5BE2212F88FDC6507E598175CF1298BA,
	PropertyDescriptorCollection_Find_m5B0293378066DA6E64B89658470B49EC2767E3B8,
	PropertyDescriptorCollection_IndexOf_mFBCAE0B916F2BF733D494020EBA7EFEEEFC20A45,
	PropertyDescriptorCollection_Insert_m22DC9C6797AE20CFE2815DCB8C5A98A9A363BDCD,
	PropertyDescriptorCollection_Remove_mCFFC999272C8C7B4C325B6D32A9DA2FC6DABC997,
	PropertyDescriptorCollection_RemoveAt_m988ED89DD8C6F2D254BD664991461869786977F0,
	PropertyDescriptorCollection_Sort_mCA6419FA5C73054D08EC62386E64C864D26C392A,
	PropertyDescriptorCollection_InternalSort_m5BEF1BE7A393A601E9E404644C037EB7552362C6,
	PropertyDescriptorCollection_InternalSort_m05765A385A5F324219F60E3880193230BCCE8863,
	PropertyDescriptorCollection_GetEnumerator_mFAB322230D6F91D8B5076910CF9D6107DBC768BD,
	PropertyDescriptorCollection_System_Collections_ICollection_get_Count_m4A8DC9D8BD368E2998FB84F1E764B746AB406C2D,
	PropertyDescriptorCollection_System_Collections_ICollection_get_SyncRoot_m0100C4A2C9B18F6E1A201E29C6F12D1F265DCA4A,
	PropertyDescriptorCollection_System_Collections_IDictionary_Add_m76AF67DE822D94A046E14382F1841C835EADA094,
	PropertyDescriptorCollection_System_Collections_IDictionary_Clear_mCD2DED6F88201D0839F266BA27ADA4C9CDAD8E7C,
	PropertyDescriptorCollection_System_Collections_IDictionary_Contains_m2BF92AB5B0E6DE71F06C21D6A79F40EEB66DE53A,
	PropertyDescriptorCollection_System_Collections_IDictionary_GetEnumerator_m8BAA6008671D58327735A8CAF9F5916EAFA4B2F2,
	PropertyDescriptorCollection_System_Collections_IDictionary_get_IsReadOnly_mCA0E47965BC12EE580E220E38B71BB97CC2807C9,
	PropertyDescriptorCollection_System_Collections_IDictionary_get_Item_m55B7B06FCFD64E0549A25F402E880015FA39237D,
	PropertyDescriptorCollection_System_Collections_IDictionary_set_Item_m45799DA37784A9840E8BCA5FA746535CDD86D696,
	PropertyDescriptorCollection_System_Collections_IDictionary_Remove_mEE3E78216CC8C1192BEF19A0610D5345808B1D76,
	PropertyDescriptorCollection_System_Collections_IEnumerable_GetEnumerator_m98DD98C01E84C0A8729E0C7EEDC9265A4911FB61,
	PropertyDescriptorCollection_System_Collections_IList_Add_m7805DEADF351C068D3397DB5C6D84C639452B874,
	PropertyDescriptorCollection_System_Collections_IList_Clear_mB8004EB4547BD17A52732BB53EE9D54FAB27C638,
	PropertyDescriptorCollection_System_Collections_IList_Contains_m480A973ED000ECA6482E3BE2970009A09ED545FA,
	PropertyDescriptorCollection_System_Collections_IList_IndexOf_m5784A077E0E4C9936D1DD476E58374AD27063CF7,
	PropertyDescriptorCollection_System_Collections_IList_Insert_m8B356017EBDC3A70B466B4787016840F89074F0D,
	PropertyDescriptorCollection_System_Collections_IList_get_IsReadOnly_mC37BCD9B3BE2F5B9773062BF82C3AA5D6645F227,
	PropertyDescriptorCollection_System_Collections_IList_get_IsFixedSize_m56B5321D84E8B06C5A557009E62A7335A4EFA018,
	PropertyDescriptorCollection_System_Collections_IList_Remove_m23C0000AD3979585B0659FEBCDE0B3EFF1207FEC,
	PropertyDescriptorCollection_System_Collections_IList_RemoveAt_m9FD20F8FDF9167173D07E0FE7C22E0D3A85B781D,
	PropertyDescriptorCollection_System_Collections_IList_get_Item_m444F1383137CD08C6AE33B93743C22970975B68B,
	PropertyDescriptorCollection_System_Collections_IList_set_Item_mC9C9476E42ADB9166CFD8FC7C7AA379EBB8F8E4B,
	PropertyDescriptorCollection__cctor_m5DE8BDE158CD72E98E2ADD9DB3151F931CC9FB0F,
	PropertyDescriptorEnumerator__ctor_mD766982CCA3E90487BD77781B1EA0C29F9477B7D,
	PropertyDescriptorEnumerator_get_Current_m010FD0E05A0FA950A30C202CF643D7B3934557D8,
	PropertyDescriptorEnumerator_get_Entry_m8BDC6BA3A4A5620F2EA393763B6BF271FD58AB60,
	PropertyDescriptorEnumerator_get_Key_m229FC1FF77DE80A679B1FE548094C02AF396A9B0,
	PropertyDescriptorEnumerator_get_Value_mADCA4A1AE3EB26072C808EACB670596099943359,
	PropertyDescriptorEnumerator_MoveNext_m6AB35EFF1B4CC455D419DF2C4F55DFCFFE420E1B,
	PropertyDescriptorEnumerator_Reset_m4FFA35A10951E339F0A75683E0151217D120329D,
	ProvidePropertyAttribute_get_PropertyName_mCFB6B8ECE17E7FFD9FA7D5EE4FB0FACEDE552AEC,
	ProvidePropertyAttribute_get_ReceiverTypeName_m66AECE2E8CB9069B1A1EC02C17BE84B4D176BB82,
	ReadOnlyAttribute__ctor_m57EACC99156B2E048A2BA49ACF9F58FBF6537752,
	ReadOnlyAttribute_get_IsReadOnly_m0626C74195DDB464E767AFE4CB8C205C267C8866,
	ReadOnlyAttribute_Equals_m26B602C82A7F89B540D34BCC23DBAFEF44AA8F4F,
	ReadOnlyAttribute_GetHashCode_m697ACF28ADDA00FCE0470F0014FB341AB141796E,
	ReadOnlyAttribute_IsDefaultAttribute_mFE2BD94B822BE83971CA81A4A364ED0265E7B294,
	ReadOnlyAttribute__cctor_m82F2AA3C79CBEBF7C845B6EF35A5774A25CB33C4,
	ReferenceConverter__ctor_m2FB1721E7BE48D8857E0BF4690A1FB82C9EC1DC7,
	ReferenceConverter_CanConvertFrom_m5B23C497B2BFB682E5733F35369FB714098EA731,
	ReferenceConverter_ConvertFrom_m9D3A8DC96E994551E61A2432EDE3978A61370650,
	ReferenceConverter_ConvertTo_m82E3032D3598D3E709C5475209ADFE427FD7EDFE,
	ReferenceConverter_GetStandardValues_mF0F5434970C6CA3D182842120296A2FCC3928BE2,
	ReferenceConverter_GetStandardValuesExclusive_m4CCC72D62B9A051A01F70D48219920A639481B28,
	ReferenceConverter_GetStandardValuesSupported_mE721CE30F2B1CC5C3BE0A46B349D6C96F0932405,
	ReferenceConverter_IsValueAllowed_m1CFB041C5BF5BE8FA167627CCC406C607498C069,
	ReferenceConverter__cctor_m6B8D4BF669E7923D139320E54DF971BF30D4825C,
	ReferenceComparer__ctor_m7547D75DBAFDA96F03302A6FE4E5AE47153AE77E,
	ReferenceComparer_Compare_m0B320ABB7F1A30AD4FB195849020B843764BE1D0,
	ReflectPropertyDescriptor__ctor_mB5E1EB28647D1B39D7EEC2A60C41BD3F2B5EBB4E,
	ReflectPropertyDescriptor__ctor_m81658E6FF4EDE19BDC21661F2AD7F1D428DE2D90,
	ReflectPropertyDescriptor__ctor_mED173B591B660C3642C4F39591EF6A2CBBA13C5F,
	ReflectPropertyDescriptor_get_ComponentType_mBDBB35C343705F6E0BCF6E29CA74EE9AD7192C5E,
	ReflectPropertyDescriptor_get_IsExtender_mFFEE1C5A723D8A0BBBAC2AFE3DA9B77D7821727A,
	ReflectPropertyDescriptor_get_IsReadOnly_m5E22D2D628A2EE4DA486A40ED815A72C1574D641,
	ReflectPropertyDescriptor_get_PropertyType_m42BC13BCBD5DD4FADEF53D5BA86EB8BD8C1153F1,
	ReflectPropertyDescriptor_get_SetMethodValue_m9C7CB91D0400A7450E620516B1A30B2FD37791A5,
	ReflectPropertyDescriptor_ExtenderGetReceiverType_mEACD75A498F4FEA40302981092B93DBBC95EB1FA,
	ReflectPropertyDescriptor_ExtenderGetType_mD6042994CD9EFFCDE3177C09E58823CADA0CFBD7,
	ReflectPropertyDescriptor_FillAttributes_m6D3D9FF9C54562771EAFA7176184DF610B99B6EC,
	ReflectPropertyDescriptor__cctor_m63AF69EC4D3FA3894DDDFC6704D71401FE8DF9F3,
	ReflectTypeDescriptionProvider__ctor_mE3E181FF24A78513F9E285D485FA292B11708B17,
	ReflectTypeDescriptionProvider_get_IntrinsicTypeConverters_m9CC87D07619955CD00731AD91FC7F8323C18AF4F,
	ReflectTypeDescriptionProvider_CreateInstance_m1A50E07E2455EA23FDE96B06EFD81DCA451025D4,
	ReflectTypeDescriptionProvider_GetAttributes_mD827142E84D2111FBD6F88118D1DD0BCF898700C,
	ReflectTypeDescriptionProvider_GetCache_m90103F5B0B173BA5AA6F8B773FA02EE66FA58D7F,
	ReflectTypeDescriptionProvider_GetConverter_mB8782B30A3D40FBDB37A4FD68A635149B0154880,
	ReflectTypeDescriptionProvider_GetExtendedAttributes_m27849C4290581FFD9B350AD671E5DE9764531E46,
	ReflectTypeDescriptionProvider_GetExtendedConverter_m54A3FED3A123C2C0375E2FBCA5C4B29C6220BA2D,
	ReflectTypeDescriptionProvider_GetExtendedProperties_mFFA65F71DEFE3C3EBEBF8EE010EA69F524AE3D1A,
	ReflectTypeDescriptionProvider_GetExtenderProviders_mF9938FD27716A116007EF4F9E60B2E4E318D62F6,
	ReflectTypeDescriptionProvider_GetExtenders_m37F9CE244018FF66E847402A2E3F3A0F805D4843,
	ReflectTypeDescriptionProvider_GetExtendedTypeDescriptor_mE33F57B6C037B34BACC549681047C513D9C6934F,
	ReflectTypeDescriptionProvider_GetProperties_m198ED05393452A6A44A4F073C6B6EA08F4C62C09,
	ReflectTypeDescriptionProvider_GetReflectionType_mF229DC91D51765143C01388F689FAA98EB4EC658,
	ReflectTypeDescriptionProvider_GetTypeData_m297505206CB7033A420244CD3962881B3FAA55E4,
	ReflectTypeDescriptionProvider_GetTypeDescriptor_m99EE1E613367E54A6132ADD94E0D34772BBEB67C,
	ReflectTypeDescriptionProvider_GetTypeFromName_mAAEB4488DDC97DDC4780EC28C8CF4BD27BB9E9EC,
	ReflectTypeDescriptionProvider_IsPopulated_mDA141741A260991A87C6B4C7EE84FAB26220A534,
	ReflectTypeDescriptionProvider_ReflectGetAttributes_m378C9A3D2CB09CE7EBA76BCF431A99F6C2EF67DD,
	ReflectTypeDescriptionProvider_ReflectGetAttributes_mA3DA28648085382DC968178CE6B9D5288DE17739,
	ReflectTypeDescriptionProvider_ReflectGetExtendedProperties_m8DF1B37E62CB64A4249355F85F421C57BA1A16F1,
	ReflectTypeDescriptionProvider_ReflectGetProperties_m0F7F5B7591FEC0B4F26419E559C20E3134F522B6,
	ReflectTypeDescriptionProvider_Refresh_m6C8F1779B16BB22FAAABA8E16E5DB5AB1025DF89,
	ReflectTypeDescriptionProvider_SearchIntrinsicTable_mD70A9E795A2A1411479E8BB0ACE34604726C9D82,
	ReflectTypeDescriptionProvider__cctor_mB9C7F73E1722134C687B3BB8E0F484EF2F30FEA5,
	ReflectedTypeData__ctor_mA8A7CF229ABE16D20515D5A827382370C78151AA,
	ReflectedTypeData_get_IsPopulated_m0BE08AAC57F2AA79A21B33C3A4A3FC7EECE35549,
	ReflectedTypeData_GetAttributes_m663A1FD9948A46D290B3D9E033F291B1E535452E,
	ReflectedTypeData_GetConverter_mD37346D7D19C72DC50CBB82BF4F4F9DF5218D0B6,
	ReflectedTypeData_GetProperties_mEDCD21FF9DB7D27C3EF7ACC291E12B348AEC7CF5,
	ReflectedTypeData_GetTypeFromName_m9E59CF61CA7CAC4E47B9736F36891FCB2E325D27,
	ReflectedTypeData_Refresh_mA966D08F6AC6693D49DCB60CE3BF23ADBF4DE7BA,
	RefreshEventArgs__ctor_mEC162508026E43A0B4E193163E6ED7D6B682D342,
	RefreshEventHandler__ctor_m37CAC58BA1E426C888118B568F540D5FA6E4E9CC,
	RefreshEventHandler_Invoke_mF3ADA58FAFE8E56B53F99B9717A4D3E252575FF5,
	RefreshEventHandler_BeginInvoke_m21258C5F768FBD9949B49F95A574B80981515AFF,
	RefreshEventHandler_EndInvoke_mAF60D2A0CC7D45F8AFD1C1135EA3DF225545C030,
	SByteConverter_get_TargetType_m034BBA889EAAC775483117120F159E328D1260D6,
	SByteConverter_FromString_m0AE243DE3D62BE5B4D6B5902412E59B6F2B4C6B4,
	SByteConverter_FromString_mE18AD8A52E1E48B186DE67EAE676B20B29C69DD3,
	SByteConverter_FromString_m7B5EE08AE984C1211B9647C245A9DB220C867467,
	SByteConverter_ToString_m7DFD79BF472530D27DE2EFA08023C39AEF3EE048,
	SByteConverter__ctor_mA13FB10F00F75128F2A56113A5AEDEA2EDFB0826,
	SingleConverter_get_AllowHex_m9A8EC29BC10782CF9BC2E9C526B1F958876DDA43,
	SingleConverter_get_TargetType_mEE841A77D0642D07A7978A8A871FD73DD57EB7DF,
	SingleConverter_FromString_mAE00A2E4F24907D0666B2C4B62833289E96FDE8C,
	SingleConverter_FromString_mAB67D8A4BDEAC852EA4060FCE6F69C40F48E13DB,
	SingleConverter_FromString_mCE7472435CF8E8DF01D4B286AFFF545393E10E28,
	SingleConverter_ToString_m5002E1C3937CECC3094583349B9EF72474524583,
	SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8,
	StringConverter_CanConvertFrom_m50224B731176E5B25E43B35F74C0D1EA0859EC81,
	StringConverter_ConvertFrom_mC11C90F2FD2BD033AEA354185DC892D951FA5005,
	StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2,
	TimeSpanConverter_CanConvertFrom_m693C336C7A5435912FC4AC569E1EAD30BEB32FFF,
	TimeSpanConverter_CanConvertTo_m5AC96B662FA4EACCEADAC81931591E0B14711276,
	TimeSpanConverter_ConvertFrom_m4244DF51D5A1AC286C35FCE04D82F5A9A2F33894,
	TimeSpanConverter_ConvertTo_m6A1E0C832909670E26B892813AD9E14F08EE316E,
	TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B,
	TypeConverter_get_UseCompatibleTypeConversion_m4E8A4FB4000523FF099E5B064BF58BA44664E8CF,
	TypeConverter_CanConvertFrom_mB405721DE7D2532FA893C4F9242BD7675784DF3D,
	TypeConverter_CanConvertFrom_m8E1F9E41B7DEE6A032EAC70130ADC6356C3F227D,
	TypeConverter_CanConvertTo_mFD084EFAE4C064C6844E20E5A0C6719925A2D938,
	TypeConverter_CanConvertTo_m1CD3397D9E5717DE72A13B28C0A75D997A9F337D,
	TypeConverter_ConvertFrom_m3E71724F5033CD589B5D01DDD14E357582BD2476,
	TypeConverter_ConvertFrom_mD5AE49E422520F6E07B3C0D6202788E49B4698A3,
	TypeConverter_ConvertFromInvariantString_m9293C7DF0805F4C7EA4510B71724BDAC3BE80AB2,
	TypeConverter_ConvertFromInvariantString_m8CA941FF49C01AB09F89531ACB3FDF4F97C041E2,
	TypeConverter_ConvertFromString_m79BBFB959114D5294C21BD6FD0C4C0F826869202,
	TypeConverter_ConvertFromString_m24C4F0F94A2F6758E32DC307B232B29E2F05049A,
	TypeConverter_ConvertFromString_m29A7CD7DC7BD65459316FA4D807A1D16362C524E,
	TypeConverter_ConvertTo_m7A68C74ECC7FD5C58919C9AAD0FA4389D4E56149,
	TypeConverter_ConvertTo_mFC7AA7F0A382607E75CCE820A705B5965D099AAC,
	TypeConverter_ConvertToInvariantString_m761850CEC1FEE3C82ABE5F794DE84FFE29C852A2,
	TypeConverter_ConvertToInvariantString_m382F27F2262271AB0775D6FA6F413D24BEA28808,
	TypeConverter_ConvertToString_m2CBE8E127541982F2FB74F81D59AA62D097FD623,
	TypeConverter_ConvertToString_m5F4325990F5C0E979B0C18408D276534CC2B5101,
	TypeConverter_ConvertToString_m2601B49A8D7AB780DBA7F2DD08A3790DF7987FB4,
	TypeConverter_CreateInstance_m910234390A61C68C5AEB1F0376D922C880254734,
	TypeConverter_CreateInstance_mDC7CFC64F7538582820FE98B48B025956549FA6F,
	TypeConverter_GetConvertFromException_m10012C012ED008F8AC9DF76BBAD93E19DDA6EAC3,
	TypeConverter_GetConvertToException_mD906D7D39A16CC8ACFC0179208CE2627B73D5C32,
	TypeConverter_GetCreateInstanceSupported_mCFECC64262DC92B2474D88446010AF0421EE7E07,
	TypeConverter_GetCreateInstanceSupported_mA94E6A163BDDEF26EF22676B270763C010FA2D1C,
	TypeConverter_GetProperties_m02BA46C92F9265712A6637DDA1E4A0DBCFC10FAA,
	TypeConverter_GetProperties_m5C07AE2E3658FB12366BFAA4A6DA26C9AA26F631,
	TypeConverter_GetProperties_mE9B2F1B88BC6A544E6FB1B5369A9603D24871DA1,
	TypeConverter_GetPropertiesSupported_m51BD8041C9104A4B4102444C6E3E6A876544D5E3,
	TypeConverter_GetPropertiesSupported_m689053FED1C08F4E898BC80D3E802866A08CCE1D,
	TypeConverter_GetStandardValues_m0E0160DE18F9601C528E8CC773C8AC3873796060,
	TypeConverter_GetStandardValues_m58938306CEF726F9537744C71AC943E399D5F927,
	TypeConverter_GetStandardValuesExclusive_mC8BBDA525FD8038D81EC1F3C0CA18F69A4DD58DA,
	TypeConverter_GetStandardValuesExclusive_m6B189B96FF37D21B43FD397661F5C9960D7204E4,
	TypeConverter_GetStandardValuesSupported_mBD5FFD9335978CCD8C3A26F80D70D6B192E9E1DB,
	TypeConverter_GetStandardValuesSupported_mE7E8F04BE48835C994C035A90CBBFD7681B0D198,
	TypeConverter_IsValid_m464CADACE18B5EDEB9202AB8DBA183D8FB3463C3,
	TypeConverter_IsValid_m7F461605B50FF4BAED21EB5B59C65459CF5DC8F4,
	TypeConverter_SortProperties_m5AD81E82E93298C5FEAF26AC70BEC8EBF9981DA3,
	TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD,
	TypeConverter__cctor_mC99D8D0F3AA6CCB3E21123CFA7BAB73800CC38DC,
	SimplePropertyDescriptor__ctor_m8F44C82E16B8574F418418F47D8E6A3A52D0978A,
	SimplePropertyDescriptor_get_ComponentType_m39197EC5A3662AA3D3C3BA74A3F65512D445DEE4,
	SimplePropertyDescriptor_get_IsReadOnly_mD5DD3E9534AFE907A9D3A6E1E00ECF6B35FE2F3D,
	SimplePropertyDescriptor_get_PropertyType_mF8DD1C406A8679B366D7BC5DF4B0C72CDFFC31FA,
	StandardValuesCollection__ctor_m75578979BC0D77C0D622E4C9D7C1CB1E047615C1,
	StandardValuesCollection_get_Count_mD0531EA777492E88EBEA8C6B8E8A12C4AFE5103A,
	StandardValuesCollection_CopyTo_mA319F11A11360C258FCEEF3C9EFA53D504BD7C3E,
	StandardValuesCollection_GetEnumerator_m40E0D69CDEDD7EDE2D9454C4A18AA4C91A96B95F,
	StandardValuesCollection_System_Collections_ICollection_get_Count_m3B04852950AC738A4E8AF41974DA6AFB1CC2BAD6,
	StandardValuesCollection_System_Collections_ICollection_get_SyncRoot_mF42D50E0E5A77DD85C897C37352834E2D4023810,
	StandardValuesCollection_System_Collections_ICollection_CopyTo_m27D62D0B27B9151F55B3F3069E72B1B8ABEC5447,
	StandardValuesCollection_System_Collections_IEnumerable_GetEnumerator_m017DACA9E9C081C4964887FF9E1F7D8A36B7BD8F,
	TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5,
	TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C,
	TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8,
	TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4,
	TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA,
	TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A,
	TypeDescriptionProvider__ctor_m9A35B40DE4D4CCB86B72BD3BABF375982DB32912,
	TypeDescriptionProvider_GetCache_m9D7FBAC80ED350BC4C50D5C58FDB8F5C6DCDC2E8,
	TypeDescriptionProvider_GetExtendedTypeDescriptor_mA6C0C2BCF78F4018FA4C2278CBFD07E2E77E3347,
	TypeDescriptionProvider_GetExtenderProviders_mF8C68F2BA1E5CDDFAD9618C257F2D743FD10FF39,
	TypeDescriptionProvider_GetReflectionType_m5A731257A8DCBE75C4FE588A1CC73EE2FFCA7E16,
	TypeDescriptionProvider_GetReflectionType_mEDACDCA9A57ADF6F376DD6847315931630CE538D,
	TypeDescriptionProvider_GetTypeDescriptor_m8CC34F54B8A643F99C2F4E4C254D661D3DC212D2,
	TypeDescriptionProvider_GetTypeDescriptor_m04847083CB9DB8E7BF69CFCD06283A8D817293A0,
	TypeDescriptionProvider_GetTypeDescriptor_mE0B51D84608BE9DAB9597220D009C8F03ED7EE39,
	EmptyCustomTypeDescriptor__ctor_m3AF937D2171D0224FC6501A9AFA23F89BAC5B1D0,
	TypeDescriptionProviderAttribute__ctor_m10489BA811D0D61760F9C90B2D72542A08A3F90A,
	TypeDescriptionProviderAttribute_get_TypeName_m6C47AACE737391F28BD1C0A762AABBECA8DB8F75,
	TypeDescriptor_get_ComObjectType_mD9A4F9CDA5863A62DEE85F88DECB3FF37CE42A4F,
	TypeDescriptor_get_InterfaceType_m0DB3316CB939FE67643C044BAF39EB4F69D758E6,
	TypeDescriptor_get_MetadataVersion_m70C215D1B15DCBD67B58127EB0E6D7E6F5D020DC,
	TypeDescriptor_AddProvider_mD81A072B4AB0D7801F9297879CB43071C8740C9A,
	TypeDescriptor_CheckDefaultProvider_m992A2ED0D5F3621C00369DF8CF35D6AFB17D3ADC,
	TypeDescriptor_FilterMembers_m6DE8E2489628CB06AFAE539F0202E73AEB645AA9,
	TypeDescriptor_GetAttributes_m945F6ABA03A5014918ACA5F9B57F1F58B805EC0B,
	TypeDescriptor_GetAttributes_m0325F763D0AA6354E3F7859E15FF7BE3A8D5F3D3,
	TypeDescriptor_GetAttributes_mA96E001729AC6C2EF5ED8E0E5573BABF67501C44,
	TypeDescriptor_GetCache_mC7540D2FBAB562E689ED1BC2399D3F3C31D97145,
	TypeDescriptor_GetConverter_m30E075F6ED53FD85B7C1F7F44E58BA20645A68BA,
	TypeDescriptor_GetDescriptor_m03B8BB2FE0F4EB472FC543B31A37D627CD02D5EB,
	TypeDescriptor_GetDescriptor_m557DDD4B793F92E5D71B980E264ACCF1C6A2EFB1,
	TypeDescriptor_GetExtendedDescriptor_mD3B3C0990D1E6DF8A99C269710B4FC77DAC1BCFE,
	TypeDescriptor_GetExtenderCollisionSuffix_m686BE0F744E8E5511310EA611B39FF891AEDC784,
	TypeDescriptor_GetNodeForBaseType_mD4DC672E329294D1CC62ED255A60FEB216151414,
	TypeDescriptor_GetProperties_m05CFF294019C93C8ADC7433BB7D5D87F19DDE7FC,
	TypeDescriptor_GetProperties_mD2A9DF20F4E4373E7144791303ECB062973647FA,
	TypeDescriptor_GetPropertiesImpl_m0F204546AFC2CCED7979E08E0FF134D7084DC248,
	TypeDescriptor_GetProviderRecursive_mFA9FD212A625262784E9B1B05D3B82564B393877,
	TypeDescriptor_GetReflectionType_mB28D64FBA294D618334381A77DAE790811611C3D,
	TypeDescriptor_NodeFor_m767FF87E78839CA052D9BA45FC6E18BD28F8E2E2,
	TypeDescriptor_NodeFor_m47CC24E4CFA599136DD05F6DD9A72A4B309D0D90,
	TypeDescriptor_NodeFor_m5CD091DA5BF7D035FA36E6E397A96B2A9610E9D5,
	TypeDescriptor_NodeFor_m90ADBC22F629303B34247E6000724298EDDF3E61,
	TypeDescriptor_PipelineAttributeFilter_mDFD0C9F6114800954B3A9275EB4109520570307D,
	TypeDescriptor_PipelineFilter_m7522739B5B21B076A5722C659E9B17A404196487,
	TypeDescriptor_PipelineInitialize_mE238329E4034835777FC35289A14EA9A1397CF66,
	TypeDescriptor_PipelineMerge_m12CD63D0457BCA451AF9635E4E754A1E27122E65,
	TypeDescriptor_RaiseRefresh_m75708E2026685B087D03E5383F08E65F1608332C,
	TypeDescriptor_Refresh_m3EE0C2B17D9683C6C719C590D0D9744D16F58027,
	TypeDescriptor_ShouldHideMember_m7530A7627AB76EB292A22E86DA7D4B1A8DFEAF01,
	TypeDescriptor_SortDescriptorArray_mF1BF8FDE18108198B6E5CF6B31909A7F544F649C,
	TypeDescriptor__cctor_m93DDEDF2D6E089FEFA7A29B425C854E1E04E6145,
	AttributeFilterCacheItem__ctor_m8319ED63E0DDDB46F62ED8DBC04CCD530C477AAF,
	AttributeFilterCacheItem_IsValid_m0218A992CF2B98E84CD36A2C037F948A5DDB6BF9,
	FilterCacheItem__ctor_m9398DF7D02FBE4926AFB8D768F6F0936E0929181,
	FilterCacheItem_IsValid_m91C02B95AF49F2BD09314CF2EB67F6090052B8B4,
	MemberDescriptorComparer_Compare_m9C56C6E64A892DB13EEB4B1F551B6F161B4C237E,
	MemberDescriptorComparer__ctor_mE0D379E9AA3712B69614E48771226910DE517618,
	MemberDescriptorComparer__cctor_m9E4FF9CCCC93BEE24671FD459069CB7793ED97C6,
	MergedTypeDescriptor__ctor_m07BED02593A42C075C4F95B23D208CF1222C12A0,
	MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_m2DD60D9C133AE18F38D7A27189168A2FBF3729FD,
	MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mFC2AC7E8BEF7680E424A34D335EB4FCC9A6BACB6,
	MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m5C461A51153A91C829F3F75CC2E2D7AD2933BC69,
	MergedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m9C59F8E3A2F518EBBE770B6ABE66B82796B18F63,
	TypeDescriptionNode__ctor_m18D16A33443D7C6C32D09203AE94E5A5DA65BDFF,
	TypeDescriptionNode_GetCache_m275E9B8AA100455DA54B9CBD3581B9556C5DE825,
	TypeDescriptionNode_GetExtendedTypeDescriptor_m014DF481F410A49BBB0B087DD65EA4DBD51E9AF2,
	TypeDescriptionNode_GetExtenderProviders_mA26764DE3C998BCD030B9E111462EB622BB127BE,
	TypeDescriptionNode_GetReflectionType_m4C80319088CB3DFFEF76A5DB4C862FCDD98BDC92,
	TypeDescriptionNode_GetTypeDescriptor_m55BB50B1A0B0542BD4736FE3F7A14A7ABEC94903,
	DefaultExtendedTypeDescriptor__ctor_mD297D84C0AEF8C2AF0867391BD0FD037D8E6AB86_AdjustorThunk,
	DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_mF4C670B634C8C86057E939F3DD5EAA4173DAB1A8_AdjustorThunk,
	DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mE26BB774C31A0760EC238B30A3BDE0EE202EF1A6_AdjustorThunk,
	DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_mCD9AF5CF5F30A8A6F9125272F6AB969039A96DA7_AdjustorThunk,
	DefaultExtendedTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m46AE37DFC7FBE5AE7641AD20F09C09109313E2AC_AdjustorThunk,
	DefaultTypeDescriptor__ctor_m8542D50B70E1A86255B2C64908C9397B971BBC90_AdjustorThunk,
	DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetAttributes_m6EEBB8DB4E72761D9CB03978D149295CFE2B39EC_AdjustorThunk,
	DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetConverter_mA5D26F3E5D42548F740BD72B1AA9AE1CE89EC6E7_AdjustorThunk,
	DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_mE25AA0FCA6D4DAD1D1C671F258B3C9B23A9D3354_AdjustorThunk,
	DefaultTypeDescriptor_System_ComponentModel_ICustomTypeDescriptor_GetProperties_m45476E33EA6039C732EF799D4E95FAE74AD67B36_AdjustorThunk,
	UInt16Converter_get_TargetType_m09485223873376B5306CC41EE00DE41C7C9A4D48,
	UInt16Converter_FromString_m6C68C86307AAFB890294E95FAFEEC5558F898B7B,
	UInt16Converter_FromString_m086976C0A5AE966B1BF493EF9215D7CD5FA1E248,
	UInt16Converter_FromString_m33761AE9D171E9D4ADB9875D87F55FB078ACA9E9,
	UInt16Converter_ToString_m104A682B05A314790038B0F6C080A2242B813E62,
	UInt16Converter__ctor_m64B8902701F454D776E92A8373B7D0C923F7507D,
	UInt32Converter_get_TargetType_mB0970D9A54AF4DBB22763BCF302C1BF96987514D,
	UInt32Converter_FromString_mC2A923816231211450F8DE19A663F73CC32F9C23,
	UInt32Converter_FromString_m3311119AE44125DA0CF3703D93966E7D3B9A66A7,
	UInt32Converter_FromString_mC1772B9D65A03EF96521A527EFC9C1B55C353908,
	UInt32Converter_ToString_m19F6F8A0D732BA61405B020CF1D2A1EDF6847AA6,
	UInt32Converter__ctor_mAC512A9B15152E36517BFB4434889F79E154C60E,
	UInt64Converter_get_TargetType_mFDC942E31D697EB81B1BC6F2DC0C1984E5B4CDF2,
	UInt64Converter_FromString_m0F4D6141688C8C778E7B5CF3F38F8F2FDC88308C,
	UInt64Converter_FromString_m335C75F6E6840F7BF678CB73845C905C1216671C,
	UInt64Converter_FromString_m119E342F5A0A5553CB6A328DADFAFE509FCB72BC,
	UInt64Converter_ToString_mB2E701BBFDC1465555D4049C047FBEB8888E29D5,
	UInt64Converter__ctor_m90B1A912D739A0CB3C30A5BC466DB7A235FB1275,
	Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759,
	Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714,
	Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6,
	Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB,
	Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8,
	Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D,
	Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438,
	Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52,
	BaseNumberConverter_get_AllowHex_m994DD130AADA77ADA7E3AF7DF18674E617417CED,
	NULL,
	NULL,
	NULL,
	NULL,
	BaseNumberConverter_FromStringError_mF63BDCFB96540E83A867B6F206D2C453B9BB0A42,
	NULL,
	BaseNumberConverter_CanConvertFrom_mCAE77B4E99810F0C9B06FCB2F4F7036C733E3016,
	BaseNumberConverter_ConvertFrom_mA629768C8117947BD168EACC84D02DBA1FCA51E6,
	BaseNumberConverter_ConvertTo_m672375F1E58DB241E693E5F45A7FFD38C3070B6A,
	BaseNumberConverter_CanConvertTo_mBAA70FD6742A616F9E0F9E42908EF6C70C3214B7,
	BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83,
	WeakHashtable__ctor_mE6517A855F67EE9584AF60DB7BC3AF5B2D58C249,
	WeakHashtable_Clear_m0559384B1ED014495416A4CD76EE26A8CCBD9531,
	WeakHashtable_Remove_m6780AE4C0C4B072B9857C7A11ABC6AAF4805F9D3,
	WeakHashtable__cctor_m7EECB04C288887CC895D8ED91A837C7822A299CE,
	WeakKeyComparer_System_Collections_IEqualityComparer_Equals_mC3D733EAC828C7C1C1B8F0890B0CD86F67F3668C,
	WeakKeyComparer_System_Collections_IEqualityComparer_GetHashCode_m8A2DBF9E2E7D75717DF22C7CF88550E0502E2F98,
	WeakKeyComparer__ctor_m084512BBA20EA3050E018C920AF05AA43F1EC704,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	InstanceDescriptor__ctor_m90DA8CABB01052EA5C5022E14FE50533254C71DD,
	InstanceDescriptor__ctor_m47D0A6167384EA496F0734E951DECD7EE576CAC4,
	InstanceDescriptor_Invoke_mFA1E52E0F4971ABC4432D30F7CF80304272355C0,
	RootDesignerSerializerAttribute__ctor_m0F3B236B6A2362EEF20773BC3205FE7DA72AD6AE,
	RootDesignerSerializerAttribute_get_TypeId_mC34D430C36628B810BB11754EAD222F65805D2A7,
	Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743,
	Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC,
	Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985,
	Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079,
	Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05,
	Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F,
	OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800,
	OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C,
	OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9,
	OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2,
	OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30,
	OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9,
	OidCollection_get_SyncRoot_m6C13949F67338F684C29DD162C8228986DAB6850,
	OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797,
	OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53,
	OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D,
	OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E,
	CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698,
	CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB,
	AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6,
	AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6,
	AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC,
	AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC,
	AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7,
	AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7,
	AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07,
	AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182,
	AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058,
	AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590,
	AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76,
	AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49,
	AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4,
	X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2,
	X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950,
	PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F,
	PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F,
	PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE,
	PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC,
	X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C,
	X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729,
	X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780,
	X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F,
	X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42,
	X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F,
	X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC,
	X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81,
	X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF,
	X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336,
	X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2,
	X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A,
	X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D,
	X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818,
	X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384,
	X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2,
	X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4,
	X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02,
	X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A,
	X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99,
	X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018,
	X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426,
	X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505,
	X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F,
	X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB,
	X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2,
	X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360,
	X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC,
	X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29,
	X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6,
	X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B,
	X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432,
	X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3,
	X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1,
	X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF,
	X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC,
	X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC,
	X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38,
	X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B,
	X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1,
	X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD,
	X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA,
	EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776,
	IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748,
	IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84,
	IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D,
	IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9,
	IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF,
	IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6,
	IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678,
	IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C,
	IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA,
	IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk,
	IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C,
	IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk,
	IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk,
	SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3,
	SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA,
	SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A,
	SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071,
	SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378,
	BitVector32_get_Item_m00C3142256C406B075C4E364C03AC3A89E37A0CB_AdjustorThunk,
	BitVector32_set_Item_mA42604EC8406BCA63DEB3434E3F9D8D16742400C_AdjustorThunk,
	BitVector32_CreateMask_mF40475E10251217A893C1C396B80B4690A6245B2,
	BitVector32_CreateMask_mFE756231DB1A3377702CD31ED57BF6CBCB0487CD,
	BitVector32_Equals_m658488AB2FE6B6D71F9574CD29A92FAB17026C5A_AdjustorThunk,
	BitVector32_GetHashCode_m27DDA82E5461278F9ED05C032F604107E67C71C1_AdjustorThunk,
	BitVector32_ToString_m5580D76C2D5C86F0AEC8538762BCE520F3EDC731,
	BitVector32_ToString_m637FCCA35840D4ABED687F1FCDAE50AB8BC7B6D0_AdjustorThunk,
	HybridDictionary__ctor_m18ABDB797A0591DF595BBDD2A03F1670DDD07AA7,
	HybridDictionary__ctor_mBA75388EDF5456916408D7D3954B6873D50BA2F1,
	HybridDictionary_get_Item_mE16332A6CE6880D436633519FAC3662ED4A89E11,
	HybridDictionary_set_Item_mFFC14A7F4B45807D97503616AF98160061F6B9D3,
	HybridDictionary_get_List_mA5314524D5C411AFB165F07D860010DC0E11D28E,
	HybridDictionary_ChangeOver_m41ACD333E29ACCFF1C0CF45DF9E09E84EA28F173,
	HybridDictionary_get_Count_m170B942CEB7FA1B42BFFB246D72B583BD1397738,
	HybridDictionary_get_IsReadOnly_mB58FCC395C6CC8A569B0277DE6D0B02550E786E1,
	HybridDictionary_get_SyncRoot_m3A81A716ADC2A40444AF517E38EA943FDC72AB97,
	HybridDictionary_Add_m8022C90B2CAE2484ED0D740734EA4E512D8B130D,
	HybridDictionary_Clear_m9C53B8C32A090321B9D928B0F2B8ACDE1BA8591E,
	HybridDictionary_Contains_mF8C826101599A5F6EDB300954BD90FDEC4BCA6D6,
	HybridDictionary_CopyTo_m130965C0084284EE331912B40157958A1075E4A1,
	HybridDictionary_GetEnumerator_m02B2FC70ED4C2E91818DC8EAA3F3602B0DE81437,
	HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m4B6D49D2814E11C16C7005F84DFC58333BCBFAA0,
	HybridDictionary_Remove_mF87829C60C964F938DE42D453582712B726A2CD7,
	ListDictionary__ctor_mEB7BEC57F72A27168FCCE46DAC90CD5B8B7088A5,
	ListDictionary__ctor_mD1A7D146747D4E3AD93C261C1783CE34B10E48EC,
	ListDictionary_get_Item_m34D2DAE21AFFB6B1801EDE8A6998732CD9B45605,
	ListDictionary_set_Item_m89155730D3E404A1270CBDE7BEEC99138FBC64A0,
	ListDictionary_get_Count_m4CB9ACB21730241E566764AAB76B8B2A3D72418B,
	ListDictionary_get_IsReadOnly_mD2FC02FAB99A9FA7FA8A69F5CAB8E5887AAEC0CE,
	ListDictionary_get_SyncRoot_m58A889327021D843C7EB9171BD6B0D1E482C8BD7,
	ListDictionary_Add_m2204C61650D1B23A093627DF4D87009A7E3F9EDB,
	ListDictionary_Clear_m9D51C37F441D6390E7FF8B633EFD144F4771DB1E,
	ListDictionary_Contains_mA832E669186A7B91FF5819A535F8D394C963C508,
	ListDictionary_CopyTo_m9B1961C99A5B80996E42431630907C6BC02627A0,
	ListDictionary_GetEnumerator_m17E264D47385C88C7C366177CE8127CE933B0F9D,
	ListDictionary_System_Collections_IEnumerable_GetEnumerator_mF0DF8988C2CA6D5D493A61C502F20DA7879FA8E3,
	ListDictionary_Remove_m8CDD8E6A5B18DAC6446C1D93BADEB0A804AC9C5E,
	NodeEnumerator__ctor_m61652E6AF76A5460A6F4EA14BF97B982B7BB0261,
	NodeEnumerator_get_Current_m08DA3FD558CA771BD75B9C9A54FE681EDE668D25,
	NodeEnumerator_get_Entry_m5C0AAD879BADE3838D42B8525084C8C5DF96C56D,
	NodeEnumerator_get_Key_m83C059C6F52DE85B2E1605051400F3751534F8FF,
	NodeEnumerator_get_Value_m8532A492ECB3CE11B557109057E81DD2175070C7,
	NodeEnumerator_MoveNext_m111785D3C26CEB364566F3E517B3EB7528940552,
	NodeEnumerator_Reset_m66F3E60AB0A5AFCB3B3A8C37399B5357098BDD2E,
	DictionaryNode__ctor_m824EFE3D79F05D11FE0DE6FD5491D2FB1D382619,
	OrderedDictionary__ctor_mABFCC28E59BA806C34604B33877C1CEAD0AA9CE9,
	OrderedDictionary__ctor_m278F36318DAF73A39FB15CF0ED1439C36237C175,
	OrderedDictionary__ctor_mEE01676A6098C432B4981481099AE2C305E606F4,
	OrderedDictionary__ctor_mD73E278CB399AD723FEC465939C20D2AAE434B3E,
	OrderedDictionary_get_Count_m55F1F94E727BA49C8D94E7A7088D4C2E4B33605C,
	OrderedDictionary_get_IsReadOnly_mF9796A4518A4F291F1FF0BD4042F5077B75710A2,
	OrderedDictionary_get_objectsArray_m690618ABC6772FE7A565AC5BDF5EE2896EB83045,
	OrderedDictionary_get_objectsTable_m0D81CE869362587F2124DAB3CE393E902DBB9F80,
	OrderedDictionary_System_Collections_ICollection_get_SyncRoot_mFCD92778BDB71764F12583F9F27054EF6957CE42,
	OrderedDictionary_get_Item_m4BA1DD5702BF43A016E1785285DE53D4E9902E7B,
	OrderedDictionary_set_Item_mA8C71C7FD9354ABDCB0DBFB1977459680BD748BB,
	OrderedDictionary_get_Values_mF389293625F26A739573D543FB5E21FEC6BDAE13,
	OrderedDictionary_Add_mF2EC1AE8051D89FD384B7D8B25E03E8A1817BC19,
	OrderedDictionary_Clear_mBC338E68811632FEA7E12E1C8CB896A9D17D9D74,
	OrderedDictionary_Contains_m957B6F29E97A93AB5A0AF9272ED0AB65E4401EF1,
	OrderedDictionary_CopyTo_m6D7C307CED28372BFE59C365B4392EBCDE64CFE2,
	OrderedDictionary_IndexOfKey_m9CC5C8BCA6AEAED5821C6A8235DB9C90140291D2,
	OrderedDictionary_OnDeserialization_mC430F0CA656131C627EE2F1920749DD36A745357,
	OrderedDictionary_Remove_m32466C87EC2ED256642300B29B89101DD5227AA0,
	OrderedDictionary_GetEnumerator_mDFBC515FDE9C8A8AE56064C0655C19C3D130EB26,
	OrderedDictionary_System_Collections_IEnumerable_GetEnumerator_m47B64CD9FF588025B1C067C150670B2EA363CB29,
	OrderedDictionary_GetObjectData_m64EA42255566CF993C85C556897C5A73263AA5C6,
	OrderedDictionary_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1B07A96F704FCEDF5A1163E40C894FC77FA6EDDB,
	OrderedDictionaryEnumerator__ctor_m0C688CE7F033E4A145EBC003E5FAC145EC117265,
	OrderedDictionaryEnumerator_get_Current_m3D8DF89674C33D4DEA12463FEC53FCF1780ADE70,
	OrderedDictionaryEnumerator_get_Entry_m378B3659B18D635E114695226BDA8094AFC46E06,
	OrderedDictionaryEnumerator_get_Key_m536FA8AF2BBBED8E47FBF8A3467596654984FF25,
	OrderedDictionaryEnumerator_get_Value_m2199F649E120FDE587520D7DED478C7E0A764DDE,
	OrderedDictionaryEnumerator_MoveNext_m93D8BD7C91EFCCBFDD85BED6FF9130E957652CD1,
	OrderedDictionaryEnumerator_Reset_m6FC4640DE96193B4BD596C9476DD56E034A9440B,
	OrderedDictionaryKeyValueCollection__ctor_mD7596CC3855A371FF8EB8C05B3E886EC52F081BC,
	OrderedDictionaryKeyValueCollection_System_Collections_ICollection_CopyTo_mE81AE69E425015D650DB16850C8BA51D73E8320A,
	OrderedDictionaryKeyValueCollection_System_Collections_ICollection_get_Count_m247949B9D6061A309DACDD9CB1D8982C0AAE4E0C,
	OrderedDictionaryKeyValueCollection_System_Collections_ICollection_get_SyncRoot_m2415812982AE4651AE467053E83243522CE5F979,
	OrderedDictionaryKeyValueCollection_System_Collections_IEnumerable_GetEnumerator_m0A5A85B1101591DE72343805CD5F1DE725DC0D04,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874,
	BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A,
	ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B,
	ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4,
	ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19,
	DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6,
	DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555,
	DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276,
	ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC,
	ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377,
	HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233,
	HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C,
	Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965,
	Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC,
	NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269,
	SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005,
	SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254,
	PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083,
	PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0,
	ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7,
	ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677,
	SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3,
	SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A,
	WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591,
	WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26,
	WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02,
	WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44,
	WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961,
	DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0,
	DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96,
	ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD,
};
static const int32_t s_InvokerIndices[1461] = 
{
	1,
	2,
	0,
	1,
	2,
	122,
	94,
	0,
	178,
	543,
	1038,
	23,
	41,
	3,
	1039,
	1040,
	1041,
	1042,
	114,
	114,
	114,
	114,
	142,
	14,
	114,
	94,
	114,
	1043,
	9,
	114,
	23,
	212,
	408,
	408,
	1044,
	1044,
	14,
	23,
	31,
	26,
	136,
	27,
	110,
	27,
	1045,
	43,
	171,
	171,
	171,
	14,
	14,
	14,
	114,
	114,
	14,
	114,
	94,
	4,
	3,
	10,
	14,
	14,
	114,
	14,
	14,
	114,
	114,
	48,
	48,
	203,
	10,
	14,
	111,
	111,
	9,
	1046,
	14,
	10,
	891,
	172,
	23,
	1047,
	23,
	160,
	34,
	160,
	1048,
	34,
	23,
	1049,
	1050,
	1051,
	1052,
	1053,
	1054,
	1055,
	1056,
	1057,
	1058,
	1059,
	1060,
	95,
	528,
	48,
	48,
	48,
	48,
	1061,
	1062,
	805,
	9,
	9,
	9,
	395,
	160,
	0,
	59,
	895,
	1063,
	1064,
	34,
	160,
	26,
	3,
	23,
	23,
	23,
	26,
	171,
	171,
	1065,
	1066,
	1067,
	1068,
	1069,
	1070,
	1071,
	48,
	48,
	48,
	48,
	3,
	14,
	10,
	14,
	609,
	663,
	54,
	49,
	3,
	10,
	30,
	30,
	30,
	52,
	32,
	0,
	114,
	14,
	609,
	663,
	54,
	35,
	1072,
	1073,
	1073,
	1074,
	1074,
	209,
	366,
	1075,
	1074,
	1076,
	1076,
	1072,
	559,
	1077,
	1078,
	1079,
	1080,
	1080,
	1081,
	88,
	1082,
	356,
	1083,
	360,
	1084,
	1072,
	1085,
	102,
	26,
	177,
	26,
	23,
	9,
	115,
	115,
	177,
	213,
	23,
	26,
	136,
	1086,
	171,
	171,
	944,
	943,
	0,
	10,
	288,
	114,
	14,
	111,
	1087,
	9,
	387,
	28,
	58,
	23,
	1088,
	0,
	28,
	114,
	114,
	3,
	1089,
	14,
	26,
	23,
	23,
	1090,
	387,
	1091,
	479,
	14,
	35,
	14,
	14,
	23,
	3,
	23,
	1092,
	114,
	31,
	582,
	26,
	26,
	26,
	1093,
	1090,
	26,
	26,
	1094,
	42,
	42,
	1095,
	206,
	94,
	94,
	94,
	94,
	94,
	94,
	48,
	48,
	1096,
	1097,
	1098,
	1098,
	1099,
	0,
	0,
	164,
	10,
	14,
	34,
	23,
	1100,
	1101,
	41,
	23,
	1093,
	1102,
	46,
	0,
	0,
	95,
	21,
	23,
	32,
	114,
	10,
	26,
	114,
	14,
	14,
	28,
	23,
	774,
	31,
	1103,
	783,
	450,
	28,
	114,
	428,
	14,
	114,
	4,
	3,
	1104,
	114,
	3,
	23,
	27,
	23,
	23,
	32,
	32,
	32,
	32,
	10,
	10,
	10,
	23,
	32,
	169,
	38,
	32,
	169,
	23,
	32,
	23,
	32,
	10,
	37,
	32,
	169,
	23,
	32,
	10,
	37,
	10,
	37,
	10,
	10,
	10,
	10,
	212,
	9,
	52,
	23,
	392,
	114,
	23,
	4,
	1105,
	1106,
	38,
	32,
	32,
	30,
	37,
	37,
	32,
	3,
	23,
	1107,
	1108,
	23,
	171,
	171,
	23,
	1108,
	169,
	1109,
	591,
	38,
	311,
	114,
	14,
	38,
	14,
	34,
	14,
	14,
	14,
	14,
	14,
	1110,
	26,
	34,
	10,
	10,
	164,
	0,
	26,
	26,
	32,
	14,
	339,
	340,
	14,
	23,
	14,
	14,
	14,
	212,
	10,
	392,
	203,
	212,
	30,
	23,
	212,
	14,
	205,
	203,
	23,
	169,
	136,
	23,
	116,
	30,
	9,
	114,
	114,
	114,
	114,
	114,
	114,
	48,
	48,
	48,
	114,
	48,
	1111,
	23,
	23,
	114,
	26,
	23,
	23,
	1112,
	14,
	582,
	582,
	26,
	26,
	32,
	23,
	23,
	23,
	114,
	23,
	28,
	10,
	32,
	212,
	23,
	32,
	23,
	392,
	212,
	392,
	10,
	3,
	23,
	1113,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	339,
	23,
	746,
	746,
	23,
	23,
	23,
	32,
	10,
	10,
	38,
	311,
	23,
	30,
	37,
	37,
	14,
	1114,
	0,
	23,
	32,
	114,
	10,
	10,
	169,
	32,
	169,
	38,
	116,
	28,
	37,
	28,
	774,
	27,
	27,
	168,
	3,
	3,
	26,
	26,
	27,
	118,
	23,
	288,
	142,
	142,
	23,
	3,
	213,
	177,
	9,
	23,
	627,
	136,
	114,
	23,
	14,
	26,
	14,
	10,
	28,
	9,
	28,
	14,
	10,
	14,
	136,
	14,
	3,
	14,
	14,
	115,
	177,
	28,
	9,
	9,
	23,
	31,
	114,
	9,
	10,
	114,
	3,
	14,
	58,
	113,
	113,
	113,
	23,
	115,
	213,
	177,
	23,
	213,
	177,
	9,
	23,
	28,
	26,
	177,
	9,
	14,
	28,
	115,
	115,
	177,
	213,
	28,
	9,
	9,
	23,
	26,
	41,
	0,
	3,
	23,
	14,
	14,
	14,
	28,
	115,
	115,
	177,
	213,
	23,
	114,
	14,
	115,
	213,
	58,
	113,
	113,
	113,
	23,
	14,
	26,
	14,
	28,
	28,
	28,
	113,
	113,
	23,
	26,
	14,
	14,
	9,
	10,
	114,
	3,
	31,
	114,
	114,
	9,
	10,
	3,
	27,
	14,
	9,
	10,
	23,
	26,
	14,
	14,
	9,
	10,
	114,
	3,
	114,
	14,
	58,
	113,
	113,
	113,
	23,
	32,
	9,
	10,
	26,
	14,
	14,
	26,
	115,
	115,
	14,
	177,
	213,
	28,
	9,
	9,
	115,
	26,
	428,
	10,
	34,
	116,
	23,
	9,
	136,
	23,
	32,
	116,
	62,
	26,
	32,
	14,
	26,
	26,
	10,
	14,
	14,
	34,
	62,
	116,
	23,
	9,
	116,
	62,
	26,
	32,
	114,
	114,
	3,
	23,
	177,
	9,
	415,
	14,
	114,
	14,
	14,
	2,
	23,
	14,
	14,
	9,
	10,
	114,
	14,
	14,
	14,
	14,
	14,
	28,
	9,
	14,
	14,
	14,
	14,
	58,
	113,
	113,
	113,
	23,
	14,
	58,
	113,
	113,
	113,
	23,
	14,
	58,
	113,
	113,
	113,
	23,
	27,
	27,
	14,
	26,
	14,
	14,
	10,
	14,
	23,
	14,
	9,
	26,
	23,
	326,
	1115,
	10,
	0,
	26,
	115,
	177,
	115,
	213,
	113,
	9,
	177,
	9,
	28,
	9,
	9,
	115,
	14,
	14,
	14,
	26,
	102,
	27,
	213,
	26,
	27,
	27,
	14,
	114,
	14,
	9,
	26,
	10,
	26,
	428,
	1116,
	10,
	34,
	28,
	116,
	23,
	9,
	136,
	23,
	32,
	112,
	116,
	62,
	26,
	32,
	28,
	26,
	26,
	14,
	10,
	14,
	27,
	23,
	9,
	14,
	114,
	28,
	27,
	26,
	14,
	116,
	23,
	9,
	116,
	62,
	114,
	114,
	26,
	32,
	34,
	62,
	3,
	26,
	14,
	668,
	14,
	14,
	114,
	23,
	14,
	14,
	31,
	114,
	9,
	10,
	114,
	3,
	26,
	115,
	177,
	213,
	28,
	9,
	9,
	115,
	3,
	26,
	41,
	415,
	927,
	927,
	14,
	114,
	114,
	14,
	14,
	14,
	28,
	26,
	3,
	23,
	4,
	1,
	28,
	28,
	113,
	28,
	28,
	28,
	28,
	2,
	28,
	28,
	113,
	112,
	113,
	0,
	9,
	0,
	0,
	0,
	0,
	26,
	1,
	3,
	26,
	114,
	14,
	28,
	14,
	28,
	23,
	26,
	102,
	26,
	177,
	26,
	14,
	58,
	113,
	113,
	113,
	23,
	114,
	14,
	58,
	113,
	113,
	113,
	23,
	115,
	177,
	23,
	115,
	115,
	177,
	213,
	23,
	49,
	9,
	115,
	9,
	115,
	28,
	177,
	28,
	113,
	28,
	113,
	177,
	113,
	213,
	28,
	113,
	28,
	113,
	177,
	28,
	113,
	28,
	113,
	114,
	9,
	28,
	113,
	177,
	114,
	9,
	14,
	28,
	114,
	9,
	114,
	9,
	9,
	115,
	113,
	23,
	3,
	415,
	14,
	114,
	14,
	26,
	10,
	136,
	14,
	10,
	14,
	136,
	14,
	23,
	26,
	14,
	9,
	10,
	3,
	23,
	28,
	28,
	28,
	28,
	113,
	28,
	28,
	113,
	23,
	26,
	14,
	4,
	4,
	131,
	134,
	122,
	1,
	0,
	0,
	121,
	0,
	0,
	1,
	121,
	0,
	0,
	0,
	1,
	178,
	1117,
	0,
	0,
	0,
	121,
	0,
	121,
	1118,
	556,
	418,
	1118,
	122,
	122,
	111,
	122,
	3,
	27,
	9,
	27,
	9,
	41,
	23,
	3,
	27,
	14,
	14,
	14,
	28,
	26,
	28,
	28,
	28,
	113,
	113,
	27,
	14,
	14,
	14,
	28,
	168,
	14,
	14,
	14,
	28,
	14,
	58,
	113,
	113,
	113,
	23,
	14,
	58,
	113,
	113,
	113,
	23,
	14,
	58,
	113,
	113,
	113,
	23,
	23,
	32,
	62,
	171,
	171,
	43,
	3,
	3,
	114,
	14,
	58,
	113,
	113,
	113,
	113,
	115,
	177,
	213,
	115,
	23,
	23,
	23,
	26,
	3,
	115,
	116,
	23,
	28,
	27,
	14,
	28,
	28,
	28,
	115,
	115,
	115,
	27,
	110,
	14,
	110,
	14,
	26,
	329,
	27,
	26,
	14,
	26,
	23,
	116,
	34,
	10,
	14,
	136,
	14,
	26,
	14,
	114,
	23,
	164,
	164,
	23,
	26,
	14,
	26,
	26,
	339,
	339,
	339,
	339,
	339,
	339,
	339,
	339,
	1119,
	1119,
	14,
	14,
	14,
	3,
	23,
	428,
	1120,
	114,
	114,
	10,
	26,
	116,
	14,
	339,
	428,
	26,
	116,
	339,
	23,
	114,
	31,
	26,
	28,
	23,
	428,
	613,
	10,
	26,
	37,
	116,
	14,
	339,
	23,
	428,
	428,
	428,
	428,
	329,
	14,
	26,
	48,
	210,
	0,
	116,
	14,
	339,
	23,
	172,
	141,
	32,
	142,
	14,
	450,
	9,
	10,
	3,
	141,
	208,
	10,
	114,
	114,
	14,
	131,
	23,
	32,
	171,
	14,
	30,
	613,
	131,
	21,
	9,
	10,
	1121,
	14,
	23,
	31,
	28,
	27,
	14,
	23,
	10,
	114,
	14,
	27,
	23,
	9,
	136,
	14,
	14,
	26,
	23,
	26,
	28,
	27,
	10,
	114,
	14,
	27,
	23,
	9,
	136,
	14,
	14,
	26,
	26,
	14,
	668,
	14,
	14,
	114,
	23,
	23,
	23,
	32,
	62,
	171,
	10,
	114,
	14,
	14,
	14,
	28,
	27,
	14,
	27,
	23,
	9,
	136,
	116,
	26,
	26,
	14,
	14,
	171,
	26,
	136,
	14,
	668,
	14,
	14,
	114,
	23,
	428,
	136,
	10,
	14,
	14,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	95,
	23,
	23,
	23,
	14,
	23,
	14,
	26,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	177,
	3,
};
static const Il2CppTokenRangePair s_rgctxIndices[8] = 
{
	{ 0x020000C6, { 0, 23 } },
	{ 0x020000C7, { 23, 2 } },
	{ 0x020000C9, { 25, 41 } },
	{ 0x020000CA, { 66, 5 } },
	{ 0x020000CB, { 71, 2 } },
	{ 0x020000CD, { 73, 6 } },
	{ 0x020000CE, { 79, 6 } },
	{ 0x020000CF, { 85, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[88] = 
{
	{ (Il2CppRGCTXDataType)3, 20369 },
	{ (Il2CppRGCTXDataType)2, 17743 },
	{ (Il2CppRGCTXDataType)3, 20370 },
	{ (Il2CppRGCTXDataType)3, 20371 },
	{ (Il2CppRGCTXDataType)3, 20372 },
	{ (Il2CppRGCTXDataType)3, 20373 },
	{ (Il2CppRGCTXDataType)3, 20374 },
	{ (Il2CppRGCTXDataType)3, 20375 },
	{ (Il2CppRGCTXDataType)3, 20376 },
	{ (Il2CppRGCTXDataType)3, 20377 },
	{ (Il2CppRGCTXDataType)3, 20378 },
	{ (Il2CppRGCTXDataType)2, 24084 },
	{ (Il2CppRGCTXDataType)2, 17744 },
	{ (Il2CppRGCTXDataType)3, 20379 },
	{ (Il2CppRGCTXDataType)2, 17746 },
	{ (Il2CppRGCTXDataType)3, 20380 },
	{ (Il2CppRGCTXDataType)3, 20381 },
	{ (Il2CppRGCTXDataType)3, 20382 },
	{ (Il2CppRGCTXDataType)3, 20383 },
	{ (Il2CppRGCTXDataType)2, 17745 },
	{ (Il2CppRGCTXDataType)3, 20384 },
	{ (Il2CppRGCTXDataType)1, 17745 },
	{ (Il2CppRGCTXDataType)2, 17745 },
	{ (Il2CppRGCTXDataType)3, 20385 },
	{ (Il2CppRGCTXDataType)2, 17752 },
	{ (Il2CppRGCTXDataType)3, 20386 },
	{ (Il2CppRGCTXDataType)3, 20387 },
	{ (Il2CppRGCTXDataType)3, 20388 },
	{ (Il2CppRGCTXDataType)2, 24085 },
	{ (Il2CppRGCTXDataType)3, 20389 },
	{ (Il2CppRGCTXDataType)2, 17773 },
	{ (Il2CppRGCTXDataType)3, 20390 },
	{ (Il2CppRGCTXDataType)3, 20391 },
	{ (Il2CppRGCTXDataType)3, 20392 },
	{ (Il2CppRGCTXDataType)3, 20393 },
	{ (Il2CppRGCTXDataType)3, 20394 },
	{ (Il2CppRGCTXDataType)3, 20395 },
	{ (Il2CppRGCTXDataType)3, 20396 },
	{ (Il2CppRGCTXDataType)2, 24086 },
	{ (Il2CppRGCTXDataType)3, 20397 },
	{ (Il2CppRGCTXDataType)3, 20398 },
	{ (Il2CppRGCTXDataType)2, 24087 },
	{ (Il2CppRGCTXDataType)2, 24088 },
	{ (Il2CppRGCTXDataType)2, 17774 },
	{ (Il2CppRGCTXDataType)1, 17773 },
	{ (Il2CppRGCTXDataType)1, 17774 },
	{ (Il2CppRGCTXDataType)3, 20399 },
	{ (Il2CppRGCTXDataType)2, 17777 },
	{ (Il2CppRGCTXDataType)3, 20400 },
	{ (Il2CppRGCTXDataType)3, 20401 },
	{ (Il2CppRGCTXDataType)3, 20402 },
	{ (Il2CppRGCTXDataType)3, 20403 },
	{ (Il2CppRGCTXDataType)2, 24089 },
	{ (Il2CppRGCTXDataType)3, 20404 },
	{ (Il2CppRGCTXDataType)3, 20405 },
	{ (Il2CppRGCTXDataType)3, 20406 },
	{ (Il2CppRGCTXDataType)3, 20407 },
	{ (Il2CppRGCTXDataType)2, 17778 },
	{ (Il2CppRGCTXDataType)2, 17775 },
	{ (Il2CppRGCTXDataType)3, 20408 },
	{ (Il2CppRGCTXDataType)2, 24090 },
	{ (Il2CppRGCTXDataType)3, 20409 },
	{ (Il2CppRGCTXDataType)3, 20410 },
	{ (Il2CppRGCTXDataType)3, 20411 },
	{ (Il2CppRGCTXDataType)3, 20412 },
	{ (Il2CppRGCTXDataType)3, 20413 },
	{ (Il2CppRGCTXDataType)3, 20414 },
	{ (Il2CppRGCTXDataType)2, 17789 },
	{ (Il2CppRGCTXDataType)2, 17790 },
	{ (Il2CppRGCTXDataType)2, 17791 },
	{ (Il2CppRGCTXDataType)3, 20415 },
	{ (Il2CppRGCTXDataType)3, 20416 },
	{ (Il2CppRGCTXDataType)2, 17800 },
	{ (Il2CppRGCTXDataType)3, 20417 },
	{ (Il2CppRGCTXDataType)3, 20418 },
	{ (Il2CppRGCTXDataType)3, 20419 },
	{ (Il2CppRGCTXDataType)2, 24091 },
	{ (Il2CppRGCTXDataType)3, 20420 },
	{ (Il2CppRGCTXDataType)3, 20421 },
	{ (Il2CppRGCTXDataType)3, 20422 },
	{ (Il2CppRGCTXDataType)2, 24092 },
	{ (Il2CppRGCTXDataType)3, 20423 },
	{ (Il2CppRGCTXDataType)3, 20424 },
	{ (Il2CppRGCTXDataType)3, 20425 },
	{ (Il2CppRGCTXDataType)3, 20426 },
	{ (Il2CppRGCTXDataType)3, 20427 },
	{ (Il2CppRGCTXDataType)3, 20428 },
	{ (Il2CppRGCTXDataType)2, 17834 },
};
extern const Il2CppCodeGenModule g_SystemCodeGenModule;
const Il2CppCodeGenModule g_SystemCodeGenModule = 
{
	"System.dll",
	1461,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	8,
	s_rgctxIndices,
	88,
	s_rgctxValues,
	NULL,
};
