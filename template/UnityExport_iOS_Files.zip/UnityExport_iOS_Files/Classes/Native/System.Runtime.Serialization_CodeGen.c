﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Boolean System.Runtime.Serialization.DataContractAttribute::get_IsReference()
extern void DataContractAttribute_get_IsReference_m585BCAC661A23A9D652CBB1A143A1A05EC982954 ();
// 0x00000002 System.String System.Runtime.Serialization.DataMemberAttribute::get_Name()
extern void DataMemberAttribute_get_Name_mA626FA1D50DB99B87C7EB674B93622431E14F973 ();
// 0x00000003 System.Int32 System.Runtime.Serialization.DataMemberAttribute::get_Order()
extern void DataMemberAttribute_get_Order_m1A3ADBDD919D8B3CECEDB183C5F8567F76CC9632 ();
// 0x00000004 System.Boolean System.Runtime.Serialization.DataMemberAttribute::get_IsRequired()
extern void DataMemberAttribute_get_IsRequired_m03BFAD34E0B734E253D49357A981D360B21CCEFA ();
// 0x00000005 System.Boolean System.Runtime.Serialization.DataMemberAttribute::get_EmitDefaultValue()
extern void DataMemberAttribute_get_EmitDefaultValue_mDFB2F1161572605FA84B4BD480360965FFB4DC9D ();
// 0x00000006 System.String System.Runtime.Serialization.EnumMemberAttribute::get_Value()
extern void EnumMemberAttribute_get_Value_mAEC018F5DF3B080413117FD31F8B87AEFBDA30F8 ();
static Il2CppMethodPointer s_methodPointers[6] = 
{
	DataContractAttribute_get_IsReference_m585BCAC661A23A9D652CBB1A143A1A05EC982954,
	DataMemberAttribute_get_Name_mA626FA1D50DB99B87C7EB674B93622431E14F973,
	DataMemberAttribute_get_Order_m1A3ADBDD919D8B3CECEDB183C5F8567F76CC9632,
	DataMemberAttribute_get_IsRequired_m03BFAD34E0B734E253D49357A981D360B21CCEFA,
	DataMemberAttribute_get_EmitDefaultValue_mDFB2F1161572605FA84B4BD480360965FFB4DC9D,
	EnumMemberAttribute_get_Value_mAEC018F5DF3B080413117FD31F8B87AEFBDA30F8,
};
static const int32_t s_InvokerIndices[6] = 
{
	114,
	14,
	10,
	114,
	114,
	14,
};
extern const Il2CppCodeGenModule g_System_Runtime_SerializationCodeGenModule;
const Il2CppCodeGenModule g_System_Runtime_SerializationCodeGenModule = 
{
	"System.Runtime.Serialization.dll",
	6,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
